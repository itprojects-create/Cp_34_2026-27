/**
 * Facial Views Configuration
 * 
 * Defines the 8 standardized facial photography views with validation parameters.
 * These configurations are used by both the backend and Python CV service.
 */

const FACIAL_VIEWS = {
  frontal_neutral: {
    id: 'frontal_neutral',
    name: 'Frontal — Neutral',
    description: 'Face directly forward with neutral expression',
    targetYaw: 0,
    targetPitch: 0,
    targetRoll: 0,
    yawTolerance: 10,
    pitchTolerance: 10,
    rollTolerance: 10,
    requiresNeutralExpression: true,
    icon: '😐',
    guidelines: [
      'Look directly at the camera',
      'Keep head level',
      'Maintain neutral expression',
      'Ensure face is centered'
    ]
  },
  frontal_smiling: {
    id: 'frontal_smiling',
    name: 'Frontal — Smiling',
    description: 'Face directly forward with natural smile',
    targetYaw: 0,
    targetPitch: 0,
    targetRoll: 0,
    yawTolerance: 10,
    pitchTolerance: 10,
    rollTolerance: 10,
    requiresNeutralExpression: false,
    icon: '😊',
    guidelines: [
      'Look directly at the camera',
      'Keep head level',
      'Show natural smile',
      'Ensure face is centered'
    ]
  },
  right_oblique_45: {
    id: 'right_oblique_45',
    name: 'Right Oblique — 45°',
    description: 'Face turned 45° to the right',
    targetYaw: 45,
    targetPitch: 0,
    targetRoll: 0,
    yawTolerance: 10,
    pitchTolerance: 10,
    rollTolerance: 10,
    requiresNeutralExpression: true,
    icon: '↗️',
    guidelines: [
      'Turn face 45° to the right',
      'Keep head level',
      'Maintain neutral expression',
      'Look straight ahead (not at camera)'
    ]
  },
  left_oblique_45: {
    id: 'left_oblique_45',
    name: 'Left Oblique — 45°',
    description: 'Face turned 45° to the left',
    targetYaw: -45,
    targetPitch: 0,
    targetRoll: 0,
    yawTolerance: 10,
    pitchTolerance: 10,
    rollTolerance: 10,
    requiresNeutralExpression: true,
    icon: '↖️',
    guidelines: [
      'Turn face 45° to the left',
      'Keep head level',
      'Maintain neutral expression',
      'Look straight ahead (not at camera)'
    ]
  },
  right_lateral: {
    id: 'right_lateral',
    name: 'Right Lateral — Profile',
    description: 'Full right profile view',
    targetYaw: 90,
    targetPitch: 0,
    targetRoll: 0,
    yawTolerance: 10,
    pitchTolerance: 10,
    rollTolerance: 10,
    requiresNeutralExpression: true,
    icon: '➡️',
    guidelines: [
      'Turn face 90° to the right (full profile)',
      'Keep head level',
      'Maintain neutral expression',
      'Look straight ahead'
    ]
  },
  left_lateral: {
    id: 'left_lateral',
    name: 'Left Lateral — Profile',
    description: 'Full left profile view',
    targetYaw: -90,
    targetPitch: 0,
    targetRoll: 0,
    yawTolerance: 10,
    pitchTolerance: 10,
    rollTolerance: 10,
    requiresNeutralExpression: true,
    icon: '⬅️',
    guidelines: [
      'Turn face 90° to the left (full profile)',
      'Keep head level',
      'Maintain neutral expression',
      'Look straight ahead'
    ]
  },
  basal: {
    id: 'basal',
    name: 'Basal — Worm\'s-Eye',
    description: 'View from below, chin tilted up',
    targetYaw: 0,
    targetPitch: -30, // Negative = looking up
    targetRoll: 0,
    yawTolerance: 10,
    pitchTolerance: 15,
    rollTolerance: 10,
    requiresNeutralExpression: true,
    icon: '⬆️',
    guidelines: [
      'Tilt head back 30°',
      'Keep face forward',
      'Camera positioned below chin level',
      'Maintain neutral expression'
    ]
  },
  top: {
    id: 'top',
    name: 'Top — Bird\'s-Eye',
    description: 'View from above, head tilted down',
    targetYaw: 0,
    targetPitch: 30, // Positive = looking down
    targetRoll: 0,
    yawTolerance: 10,
    pitchTolerance: 15,
    rollTolerance: 10,
    requiresNeutralExpression: true,
    icon: '⬇️',
    guidelines: [
      'Tilt head forward 30°',
      'Keep face forward',
      'Camera positioned above forehead level',
      'Maintain neutral expression'
    ]
  }
};

const TREATMENT_STAGES = [
  { id: 'pre_surgery', name: 'Pre-Surgery', order: 1 },
  { id: 'post_surgery', name: 'Post-Surgery', order: 2 },
  { id: 'follow_up_1', name: 'Follow-Up 1', order: 3 },
  { id: 'follow_up_2', name: 'Follow-Up 2', order: 4 },
  { id: 'follow_up_3', name: 'Follow-Up 3', order: 5 },
  { id: 'follow_up_4', name: 'Follow-Up 4', order: 6 },
  { id: 'follow_up_5', name: 'Follow-Up 5', order: 7 },
  { id: 'additional_follow_up', name: 'Additional Follow-Up', order: 8 }
];

const PROCEDURE_TYPES = [
  'Rhinoplasty',
  'Blepharoplasty',
  'Facelift',
  'Brow Lift',
  'Cheek Augmentation',
  'Chin Augmentation',
  'Lip Enhancement',
  'Otoplasty',
  'Scar Revision',
  'Other'
];

/**
 * Validate if a facial view ID is valid
 */
const VIEW_ALIASES = { FRONT: 'frontal_neutral', RIGHT_OBLIQUE: 'right_oblique_45', LEFT_OBLIQUE: 'left_oblique_45',
  RIGHT_LATERAL: 'right_lateral', LEFT_LATERAL: 'left_lateral', BASAL: 'basal',
  right_oblique: 'right_oblique_45', left_oblique: 'left_oblique_45', worms_view: 'basal' };
function canonicalView(viewId) { return Object.hasOwn(VIEW_ALIASES, viewId) ? VIEW_ALIASES[viewId] : viewId; }
function isValidFacialView(viewId) {
  return Object.hasOwn(FACIAL_VIEWS, viewId);
}

/**
 * Validate if a treatment stage is valid
 */
function isValidTreatmentStage(stage) {
  return TREATMENT_STAGES.some(s => s.id === stage || s.name === stage);
}

/**
 * Get facial view configuration by ID
 */
function getFacialView(viewId) {
  return FACIAL_VIEWS[viewId] || null;
}

/**
 * Get all facial views as array
 */
function getAllFacialViews() {
  return Object.values(FACIAL_VIEWS);
}

/**
 * Get all treatment stages
 */
function getAllTreatmentStages() {
  return TREATMENT_STAGES;
}

/**
 * Get all procedure types
 */
function getAllProcedureTypes() {
  return PROCEDURE_TYPES;
}

module.exports = {
  canonicalView,
  FACIAL_VIEWS,
  TREATMENT_STAGES,
  PROCEDURE_TYPES,
  isValidFacialView,
  isValidTreatmentStage,
  getFacialView,
  getAllFacialViews,
  getAllTreatmentStages,
  getAllProcedureTypes
};
