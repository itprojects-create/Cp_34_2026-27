const fs = require('node:fs/promises');
const path = require('node:path');
const { BASE_UPLOAD_DIR } = require('../services/localPhotoStorageService');
module.exports = (req, res, next) => {
  res.on('finish', () => {
    const entry = { at: new Date().toISOString(), actor: null, authentication: 'deferred', method: req.method,
      route: req.route?.path || req.path, photo_id: req.params.id || null, status: res.statusCode };
    fs.mkdir(BASE_UPLOAD_DIR, { recursive: true, mode: 0o700 })
      .then(() => fs.appendFile(path.join(BASE_UPLOAD_DIR, 'access-audit.jsonl'), JSON.stringify(entry)+'\n', { mode: 0o600 }))
      .catch(() => console.error('Photo audit write failed'));
  });
  next();
};
