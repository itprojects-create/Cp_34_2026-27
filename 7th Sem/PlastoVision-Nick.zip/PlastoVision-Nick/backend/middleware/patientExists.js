const { supabaseAdmin } = require('../config/supabase');

// Referential integrity only; authentication is deferred for local development.
const verifyPatientExists = (parameter = 'patientId') => async (req, res, next) => {
  try {
    const id = req.params[parameter] || req.body[parameter];
    const { data, error } = await supabaseAdmin.from('patients').select('id').eq('id', id).maybeSingle();
    if (error || !data) return res.status(404).json({ error: 'Patient not found' });
    next();
  } catch { res.status(503).json({ error: 'Could not verify patient' }); }
};
module.exports = { verifyPatientExists };
