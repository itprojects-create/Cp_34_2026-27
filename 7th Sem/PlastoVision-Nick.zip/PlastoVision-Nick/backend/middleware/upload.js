/**
 * Multer Configuration for Photo Uploads
 * 
 * Handles file upload validation and storage configuration.
 * Security measures:
 * - File type validation
 * - File size limits
 * - Filename sanitization
 * - MIME type verification
 */

const multer = require('multer');
const path = require('path');
const { randomUUID: uuidv4 } = require('node:crypto');

// Maximum file size (10MB by default)
const MAX_FILE_SIZE = (parseInt(process.env.MAX_FILE_SIZE_MB) || 10) * 1024 * 1024;

// Allowed MIME types
const ALLOWED_MIME_TYPES = process.env.ALLOWED_MIME_TYPES 
  ? process.env.ALLOWED_MIME_TYPES.split(',')
  : ['image/jpeg', 'image/jpg', 'image/png'];

/**
 * File filter function
 * Validates MIME type and file extension
 */
function fileFilter(req, file, cb) {
  // Check MIME type
  if (!ALLOWED_MIME_TYPES.includes(file.mimetype)) {
    const error = new Error(
      `Invalid file type. Allowed types: ${ALLOWED_MIME_TYPES.join(', ')}`
    );
    error.code = 'INVALID_FILE_TYPE';
    return cb(error, false);
  }
  
  // Check file extension
  const ext = path.extname(file.originalname).toLowerCase();
  const allowedExtensions = ['.jpg', '.jpeg', '.png'];
  
  if (!allowedExtensions.includes(ext)) {
    const error = new Error(
      `Invalid file extension. Allowed extensions: ${allowedExtensions.join(', ')}`
    );
    error.code = 'INVALID_FILE_EXTENSION';
    return cb(error, false);
  }
  
  cb(null, true);
}

/**
 * Storage configuration
 * Uses memory storage so we can validate before saving to disk
 */
const storage = multer.memoryStorage();

/**
 * Multer instance for photo uploads
 */
const upload = multer({
  storage: storage,
  limits: {
    fileSize: MAX_FILE_SIZE,
    files: 1 // Only one file per upload
  },
  fileFilter: fileFilter
});

/**
 * Middleware for single photo upload
 */
const uploadSingle = upload.single('photo');

/**
 * Sanitize filename
 * Removes special characters and ensures safe filename
 */
function sanitizeFilename(filename) {
  // Remove path traversal attempts
  const basename = path.basename(filename);
  
  // Remove special characters except dots, hyphens, and underscores
  const sanitized = basename
    .replace(/[^a-zA-Z0-9._-]/g, '_')
    .replace(/_{2,}/g, '_')
    .toLowerCase();
  
  return sanitized;
}

/**
 * Generate unique filename
 * Format: photo_{timestamp}_{uuid}.{ext}
 */
function generateUniqueFilename(originalFilename) {
  const ext = path.extname(originalFilename).toLowerCase();
  const timestamp = Date.now();
  const uniqueId = uuidv4().split('-')[0]; // Use first segment of UUID
  
  return `photo_${timestamp}_${uniqueId}${ext}`;
}

/**
 * Get file extension from MIME type
 */
function getExtensionFromMimeType(mimeType) {
  const mimeMap = {
    'image/jpeg': '.jpg',
    'image/jpg': '.jpg',
    'image/png': '.png',
    'image/webp': '.webp'
  };
  
  return mimeMap[mimeType] || '.jpg';
}

module.exports = {
  upload,
  uploadSingle,
  sanitizeFilename,
  generateUniqueFilename,
  getExtensionFromMimeType,
  MAX_FILE_SIZE,
  ALLOWED_MIME_TYPES
};
