/**
 * Request Validation Middleware
 * 
 * Validates incoming requests using express-validator.
 * Ensures data integrity before processing.
 */

const { body, param, query, validationResult } = require('express-validator');
const { isValidFacialView, isValidTreatmentStage, canonicalView } = require('../config/facialViews');

/**
 * Handle validation errors
 */
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation Error',
      message: 'Invalid request parameters',
      details: errors.array().map(err => ({
        field: err.param,
        message: err.msg,
        value: err.value
      })),
      timestamp: new Date().toISOString()
    });
  }
  
  next();
};

/**
 * Validation rules for photo upload
 */
const validatePhotoUpload = [
  body('patientId')
    .notEmpty().withMessage('Patient ID is required')
    .isUUID().withMessage('Patient ID must be a valid UUID'),
  
  body('visitId')
    .optional({ values: 'falsy' }) // Made optional in Phase 3 - auto-creates visit if not provided
    .isUUID().withMessage('Visit ID must be a valid UUID'),
  
  body('captureId').notEmpty().isUUID().withMessage('A capture request UUID is required'),
  
  body('appointmentId')
    .optional()
    .isUUID().withMessage('Appointment ID must be a valid UUID'),
  
  body('treatmentStage')
    .notEmpty().withMessage('Treatment stage is required')
    .custom((value) => {
      if (!isValidTreatmentStage(value)) {
        throw new Error('Invalid treatment stage');
      }
      return true;
    }),
  
  body('facialView')
    .customSanitizer(canonicalView)
    .notEmpty().withMessage('Facial view is required')
    .custom((value) => {
      if (!isValidFacialView(value)) {
        throw new Error('Invalid facial view');
      }
      return true;
    }),
  
  body('procedureId').optional().isUUID(),
  body('setup').optional().isJSON(),
  body('reviewReason').optional().isString().isLength({ min: 15, max: 2000 }),
  body('procedureType')
    .optional()
    .isString().withMessage('Procedure type must be a string')
    .trim(),
  
  body('captureMethod')
    .notEmpty().withMessage('Capture method is required')
    .isIn(['camera', 'upload']).withMessage('Capture method must be either "camera" or "upload"'),
  
  body('notes')
    .optional()
    .isString().withMessage('Notes must be a string')
    .trim(),
  
  handleValidationErrors
];

/**
 * Validation rules for photo validation (without saving)
 */
const validatePhotoValidation = [
  body('facialView')
    .customSanitizer(canonicalView)
    .notEmpty().withMessage('Facial view is required')
    .custom((value) => {
      if (!isValidFacialView(value)) {
        throw new Error('Invalid facial view');
      }
      return true;
    }),
  
  handleValidationErrors
];

/**
 * Validation rules for UUID parameter
 */
const validateUUIDParam = [
  param('id')
    .isUUID().withMessage('ID must be a valid UUID'),
  
  handleValidationErrors
];

/**
 * Validation rules for patient ID parameter
 */
const validatePatientIdParam = [
  param('patientId')
    .isUUID().withMessage('Patient ID must be a valid UUID'),
  
  handleValidationErrors
];

/**
 * Validation rules for query filters
 */
const validateQueryFilters = [
  query('treatmentStage')
    .optional()
    .custom((value) => {
      if (value && !isValidTreatmentStage(value)) {
        throw new Error('Invalid treatment stage');
      }
      return true;
    }),
  
  query('facialView')
    .optional()
    .customSanitizer(canonicalView)
    .custom((value) => {
      if (value && !isValidFacialView(value)) {
        throw new Error('Invalid facial view');
      }
      return true;
    }),
  
  query('validationStatus')
    .optional()
    .isIn(['valid', 'invalid', 'pending', 'error', 'clinician_confirmed'])
    .withMessage('Validation status must be one of: valid, invalid, pending, error'),
  
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100')
    .toInt(),
  
  query('offset')
    .optional()
    .isInt({ min: 0 }).withMessage('Offset must be a non-negative integer')
    .toInt(),
  
  handleValidationErrors
];

module.exports = {
  validatePhotoUpload,
  validatePhotoValidation,
  validateUUIDParam,
  validatePatientIdParam,
  validateQueryFilters,
  handleValidationErrors
};
