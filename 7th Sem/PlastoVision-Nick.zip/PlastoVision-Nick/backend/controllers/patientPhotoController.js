const { supabaseAdmin } = require('../config/supabase');
const { reviewDecision } = require('../services/photoReview');
const { createHash } = require('node:crypto');
const { v4: uuidv4 } = require('uuid');
const pendingCaptures = new Set();

// Validation result cache - stores validation results temporarily
// Key: validationResultId, Value: {validationResult, imageHash, timestamp, patientId, facialView}
const validationCache = new Map();

// Clean up old cache entries every 15 minutes
setInterval(() => {
  const now = Date.now();
  const expired = [];
  for (const [key, value] of validationCache.entries()) {
    if (now - value.timestamp > 600000) { // 10 minutes
      expired.push(key);
    }
  }
  expired.forEach(key => validationCache.delete(key));
  if (expired.length > 0) {
    console.log(`Cleaned up ${expired.length} expired validation cache entries`);
  }
}, 900000); // 15 minutes

/**
 * Patient Photo Controller
 * 
 * Handles HTTP requests for patient photo operations.
 * Coordinates between storage, validation, and metadata services.
 */

const {
  savePhoto,
  savePhotoSidecar,
  getPhoto,
  deletePhoto,
  photoExists,
  createThumbnail
} = require('../services/localPhotoStorageService');

const {
  createPhotoMetadata,
  findCaptureMetadata,
  getPhotoMetadata,
  getPatientPhotos,
  getVisitPhotos,
  updatePhotoMetadata,
  deletePhotoMetadata,
  getPhotoCountByStage,
  getTreatmentStageCompletion,
  findSimilarCases,
  getPatientPhotoStats
} = require('../services/photoMetadataService');

const {
  validatePhoto,
  checkCVServiceHealth,
  getCVServiceInfo,
  parseValidationForDatabase,
  formatValidationErrors
} = require('../services/cvValidationService');

/**
 * Upload and validate patient photo
 * POST /api/patient-photos/upload
 */
async function uploadPhoto(req, res) {
  const captureId = req.body.captureId;
  if (!captureId) return res.status(400).json({ error: 'captureId is required' });
  if (pendingCaptures.has(captureId)) return res.status(409).json({ error: 'Capture save in progress; retry using the same captureId' });
  pendingCaptures.add(captureId);
  try { return await persistPhoto(req, res); }
  finally { pendingCaptures.delete(captureId); }
}

/**
 * Get or create photography visit for a patient
 * Finds an existing photography session visit or creates one automatically
 */
async function getOrCreatePhotographyVisit(patientId, treatmentStage) {
  // Look for recent photography sessions (visits with "Photography" in diagnosis)
  // within the last 24 hours for the same treatment stage
  const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
  
  const { data: recentVisit, error: searchError } = await supabaseAdmin
    .from('visits')
    .select('id, visit_date, diagnosis')
    .eq('patient_id', patientId)
    .ilike('diagnosis', '%Photography%')
    .gte('visit_date', oneDayAgo)
    .order('visit_date', { ascending: false })
    .limit(1)
    .maybeSingle();

  if (searchError) {
    console.error('Error searching for recent photography visit:', searchError);
  }

  // If found a recent photography visit, reuse it
  if (recentVisit) {
    console.log(`Reusing existing photography visit: ${recentVisit.id}`);
    return { id: recentVisit.id, created: false };
  }

  // Create new photography session visit
  const { data: newVisit, error: createError } = await supabaseAdmin
    .from('visits')
    .insert({
      patient_id: patientId,
      visit_date: new Date().toISOString(),
      diagnosis: `Photography Session - ${treatmentStage}`,
      doctor_notes: 'Automated photography session created during photo capture workflow',
      treatment_plan: null,
      follow_up_date: null
    })
    .select()
    .single();

  if (createError) {
    console.error('Error creating photography visit:', createError);
    throw new Error('Failed to create photography session visit');
  }

  console.log(`Created new photography visit: ${newVisit.id}`);
  return { id: newVisit.id, created: true };
}

async function persistPhoto(req, res) {
  let writtenPath = null;
  try {
    // Check if file was uploaded
    if (!req.file) {
      return res.status(400).json({
        error: 'Bad Request',
        message: 'No photo file uploaded',
        timestamp: new Date().toISOString()
      });
    }

    const {
      patientId,
      appointmentId,
      treatmentStage,
      facialView,
      procedureType,
      captureMethod,
      notes
    } = req.body;

    let { visitId } = req.body;

    // Auto-create or find photography visit if not provided
    if (!visitId || visitId === '' || visitId === 'null') {
      console.log(`No visitId provided, auto-creating photography session for patient ${patientId}`);
      try {
        const visitResult = await getOrCreatePhotographyVisit(patientId, treatmentStage);
        visitId = visitResult.id;
        console.log(`Using visit: ${visitId} (${visitResult.created ? 'newly created' : 'existing'})`);
      } catch (error) {
        return res.status(500).json({
          error: 'Failed to create photography session',
          message: error.message,
          timestamp: new Date().toISOString()
        });
      }
    }

    const requestFingerprint = createHash('sha256').update(req.file.buffer).update(JSON.stringify({
      patientId, visitId, appointmentId, treatmentStage, facialView, procedureType, captureMethod, notes,
      setup: req.body.setup, procedureId: req.body.procedureId, reviewReason: req.body.reviewReason,
    })).digest('hex');
    const existing = await findCaptureMetadata(req.body.captureId);
    if (existing.error) return res.status(503).json({ error: 'Could not check capture persistence; retry with the same captureId' });
    if (existing.data) {
      if (existing.data.patient_id !== patientId || existing.data.capture_setup?.request_fingerprint !== requestFingerprint)
        return res.status(409).json({ error: 'Capture ID already belongs to another image or context' });
      return res.status(200).json({ success: true, photo: existing.data, replayed: true });
    }

    // Verify visit belongs to patient
    if (visitId) {
      const { data: visit, error: visitError } = await supabaseAdmin.from('visits')
        .select('id,patient_id').eq('id', visitId).eq('patient_id', patientId).maybeSingle();
      if (visitError || !visit) return res.status(422).json({ error: 'Visit does not belong to this patient' });
    }
    
    if (appointmentId) {
      const { data: appointment, error } = await supabaseAdmin.from('appointments').select('id')
        .eq('id', appointmentId).eq('patient_id', patientId).maybeSingle();
      if (error || !appointment) return res.status(422).json({ error: 'Appointment does not belong to patient' });
    }
    if (req.body.procedureId) {
      const { data: procedure, error } = await supabaseAdmin.from('patient_procedures').select('id')
        .eq('id', req.body.procedureId).eq('patient_id', patientId).maybeSingle();
      if (error || !procedure) return res.status(422).json({ error: 'Procedure does not belong to patient' });
    }
    let setup;
    try { setup = JSON.parse(req.body.setup || '{}'); } catch { return res.status(400).json({ error: 'Invalid capture setup' }); }
    if (!setup || typeof setup !== 'object' || Array.isArray(setup)) return res.status(400).json({ error: 'Capture setup must be an object' }); 
    
    // Check if we have a cached validation result
    let validationResult;
    const validationResultId = req.body.validation_result_id;
    const currentImageHash = createHash('sha256').update(req.file.buffer).digest('hex');
    
    if (validationResultId && validationCache.has(validationResultId)) {
      const cached = validationCache.get(validationResultId);
      
      // Verify cache validity
      const cacheValid = cached.imageHash === currentImageHash &&
                        cached.patientId === patientId &&
                        cached.facialView === facialView &&
                        (Date.now() - cached.timestamp) < 600000; // 10 minutes
      
      if (cacheValid) {
        console.log(`Using cached validation result for ${facialView}`);
        validationResult = cached.validationResult;
        // Clear from cache after use
        validationCache.delete(validationResultId);
      } else {
        console.log(`Cached validation expired or mismatched, re-validating`);
      }
    }
    
    // If no valid cache, perform validation
    if (!validationResult) {
      console.log(`Validating photo for facial view: ${facialView}`);
      validationResult = await validatePhoto(
        req.file.buffer,
        facialView,
        req.file.originalname, setup
      );
    }

    // Check for view mismatch - reject if uploaded photo doesn't match selected view
    // Only reject confident mismatches; uncertain cases allow clinician review
    if (validationResult.view_match === false && validationResult.detected_view) {
      const confidence = validationResult.view_confidence || 'uncertain';
      
      if (confidence === 'confident' || confidence === 'probable') {
        console.log(`View mismatch detected (${confidence}): requested ${facialView}, detected ${validationResult.detected_view}`);
        return res.status(400).json({
          error: 'View Mismatch',
          message: `The uploaded photo appears to show ${validationResult.detected_view} (${confidence} detection) but you selected ${facialView}. Please upload the correct photo or select the matching view.`,
          validation: {
            requested_view: facialView,
            detected_view: validationResult.detected_view,
            confidence: confidence,
            reasoning: validationResult.view_detection_reasoning,
            yaw: validationResult.yaw,
            pitch: validationResult.pitch,
            roll: validationResult.roll
          },
          timestamp: new Date().toISOString()
        });
      } else {
        // Uncertain mismatch - log but allow with review flag
        console.log(`Uncertain view mismatch: requested ${facialView}, possibly ${validationResult.detected_view} - allowing with clinician review`);
      }
    }

    let decision;
    try { decision = reviewDecision(validationResult, req.body.reviewReason); }
    catch (error) { return res.status(error.status || 422).json({ error: error.message, validation: validationResult }); }

    // Save photo to local storage
    console.log('Saving photo to local storage...');
    const storageResult = await savePhoto(req.file.buffer, {
      patientId,
      visitId,
      treatmentStage,
      facialView,
      mimeType: req.file.mimetype
    });
    writtenPath = storageResult.relativePath;

    // Parse validation data for database
    const validationData = parseValidationForDatabase(validationResult);

    // Determine if this is a clinician override case
    const isOverride = decision.status === 'approved' && 
                       (validationResult.view_match === false || 
                        !validationResult.reviewable ||
                        validationResult.validation_status === 'invalid');

    // Create metadata record in database
    const metadata = {
      id: req.body.captureId,
      patient_id: patientId,
      visit_id: visitId || null,
      appointment_id: appointmentId || null,
      treatment_stage: treatmentStage,
      facial_view: facialView,
      procedure_type: procedureType || null,
      local_storage_path: storageResult.relativePath,
      file_name: storageResult.filename,
      mime_type: req.file.mimetype,
      file_size: storageResult.fileSize,
      capture_method: captureMethod,
      captured_at: typeof setup.captured_at === 'string' && Number.isFinite(Date.parse(setup.captured_at)) ? new Date(setup.captured_at).toISOString() : new Date().toISOString(),
      capture_device: setup.actual_camera?.deviceId || req.headers['user-agent'],
      notes: notes || null,
      created_by: null,
      ...validationData,
      validation_status: decision.status,
      framing_protocol: validationResult.framing?.protocol || 'full_face',
      capture_setup: { ...setup, request_fingerprint: requestFingerprint },
      clinician_confirmation: decision.confirmation,
      image_width: storageResult.width,
      image_height: storageResult.height,
      original_checksum: storageResult.checksum,
      procedure_id: req.body.procedureId || null,
      // Override tracking fields
      clinician_override: isOverride,
      override_reason: isOverride ? (req.body.reviewReason || decision.confirmation || 'Clinician approved photo despite validation concerns') : null,
      override_by: null, // TODO: Set to actual user ID when auth is implemented
      override_at: isOverride ? new Date().toISOString() : null,
      detected_view: validationResult.detected_view || null,
      view_confidence: validationResult.view_confidence || null,
      pose_reliable: validationResult.pose_reliable !== false // Default to true if not specified
    };

    await savePhotoSidecar(storageResult.relativePath, metadata);
    const { data: photoRecord, error: dbError } = await createPhotoMetadata(metadata);

    if (dbError) {
      // If database insert fails, try to clean up the file
      try {
        await deletePhoto(storageResult.relativePath);
        writtenPath = null;
      } catch (cleanupError) {
        console.error('Failed to cleanup file after DB error:', cleanupError);
      }

      // A second server process may have won the primary-key race.
      const winner = await findCaptureMetadata(req.body.captureId);
      if (winner.data?.capture_setup?.request_fingerprint === requestFingerprint)
        return res.status(200).json({ success: true, replayed: true, photo: winner.data });

      return res.status(500).json({
        error: 'Database Error',
        message: 'Photo registration failed; the image remains available in this capture session for retry',
        details: dbError,
        timestamp: new Date().toISOString()
      });
    }
    writtenPath = null;

    // Success response
    res.status(201).json({
      success: true,
      message: 'Photo uploaded and validated successfully',
      photo: photoRecord,
      storage: { location: 'local_backend_device', relative_path: storageResult.relativePath, metadata_path: `${storageResult.relativePath}.json` },
      validation: {
        status: decision.status,
        yaw: validationResult.yaw,
        pitch: validationResult.pitch,
        roll: validationResult.roll,
        warnings: validationResult.warnings || []
      },
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    if (writtenPath) await deletePhoto(writtenPath).catch(cleanup => console.error('Photo rollback failed:', cleanup.message));
    console.error('Upload error:', error);
    res.status(500).json({
      error: 'Upload Failed',
      message: error.message,
      timestamp: new Date().toISOString()
    });
  }
}

/**
 * Validate photo without saving
 * POST /api/patient-photos/validate
 */
async function validatePhotoOnly(req, res) {
  try {
    if (!req.file) {
      return res.status(400).json({
        error: 'Bad Request',
        message: 'No photo file provided',
        timestamp: new Date().toISOString()
      });
    }

    const { facialView, patientId } = req.body;
    let setup;
    try { setup = JSON.parse(req.body.setup || '{}'); } catch { return res.status(400).json({ error: 'Invalid capture setup' }); }

    // Calculate image hash for validation result binding
    const imageHash = createHash('sha256').update(req.file.buffer).digest('hex');

    // Validate photo
    const validationResult = await validatePhoto(
      req.file.buffer,
      facialView,
      req.file.originalname, setup
    );

    // Generate validation result ID and cache it
    const validationResultId = uuidv4();
    validationCache.set(validationResultId, {
      validationResult,
      imageHash,
      timestamp: Date.now(),
      patientId,
      facialView
    });

    const userFriendlyErrors = formatValidationErrors(validationResult.errors || []);

    res.json({
      validation: validationResult,
      errors: userFriendlyErrors,
      validation_result_id: validationResultId, // Include ID for later use
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Validation error:', error);
    res.status(500).json({
      error: 'Validation Failed',
      message: error.message,
      timestamp: new Date().toISOString()
    });
  }
}

/**
 * Get photo file
 * GET /api/patient-photos/:id
 */
async function getPhotoFile(req, res) {
  try {
    const { id } = req.params;
    const { thumbnail } = req.query;

    // Get metadata from database
    const { data: metadata, error: dbError } = await getPhotoMetadata(id);

    if (dbError || !metadata) {
      return res.status(404).json({
        error: 'Not Found',
        message: 'Photo not found',
        timestamp: new Date().toISOString()
      });
    }

    // Authentication is deferred for local development.

    // Get photo from storage
    let photoBuffer;
    
    if (thumbnail === 'true') {
      photoBuffer = await createThumbnail(metadata.local_storage_path, 300);
    } else {
      photoBuffer = await getPhoto(metadata.local_storage_path);
    }

    if (req.query.export === 'true') {
      photoBuffer = await require('sharp')(photoBuffer).rotate().jpeg({ quality: 95 }).toBuffer();
    }
    // Set appropriate headers
    res.set({
      'Content-Type': (thumbnail === 'true' || req.query.export === 'true') ? 'image/jpeg' : metadata.mime_type,
      'Content-Length': photoBuffer.length,
      'Cache-Control': 'private, no-store', // Cache for 1 year
      'X-Photo-ID': id,
      'X-Facial-View': metadata.facial_view,
      'X-Treatment-Stage': metadata.treatment_stage
    });

    res.send(photoBuffer);

  } catch (error) {
    console.error('Get photo error:', error);
    
    if (error.message === 'Photo not found') {
      return res.status(404).json({
        error: 'Not Found',
        message: 'Photo file not found',
        timestamp: new Date().toISOString()
      });
    }

    res.status(500).json({
      error: 'Retrieval Failed',
      message: error.message,
      timestamp: new Date().toISOString()
    });
  }
}

/**
 * Get photo metadata
 * GET /api/patient-photos/metadata/:id
 */
async function getPhotoMetadataById(req, res) {
  try {
    const { id } = req.params;

    const { data: metadata, error } = await getPhotoMetadata(id);

    if (error || !metadata) {
      return res.status(404).json({
        error: 'Not Found',
        message: 'Photo not found',
        timestamp: new Date().toISOString()
      });
    }

    // Authentication is deferred for local development.

    res.json({
      photo: metadata,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Get metadata error:', error);
    res.status(500).json({
      error: 'Retrieval Failed',
      message: error.message,
      timestamp: new Date().toISOString()
    });
  }
}

/**
 * Get all photos for a patient
 * GET /api/patient-photos/patient/:patientId
 */
async function getPatientPhotosController(req, res) {
  try {
    const { patientId } = req.params;
    const filters = {
      treatmentStage: req.query.treatmentStage,
      facialView: req.query.facialView,
      validationStatus: req.query.validationStatus,
      visitId: req.query.visitId,
      procedureType: req.query.procedureType,
      procedureId: req.query.procedureId,
      limit: parseInt(req.query.limit) || 100,
      offset: parseInt(req.query.offset) || 0
    };

    // Authentication is deferred for local development.

    const { data: photos, error } = await getPatientPhotos(patientId, filters);

    if (error) {
      return res.status(500).json({
        error: 'Database Error',
        message: error,
        timestamp: new Date().toISOString()
      });
    }

    res.json({
      photos: photos || [],
      count: photos ? photos.length : 0,
      filters: filters,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Get patient photos error:', error);
    res.status(500).json({
      error: 'Retrieval Failed',
      message: error.message,
      timestamp: new Date().toISOString()
    });
  }
}

/**
 * Get photos for a visit
 * GET /api/patient-photos/visit/:visitId
 */
async function getVisitPhotosController(req, res) {
  try {
    const { visitId } = req.params;

    const { data: photos, error } = await getVisitPhotos(visitId);

    if (error) {
      return res.status(500).json({
        error: 'Database Error',
        message: error,
        timestamp: new Date().toISOString()
      });
    }

    res.json({
      photos: photos || [],
      count: photos ? photos.length : 0,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Get visit photos error:', error);
    res.status(500).json({
      error: 'Retrieval Failed',
      message: error.message,
      timestamp: new Date().toISOString()
    });
  }
}

/**
 * Delete photo
 * DELETE /api/patient-photos/:id
 */
async function deletePhotoController(req, res) {
  try {
    const { id } = req.params;

    // Get metadata first
    const { data: metadata, error: getError } = await getPhotoMetadata(id);

    if (getError || !metadata) {
      return res.status(404).json({
        error: 'Not Found',
        message: 'Photo not found',
        timestamp: new Date().toISOString()
      });
    }

    // Authentication is deferred for local development.

    // Delete file from storage
    const fileDeleted = await deletePhoto(metadata.local_storage_path);

    // Delete metadata from database
    const { success: dbDeleted, error: dbError } = await deletePhotoMetadata(id);

    if (dbError) {
      return res.status(500).json({
        error: 'Database Error',
        message: 'Failed to delete photo metadata',
        details: dbError,
        timestamp: new Date().toISOString()
      });
    }

    res.json({
      success: true,
      message: 'Photo deleted successfully',
      deleted: {
        file: fileDeleted,
        metadata: dbDeleted
      },
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Delete photo error:', error);
    res.status(500).json({
      error: 'Deletion Failed',
      message: error.message,
      timestamp: new Date().toISOString()
    });
  }
}

/**
 * Get photo count by treatment stage
 * GET /api/patient-photos/patient/:patientId/count-by-stage
 */
async function getPhotoCountByStageController(req, res) {
  try {
    const { patientId } = req.params;

    const { data, error } = await getPhotoCountByStage(patientId);

    if (error) {
      return res.status(500).json({
        error: 'Database Error',
        message: error,
        timestamp: new Date().toISOString()
      });
    }

    res.json({
      counts: data || [],
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Get count by stage error:', error);
    res.status(500).json({
      error: 'Retrieval Failed',
      message: error.message,
      timestamp: new Date().toISOString()
    });
  }
}

/**
 * Get treatment stage completion
 * GET /api/patient-photos/patient/:patientId/stage-completion
 */
async function getTreatmentStageCompletionController(req, res) {
  try {
    const { patientId } = req.params;
    const { treatmentStage } = req.query;

    if (!treatmentStage) {
      return res.status(400).json({
        error: 'Bad Request',
        message: 'treatmentStage query parameter is required',
        timestamp: new Date().toISOString()
      });
    }

    const { data, error } = await getTreatmentStageCompletion(patientId, treatmentStage);

    if (error) {
      return res.status(500).json({
        error: 'Database Error',
        message: error,
        timestamp: new Date().toISOString()
      });
    }

    res.json({
      treatmentStage,
      views: data || [],
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Get stage completion error:', error);
    res.status(500).json({
      error: 'Retrieval Failed',
      message: error.message,
      timestamp: new Date().toISOString()
    });
  }
}

/**
 * Find similar cases
 * GET /api/patient-photos/similar-cases
 */
async function findSimilarCasesController(req, res) {
  try {
    const {
      procedureType,
      treatmentStage,
      facialView,
      excludePatientId,
      limit
    } = req.query;

    if (!procedureType || !treatmentStage || !facialView) {
      return res.status(400).json({
        error: 'Bad Request',
        message: 'procedureType, treatmentStage, and facialView are required',
        timestamp: new Date().toISOString()
      });
    }

    const { data, error } = await findSimilarCases({
      procedureType,
      treatmentStage,
      facialView,
      excludePatientId: excludePatientId || null,
      limit: parseInt(limit) || 10
    });

    if (error) {
      return res.status(500).json({
        error: 'Database Error',
        message: error,
        timestamp: new Date().toISOString()
      });
    }

    res.json({
      cases: data || [],
      count: data ? data.length : 0,
      criteria: { procedureType, treatmentStage, facialView },
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Find similar cases error:', error);
    res.status(500).json({
      error: 'Search Failed',
      message: error.message,
      timestamp: new Date().toISOString()
    });
  }
}

/**
 * Get patient photo statistics
 * GET /api/patient-photos/patient/:patientId/stats
 */
async function getPatientPhotoStatsController(req, res) {
  try {
    const { patientId } = req.params;

    const { data, error } = await getPatientPhotoStats(patientId);

    if (error) {
      return res.status(500).json({
        error: 'Database Error',
        message: error,
        timestamp: new Date().toISOString()
      });
    }

    res.json({
      stats: data,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Get photo stats error:', error);
    res.status(500).json({
      error: 'Retrieval Failed',
      message: error.message,
      timestamp: new Date().toISOString()
    });
  }
}

/**
 * Check CV service health
 * GET /api/patient-photos/cv-service/health
 */
async function checkCVServiceHealthController(req, res) {
  try {
    const isHealthy = await checkCVServiceHealth();
    const info = await getCVServiceInfo();

    res.json({
      healthy: isHealthy,
      service: info,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('CV service health check error:', error);
    res.status(500).json({
      error: 'Health Check Failed',
      message: error.message,
      timestamp: new Date().toISOString()
    });
  }
}

module.exports = {
  uploadPhoto,
  validatePhotoOnly,
  getPhotoFile,
  getPhotoMetadataById,
  getPatientPhotosController,
  getVisitPhotosController,
  deletePhotoController,
  getPhotoCountByStageController,
  getTreatmentStageCompletionController,
  findSimilarCasesController,
  getPatientPhotoStatsController,
  checkCVServiceHealthController
};
