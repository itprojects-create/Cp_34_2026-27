/**
 * Patient Photos Routes
 * 
 * API endpoints for patient facial photography operations.
 */

const express = require('express');
const router = express.Router();
router.use(require('../middleware/photoAudit'));

// Import middleware
const { uploadSingle } = require('../middleware/upload');
const { verifyPatientExists } = require('../middleware/patientExists');
const {
  validatePhotoUpload,
  validatePhotoValidation,
  validateUUIDParam,
  validatePatientIdParam,
  validateQueryFilters
} = require('../middleware/validation');

// Import controller functions
const {
  uploadPhoto,
  validatePhotoOnly,
  getPhotoFile,
  getPhotoMetadataById,
  getPatientPhotosController,
  getVisitPhotosController,
  deletePhotoController,
  getPhotoCountByStageController,
  getTreatmentStageCompletionController,
  findSimilarCasesController,
  getPatientPhotoStatsController,
  checkCVServiceHealthController
} = require('../controllers/patientPhotoController');

router.get('/patient/:patientId/procedures', validatePatientIdParam, verifyPatientExists('patientId'), async (req, res) => {
  try {
    const { supabaseAdmin } = require('../config/supabase');
    const { data, error } = await supabaseAdmin.from('patient_procedures').select('id,name')
      .eq('patient_id', req.params.patientId).order('created_at');
    if (error && ['42P01','PGRST205'].includes(error.code)) return res.json({ procedures: [], available: false });
    if (error) return res.status(500).json({ error: 'Could not load procedure episodes', message: error.message });
    res.json({ procedures: data || [] });
  } catch { res.status(500).json({ error: 'Could not load procedure episodes' }); }
});
router.post('/patient/:patientId/procedures', validatePatientIdParam, verifyPatientExists('patientId'), async (req, res) => {
  const name = req.body.name;
  if (typeof name !== 'string' || !name.trim() || name.trim().length > 200)
    return res.status(400).json({ error: 'Procedure name must contain 1–200 characters' });
  try {
    const { supabaseAdmin } = require('../config/supabase');
    const { data, error } = await supabaseAdmin.from('patient_procedures')
      .insert({ patient_id: req.params.patientId, name: name.trim() }).select('id,name').single();
    if (error) return res.status(500).json({ error: 'Could not create procedure episode', message: error.message });
    res.status(201).json({ procedure: data });
  } catch { res.status(500).json({ error: 'Could not create procedure episode' }); }
});

// ============================================
// ROUTES
// ============================================

/**
 * @route   POST /api/patient-photos/upload
 * @desc    Upload and validate a patient photo
 * @access  Local development — authentication deferred
 */
router.post(
  '/upload',
  uploadSingle,
  validatePhotoUpload,
  verifyPatientExists('patientId'),
  uploadPhoto
);

router.get('/capture-config', async (_req, res) => {
  try {
    const { data } = await require('axios').get(`${process.env.PYTHON_CV_SERVICE_URL || 'http://127.0.0.1:5002'}/capture-config`, { timeout: 5000 });
    res.json(data);
  } catch { res.status(503).json({ error: 'Local CV configuration unavailable' }); }
});

/**
 * @route   POST /api/patient-photos/upload-direct
 * @desc    Upload photo directly without validation (for enhanced capture workflow)
 * @access  Local development — authentication deferred
 */
router.post('/upload-direct', (req, res) => res.status(410).json({ error: 'Use the /upload workflow with final validation and visit metadata' }));

/**
 * @route   POST /api/patient-photos/validate
 * @desc    Validate a photo without saving
 * @access  Local development — authentication deferred
 */
router.post(
  '/validate',
  uploadSingle,
  validatePhotoValidation,
  validatePhotoOnly
);

/**
 * @route   POST /api/patient-photos/validate-live
 * @desc    Validate live camera frame (base64 JSON, optimized for real-time)
 * @access  Local development — authentication deferred
 */
router.post(
  '/validate-live',
  express.json({ limit: '10mb' }),
  async (req, res) => {
    try {
      const { frame, facial_view, setup, frame_id, timestamp } = req.body;
      if (typeof frame !== 'string' || frame.length > 2*1024*1024 || typeof facial_view !== 'string' ||
          !Number.isSafeInteger(frame_id) || frame_id < 1 || !Number.isFinite(timestamp) ||
          (setup != null && (typeof setup !== 'object' || Array.isArray(setup)))) {
        return res.status(400).json({
          error: 'Supply a bounded frame, facial_view, positive frame_id, timestamp and setup object'
        });
      }

      // Forward to Python CV service
      const axios = require('axios');
      const CV_SERVICE_URL = process.env.PYTHON_CV_SERVICE_URL || 'http://127.0.0.1:5002';


      const response = await axios.post(
        `${CV_SERVICE_URL}/validate-live`,
        { frame, facial_view, setup, frame_id, timestamp },
        {
          headers: { 'Content-Type': 'application/json' },
          timeout: 5000 // 5 second timeout for live validation
        }
      );


      res.json(response.data);
    } catch (error) {
      console.error('[validate-live] ERROR:', error.message);
      
      if (error.code === 'ECONNREFUSED') {
        return res.status(503).json({
          error: 'CV service unavailable',
          details: 'Python CV service is not running'
        });
      }

      if (error.response) {
        console.error('[validate-live] Python error response:', error.response.status, error.response.data);
        return res.status(error.response.status).json(error.response.data);
      }

      res.status(500).json({
        error: 'Live validation failed',
        details: error.message
      });
    }
  }
);

/**
 * @route   GET /api/patient-photos/:id
 * @desc    Get photo file (actual image)
 * @access  Local development — authentication deferred
 * @query   ?thumbnail=true - Return thumbnail instead of full image
 */
router.get(
  '/similar-cases',
  findSimilarCasesController
);


router.get(
  '/:id',
  validateUUIDParam,
  getPhotoFile
);

/**
 * @route   GET /api/patient-photos/metadata/:id
 * @desc    Get photo metadata
 * @access  Local development — authentication deferred
 */
router.get(
  '/metadata/:id',
  validateUUIDParam,
  getPhotoMetadataById
);

/**
 * @route   GET /api/patient-photos/patient/:patientId
 * @desc    Get all photos for a patient
 * @access  Local development — authentication deferred
 * @query   ?treatmentStage, ?facialView, ?validationStatus, ?visitId, ?limit, ?offset
 */
router.get(
  '/patient/:patientId',
  validatePatientIdParam,
  validateQueryFilters,
  verifyPatientExists('patientId'),
  getPatientPhotosController
);

/**
 * @route   GET /api/patient-photos/patient/:patientId/stats
 * @desc    Get photo statistics for a patient
 * @access  Local development — authentication deferred
 */
router.get(
  '/patient/:patientId/stats',
  validatePatientIdParam,
  verifyPatientExists('patientId'),
  getPatientPhotoStatsController
);

/**
 * @route   GET /api/patient-photos/patient/:patientId/count-by-stage
 * @desc    Get photo count by treatment stage
 * @access  Local development — authentication deferred
 */
router.get(
  '/patient/:patientId/count-by-stage',
  validatePatientIdParam,
  verifyPatientExists('patientId'),
  getPhotoCountByStageController
);

/**
 * @route   GET /api/patient-photos/patient/:patientId/stage-completion
 * @desc    Get treatment stage completion status
 * @access  Local development — authentication deferred
 * @query   treatmentStage (required)
 */
router.get(
  '/patient/:patientId/stage-completion',
  validatePatientIdParam,
  verifyPatientExists('patientId'),
  getTreatmentStageCompletionController
);

/**
 * @route   GET /api/patient-photos/visit/:visitId
 * @desc    Get all photos for a visit
 * @access  Local development — authentication deferred
 */
router.get(
  '/visit/:visitId',
  require('express-validator').param('visitId').isUUID(),
  require('../middleware/validation').handleValidationErrors,
  getVisitPhotosController
);

/**
 * @route   DELETE /api/patient-photos/:id
 * @desc    Delete a photo (file and metadata)
 * @access  Local development — authentication deferred
 */
router.delete(
  '/:id',
  validateUUIDParam,
  deletePhotoController
);

/**
 * @route   GET /api/patient-photos/similar-cases
 * @desc    Find similar cases
 * @access  Local development — authentication deferred
 * @query   procedureType, treatmentStage, facialView (all required)
 * @query   excludePatientId, limit (optional)
 */

/**
 * @route   GET /api/patient-photos/cv-service/health
 * @desc    Check Python CV service health
 * @access  Local development — authentication deferred
 */
router.get(
  '/cv-service/health',
  checkCVServiceHealthController
);

module.exports = router;
