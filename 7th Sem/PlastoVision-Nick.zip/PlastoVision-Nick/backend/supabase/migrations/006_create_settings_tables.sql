-- ============================================
-- SETTINGS MODULE TABLES
-- ============================================
-- This migration creates all tables needed for the Settings module
-- including profiles, clinic settings, notification preferences, and user preferences

-- ============================================
-- PROFILES TABLE
-- ============================================
-- Store user profile information
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT UNIQUE NOT NULL, -- For now, using text identifier. Will be auth.uid() when Supabase Auth is enabled
  full_name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT,
  designation TEXT, -- e.g., "Lead Surgeon", "Receptionist", "Admin"
  department TEXT, -- e.g., "Surgery", "Administration"
  avatar_url TEXT,
  role TEXT NOT NULL DEFAULT 'Doctor', -- 'Admin', 'Doctor', 'Receptionist'
  bio TEXT,
  specialization TEXT, -- For doctors
  license_number TEXT, -- For doctors
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for profiles
CREATE INDEX IF NOT EXISTS idx_profiles_user_id ON profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_profiles_email ON profiles(email);
CREATE INDEX IF NOT EXISTS idx_profiles_role ON profiles(role);
CREATE INDEX IF NOT EXISTS idx_profiles_is_active ON profiles(is_active);

-- Add constraints for valid roles
ALTER TABLE profiles 
ADD CONSTRAINT check_profile_role 
CHECK (role IN ('Admin', 'Doctor', 'Receptionist'));

-- ============================================
-- CLINIC SETTINGS TABLE
-- ============================================
-- Store clinic/hospital configuration (single row)
CREATE TABLE IF NOT EXISTS clinic_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  clinic_name TEXT NOT NULL,
  logo_url TEXT,
  address TEXT,
  city TEXT,
  state TEXT,
  country TEXT,
  postal_code TEXT,
  phone TEXT,
  email TEXT,
  website TEXT,
  working_hours JSONB DEFAULT '{"monday": {"open": "09:00", "close": "17:00", "closed": false}, "tuesday": {"open": "09:00", "close": "17:00", "closed": false}, "wednesday": {"open": "09:00", "close": "17:00", "closed": false}, "thursday": {"open": "09:00", "close": "17:00", "closed": false}, "friday": {"open": "09:00", "close": "17:00", "closed": false}, "saturday": {"open": "09:00", "close": "13:00", "closed": false}, "sunday": {"open": "09:00", "close": "17:00", "closed": true}}'::JSONB,
  appointment_duration INTEGER DEFAULT 30, -- Default appointment duration in minutes
  timezone TEXT DEFAULT 'UTC',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert default clinic settings
INSERT INTO clinic_settings (clinic_name, phone, email)
VALUES ('PlastoVision Clinic', '+1 (555) 123-4567', 'info@plastovision.com')
ON CONFLICT DO NOTHING;

-- ============================================
-- NOTIFICATION PREFERENCES TABLE
-- ============================================
-- Store user-specific notification preferences
CREATE TABLE IF NOT EXISTS notification_preferences (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT UNIQUE NOT NULL,
  
  -- Appointment notifications
  appointment_created BOOLEAN DEFAULT true,
  appointment_updated BOOLEAN DEFAULT true,
  appointment_cancelled BOOLEAN DEFAULT true,
  appointment_reminder BOOLEAN DEFAULT true, -- Reminder before appointment
  
  -- System notifications
  system_updates BOOLEAN DEFAULT true,
  system_maintenance BOOLEAN DEFAULT true,
  
  -- Email notifications
  email_notifications BOOLEAN DEFAULT true,
  
  -- SMS notifications (for future implementation)
  sms_notifications BOOLEAN DEFAULT false,
  
  -- Push notifications (for future implementation)
  push_notifications BOOLEAN DEFAULT true,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create index for notification_preferences
CREATE INDEX IF NOT EXISTS idx_notification_preferences_user_id ON notification_preferences(user_id);

-- ============================================
-- USER PREFERENCES TABLE
-- ============================================
-- Store user UI/UX preferences
CREATE TABLE IF NOT EXISTS user_preferences (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT UNIQUE NOT NULL,
  
  -- Appearance settings
  theme TEXT DEFAULT 'light', -- 'light', 'dark', 'auto'
  compact_mode BOOLEAN DEFAULT false,
  
  -- Language and locale
  language TEXT DEFAULT 'en',
  date_format TEXT DEFAULT 'MM/DD/YYYY', -- e.g., 'MM/DD/YYYY', 'DD/MM/YYYY'
  time_format TEXT DEFAULT '12h', -- '12h' or '24h'
  
  -- Dashboard preferences
  dashboard_layout TEXT DEFAULT 'default',
  default_view TEXT DEFAULT 'dashboard', -- Default landing page
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create index for user_preferences
CREATE INDEX IF NOT EXISTS idx_user_preferences_user_id ON user_preferences(user_id);

-- Add constraints for valid values
ALTER TABLE user_preferences 
ADD CONSTRAINT check_theme 
CHECK (theme IN ('light', 'dark', 'auto'));

ALTER TABLE user_preferences 
ADD CONSTRAINT check_time_format 
CHECK (time_format IN ('12h', '24h'));

-- ============================================
-- UPDATE TRIGGERS
-- ============================================
-- These triggers automatically update the updated_at timestamp

CREATE TRIGGER trigger_update_profiles_updated_at
BEFORE UPDATE ON profiles
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trigger_update_clinic_settings_updated_at
BEFORE UPDATE ON clinic_settings
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trigger_update_notification_preferences_updated_at
BEFORE UPDATE ON notification_preferences
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trigger_update_user_preferences_updated_at
BEFORE UPDATE ON user_preferences
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- ROW LEVEL SECURITY (RLS)
-- ============================================
-- Enable RLS on all settings tables

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE clinic_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE notification_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_preferences ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Allow users to view all profiles"
ON profiles FOR SELECT
USING (true);

CREATE POLICY "Allow users to update own profile"
ON profiles FOR UPDATE
USING (true)
WITH CHECK (true);

CREATE POLICY "Allow admins to manage all profiles"
ON profiles FOR ALL
USING (true)
WITH CHECK (true);

-- Clinic settings policies (readable by all, editable by admins)
CREATE POLICY "Allow all users to read clinic settings"
ON clinic_settings FOR SELECT
USING (true);

CREATE POLICY "Allow all users to update clinic settings"
ON clinic_settings FOR UPDATE
USING (true)
WITH CHECK (true);

-- Notification preferences policies (users can only manage their own)
CREATE POLICY "Allow users to view own notification preferences"
ON notification_preferences FOR SELECT
USING (true);

CREATE POLICY "Allow users to update own notification preferences"
ON notification_preferences FOR UPDATE
USING (true)
WITH CHECK (true);

CREATE POLICY "Allow users to insert own notification preferences"
ON notification_preferences FOR INSERT
WITH CHECK (true);

-- User preferences policies (users can only manage their own)
CREATE POLICY "Allow users to view own preferences"
ON user_preferences FOR SELECT
USING (true);

CREATE POLICY "Allow users to update own preferences"
ON user_preferences FOR UPDATE
USING (true)
WITH CHECK (true);

CREATE POLICY "Allow users to insert own preferences"
ON user_preferences FOR INSERT
WITH CHECK (true);

-- ============================================
-- SEED DATA FOR DEVELOPMENT
-- ============================================
-- Insert default profile for Dr. Michaels
INSERT INTO profiles (user_id, full_name, email, phone, designation, department, role, specialization, license_number, bio)
VALUES (
  'dr-yogesh-001',
  'Dr. Yogesh Jaiswal',
  'dr.yogesh@plastovision.com',
  '+919878657856',
  'Lead Surgeon',
  'Plastic Surgery',
  'Doctor',
  'Reconstructive & Cosmetic Surgery',
  'MED-12345-NY',
  'Board-certified plastic surgeon with over 15 years of experience in reconstructive and cosmetic procedures.'
)
ON CONFLICT (user_id) DO NOTHING;

-- Insert default notification preferences for Dr. Michaels
INSERT INTO notification_preferences (user_id)
VALUES ('dr-yogesh-001')
ON CONFLICT (user_id) DO NOTHING;

-- Insert default user preferences for Dr. Michaels
INSERT INTO user_preferences (user_id)
VALUES ('dr-yogesh-001')
ON CONFLICT (user_id) DO NOTHING;

-- ============================================
-- SETUP COMPLETE
-- ============================================
-- 
-- Next Steps:
-- 1. Create Supabase Storage bucket: 'user-avatars'
-- 2. Create Supabase Storage bucket: 'clinic-logos'
-- 3. Implement settings service layer
-- 4. Create settings UI components
-- 
-- Tables: profiles, clinic_settings, notification_preferences, user_preferences
-- Indexes: Optimized for user lookups
-- RLS: Enabled with appropriate policies
-- ============================================
