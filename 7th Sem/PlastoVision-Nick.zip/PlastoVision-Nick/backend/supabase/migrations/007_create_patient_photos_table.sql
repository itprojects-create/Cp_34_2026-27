-- ============================================
-- PATIENT PHOTOS TABLE - FACIAL PHOTOGRAPHY MODULE
-- ============================================
-- 
-- This table stores METADATA ONLY for patient photographs.
-- Actual image files are stored in local filesystem controlled by the clinic.
-- 
-- Privacy Requirement: Patient photographs must NOT be stored in cloud storage.
-- Only metadata (file references, validation data, timestamps) is stored in PostgreSQL.
--
-- Storage Architecture:
--   PostgreSQL: Metadata (this table)
--   Local FS:   Actual image files (/uploads/patients/...)
--
-- ============================================

-- Create patient_photos table
CREATE TABLE IF NOT EXISTS patient_photos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Patient & Visit References
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  visit_id UUID REFERENCES visits(id) ON DELETE SET NULL,
  appointment_id UUID REFERENCES appointments(id) ON DELETE SET NULL,
  
  -- Photo Classification
  treatment_stage TEXT NOT NULL, -- 'Pre-Surgery', 'Post-Surgery', 'Follow-Up 1', etc.
  facial_view TEXT NOT NULL, -- 'frontal_neutral', 'frontal_smiling', 'right_oblique_45', etc.
  procedure_type TEXT, -- 'Rhinoplasty', 'Blepharoplasty', 'Facelift', etc.
  
  -- Local Storage Reference
  -- Relative path within the local storage system
  -- Example: 'patients/abc123.../visits/def456.../facial/pre_surgery/frontal_neutral/photo_1726123456_xyz.jpg'
  local_storage_path TEXT NOT NULL UNIQUE,
  file_name TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  file_size BIGINT,
  
  -- Capture Metadata
  capture_method TEXT NOT NULL CHECK (capture_method IN ('camera', 'upload')),
  captured_at TIMESTAMPTZ NOT NULL,
  capture_device TEXT, -- User agent or device info
  
  -- Validation Metadata (from Python CV service)
  validation_status TEXT NOT NULL CHECK (validation_status IN ('valid', 'invalid', 'pending', 'error')),
  
  -- Head Pose Angles (degrees)
  yaw NUMERIC, -- Rotation around vertical axis (left/right)
  pitch NUMERIC, -- Rotation around lateral axis (up/down)
  roll NUMERIC, -- Rotation around longitudinal axis (tilt)
  
  -- Validation Flags
  face_detected BOOLEAN DEFAULT false,
  landmarks_detected BOOLEAN DEFAULT false,
  framing_ok BOOLEAN DEFAULT false,
  quality_ok BOOLEAN DEFAULT false,
  
  -- Validation Details (JSON)
  validation_errors JSONB DEFAULT '[]'::jsonb, -- Array of error messages
  validation_warnings JSONB DEFAULT '[]'::jsonb, -- Array of warning messages
  validation_metadata JSONB, -- Additional CV metadata (confidence scores, etc.)
  
  -- Notes
  notes TEXT, -- Doctor's notes about this specific photo
  
  -- Audit Trail
  created_by UUID, -- Doctor/user who captured/uploaded
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- INDEXES FOR PERFORMANCE
-- ============================================

-- Basic lookups
CREATE INDEX idx_patient_photos_patient_id ON patient_photos(patient_id);
CREATE INDEX idx_patient_photos_visit_id ON patient_photos(visit_id);
CREATE INDEX idx_patient_photos_appointment_id ON patient_photos(appointment_id);

-- Photo classification
CREATE INDEX idx_patient_photos_treatment_stage ON patient_photos(treatment_stage);
CREATE INDEX idx_patient_photos_facial_view ON patient_photos(facial_view);
CREATE INDEX idx_patient_photos_procedure_type ON patient_photos(procedure_type);
CREATE INDEX idx_patient_photos_validation_status ON patient_photos(validation_status);

-- Temporal queries
CREATE INDEX idx_patient_photos_captured_at ON patient_photos(captured_at DESC);

-- Composite index for patient timeline (most common query)
CREATE INDEX idx_patient_photos_timeline 
ON patient_photos(patient_id, treatment_stage, captured_at DESC);

-- Composite index for same-patient same-view comparison
CREATE INDEX idx_patient_photos_comparison 
ON patient_photos(patient_id, facial_view, treatment_stage, captured_at DESC);

-- Composite index for similar cases search
CREATE INDEX idx_patient_photos_similar_cases 
ON patient_photos(procedure_type, treatment_stage, facial_view, validation_status);

-- Storage path lookup (for duplicate prevention)
CREATE UNIQUE INDEX idx_patient_photos_storage_path ON patient_photos(local_storage_path);

-- ============================================
-- CONSTRAINTS
-- ============================================

-- Ensure treatment stage is valid
ALTER TABLE patient_photos 
ADD CONSTRAINT check_treatment_stage 
CHECK (treatment_stage IN (
  'Pre-Surgery',
  'Post-Surgery',
  'Follow-Up 1',
  'Follow-Up 2',
  'Follow-Up 3',
  'Follow-Up 4',
  'Follow-Up 5',
  'Additional Follow-Up'
));

-- Ensure facial view is one of the 8 standardized views
ALTER TABLE patient_photos 
ADD CONSTRAINT check_facial_view 
CHECK (facial_view IN (
  'frontal_neutral',
  'frontal_smiling',
  'right_oblique_45',
  'left_oblique_45',
  'right_lateral',
  'left_lateral',
  'basal',
  'top'
));

-- Ensure mime type is an image format
ALTER TABLE patient_photos 
ADD CONSTRAINT check_mime_type 
CHECK (mime_type IN (
  'image/jpeg',
  'image/jpg',
  'image/png',
  'image/webp'
));

-- File size limit (10MB)
ALTER TABLE patient_photos 
ADD CONSTRAINT check_file_size 
CHECK (file_size > 0 AND file_size <= 10485760);

-- ============================================
-- TRIGGERS
-- ============================================

-- Auto-update updated_at timestamp
CREATE TRIGGER trigger_update_patient_photos_updated_at
BEFORE UPDATE ON patient_photos
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- ROW LEVEL SECURITY
-- ============================================

-- Enable RLS
ALTER TABLE patient_photos ENABLE ROW LEVEL SECURITY;

-- Policy: Allow all operations for authenticated users (Doctor role)
-- In production, this should be more restrictive based on actual roles
CREATE POLICY "Allow all operations for authenticated users"
ON patient_photos
FOR ALL
USING (true)
WITH CHECK (true);

-- ============================================
-- HELPER FUNCTIONS
-- ============================================

-- Function to get photo count by treatment stage for a patient
CREATE OR REPLACE FUNCTION get_patient_photo_count_by_stage(p_patient_id UUID)
RETURNS TABLE(treatment_stage TEXT, photo_count BIGINT) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    pp.treatment_stage,
    COUNT(*)::BIGINT as photo_count
  FROM patient_photos pp
  WHERE pp.patient_id = p_patient_id
    AND pp.validation_status = 'valid'
  GROUP BY pp.treatment_stage
  ORDER BY 
    CASE pp.treatment_stage
      WHEN 'Pre-Surgery' THEN 1
      WHEN 'Post-Surgery' THEN 2
      WHEN 'Follow-Up 1' THEN 3
      WHEN 'Follow-Up 2' THEN 4
      WHEN 'Follow-Up 3' THEN 5
      WHEN 'Follow-Up 4' THEN 6
      WHEN 'Follow-Up 5' THEN 7
      WHEN 'Additional Follow-Up' THEN 8
      ELSE 9
    END;
END;
$$ LANGUAGE plpgsql;

-- Function to get photo completion status for a treatment stage
-- Returns which views are captured and which are missing
CREATE OR REPLACE FUNCTION get_treatment_stage_completion(
  p_patient_id UUID,
  p_treatment_stage TEXT
)
RETURNS TABLE(
  facial_view TEXT,
  is_captured BOOLEAN,
  photo_id UUID,
  captured_at TIMESTAMPTZ
) AS $$
BEGIN
  RETURN QUERY
  WITH all_views AS (
    SELECT unnest(ARRAY[
      'frontal_neutral',
      'frontal_smiling',
      'right_oblique_45',
      'left_oblique_45',
      'right_lateral',
      'left_lateral',
      'basal',
      'top'
    ]) AS view_name
  )
  SELECT 
    av.view_name AS facial_view,
    pp.id IS NOT NULL AS is_captured,
    pp.id AS photo_id,
    pp.captured_at
  FROM all_views av
  LEFT JOIN LATERAL (
    SELECT id, captured_at
    FROM patient_photos
    WHERE patient_id = p_patient_id
      AND treatment_stage = p_treatment_stage
      AND facial_view = av.view_name
      AND validation_status = 'valid'
    ORDER BY captured_at DESC
    LIMIT 1
  ) pp ON true
  ORDER BY 
    CASE av.view_name
      WHEN 'frontal_neutral' THEN 1
      WHEN 'frontal_smiling' THEN 2
      WHEN 'right_oblique_45' THEN 3
      WHEN 'left_oblique_45' THEN 4
      WHEN 'right_lateral' THEN 5
      WHEN 'left_lateral' THEN 6
      WHEN 'basal' THEN 7
      WHEN 'top' THEN 8
      ELSE 9
    END;
END;
$$ LANGUAGE plpgsql;

-- Function to find similar cases
CREATE OR REPLACE FUNCTION find_similar_cases(
  p_procedure_type TEXT,
  p_treatment_stage TEXT,
  p_facial_view TEXT,
  p_exclude_patient_id UUID DEFAULT NULL,
  p_limit INTEGER DEFAULT 10
)
RETURNS TABLE(
  patient_id UUID,
  photo_id UUID,
  patient_name TEXT,
  captured_at TIMESTAMPTZ,
  yaw NUMERIC,
  pitch NUMERIC,
  roll NUMERIC
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    pp.patient_id,
    pp.id AS photo_id,
    CONCAT(p.first_name, ' ', p.last_name) AS patient_name,
    pp.captured_at,
    pp.yaw,
    pp.pitch,
    pp.roll
  FROM patient_photos pp
  JOIN patients p ON pp.patient_id = p.id
  WHERE pp.procedure_type = p_procedure_type
    AND pp.treatment_stage = p_treatment_stage
    AND pp.facial_view = p_facial_view
    AND pp.validation_status = 'valid'
    AND (p_exclude_patient_id IS NULL OR pp.patient_id != p_exclude_patient_id)
  ORDER BY pp.captured_at DESC
  LIMIT p_limit;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- COMMENTS FOR DOCUMENTATION
-- ============================================

COMMENT ON TABLE patient_photos IS 'Stores metadata for patient facial photographs. Actual images are stored in local filesystem.';
COMMENT ON COLUMN patient_photos.local_storage_path IS 'Relative path to image file in local storage system. Actual filesystem path is resolved by backend.';
COMMENT ON COLUMN patient_photos.yaw IS 'Head rotation around vertical axis in degrees. 0=frontal, +ve=right, -ve=left';
COMMENT ON COLUMN patient_photos.pitch IS 'Head rotation around lateral axis in degrees. 0=level, +ve=up, -ve=down';
COMMENT ON COLUMN patient_photos.roll IS 'Head rotation around longitudinal axis in degrees. 0=level, +ve=right tilt, -ve=left tilt';
COMMENT ON COLUMN patient_photos.validation_status IS 'Result of CV validation: valid=passed all checks, invalid=failed validation, pending=not yet validated, error=validation service error';

-- ============================================
-- MIGRATION COMPLETE
-- ============================================
-- 
-- Summary:
-- - Created patient_photos table with comprehensive metadata fields
-- - Added 9 indexes for optimized queries
-- - Added 6 constraints for data integrity
-- - Enabled Row Level Security
-- - Created 3 helper functions for common queries
-- - Added audit trail with created_by and timestamps
-- 
-- Important Notes:
-- 1. This table stores METADATA ONLY
-- 2. Actual image files must be stored in local filesystem
-- 3. local_storage_path is a RELATIVE path, not absolute
-- 4. Backend service resolves actual filesystem location
-- 5. Never expose absolute filesystem paths to frontend
-- 
-- Next Steps:
-- 1. Run this migration in Supabase SQL Editor
-- 2. Create Express backend for file operations
-- 3. Create Python CV service for validation
-- 4. Implement frontend components
-- 
-- ============================================
