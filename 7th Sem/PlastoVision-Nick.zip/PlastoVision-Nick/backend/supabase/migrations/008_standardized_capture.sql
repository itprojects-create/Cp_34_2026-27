-- Additive migration. Apply after 007. Enroll clinicians explicitly through SQL/admin tools.
BEGIN;
CREATE TABLE IF NOT EXISTS clinic_clinicians (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  active boolean NOT NULL DEFAULT true
);
ALTER TABLE clinic_clinicians ENABLE ROW LEVEL SECURITY;
CREATE OR REPLACE FUNCTION public.is_clinic_clinician() RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM clinic_clinicians WHERE user_id = auth.uid() AND active)
$$;
REVOKE ALL ON FUNCTION public.is_clinic_clinician() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.is_clinic_clinician() TO authenticated;

CREATE TABLE IF NOT EXISTS patient_procedures (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  name text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (id, patient_id)
);
ALTER TABLE patient_procedures ENABLE ROW LEVEL SECURITY;
CREATE POLICY clinic_procedures ON patient_procedures FOR ALL TO authenticated
USING (public.is_clinic_clinician()) WITH CHECK (public.is_clinic_clinician());
ALTER TABLE patient_photos ADD COLUMN IF NOT EXISTS procedure_id uuid;
ALTER TABLE patient_photos ADD COLUMN IF NOT EXISTS framing_protocol text DEFAULT 'full_face'
  CHECK (framing_protocol IN ('full_face', 'nasal_focused', 'basal'));
ALTER TABLE patient_photos ADD COLUMN IF NOT EXISTS capture_setup jsonb DEFAULT '{}'::jsonb;
ALTER TABLE patient_photos ADD COLUMN IF NOT EXISTS clinician_confirmation jsonb;
ALTER TABLE patient_photos ADD COLUMN IF NOT EXISTS original_checksum text;
ALTER TABLE patient_photos ADD COLUMN IF NOT EXISTS image_width integer;
ALTER TABLE patient_photos ADD COLUMN IF NOT EXISTS image_height integer;
ALTER TABLE patient_photos DROP CONSTRAINT IF EXISTS patient_photos_validation_status_check;
ALTER TABLE patient_photos ADD CONSTRAINT patient_photos_validation_status_check
 CHECK (validation_status IN ('valid','invalid','pending','error','clinician_confirmed'));
ALTER TABLE patient_photos ADD CONSTRAINT photo_procedure_patient
 FOREIGN KEY (procedure_id, patient_id) REFERENCES patient_procedures(id, patient_id);
-- Existing unmatched legacy visit links must be repaired before this NOT VALID constraint is validated.
CREATE UNIQUE INDEX IF NOT EXISTS visits_id_patient ON visits(id,patient_id);
ALTER TABLE patient_photos ADD CONSTRAINT photo_visit_patient FOREIGN KEY (visit_id,patient_id)
 REFERENCES visits(id,patient_id) NOT VALID;
CREATE INDEX IF NOT EXISTS photo_visit_comparison ON patient_photos(patient_id,procedure_id,visit_id,facial_view,captured_at DESC);
DROP POLICY IF EXISTS "Allow all operations for authenticated users" ON patient_photos;
-- Browser may read metadata; writes must go through the validated local backend.
CREATE POLICY clinic_photo_metadata ON patient_photos FOR SELECT TO authenticated
USING (public.is_clinic_clinician());
COMMIT;
