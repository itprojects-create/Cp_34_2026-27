-- Create visits table
CREATE TABLE IF NOT EXISTS visits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  visit_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  diagnosis TEXT,
  doctor_notes TEXT,
  treatment_plan TEXT,
  follow_up_date DATE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create index on patient_id for faster lookups
CREATE INDEX IF NOT EXISTS idx_visits_patient_id ON visits(patient_id);

-- Create index on visit_date for sorting
CREATE INDEX IF NOT EXISTS idx_visits_visit_date ON visits(visit_date DESC);

-- Enable Row Level Security
ALTER TABLE visits ENABLE ROW LEVEL SECURITY;

-- Create policy to allow all operations for authenticated users
CREATE POLICY "Allow all operations for authenticated users"
ON visits
FOR ALL
USING (true)
WITH CHECK (true);
