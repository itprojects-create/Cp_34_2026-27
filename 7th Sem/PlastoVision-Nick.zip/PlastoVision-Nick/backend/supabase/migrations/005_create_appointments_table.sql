-- ============================================
-- APPOINTMENTS TABLE
-- ============================================
-- Create appointments table
CREATE TABLE IF NOT EXISTS appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  doctor_name TEXT NOT NULL,
  doctor_id TEXT,
  appointment_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  appointment_type TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Scheduled',
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for faster lookups
CREATE INDEX IF NOT EXISTS idx_appointments_patient_id ON appointments(patient_id);
CREATE INDEX IF NOT EXISTS idx_appointments_date ON appointments(appointment_date DESC);
CREATE INDEX IF NOT EXISTS idx_appointments_status ON appointments(status);
CREATE INDEX IF NOT EXISTS idx_appointments_doctor_id ON appointments(doctor_id);
CREATE INDEX IF NOT EXISTS idx_appointments_date_time ON appointments(appointment_date, start_time);

-- Create composite index for conflict detection
CREATE INDEX IF NOT EXISTS idx_appointments_conflict_check 
ON appointments(doctor_id, appointment_date, start_time, end_time)
WHERE status != 'Cancelled';

-- Create trigger to update updated_at on row update
CREATE TRIGGER trigger_update_appointments_updated_at
BEFORE UPDATE ON appointments
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

-- Add constraint to ensure end_time is after start_time
ALTER TABLE appointments 
ADD CONSTRAINT check_appointment_times 
CHECK (end_time > start_time);

-- Add constraint for valid appointment types
ALTER TABLE appointments 
ADD CONSTRAINT check_appointment_type 
CHECK (appointment_type IN (
  'Initial Consultation',
  'Follow-up',
  'Post-operative Checkup',
  'Pre-operative Consultation',
  'Surgery',
  'Rhinoplasty Consultation',
  'General Consultation',
  'Emergency',
  'Other'
));

-- Add constraint for valid statuses
ALTER TABLE appointments 
ADD CONSTRAINT check_appointment_status 
CHECK (status IN (
  'Scheduled',
  'Confirmed',
  'Completed',
  'Cancelled',
  'No Show'
));

-- Enable Row Level Security
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;

-- Create policy to allow all operations for authenticated users
CREATE POLICY "Allow all operations for authenticated users"
ON appointments
FOR ALL
USING (true)
WITH CHECK (true);

-- ============================================
-- CONFLICT DETECTION FUNCTION
-- ============================================
-- Function to check for appointment conflicts
CREATE OR REPLACE FUNCTION check_appointment_conflict(
  p_doctor_id TEXT,
  p_appointment_date DATE,
  p_start_time TIME,
  p_end_time TIME,
  p_appointment_id UUID DEFAULT NULL
)
RETURNS BOOLEAN AS $$
DECLARE
  conflict_count INTEGER;
BEGIN
  -- Check if there are any overlapping appointments for the same doctor
  -- Exclude the current appointment if updating (p_appointment_id is provided)
  -- Exclude cancelled appointments
  SELECT COUNT(*)
  INTO conflict_count
  FROM appointments
  WHERE doctor_id = p_doctor_id
    AND appointment_date = p_appointment_date
    AND status != 'Cancelled'
    AND (p_appointment_id IS NULL OR id != p_appointment_id)
    AND (
      -- New appointment starts during existing appointment
      (p_start_time >= start_time AND p_start_time < end_time)
      OR
      -- New appointment ends during existing appointment
      (p_end_time > start_time AND p_end_time <= end_time)
      OR
      -- New appointment completely encompasses existing appointment
      (p_start_time <= start_time AND p_end_time >= end_time)
    );
  
  RETURN conflict_count > 0;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- SETUP COMPLETE
-- ============================================
-- 
-- Next Steps:
-- 1. Implement appointment service layer
-- 2. Create appointment UI components
-- 3. Integrate with existing patient system
-- 
-- Tables: appointments
-- Functions: check_appointment_conflict
-- Indexes: Optimized for date/time queries and conflict detection
-- ============================================
