-- ============================================
-- CLINICIAN OVERRIDE TRACKING
-- ============================================
-- 
-- This migration adds columns to track when clinicians approve photos
-- that failed automatic validation, including the reason for override.
--
-- Use Case: A frontal photo may be classified as basal by CV service,
-- but the clinician reviews it and confirms it's actually frontal.
-- This override must be documented for audit and quality purposes.
-- ============================================

-- Add override tracking columns
ALTER TABLE patient_photos
ADD COLUMN IF NOT EXISTS clinician_override BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS override_reason TEXT,
ADD COLUMN IF NOT EXISTS override_by UUID REFERENCES patients(id), -- Will later reference users table when implemented
ADD COLUMN IF NOT EXISTS override_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS detected_view TEXT, -- What the CV system detected
ADD COLUMN IF NOT EXISTS view_confidence TEXT, -- confident, probable, uncertain
ADD COLUMN IF NOT EXISTS pose_reliable BOOLEAN; -- Was the pose estimation reliable?

-- Add index for querying overridden photos
CREATE INDEX IF NOT EXISTS idx_patient_photos_override 
ON patient_photos(clinician_override, patient_id, captured_at DESC) 
WHERE clinician_override = true;

-- Add constraint for override consistency
ALTER TABLE patient_photos 
ADD CONSTRAINT check_override_consistency
CHECK (
  (clinician_override = false) OR
  (clinician_override = true AND override_reason IS NOT NULL AND override_at IS NOT NULL)
);

-- ============================================
-- COMMENTS
-- ============================================

COMMENT ON COLUMN patient_photos.clinician_override IS 'True if clinician approved photo despite failed automatic validation';
COMMENT ON COLUMN patient_photos.override_reason IS 'Clinician explanation for approving photo that failed validation';
COMMENT ON COLUMN patient_photos.override_by IS 'User ID of clinician who approved the override';
COMMENT ON COLUMN patient_photos.override_at IS 'Timestamp when override was approved';
COMMENT ON COLUMN patient_photos.detected_view IS 'Facial view detected by CV system (may differ from facial_view)';
COMMENT ON COLUMN patient_photos.view_confidence IS 'Confidence level of CV detection: confident, probable, or uncertain';
COMMENT ON COLUMN patient_photos.pose_reliable IS 'Whether pose estimation was reliable (low reprojection error)';

-- ============================================
-- HELPER FUNCTION: Get Override Statistics
-- ============================================

CREATE OR REPLACE FUNCTION get_override_statistics(
  p_patient_id UUID DEFAULT NULL,
  p_start_date TIMESTAMPTZ DEFAULT NULL,
  p_end_date TIMESTAMPTZ DEFAULT NULL
)
RETURNS TABLE(
  total_photos BIGINT,
  overridden_photos BIGINT,
  override_percentage NUMERIC,
  by_detected_view JSONB
) AS $$
BEGIN
  RETURN QUERY
  WITH photo_stats AS (
    SELECT
      COUNT(*) as total,
      COUNT(*) FILTER (WHERE clinician_override = true) as overridden,
      ROUND(
        (COUNT(*) FILTER (WHERE clinician_override = true)::NUMERIC / 
         NULLIF(COUNT(*), 0) * 100), 2
      ) as override_pct,
      jsonb_object_agg(
        COALESCE(detected_view, 'unknown'),
        COUNT(*) FILTER (WHERE clinician_override = true AND detected_view IS NOT NULL)
      ) FILTER (WHERE clinician_override = true) as by_view
    FROM patient_photos
    WHERE (p_patient_id IS NULL OR patient_id = p_patient_id)
      AND (p_start_date IS NULL OR captured_at >= p_start_date)
      AND (p_end_date IS NULL OR captured_at <= p_end_date)
  )
  SELECT
    total::BIGINT,
    overridden::BIGINT,
    override_pct,
    COALESCE(by_view, '{}'::jsonb)
  FROM photo_stats;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION get_override_statistics IS 'Returns statistics about clinician overrides for quality monitoring';

-- ============================================
-- MIGRATION COMPLETE
-- ============================================
-- 
-- Added columns:
-- - clinician_override: boolean flag
-- - override_reason: text explanation
-- - override_by: clinician user ID
-- - override_at: timestamp
-- - detected_view: CV detected view
-- - view_confidence: detection confidence
-- - pose_reliable: pose quality flag
--
-- This enables:
-- 1. Full audit trail of validation overrides
-- 2. Quality metrics on CV accuracy
-- 3. Clinician decision transparency
-- 4. Future ML training data
-- ============================================
