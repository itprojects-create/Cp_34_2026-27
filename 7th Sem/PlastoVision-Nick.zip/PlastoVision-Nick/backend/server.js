/**
 * PlastoVision Express Backend Server
 * 
 * Handles local photo storage operations that cannot be done from browser.
 * Integrates with Python CV service for photo validation.
 * Stores only metadata in Supabase PostgreSQL.
 * 
 * IMPORTANT: Patient photos are stored LOCALLY, not in cloud storage.
 */

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
const fs = require('fs').promises;

// Import routes
const patientPhotosRoutes = require('./routes/patientPhotos');

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3001;

// ============================================
// MIDDLEWARE
// ============================================

// Security headers
app.use(helmet());

// CORS configuration
const corsOptions = {
  origin: process.env.CORS_ORIGINS 
    ? process.env.CORS_ORIGINS.split(',') 
    : ['http://localhost:5173', 'http://localhost:3000'],
  credentials: true,
  optionsSuccessStatus: 200
};
app.use(cors(corsOptions));

// Request logging
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
} else {
  app.use(morgan('combined'));
}

// Body parsing
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// ============================================
// ENSURE UPLOAD DIRECTORY EXISTS
// ============================================

// Handle both absolute and relative paths for PHOTO_STORAGE_PATH
const storagePath = process.env.PHOTO_STORAGE_PATH || './uploads/patients';
const UPLOAD_DIR = path.isAbsolute(storagePath) 
  ? storagePath 
  : path.join(__dirname, storagePath);

async function ensureUploadDirectory() {
  try {
    await fs.access(UPLOAD_DIR);
    console.log(`✅ Upload directory exists: ${UPLOAD_DIR}`);
  } catch {
    try {
      await fs.mkdir(UPLOAD_DIR, { recursive: true });
      console.log(`✅ Created upload directory: ${UPLOAD_DIR}`);
    } catch (error) {
      console.error(`❌ Failed to create upload directory: ${error.message}`);
      process.exit(1);
    }
  }
}

// ============================================
// ROUTES
// ============================================

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'PlastoVision Backend',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development',
  });
});

// Patient photos routes
app.use('/api/patient-photos', patientPhotosRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    error: 'Not Found',
    message: `Cannot ${req.method} ${req.url}`,
    timestamp: new Date().toISOString()
  });
});

// ============================================
// ERROR HANDLER
// ============================================

app.use((err, req, res, next) => {
  console.error('❌ Error:', err);
  
  // Multer errors (file upload)
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({
      error: 'File Too Large',
      message: `File size exceeds ${process.env.MAX_FILE_SIZE_MB || 10}MB limit`,
      timestamp: new Date().toISOString()
    });
  }
  
  if (err.code === 'LIMIT_UNEXPECTED_FILE') {
    return res.status(400).json({
      error: 'Invalid Upload',
      message: 'Unexpected field name in upload',
      timestamp: new Date().toISOString()
    });
  }
  
  // Validation errors
  if (err.name === 'ValidationError') {
    return res.status(400).json({
      error: 'Validation Error',
      message: err.message,
      details: err.details || null,
      timestamp: new Date().toISOString()
    });
  }
  
  // Default error response
  const statusCode = err.statusCode || err.status || 500;
  res.status(statusCode).json({
    error: err.name || 'Internal Server Error',
    message: err.message || 'An unexpected error occurred',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
    timestamp: new Date().toISOString()
  });
});

// ============================================
// START SERVER
// ============================================

async function startServer() {
  try {
    // Ensure upload directory exists
    await ensureUploadDirectory();
    
    // Verify Supabase configuration
    if (!process.env.SUPABASE_URL || !process.env.SUPABASE_ANON_KEY) {
      console.warn('⚠️  Warning: Supabase credentials not configured');
      console.warn('   Set SUPABASE_URL and SUPABASE_ANON_KEY in .env file');
    }
    
    // Verify Python CV service configuration
    if (!process.env.PYTHON_CV_SERVICE_URL) {
      console.warn('⚠️  Warning: Python CV service URL not configured');
      console.warn('   Set PYTHON_CV_SERVICE_URL in .env file');
      console.warn('   Photo validation will not work without CV service');
    }
    
    // Start listening
    app.listen(PORT, process.env.HOST || '127.0.0.1', () => {
      console.log('');
      console.log('🏥 ========================================');
      console.log('   PlastoVision Backend Server');
      console.log('   ========================================');
      console.log(`   Environment: ${process.env.NODE_ENV || 'development'}`);
      console.log(`   Port: ${PORT}`);
      console.log(`   URL: http://localhost:${PORT}`);
      console.log(`   Upload Directory: ${UPLOAD_DIR}`);
      console.log('   ========================================');
      console.log('');
      console.log('📋 Available Endpoints:');
      console.log(`   GET  /api/health - Health check`);
      console.log(`   POST /api/patient-photos/upload - Upload photo`);
      console.log(`   GET  /api/patient-photos/:id - Get photo file`);
      console.log(`   GET  /api/patient-photos/metadata/:id - Get metadata`);
      console.log(`   DELETE /api/patient-photos/:id - Delete photo`);
      console.log('');
      console.log('✅ Server is running and ready to accept requests');
      console.log('');
    });
  } catch (error) {
    console.error('❌ Failed to start server:', error);
    process.exit(1);
  }
}

// Handle graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM signal received: closing HTTP server');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT signal received: closing HTTP server');
  process.exit(0);
});

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  console.error('❌ Uncaught Exception:', error);
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('❌ Unhandled Rejection at:', promise, 'reason:', reason);
  process.exit(1);
});

// Start the server
if (require.main === module) startServer();

module.exports = app;
 
