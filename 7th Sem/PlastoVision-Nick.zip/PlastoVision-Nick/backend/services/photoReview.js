/** Review cannot bypass decoding errors, no/multiple faces, clipping or unacceptable quality. */
function reviewDecision(validation, reason) {
  const gazePass = !(validation.gaze_required === true || validation.facial_view === 'frontal_neutral') || validation.gaze_ok === true;
  if (validation.valid === true && validation.capture_ready === true && validation.face_count === 1 &&
      validation.quality_ok === true && validation.framing_ok === true && gazePass) return { status: 'valid', confirmation: null };
  if (!validation.reviewable || validation.face_count !== 1 || !validation.quality_ok || !validation.framing_ok || validation.state === 'ERROR') {
    throw Object.assign(new Error('Photo fails mandatory measurable checks; retake required'), { status: 422 });
  }
  if (validation.automation_mode === 'experimental' && validation.experimental_capture_ready === true &&
      validation.capture_ready === true && validation.auto_capture_eligible === true &&
      validation.pose_estimated === true && validation.alignment_ok === true &&
      validation.anatomical_evidence?.passed === true && gazePass &&
      ['frontal_neutral','right_oblique_45','left_oblique_45'].includes(validation.facial_view)) {
    return { status: 'pending', confirmation: null };
  }
  if (typeof reason !== 'string' || reason.trim().length < 15 || reason.length > 2000) {
    throw Object.assign(new Error('Clinician confirmation requires a review reason of 15–2000 characters'), { status: 422 });
  }
  return { status: 'clinician_confirmed', confirmation: { clinician_id: null, identity_verified: false, reason: reason.trim(), confirmed_at: new Date().toISOString() } };
}
module.exports = { reviewDecision };
