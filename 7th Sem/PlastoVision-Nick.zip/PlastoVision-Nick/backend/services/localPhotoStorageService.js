/**
 * Local Photo Storage Service
 * 
 * Handles secure file operations on local filesystem.
 * 
 * SECURITY FEATURES:
 * - Path traversal protection
 * - Unique filenames with UUIDs
 * - Organized directory structure
 * - Safe file deletion
 * - No direct path exposure
 * 
 * STORAGE STRUCTURE:
 * uploads/patients/
 *   └── {patient_uuid}/
 *       └── visits/
 *           └── {visit_uuid}/
 *               └── facial/
 *                   └── {treatment_stage}/
 *                       └── {facial_view}/
 *                           └── photo_{timestamp}_{uuid}.jpg
 */

const fs = require('fs').promises;
const path = require('path');
const { randomUUID: uuidv4, createHash } = require('node:crypto');
const sharp = require('sharp');

// Base upload directory (configurable via env)
const BASE_UPLOAD_DIR = path.resolve(
  __dirname,
  '..',
  process.env.PHOTO_STORAGE_PATH || './uploads/patients'
);

/**
 * Validate and sanitize path to prevent directory traversal attacks
 * 
 * @param {string} inputPath - User-provided path component
 * @returns {string} Sanitized path
 * @throws {Error} If path contains traversal attempts
 */
function sanitizePath(inputPath) {
  if (typeof inputPath !== 'string' || !inputPath || path.isAbsolute(inputPath) ||
      inputPath.includes('\\') || inputPath.split('/').some(part => !part || part === '.' || part === '..') || inputPath.includes('\0')) {
    throw new Error('Unsafe storage path');
  }
  return inputPath;
}

/**
 * Build storage path for a photo
 * 
 * @param {Object} options - Path components
 * @param {string} options.patientId - Patient UUID
 * @param {string} [options.visitId] - Visit UUID (optional)
 * @param {string} options.treatmentStage - Treatment stage
 * @param {string} options.facialView - Facial view
 * @returns {string} Relative storage path
 */
function buildStoragePath({ patientId, visitId, treatmentStage, facialView }) {
  for (const value of [patientId, visitId, treatmentStage, facialView].filter(Boolean)) {
    if (/[\\/]/.test(value)) throw new Error('Unsafe storage component');
  }
  // Sanitize all components
  const safePatientId = sanitizePath(patientId);
  const safeTreatmentStage = sanitizePath(treatmentStage.toLowerCase().replace(/\s+/g, '_'));
  const safeFacialView = sanitizePath(facialView);
  
  // Build path components
  const pathComponents = [
    safePatientId,
    'visits'
  ];
  
  // Add visit ID if provided
  if (visitId) {
    pathComponents.push(sanitizePath(visitId));
  } else {
    pathComponents.push('general');
  }
  
  pathComponents.push('facial', safeTreatmentStage, safeFacialView);
  
  return path.join(...pathComponents);
}

/**
 * Generate unique filename
 * 
 * @param {string} originalExtension - File extension (e.g., '.jpg')
 * @returns {string} Unique filename
 */
function generateFilename(originalExtension) {
  const timestamp = Date.now();
  const uniqueId = uuidv4().split('-')[0];
  return `photo_${timestamp}_${uniqueId}${originalExtension}`;
}

/**
 * Ensure directory exists, create if not
 * 
 * @param {string} dirPath - Directory path
 */
async function ensureDirectory(dirPath) {
  await fs.mkdir(BASE_UPLOAD_DIR, { recursive: true, mode: 0o700 });
  await fs.chmod(BASE_UPLOAD_DIR, 0o700);
  const relative = path.relative(BASE_UPLOAD_DIR, dirPath);
  if (relative.startsWith('..') || path.isAbsolute(relative)) throw new Error('Unsafe storage directory');
  let current = BASE_UPLOAD_DIR;
  for (const part of relative.split(path.sep).filter(Boolean)) {
    current = path.join(current, part);
    await fs.mkdir(current, { mode: 0o700 }).catch(error => { if (error.code !== 'EEXIST') throw error; });
    if ((await fs.lstat(current)).isSymbolicLink()) throw new Error('Storage symlinks are not allowed');
    await fs.chmod(current, 0o700);
  }
}

async function verifyRealPath(fullPath) {
  const [realBase, realFile] = await Promise.all([fs.realpath(BASE_UPLOAD_DIR), fs.realpath(fullPath)]);
  if (!realFile.startsWith(realBase + path.sep)) throw new Error('Access denied: Storage symlink escapes base directory');
}

/**
 * Save photo to local storage
 * 
 * @param {Buffer} fileBuffer - Image file buffer
 * @param {Object} options - Storage options
 * @param {string} options.patientId - Patient UUID
 * @param {string} [options.visitId] - Visit UUID
 * @param {string} options.treatmentStage - Treatment stage
 * @param {string} options.facialView - Facial view
 * @param {string} options.mimeType - MIME type
 * @returns {Promise<Object>} Storage result
 */
async function savePhoto(fileBuffer, options) {
  try {
    const { patientId, visitId, treatmentStage, facialView, mimeType } = options;
    
    // Validate required parameters
    if (!patientId || !treatmentStage || !facialView) {
      throw new Error('Missing required parameters: patientId, treatmentStage, facialView');
    }
    
    // Get file extension from MIME type
    const extension = mimeType === 'image/png' ? '.png' : '.jpg';
    
    // Build relative storage path
    const relativePath = buildStoragePath({
      patientId,
      visitId,
      treatmentStage,
      facialView
    });
    
    // Generate unique filename
    const filename = generateFilename(extension);
    
    // Build full directory path
    const fullDirPath = path.join(BASE_UPLOAD_DIR, relativePath);
    
    // Ensure directory exists
    await ensureDirectory(fullDirPath);
    
    // Build full file path
    const fullFilePath = path.join(fullDirPath, filename);
    
    // Decode content before writing; preserve original bytes and checksum.
    const decoded = await sharp(fileBuffer, { limitInputPixels: 40000000 }).metadata();
    if (!['jpeg', 'png'].includes(decoded.format) ||
        (decoded.format === 'png') !== (mimeType === 'image/png')) {
      throw new Error('Image content does not match declared type');
    }
    await sharp(fileBuffer, { limitInputPixels: 40000000 }).stats();
    await fs.writeFile(fullFilePath, fileBuffer, { mode: 0o600, flag: 'wx' });

    // Get file stats
    const stats = await fs.stat(fullFilePath);
    
    // Return storage result with RELATIVE path only
    // Never expose absolute filesystem paths
    return {
      success: true,
      relativePath: path.join(relativePath, filename),
      filename: filename,
      fileSize: stats.size,
      width: decoded.width, height: decoded.height,
      checksum: createHash('sha256').update(fileBuffer).digest('hex'),
      fullPath: fullFilePath // Internal use only, not exposed to API
    };
    
  } catch (error) {
    console.error('Error saving photo:', error);
    throw new Error(`Failed to save photo: ${error.message}`);
  }
}

// A protected sidecar keeps capture metadata beside the unchanged original on
// the same local device. No image bytes are sent to a cloud storage service.
async function savePhotoSidecar(relativePath, metadata) {
  const safePath = sanitizePath(relativePath);
  const imagePath = path.join(BASE_UPLOAD_DIR, safePath);
  await verifyRealPath(imagePath);
  const sidecarPath = `${imagePath}.json`;
  const file = await fs.open(sidecarPath, 'wx', 0o600);
  try {
    await file.writeFile(JSON.stringify({ schema_version: 1, photo: metadata }, null, 2));
    await file.sync();
  } finally { await file.close(); }
  return `${safePath}.json`;
}

/**
 * Get photo from storage
 * 
 * @param {string} relativePath - Relative storage path
 * @returns {Promise<Buffer>} File buffer
 */
async function getPhoto(relativePath) {
  try {
    // Sanitize path
    const safePath = sanitizePath(relativePath);
    
    // Build full path
    const fullPath = path.join(BASE_UPLOAD_DIR, safePath);
    
    // Verify path is within BASE_UPLOAD_DIR (security check)
    const resolvedPath = path.resolve(fullPath);
    const resolvedBase = path.resolve(BASE_UPLOAD_DIR);
    
    if (!resolvedPath.startsWith(resolvedBase + path.sep)) {
      throw new Error('Access denied: Path outside base directory');
    }
    
    // Check if file exists
    await verifyRealPath(fullPath);
    await fs.access(fullPath);
    
    // Read and return file
    return await fs.readFile(fullPath);
    
  } catch (error) {
    if (error.code === 'ENOENT') {
      throw new Error('Photo not found');
    }
    console.error('Error retrieving photo:', error);
    throw new Error(`Failed to retrieve photo: ${error.message}`);
  }
}

/**
 * Check if photo exists
 * 
 * @param {string} relativePath - Relative storage path
 * @returns {Promise<boolean>} True if exists
 */
async function photoExists(relativePath) {
  try {
    const safePath = sanitizePath(relativePath);
    const fullPath = path.join(BASE_UPLOAD_DIR, safePath);
    
    // Verify path is within BASE_UPLOAD_DIR
    const resolvedPath = path.resolve(fullPath);
    const resolvedBase = path.resolve(BASE_UPLOAD_DIR);
    
    if (!resolvedPath.startsWith(resolvedBase + path.sep)) {
      return false;
    }
    
    await verifyRealPath(fullPath);
    await fs.access(fullPath);
    return true;
  } catch {
    return false;
  }
}

/**
 * Delete photo from storage
 * 
 * @param {string} relativePath - Relative storage path
 * @returns {Promise<boolean>} True if deleted
 */
async function deletePhoto(relativePath) {
  try {
    const safePath = sanitizePath(relativePath);
    const fullPath = path.join(BASE_UPLOAD_DIR, safePath);
    
    // Verify path is within BASE_UPLOAD_DIR
    const resolvedPath = path.resolve(fullPath);
    const resolvedBase = path.resolve(BASE_UPLOAD_DIR);
    
    if (!resolvedPath.startsWith(resolvedBase + path.sep)) {
      throw new Error('Access denied: Path outside base directory');
    }
    
    // Check if file exists
    await verifyRealPath(fullPath);
    await fs.access(fullPath);
    
    // Delete file
    await fs.unlink(fullPath);
    await fs.unlink(`${fullPath}.json`).catch(error => { if (error.code !== 'ENOENT') throw error; });
    
    // Optionally clean up empty directories
    await cleanupEmptyDirectories(path.dirname(fullPath));
    
    return true;
    
  } catch (error) {
    if (error.code === 'ENOENT') {
      // File doesn't exist, consider it deleted
      return true;
    }
    console.error('Error deleting photo:', error);
    throw new Error(`Failed to delete photo: ${error.message}`);
  }
}

/**
 * Clean up empty directories after file deletion
 * Only removes empty directories up to patient level
 * 
 * @param {string} dirPath - Directory path to start cleanup
 */
async function cleanupEmptyDirectories(dirPath) {
  try {
    // Don't clean up base directory
    if (dirPath === BASE_UPLOAD_DIR) {
      return;
    }
    
    // Check if directory is empty
    const files = await fs.readdir(dirPath);
    
    if (files.length === 0) {
      // Directory is empty, remove it
      await fs.rmdir(dirPath);
      
      // Recursively check parent directory
      await cleanupEmptyDirectories(path.dirname(dirPath));
    }
  } catch (error) {
    // Ignore errors during cleanup
    // This is a best-effort operation
  }
}

/**
 * Get file extension from MIME type
 * 
 * @param {string} mimeType - MIME type
 * @returns {string} File extension
 */
function getExtensionFromMimeType(mimeType) {
  const mimeMap = {
    'image/jpeg': '.jpg',
    'image/jpg': '.jpg',
    'image/png': '.png',
    'image/webp': '.webp'
  };
  
  return mimeMap[mimeType] || '.jpg';
}

/**
 * Get storage statistics
 * 
 * @returns {Promise<Object>} Storage stats
 */
async function getStorageStats() {
  try {
    // This is a simplified version
    // In production, you might want to cache this or compute it differently
    
    let totalSize = 0;
    let totalFiles = 0;
    
    async function scanDirectory(dirPath) {
      try {
        const entries = await fs.readdir(dirPath, { withFileTypes: true });
        
        for (const entry of entries) {
          const fullPath = path.join(dirPath, entry.name);
          
          if (entry.isDirectory()) {
            await scanDirectory(fullPath);
          } else if (entry.isFile()) {
            const stats = await fs.stat(fullPath);
            totalSize += stats.size;
            totalFiles++;
          }
        }
      } catch (error) {
        // Skip directories we can't read
      }
    }
    
    await scanDirectory(BASE_UPLOAD_DIR);
    
    return {
      totalFiles,
      totalSizeBytes: totalSize,
      totalSizeMB: (totalSize / (1024 * 1024)).toFixed(2),
      baseDirectory: BASE_UPLOAD_DIR
    };
    
  } catch (error) {
    console.error('Error getting storage stats:', error);
    return {
      totalFiles: 0,
      totalSizeBytes: 0,
      totalSizeMB: '0.00',
      baseDirectory: BASE_UPLOAD_DIR,
      error: error.message
    };
  }
}

/**
 * Create thumbnail for a photo
 * 
 * @param {string} relativePath - Original photo path
 * @param {number} width - Thumbnail width
 * @returns {Promise<Buffer>} Thumbnail buffer
 */
async function createThumbnail(relativePath, width = 300) {
  try {
    const photoBuffer = await getPhoto(relativePath);
    
    // Create thumbnail using sharp
    const thumbnail = await sharp(photoBuffer)
      .resize(width, null, {
        fit: 'inside',
        withoutEnlargement: true
      })
      .jpeg({ quality: 80 })
      .toBuffer();
    
    return thumbnail;
    
  } catch (error) {
    console.error('Error creating thumbnail:', error);
    throw new Error(`Failed to create thumbnail: ${error.message}`);
  }
}

module.exports = {
  savePhoto,
  savePhotoSidecar,
  getPhoto,
  photoExists,
  deletePhoto,
  getStorageStats,
  createThumbnail,
  buildStoragePath,
  BASE_UPLOAD_DIR
};
