/**
 * Photo Metadata Service
 * 
 * Handles database operations for patient photo metadata.
 * Works with Supabase PostgreSQL to store/retrieve metadata only.
 * Actual image files are stored locally via localPhotoStorageService.
 */

const { supabaseAdmin } = require('../config/supabase');
const { packPhotoMetadata, unpackPhotoMetadata, isMissingCaptureColumn, isLegacyReviewConstraint } = require('./photoMetadataCompatibility');
async function findCaptureMetadata(id) {
  const result = await supabaseAdmin.from('patient_photos').select('*').eq('id', id).maybeSingle();
  return { ...result, data: unpackPhotoMetadata(result.data) };
}

/**
 * Create photo metadata record
 * 
 * @param {Object} metadata - Photo metadata
 * @returns {Promise<Object>} Created record
 */
async function createPhotoMetadata(metadata) {
  try {
    let { data, error } = await supabaseAdmin
      .from('patient_photos')
      .insert([packPhotoMetadata(metadata)])
      .select()
      .single();
    if (isMissingCaptureColumn(error) || (metadata.validation_status === 'clinician_confirmed' && isLegacyReviewConstraint(error))) {
      ({ data, error } = await supabaseAdmin.from('patient_photos')
        .insert([packPhotoMetadata(metadata, true)]).select().single());
    }
    
    if (error) throw error;
    
    return { data: unpackPhotoMetadata(data), error: null };
  } catch (error) {
    console.error('Error creating photo metadata:', error);
    return { data: null, error: error.message, code: error.code };
  }
}

/**
 * Get photo metadata by ID
 * 
 * @param {string} photoId - Photo UUID
 * @returns {Promise<Object>} Photo metadata
 */
async function getPhotoMetadata(photoId) {
  try {
    const { data, error } = await supabaseAdmin
      .from('patient_photos')
      .select('*')
      .eq('id', photoId)
      .single();
    
    if (error) throw error;
    
    return { data: unpackPhotoMetadata(data), error: null };
  } catch (error) {
    console.error('Error fetching photo metadata:', error);
    return { data: null, error: error.message };
  }
}

/**
 * Get all photos for a patient
 * 
 * @param {string} patientId - Patient UUID
 * @param {Object} filters - Optional filters
 * @returns {Promise<Object>} Array of photo metadata
 */
async function getPatientPhotos(patientId, filters = {}) {
  try {
    let query = supabaseAdmin
      .from('patient_photos')
      .select(`
        *,
        visit:visits(id, visit_date, diagnosis, doctor_notes)
      `)
      .eq('patient_id', patientId)
      .order('captured_at', { ascending: false });
    
    // Apply filters
    if (filters.treatmentStage) {
      query = query.eq('treatment_stage', filters.treatmentStage);
    }
    
    if (filters.facialView) {
      query = query.eq('facial_view', filters.facialView);
    }
    
    if (filters.validationStatus) {
      query = query.eq('validation_status', filters.validationStatus);
    }
    
    if (filters.procedureId) query = query.eq('procedure_id', filters.procedureId);
    if (filters.visitId) {
      query = query.eq('visit_id', filters.visitId);
    }
    
    if (filters.procedureType) {
      query = query.eq('procedure_type', filters.procedureType);
    }
    
    // Pagination
    if (filters.limit) {
      query = query.limit(filters.limit);
    }
    
    if (filters.offset) {
      query = query.range(filters.offset, filters.offset + (filters.limit || 50) - 1);
    }
    
    const { data, error } = await query;
    
    if (error) throw error;
    
    return { data: data?.map(unpackPhotoMetadata), error: null };
  } catch (error) {
    console.error('Error fetching patient photos:', error);
    return { data: null, error: error.message };
  }
}

/**
 * Get photos for a specific visit
 * 
 * @param {string} visitId - Visit UUID
 * @returns {Promise<Object>} Array of photo metadata
 */
async function getVisitPhotos(visitId) {
  try {
    const { data, error } = await supabaseAdmin
      .from('patient_photos')
      .select('*')
      .eq('visit_id', visitId)
      .order('facial_view');
    
    if (error) throw error;
    
    return { data: data?.map(unpackPhotoMetadata), error: null };
  } catch (error) {
    console.error('Error fetching visit photos:', error);
    return { data: null, error: error.message };
  }
}

/**
 * Update photo metadata
 * 
 * @param {string} photoId - Photo UUID
 * @param {Object} updates - Fields to update
 * @returns {Promise<Object>} Updated record
 */
async function updatePhotoMetadata(photoId, updates) {
  try {
    // Remove fields that shouldn't be updated
    const { id, created_at, local_storage_path, ...allowedUpdates } = updates;
    
    const { data, error } = await supabaseAdmin
      .from('patient_photos')
      .update(allowedUpdates)
      .eq('id', photoId)
      .select()
      .single();
    
    if (error) throw error;
    
    return { data, error: null };
  } catch (error) {
    console.error('Error updating photo metadata:', error);
    return { data: null, error: error.message };
  }
}

/**
 * Delete photo metadata
 * 
 * @param {string} photoId - Photo UUID
 * @returns {Promise<Object>} Deletion result
 */
async function deletePhotoMetadata(photoId) {
  try {
    const { error } = await supabaseAdmin
      .from('patient_photos')
      .delete()
      .eq('id', photoId);
    
    if (error) throw error;
    
    return { success: true, error: null };
  } catch (error) {
    console.error('Error deleting photo metadata:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Get photo count by treatment stage for a patient
 * Uses the database helper function
 * 
 * @param {string} patientId - Patient UUID
 * @returns {Promise<Object>} Photo counts by stage
 */
async function getPhotoCountByStage(patientId) {
  try {
    const { data, error } = await supabaseAdmin
      .rpc('get_patient_photo_count_by_stage', {
        p_patient_id: patientId
      });
    
    if (error) throw error;
    
    return { data, error: null };
  } catch (error) {
    console.error('Error getting photo count by stage:', error);
    return { data: null, error: error.message };
  }
}

/**
 * Get treatment stage completion status
 * Shows which views are captured and which are missing
 * 
 * @param {string} patientId - Patient UUID
 * @param {string} treatmentStage - Treatment stage
 * @returns {Promise<Object>} Completion status
 */
async function getTreatmentStageCompletion(patientId, treatmentStage) {
  try {
    const { data, error } = await supabaseAdmin
      .rpc('get_treatment_stage_completion', {
        p_patient_id: patientId,
        p_treatment_stage: treatmentStage
      });
    
    if (error) throw error;
    
    return { data, error: null };
  } catch (error) {
    console.error('Error getting treatment stage completion:', error);
    return { data: null, error: error.message };
  }
}

/**
 * Find similar cases
 * 
 * @param {Object} criteria - Search criteria
 * @returns {Promise<Object>} Similar cases
 */
async function findSimilarCases(criteria) {
  try {
    const {
      procedureType,
      treatmentStage,
      facialView,
      excludePatientId,
      limit = 10
    } = criteria;
    
    const { data, error } = await supabaseAdmin
      .rpc('find_similar_cases', {
        p_procedure_type: procedureType,
        p_treatment_stage: treatmentStage,
        p_facial_view: facialView,
        p_exclude_patient_id: excludePatientId || null,
        p_limit: limit
      });
    
    if (error) throw error;
    
    return { data, error: null };
  } catch (error) {
    console.error('Error finding similar cases:', error);
    return { data: null, error: error.message };
  }
}

/**
 * Get photo statistics for a patient
 * 
 * @param {string} patientId - Patient UUID
 * @returns {Promise<Object>} Photo statistics
 */
async function getPatientPhotoStats(patientId) {
  try {
    const { data, error } = await supabaseAdmin
      .from('patient_photos')
      .select('*')
      .eq('patient_id', patientId);
    
    if (error) throw error;
    
    const photos = data.map(unpackPhotoMetadata);
    // Calculate statistics
    const stats = {
      total: photos.length,
      valid: photos.filter(p => ['valid', 'clinician_confirmed'].includes(p.validation_status)).length,
      invalid: photos.filter(p => p.validation_status === 'invalid').length,
      byStage: {},
      byView: {},
      completionPercentage: 0
    };
    
    // Count by treatment stage
    photos.forEach(photo => {
      stats.byStage[photo.treatment_stage] = (stats.byStage[photo.treatment_stage] || 0) + 1;
      stats.byView[photo.facial_view] = (stats.byView[photo.facial_view] || 0) + 1;
    });
    
    const views = new Set(['frontal_neutral','right_oblique_45','right_lateral','left_oblique_45','left_lateral','basal']);
    const sessions = new Set(photos.map(p => `${p.visit_id || 'legacy'}:${p.procedure_id || 'legacy'}`));
    
    // Count DISTINCT views per session (not total photos)
    const sessionViews = new Map();
    photos.filter(p => views.has(p.facial_view) && ['valid','clinician_confirmed'].includes(p.validation_status))
      .forEach(p => {
        const sessionKey = `${p.visit_id || 'legacy'}:${p.procedure_id || 'legacy'}`;
        if (!sessionViews.has(sessionKey)) {
          sessionViews.set(sessionKey, new Set());
        }
        sessionViews.get(sessionKey).add(p.facial_view);
      });
    
    // Calculate total distinct views across all sessions
    const totalDistinctViews = Array.from(sessionViews.values())
      .reduce((sum, viewSet) => sum + viewSet.size, 0);
    
    // Completion = distinct views / (sessions × 6), capped at 100%
    const rawPercentage = sessions.size ? (100 * totalDistinctViews / (sessions.size * 6)) : 0;
    stats.completionPercentage = Math.min(100, Math.round(rawPercentage));

    return { data: stats, error: null };
  } catch (error) {
    console.error('Error getting patient photo stats:', error);
    return { data: null, error: error.message };
  }
}

/**
 * Check if a photo with same parameters already exists
 * 
 * @param {Object} params - Photo parameters
 * @returns {Promise<Object>} Existing photo or null
 */
async function findExistingPhoto(params) {
  try {
    const { patientId, treatmentStage, facialView, visitId } = params;
    
    let query = supabaseAdmin
      .from('patient_photos')
      .select('*')
      .eq('patient_id', patientId)
      .eq('treatment_stage', treatmentStage)
      .eq('facial_view', facialView)
      .eq('validation_status', 'valid')
      .order('captured_at', { ascending: false })
      .limit(1);
    
    if (visitId) {
      query = query.eq('visit_id', visitId);
    }
    
    const { data, error } = await query;
    
    if (error) throw error;
    
    return { data: data && data.length > 0 ? data[0] : null, error: null };
  } catch (error) {
    console.error('Error finding existing photo:', error);
    return { data: null, error: error.message };
  }
}

module.exports = {
  findCaptureMetadata,
  createPhotoMetadata,
  getPhotoMetadata,
  getPatientPhotos,
  getVisitPhotos,
  updatePhotoMetadata,
  deletePhotoMetadata,
  getPhotoCountByStage,
  getTreatmentStageCompletion,
  findSimilarCases,
  getPatientPhotoStats,
  findExistingPhoto
};
