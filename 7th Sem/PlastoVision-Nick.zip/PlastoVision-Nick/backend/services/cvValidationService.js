/**
 * CV Validation Service
 * 
 * Integrates with Python Computer Vision service for photo validation.
 * Sends images to Python service for:
 * - Face detection
 * - Landmark detection
 * - Pose estimation (yaw, pitch, roll)
 * - Facial view validation
 * - Image quality checks
 */

const axios = require('axios');
const FormData = require('form-data');
const { getFacialView } = require('../config/facialViews');

// Python CV service URL
const PYTHON_CV_URL = process.env.PYTHON_CV_SERVICE_URL || 'http://127.0.0.1:5002';

/**
 * Validate photo against selected facial view
 * 
 * @param {Buffer} imageBuffer - Image buffer
 * @param {string} facialView - Selected facial view ID
 * @param {string} filename - Original filename
 * @returns {Promise<Object>} Validation result
 */
async function validatePhoto(imageBuffer, facialView, filename = 'photo.jpg', setup = {}) {
  try {
    // Get facial view configuration
    const viewConfig = getFacialView(facialView);
    
    if (!viewConfig) {
      return {
        valid: false,
        error: 'Invalid facial view specified',
        validation_status: 'error'
      };
    }
    
    // Create form data
    const formData = new FormData();
    formData.append('photo', imageBuffer, {
      filename: filename,
      contentType: 'image/jpeg'
    });
    formData.append('facial_view', facialView);
    formData.append('setup', JSON.stringify(setup));
    // Send to Python CV service
    const response = await axios.post(
      `${PYTHON_CV_URL}/validate`,
      formData,
      {
        headers: formData.getHeaders(),
        timeout: 30000, // 30 second timeout
        maxContentLength: Infinity,
        maxBodyLength: Infinity
      }
    );
    
    // Parse response
    const result = response.data;
    
    // Enhance result with additional context
    return {
      ...result,
      facial_view: facialView,
      view_name: viewConfig.name,
      validation_status: result.valid ? 'valid' : 'invalid',
      timestamp: new Date().toISOString()
    };
    
  } catch (error) {
    console.error('CV validation error:', error.message);
    
    // Check if Python service is unavailable
    if (error.code === 'ECONNREFUSED' || error.code === 'ENOTFOUND') {
      return {
        valid: false,
        error: 'Computer vision service is unavailable',
        validation_status: 'error',
        face_detected: false,
        landmarks_detected: false,
        errors: ['CV service connection failed'],
        warnings: ['Photo validation could not be performed'],
        timestamp: new Date().toISOString()
      };
    }
    
    // Check for timeout
    if (error.code === 'ECONNABORTED') {
      return {
        valid: false,
        error: 'Validation timeout',
        validation_status: 'error',
        errors: ['Validation took too long'],
        timestamp: new Date().toISOString()
      };
    }
    
    // Other errors
    return {
      valid: false,
      error: error.message,
      validation_status: 'error',
      errors: [error.message],
      timestamp: new Date().toISOString()
    };
  }
}

/**
 * Check if Python CV service is available
 * 
 * @returns {Promise<boolean>} True if service is available
 */
async function checkCVServiceHealth() {
  try {
    const response = await axios.get(`${PYTHON_CV_URL}/health`, {
      timeout: 5000
    });
    
    return response.status === 200;
  } catch (error) {
    console.error('CV service health check failed:', error.message);
    return false;
  }
}

/**
 * Get CV service information
 * 
 * @returns {Promise<Object>} Service info
 */
async function getCVServiceInfo() {
  try {
    const response = await axios.get(`${PYTHON_CV_URL}/info`, {
      timeout: 5000
    });
    
    return {
      available: true,
      ...response.data
    };
  } catch (error) {
    return {
      available: false,
      error: error.message,
      url: PYTHON_CV_URL
    };
  }
}

/**
 * Parse validation result for database storage
 * Extracts relevant fields from CV service response
 * 
 * @param {Object} validationResult - Result from validatePhoto()
 * @returns {Object} Database-ready validation data
 */
function parseValidationForDatabase(validationResult) {
  const measurements = { ...validationResult };
  delete measurements.tracking; // Live mesh/iris coordinates are display-only.
  return {
    validation_status: validationResult.validation_status || 'pending',
    yaw: validationResult.yaw ?? null,
    pitch: validationResult.pitch ?? null,
    roll: validationResult.roll ?? null,
    face_detected: validationResult.face_detected || false,
    landmarks_detected: validationResult.landmarks_detected || false,
    framing_ok: validationResult.framing_ok || false,
    quality_ok: validationResult.quality_ok || false,
    validation_errors: validationResult.errors || [],
    validation_warnings: validationResult.warnings || [],
    validation_metadata: {
      ...measurements,
      confidence: null,
      landmark_count: validationResult.landmark_count,
      processing_time_ms: validationResult.processing_time_ms,
      ...validationResult.metadata
    }
  };
}

/**
 * Format validation errors for user display
 * Converts technical errors into user-friendly messages
 * 
 * @param {Array} errors - Array of error messages
 * @returns {Array} User-friendly error messages
 */
function formatValidationErrors(errors) {
  if (!errors || errors.length === 0) {
    return [];
  }
  
  const errorMap = {
    'no_face_detected': 'No face detected in the image. Please ensure your face is clearly visible.',
    'multiple_faces': 'Multiple faces detected. Please ensure only one person is in the frame.',
    'landmarks_insufficient': 'Facial landmarks could not be detected. Please improve lighting and ensure face is clearly visible.',
    'yaw_out_of_range': 'Head rotation is incorrect for this view. Please adjust your head position.',
    'pitch_out_of_range': 'Head tilt is incorrect for this view. Please adjust your head position.',
    'roll_out_of_range': 'Head is tilted. Please keep your head level.',
    'face_too_small': 'Face is too far from camera. Please move closer.',
    'face_too_large': 'Face is too close to camera. Please move back slightly.',
    'face_off_center': 'Face is not centered. Please center your face in the frame.',
    'image_too_blurry': 'Image is blurry. Please hold the camera steady.',
    'insufficient_lighting': 'Lighting is insufficient. Please improve lighting conditions.',
    'overexposed': 'Image is too bright. Please reduce lighting or adjust camera settings.',
    'underexposed': 'Image is too dark. Please improve lighting.'
  };
  
  return errors.map(error => errorMap[error] || error);
}

module.exports = {
  validatePhoto,
  checkCVServiceHealth,
  getCVServiceInfo,
  parseValidationForDatabase,
  formatValidationErrors,
  PYTHON_CV_URL
};
