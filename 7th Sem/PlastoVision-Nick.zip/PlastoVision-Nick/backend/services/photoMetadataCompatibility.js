// Migration 007 already provides validation_metadata JSONB. Preserve newer fields
// there when migration 008 columns are absent, without changing the database schema.
const EXTENDED_FIELDS = ['procedure_id','framing_protocol','capture_setup','clinician_confirmation',
  'original_checksum','image_width','image_height'];

function packPhotoMetadata(metadata, legacy = false) {
  const details = { version: 1, validation_status: metadata.validation_status };
  for (const key of EXTENDED_FIELDS) if (Object.hasOwn(metadata,key)) details[key] = metadata[key];
  const row = { ...metadata, validation_metadata: { ...metadata.validation_metadata, standardized_capture: details } };
  if (legacy) {
    for (const key of EXTENDED_FIELDS) delete row[key];
    if (row.validation_status === 'clinician_confirmed') row.validation_status = 'pending';
  }
  return row;
}

function unpackPhotoMetadata(row) {
  if (!row) return row;
  const details = row.validation_metadata?.standardized_capture;
  if (details?.version !== 1) return row;
  const result = { ...row };
  for (const key of EXTENDED_FIELDS) if (Object.hasOwn(details,key)) result[key] = details[key];
  if (row.validation_status === 'pending' && details.validation_status === 'clinician_confirmed')
    result.validation_status = 'clinician_confirmed';
  return result;
}

function isMissingCaptureColumn(error) {
  if (!['PGRST204','42703'].includes(error?.code)) return false;
  return EXTENDED_FIELDS.some(key => new RegExp(`(?:'|"|\\b)${key}(?:'|"|\\b)`).test(error.message || ''));
}
function isLegacyReviewConstraint(error) {
  return error?.code === '23514' && /patient_photos_validation_status_check/.test(error.message || '');
}
module.exports = { packPhotoMetadata, unpackPhotoMetadata, isMissingCaptureColumn, isLegacyReviewConstraint };
