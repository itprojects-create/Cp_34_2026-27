# PlastoVision Backend

Express.js backend server for PlastoVision facial photography module.

## Purpose

This backend handles operations that cannot be performed from the browser:
- **Local photo storage** - Stores patient photos in local filesystem (NOT cloud storage)
- **Photo validation** - Integrates with Python CV service for pose/quality validation
- **Metadata management** - Stores only metadata in Supabase PostgreSQL
- **Secure file access** - Provides authorized access to stored photos

## Architecture

```
React Frontend
      ↓
Express Backend (THIS)
      ↓
┌─────┴──────┐
│            │
PostgreSQL   Local
(Metadata)   (Images)
      │
      ↓
Python CV Service
(Validation)
```

## Installation

### 1. Install Dependencies

```bash
cd backend
npm install
```

### 2. Configure Environment

Copy `.env.example` to `.env` and configure:

```bash
cp .env.example .env
```

Edit `.env` and set:
- `SUPABASE_URL` - Your Supabase project URL
- `SUPABASE_ANON_KEY` - Your Supabase anon key
- `SUPABASE_SERVICE_ROLE_KEY` - Your Supabase service role key
- `PYTHON_CV_SERVICE_URL` - Python CV service URL (default: http://localhost:5000)
- `PHOTO_STORAGE_PATH` - Local directory for photos (default: ./uploads/patients)

### 3. Run Database Migrations

Run the patient_photos table migration in Supabase SQL Editor:

```bash
# See RUN_PHOTO_MIGRATION.md for instructions
```

### 4. Start the Server

**Development mode** (with auto-reload):
```bash
npm run dev
```

**Production mode**:
```bash
npm start
```

The server will start on http://localhost:3001

## API Endpoints

### Health Check
```
GET /api/health
```

Returns server status and configuration.

### Upload Photo
```
POST /api/patient-photos/upload
Content-Type: multipart/form-data

Fields:
- photo: File (required)
- patientId: UUID (required)
- visitId: UUID (optional)
- appointmentId: UUID (optional)
- treatmentStage: String (required)
- facialView: String (required)
- procedureType: String (optional)
- captureMethod: 'camera' | 'upload' (required)
```

### Get Photo File
```
GET /api/patient-photos/:id
```

Returns the actual image file. Requires authorization.

### Get Photo Metadata
```
GET /api/patient-photos/metadata/:id
```

Returns photo metadata from database.

### Get Patient Photos
```
GET /api/patient-photos/patient/:patientId
Query params:
- treatmentStage: Filter by stage
- facialView: Filter by view
- validationStatus: Filter by status
```

### Delete Photo
```
DELETE /api/patient-photos/:id
```

Deletes both file and metadata. Requires authorization.

### Validate Photo (without saving)
```
POST /api/patient-photos/validate
Content-Type: multipart/form-data

Fields:
- photo: File (required)
- facialView: String (required)
```

Returns validation results without storing the photo.

## Directory Structure

```
backend/
├── server.js              # Main server file
├── package.json           # Dependencies
├── .env                   # Environment variables (not in git)
├── .env.example           # Environment template
├── config/
│   ├── supabase.js        # Supabase client setup
│   └── facialViews.js     # Facial view configurations
├── routes/
│   └── patientPhotos.js   # Photo API routes
├── controllers/
│   └── patientPhotoController.js  # Request handlers
├── services/
│   ├── localPhotoStorageService.js  # File operations
│   ├── photoMetadataService.js      # Database operations
│   └── cvValidationService.js       # Python CV integration
├── middleware/
│   ├── patientExists.js   # Patient existence checks
│   ├── validation.js      # Request validation
│   └── upload.js          # File upload configuration
└── uploads/
    └── patients/          # Local photo storage
        └── {patient_id}/
            └── visits/
                └── {visit_id}/
                    └── facial/
                        └── {stage}/
                            └── {view}/
                                └── photo_{timestamp}_{uuid}.jpg
```

## Security

### File Storage
- Photos stored outside web root
- No direct filesystem access from frontend
- Path traversal protection
- Unique UUIDs in filenames
- Sanitized filenames

### Access Control
- Authentication required for all photo operations
- Patient ownership verification
- Role-based access control (future)

### File Upload
- File type validation (images only)
- File size limits (10MB max)
- MIME type verification
- Malicious file detection

### Privacy
- **NO cloud storage** - Photos stay local
- Metadata only in database
- Encrypted database connections
- Audit logging

## Integration with Python CV Service

The backend communicates with a separate Python service for photo validation:

```
Express Backend → HTTP POST → Python CV Service
                              ↓
                         MediaPipe + OpenCV
                              ↓
                         Validation Result
```

Python service must be running on `PYTHON_CV_SERVICE_URL` (default: localhost:5000)

See `../python-cv/README.md` for Python service setup.

## Storage Path Structure

Photos are organized in a hierarchical structure:

```
uploads/patients/
└── 8f72abc-...                    # Patient UUID
    └── visits/
        └── 91ac123-...            # Visit UUID
            └── facial/
                └── pre_surgery/   # Treatment stage
                    ├── frontal_neutral/
                    │   └── photo_1726123456_abc123.jpg
                    ├── frontal_smiling/
                    │   └── photo_1726123460_def456.jpg
                    └── right_lateral/
                        └── photo_1726123465_ghi789.jpg
```

## Database Schema

The backend interacts with the `patient_photos` table:

```sql
patient_photos (
  id, patient_id, visit_id, appointment_id,
  treatment_stage, facial_view, procedure_type,
  local_storage_path, file_name, mime_type, file_size,
  capture_method, captured_at, capture_device,
  validation_status, yaw, pitch, roll,
  face_detected, landmarks_detected, framing_ok, quality_ok,
  validation_errors, validation_warnings,
  created_by, created_at, updated_at
)
```

## Troubleshooting

### "Cannot find module"
```bash
npm install
```

### "ENOENT: no such file or directory, open '.env'"
```bash
cp .env.example .env
# Then edit .env with your credentials
```

### "Upload directory creation failed"
Check filesystem permissions:
```bash
mkdir -p uploads/patients
chmod 755 uploads
```

### "Python CV service not responding"
Ensure Python service is running:
```bash
cd ../python-cv
python app.py
```

### "Supabase connection failed"
Verify credentials in `.env`:
- Check SUPABASE_URL is correct
- Check SUPABASE_ANON_KEY is valid
- Ensure migrations are run

## Development

### Add New Endpoint

1. Add route in `routes/patientPhotos.js`
2. Add handler in `controllers/patientPhotoController.js`
3. Add business logic in `services/`
4. Add validation middleware if needed
5. Test endpoint

### Testing

```bash
# Health check
curl http://localhost:3001/api/health

# Upload photo (replace with actual values)
curl -X POST http://localhost:3001/api/patient-photos/upload \
  -F "photo=@test.jpg" \
  -F "patientId=uuid-here" \
  -F "treatmentStage=Pre-Surgery" \
  -F "facialView=frontal_neutral" \
  -F "captureMethod=upload"
```

## Production Deployment

### Before Deployment

1. Set `NODE_ENV=production` in `.env`
2. Set `ENFORCE_HTTPS=true`
3. Configure production `CORS_ORIGINS`
4. Use strong `SUPABASE_SERVICE_ROLE_KEY`
5. Set up proper filesystem permissions
6. Configure backup strategy for photos
7. Set up monitoring and logging

### Recommended Setup

- **Reverse Proxy**: Nginx/Apache in front of Express
- **Process Manager**: PM2 for process management
- **SSL/TLS**: Let's Encrypt certificates
- **Firewall**: Restrict Python CV service to localhost
- **Backups**: Regular encrypted backups of photo directory
- **Monitoring**: Log aggregation and alerting

## License

This is part of the PlastoVision capstone project.

## Support

For issues or questions, contact the development team.
# Current live photography workflow

Read [the live capture report](../docs/LIVE_CAPTURE_REPORT.md) for authoritative setup and verification instructions. Authentication is deferred for local development. Photo routes require no login or clinic membership; saves still require visitId and captureId. Run Node and CV on the workstation or an authorized local clinic device; remote server storage is not browser-local storage.

