const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const sharp = require('sharp');
const { reviewDecision } = require('../services/photoReview');
const { parseValidationForDatabase } = require('../services/cvValidationService');
test('zero degrees persist; unavailable angles remain null', () => {
  const result = parseValidationForDatabase({yaw:0,pitch:null,roll:0,tracking:{face_outline:[[.5,.5]]},gaze_ok:true});
  assert.equal(result.yaw,0); assert.equal(result.pitch,null); assert.equal(result.roll,0);
  assert.equal(result.validation_metadata.tracking,undefined);assert.equal(result.validation_metadata.gaze_ok,true);
});
test('review requires mandatory checks and reason without claiming verified identity', () => {
  const good = {reviewable:true,quality_ok:true,framing_ok:true,face_count:1};
  assert.throws(() => reviewDecision(good,'short','actor'));
  assert.throws(() => reviewDecision({...good,quality_ok:false},'Reviewed framing and viewpoint','actor'));
  assert.throws(() => reviewDecision({...good,face_count:2},'Reviewed framing and viewpoint','actor'));
  assert.equal(reviewDecision(good,'Reviewed framing and viewpoint').confirmation.identity_verified,false);
  const decision = reviewDecision(good,'Reviewed basal anatomy and framing','actor');
  assert.equal(decision.status,'clinician_confirmed');
  assert.equal(decision.confirmation.clinician_id,null);
  assert.equal(decision.confirmation.identity_verified,false);
});
test('experimental automatic capture saves pending without inventing clinician confirmation', () => {
  const result={valid:false,reviewable:true,capture_ready:true,auto_capture_eligible:true,automation_mode:'experimental',
    experimental_capture_ready:true,pose_estimated:true,alignment_ok:true,face_count:1,quality_ok:true,framing_ok:true,
    gaze_ok:true,facial_view:'frontal_neutral',anatomical_evidence:{passed:true}};
  assert.deepEqual(reviewDecision(result),{status:'pending',confirmation:null});
  for(const change of [{gaze_ok:false},{quality_ok:false},{pose_estimated:false},{facial_view:'basal'},{alignment_ok:false}])
    assert.throws(()=>reviewDecision({...result,...change}));
});
test('storage preserves bytes, validates decoded content and rejects traversal', async () => {
  const temporary = await fs.mkdtemp(path.join(os.tmpdir(),'plastovision-storage-'));
  process.env.PHOTO_STORAGE_PATH = temporary;
  const storage = require('../services/localPhotoStorageService');
  try {
    const bytes = await sharp({create:{width:64,height:64,channels:3,background:'#887766'}}).png().toBuffer();
    const result = await storage.savePhoto(bytes,{patientId:'test-patient',visitId:'test-visit',treatmentStage:'Pre-Surgery',facialView:'basal',mimeType:'image/png'});
    assert.deepEqual(await storage.getPhoto(result.relativePath),bytes);
    assert.equal(result.width,64); assert.equal(result.checksum.length,64);
    assert.equal((await fs.stat(result.fullPath)).mode & 0o777,0o600);
    const sidecar = await storage.savePhotoSidecar(result.relativePath,{id:'local-capture',original_checksum:result.checksum});
    assert.equal(JSON.parse(await fs.readFile(path.join(temporary,sidecar),'utf8')).photo.original_checksum,result.checksum);
    for (const unsafe of ['../escape.jpg','/tmp/escape.jpg','a/../../escape.jpg','a\\b']) {
      await assert.rejects(storage.getPhoto(unsafe));
    }
    assert.throws(() => storage.buildStoragePath({patientId:'a/b',visitId:'v',treatmentStage:'Pre-Surgery',facialView:'basal'}));
    await assert.rejects(storage.savePhoto(Buffer.from('bad'),{patientId:'p',visitId:'v',treatmentStage:'Pre-Surgery',facialView:'basal',mimeType:'image/png'}));
    await assert.rejects(storage.savePhoto(bytes,{patientId:'p',visitId:'v',treatmentStage:'Pre-Surgery',facialView:'basal',mimeType:'image/jpeg'}));
    const external = await fs.mkdtemp(path.join(os.tmpdir(),'plastovision-outside-'));
    try {
      await fs.writeFile(path.join(external,'outside.jpg'),bytes);
      await fs.symlink(external,path.join(temporary,'escape'));
      await assert.rejects(storage.getPhoto('escape/outside.jpg'));
      await assert.rejects(storage.deletePhoto('escape/outside.jpg'));
      assert.deepEqual(await fs.readFile(path.join(external,'outside.jpg')),bytes);
    } finally { await fs.rm(external,{recursive:true,force:true}); }
    await storage.deletePhoto(result.relativePath);
    assert.equal(await storage.photoExists(result.relativePath),false);
    await assert.rejects(fs.access(path.join(temporary,sidecar)));
  } finally { await fs.rm(temporary,{recursive:true,force:true}); }
});
test('upload API validates canonical fields, stages, views and visit UUIDs', async () => {
  const { validatePhotoUpload } = require('../middleware/validation');
  const { validationResult } = require('express-validator');
  const validate = async body => {
    const req={body,params:{},query:{}};
    for (const middleware of validatePhotoUpload) if (middleware.run) await middleware.run(req);
    return validationResult(req);
  };
  const valid={patientId:'f5d134fb-a2cc-4b0c-9588-333e30c149b1',visitId:'36901393-fca2-4d4e-a7cc-41003fd103bb',
    facialView:'right_oblique_45',treatmentStage:'Pre-Surgery',captureMethod:'camera',captureId:'1138ca93-dfa2-43dc-9d6f-7bf3aa249b5a'};
  assert.equal((await validate(valid)).isEmpty(),true);
  const {visitId, ...withoutVisit} = valid;
  assert.equal((await validate(withoutVisit)).isEmpty(),false);
  assert.equal((await validate({...valid,visitId:'wrong-patient-or-non-uuid'})).isEmpty(),false);
  assert.equal((await validate({...valid,facialView:'unknown'})).isEmpty(),false);
  assert.equal((await validate({patient_id:valid.patientId,facial_view:'basal'})).isEmpty(),false);
});
