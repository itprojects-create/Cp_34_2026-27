const test=require('node:test');
const assert=require('node:assert/strict');
const {packPhotoMetadata,unpackPhotoMetadata}=require('../services/photoMetadataCompatibility');
const records=new Map();
let mode='modern',attempts=0;
const configPath=require.resolve('../config/supabase');
require.cache[configPath]={id:configPath,filename:configPath,loaded:true,exports:{supabaseAdmin:{from(){
  let value,id;
  return {insert(rows){value=rows[0];return this;},select(){return this;},eq(_key,v){id=v;return this;},
    async single(){
      if(!value) return {data:records.get(id)};
      attempts++;
      if(mode==='missing' && Object.hasOwn(value,'capture_setup')) return {error:{code:'PGRST204',message:"Could not find the 'capture_setup' column of 'patient_photos' in the schema cache"}};
      if(mode==='constraint' && value.validation_status==='clinician_confirmed') return {error:{code:'23514',message:'violates check constraint "patient_photos_validation_status_check"'}};
      if(mode==='other') return {error:{code:'23514',message:'violates check constraint "check_file_size"'}};
      records.set(value.id,value);return {data:value};
    },async maybeSingle(){return {data:records.get(id)||null};}};
}}}};
const {createPhotoMetadata,findCaptureMetadata,getPhotoMetadata}=require('../services/photoMetadataService');
const photo=()=>({id:`photo-${mode}`,patient_id:'patient',visit_id:'visit',facial_view:'frontal_neutral',validation_status:'pending',
  capture_setup:{request_fingerprint:'same-request',actual_camera:{deviceId:'webcam'}},framing_protocol:'full_face',
  image_width:1920,image_height:1080,original_checksum:'original',procedure_id:null,clinician_confirmation:null,
  validation_metadata:{quality_ok:true}});
test('modern schema keeps dedicated capture columns and full metadata',async()=>{
  mode='modern';attempts=0;const result=await createPhotoMetadata(photo());
  assert.equal(result.error,null);assert.equal(attempts,1);assert.equal(records.get(result.data.id).image_width,1920);
});
test('PGRST204 compatibility preserves all capture fields and idempotency after rereading old schema rows',async()=>{
  mode='missing';attempts=0;const result=await createPhotoMetadata(photo());
  assert.equal(result.error,null);assert.equal(attempts,2);
  const raw=records.get(result.data.id);assert.equal(raw.capture_setup,undefined);
  for(const reread of [(await findCaptureMetadata(raw.id)).data,(await getPhotoMetadata(raw.id)).data]){
    assert.equal(reread.capture_setup.request_fingerprint,'same-request');assert.equal(reread.original_checksum,'original');
    assert.equal(reread.image_width,1920);assert.equal(reread.framing_protocol,'full_face');assert.equal(reread.visit_id,'visit');
  }
});
test('older status constraint stores pending while preserving explicit clinician confirmation',async()=>{
  mode='constraint';attempts=0;const input={...photo(),validation_status:'clinician_confirmed',clinician_confirmation:{reason:'Reviewed anatomy and view',identity_verified:false}};
  const result=await createPhotoMetadata(input);assert.equal(result.error,null);assert.equal(attempts,2);
  assert.equal(records.get(result.data.id).validation_status,'pending');assert.equal(result.data.validation_status,'clinician_confirmed');
  assert.equal(result.data.clinician_confirmation.identity_verified,false);
});
test('unrelated database constraints still reject instead of masking data errors',async()=>{
  mode='other';attempts=0;const result=await createPhotoMetadata(photo());
  assert.match(result.error,/check_file_size/);assert.equal(attempts,1);assert.equal(result.code,'23514');
});
test('compatibility envelope cannot change patient, visit, image path or stored UUID',()=>{
  const row=packPhotoMetadata(photo(),true);
  Object.assign(row.validation_metadata.standardized_capture,{patient_id:'other',visit_id:'other',local_storage_path:'escape',id:'other'});
  const decoded=unpackPhotoMetadata(row);assert.equal(decoded.patient_id,'patient');assert.equal(decoded.visit_id,'visit');assert.equal(decoded.id,row.id);
});
