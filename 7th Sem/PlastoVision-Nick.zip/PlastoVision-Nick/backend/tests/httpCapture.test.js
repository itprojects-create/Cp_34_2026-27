// Exercise the real Express router, multipart decoder, controller and disk
// without opening sockets, contacting a database or using patient photographs.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');
const sharp = require('sharp');
const {randomUUID} = require('node:crypto');
const records = new Map();
const patientId=randomUUID(), visitId=randomUUID();
const configPath=require.resolve('../config/supabase');
const admin={from(table){
  let where={},value;
  return {select(){return this;},eq(key,v){where[key]=v;return this;},insert(rows){value=rows[0];return this;},
    async maybeSingle(){return {data:table==='patient_photos'?records.get(where.id)||null:table==='patients'?{id:patientId}:table==='visits'?{id:visitId,patient_id:patientId}:null};},
    async single(){if(value){
      if(Object.hasOwn(value,'capture_setup')) return {data:null,error:{code:'PGRST204',message:"Could not find the 'capture_setup' column of 'patient_photos' in the schema cache"}};
      records.set(value.id,value);return {data:value};}return {data:records.get(where.id)||null};}};
}};
require.cache[configPath]={id:configPath,filename:configPath,loaded:true,exports:{supabaseAdmin:admin}};
const cvPath=require.resolve('../services/cvValidationService');
require.cache[cvPath]={id:cvPath,filename:cvPath,loaded:true,exports:{async validatePhoto(){return {valid:true,gaze_ok:true,capture_ready:true,auto_capture_eligible:true,reviewable:true,face_count:1,quality_ok:true,framing_ok:true,framing:{protocol:'full_face'}};},parseValidationForDatabase(value){return {validation_metadata:value};}}};
async function dispatch(app, method, url, headers={}, bytes=Buffer.alloc(0)) {
  return new Promise((resolve,reject)=>{
    const req=new http.IncomingMessage(null);
    Object.assign(req,{method,url,headers:{...headers,'content-length':String(bytes.length)}});
    const res=new http.ServerResponse(req);
    res.end=function(body){resolve({status:this.statusCode,headers:this.getHeaders(),body:body==null?Buffer.alloc(0):Buffer.from(body)});return this;};
    app.handle(req,res,error=>error?reject(error):resolve({status:404}));
    req.push(bytes);req.push(null);
  });
}
test('legacy schema HTTP capture saves original + local sidecar, retrieves metadata and replays after restart',async()=>{
  const directory=await fs.mkdtemp(path.join(os.tmpdir(),'plastovision-http-'));
  process.env.PHOTO_STORAGE_PATH=directory;
  const express=require('express');
  const app=express();app.use(express.json());app.use('/photos',require('../routes/patientPhotos'));
  try{
    const bytes=await sharp({create:{width:640,height:480,channels:3,background:'#987654'}}).png().toBuffer();
    const form=new FormData(),captureId=randomUUID();
    form.append('photo',new Blob([bytes],{type:'image/png'}),'capture.png');
    for(const [key,value] of Object.entries({patientId,visitId,captureId,facialView:'frontal_neutral',treatmentStage:'Pre-Surgery',captureMethod:'camera',setup:'{}'}))form.append(key,value);
    const encoded=new Request('http://local.invalid',{method:'POST',body:form});
    const payload=Buffer.from(await encoded.arrayBuffer()),headers={'content-type':encoded.headers.get('content-type')};
    let res=await dispatch(app,'POST','/photos/upload',headers,payload);
    assert.equal(res.status,201,res.body.toString());
    const photo=JSON.parse(res.body).photo;
    assert.equal(photo.created_by,null);
    assert.equal(photo.id,captureId);assert.equal(photo.patient_id,patientId);assert.equal(photo.visit_id,visitId);assert.equal(photo.validation_status,'valid');
    assert.deepEqual(await fs.readFile(path.join(directory,photo.local_storage_path)),bytes);
    const sidecarPath=path.join(directory,`${photo.local_storage_path}.json`);
    const localMetadata=JSON.parse(await fs.readFile(sidecarPath,'utf8')).photo;
    assert.equal(localMetadata.id,captureId);assert.equal(localMetadata.original_checksum,photo.original_checksum);
    assert.equal((await fs.stat(sidecarPath)).mode & 0o777,0o600);
    assert.equal(records.get(captureId).capture_setup,undefined);
    assert.ok(records.get(captureId).validation_metadata.standardized_capture.capture_setup.request_fingerprint);
    res=await dispatch(app,'GET',`/photos/${captureId}`,{});
    assert.equal(res.status,200);assert.deepEqual(res.body,bytes);assert.equal(res.headers['cache-control'],'private, no-store');
    // Discard process-local request locks; the database primary key is durable.
    delete require.cache[require.resolve('../controllers/patientPhotoController')];
    delete require.cache[require.resolve('../routes/patientPhotos')];
    const restarted=express();restarted.use('/photos',require('../routes/patientPhotos'));
    res=await dispatch(restarted,'POST','/photos/upload',headers,payload);
    assert.equal(res.status,200,res.body.toString());assert.equal(JSON.parse(res.body).replayed,true);assert.equal(records.size,1);
  }finally{await fs.rm(directory,{recursive:true,force:true});}
});
