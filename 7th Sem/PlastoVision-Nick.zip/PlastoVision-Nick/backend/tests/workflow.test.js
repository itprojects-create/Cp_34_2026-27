const test = require('node:test');
const assert = require('node:assert/strict');
const configPath = require.resolve('../config/supabase');
let visit = {id:'visit',patient_id:'patient'};
const query = {select(){return this;},eq(){return this;},async maybeSingle(){return {data:visit};}};
const admin = {from(){return query;}};
require.cache[configPath] = {id:configPath,filename:configPath,loaded:true,exports:{supabaseAdmin:admin}};
let validation = {}, saved = 0, deleted = 0, metadata = null, dbError = null;
const records = new Map();
for (const [name, exports] of [
  ['../services/localPhotoStorageService',{async savePhotoSidecar(){},async savePhoto(){saved++;return {relativePath:'safe/photo.jpg',filename:'photo.jpg',fileSize:20,width:20,height:30,checksum:'abc'};},async deletePhoto(){deleted++;}}],
  ['../services/photoMetadataService',{async findCaptureMetadata(id){return {data:records.get(id)||null};},async createPhotoMetadata(value){metadata=value;if (!dbError) records.set(value.id,value);return {data:dbError?null:{...value},error:dbError};}}],
  ['../services/cvValidationService',{async validatePhoto(){return validation;},parseValidationForDatabase(result){return {validation_status:result.valid?'valid':'invalid',validation_metadata:result};}}]
]) { const id=require.resolve(name); require.cache[id]={id,filename:id,loaded:true,exports}; }
const {verifyPatientExists} = require('../middleware/patientExists');
const {uploadPhoto} = require('../controllers/patientPhotoController');
function response(){return {statusCode:200,status(code){this.statusCode=code;return this;},json(value){this.body=value;return this;}};}
function request(captureId='capture-1'){return {file:{buffer:Buffer.from('test'),mimetype:'image/jpeg',originalname:'capture.jpg'},body:{captureId,patientId:'patient',visitId:'visit',facialView:'basal',treatmentStage:'Pre-Surgery',captureMethod:'camera',reviewReason:'Clinician confirmed basal anatomy and correct setup'},headers:{}};}
test('patient existence checks remain available without session or identity', async () => {
  const req={params:{patientId:'patient'},body:{},headers:{}};
  let calls=0; await verifyPatientExists()(req,response(),()=>calls++);
  assert.equal(calls,1); assert.equal(req.user,undefined);
  visit=null; const res=response(); await verifyPatientExists()(req,res,()=>assert.fail());
  assert.equal(res.statusCode,404); visit={id:'visit',patient_id:'patient'};
});
test('visit integrity, final rejection, unverified confirmation, idempotent replay and rollback', async () => {
  visit=null; let res=response(); await uploadPhoto(request(),res); assert.equal(res.statusCode,422); assert.equal(saved,0);
  visit={id:'visit',patient_id:'patient'}; validation={valid:false,reviewable:false,face_count:1};
  res=response(); await uploadPhoto(request(),res); assert.equal(res.statusCode,422); assert.equal(saved,0);
  validation={valid:false,reviewable:true,face_count:1,framing_ok:true,quality_ok:true,framing:{protocol:'basal'}};
  res=response(); await uploadPhoto(request(),res); assert.equal(res.statusCode,201); assert.equal(saved,1);
  assert.equal(metadata.validation_status,'clinician_confirmed'); assert.equal(metadata.visit_id,'visit');
  assert.equal(metadata.clinician_confirmation.clinician_id,null); assert.equal(metadata.original_checksum,'abc');
  assert.equal(metadata.created_by,null); assert.equal(metadata.clinician_confirmation.identity_verified,false);
  res=response(); await uploadPhoto(request(),res); assert.equal(res.statusCode,200); assert.equal(res.body.replayed,true); assert.equal(saved,1);
  const changed=request(); changed.file.buffer=Buffer.from('different image');
  res=response(); await uploadPhoto(changed,res); assert.equal(res.statusCode,409); assert.equal(saved,1);
  dbError='simulated database failure'; res=response(); await uploadPhoto(request('capture-2'),res); assert.equal(res.statusCode,500); assert.equal(deleted,1);
  dbError=null; res=response(); await uploadPhoto(request('capture-2'),res); assert.equal(res.statusCode,201);
});
test('photo routes do not install session or role guards', () => {
  const router = require('../routes/patientPhotos');
  assert.ok(router.stack.every(layer => !['authenticate','authorize'].includes(layer.handle?.name)));
  assert.ok(!router.stack[0].route);
  const routes=router.stack.filter(layer=>layer.route).map(layer=>layer.route.path);
  for (const route of ['/:id','/metadata/:id','/upload','/validate-live','/capture-config','/visit/:visitId']) assert.ok(routes.includes(route));
});
test('capture without a visit or retry UUID fails before writing', async () => {
  for (const field of ['visitId','captureId']) {
    const req=request(); delete req.body[field]; const res=response(), before=saved;
    await uploadPhoto(req,res); assert.equal(res.statusCode,400); assert.equal(saved,before);
  }
});
test('automatic final acceptance saves directly without a clinician override reason', async () => {
  validation={valid:true,capture_ready:true,auto_capture_eligible:true,reviewable:true,face_count:1,quality_ok:true,framing_ok:true};
  const req=request('capture-auto'); delete req.body.reviewReason;
  const res=response(); await uploadPhoto(req,res); assert.equal(res.statusCode,201);
  assert.equal(res.body.photo.validation_status,'valid'); assert.equal(res.body.photo.clinician_confirmation,null);
});
