import test from 'node:test';
import assert from 'node:assert/strict';
import {createCaptureTracker, createAutoCountdown, createGuidanceFilter, createAutoCaptureController, isAutomaticFrameReady} from '../src/lib/captureState.js';
import {matchingPhotos, canonicalView, comparisonWarnings, SIX_VIEWS} from '../src/lib/photoComparison.js';
import {captureGuideGeometry,trackedFaceGuide} from '../src/lib/captureGuide.js';
const frame = extra => ({reviewable:true,face_count:1,quality_ok:true,framing_ok:true,yaw:0,pitch:0,roll:0,face_bbox:[.3,.2,.4,.5], ...extra});
test('face guide stays upright at native 16:9, 4:3 and portrait video aspect ratios', () => {
  for (const [width,height] of [[1920,1080],[640,480],[720,1280]]) {
    const guide=captureGuideGeometry({guide:{center_x:.5,center_y:.45,height:.475},view:'frontal_neutral',width,height});
    const pixelWidth=guide.rx*2/100*width, pixelHeight=guide.ry*2/100*height;
    assert.ok(Math.abs(pixelWidth/pixelHeight-.78)<1e-9);
    assert.equal(guide.cx,50);assert.equal(guide.cy,45);
    assert.ok(Math.abs(pixelHeight/height-.475)<1e-9);
  }
});
test('guide uses the configured target rather than following the detected face and mirrors correctly', () => {
  const options={framing:{min_height:.3,max_height:.65,center_x:.4,center_y:.45},view:'right_lateral',width:1920,height:1080};
  assert.equal(captureGuideGeometry(options).cx,40);
  assert.equal(captureGuideGeometry({...options,mirrored:true}).cx,60);
  assert.equal(captureGuideGeometry({...options,guide:{center_x:.4,center_y:.45,height:.6}}).ry,30);
});
test('live dotted outline follows landmarks and correction arrow leads toward ideal position', () => {
  const outline=Array.from({length:8},(_,i)=>[.2+i*.01,.3+i*.01]);
  const options={tracking:{face_outline:outline},bbox:[.2,.2,.2,.3],center:[.3,.35],target:{cx:50,cy:45}};
  const first=trackedFaceGuide(options);
  const moved=trackedFaceGuide({...options,tracking:{face_outline:outline.map(([x,y])=>[x+.1,y])},center:[.4,.35]});
  assert.notEqual(first.path,moved.path);assert.equal(first.arrow.x1,30);assert.equal(moved.arrow.x1,40);
  assert.equal(moved.arrow.x2,50);
  const mirror=trackedFaceGuide({...options,mirrored:true});assert.equal(mirror.arrow.x1,70);
  assert.equal(trackedFaceGuide({target:{cx:50,cy:45}}),null);
});
test('a single frame never establishes stability; elapsed time does', () => {
  const tracker = createCaptureTracker();
  assert.equal(tracker.update(frame(),0,1).stable,false);
  tracker.update(frame(),400,2); tracker.update(frame(),800,3);
  assert.equal(tracker.update(frame(),1000,4).stable,true);
});
test('invalid frames and gaps reset stability and block countdown', () => {
  const tracker = createCaptureTracker();
  tracker.update(frame(),0,1); tracker.update(frame(),500,2);
  assert.equal(tracker.update(frame({quality_ok:false}),1000,3).duration,0);
  tracker.update(frame(),1100,4);
  assert.equal(tracker.update(frame(),1800,5).stable,false);
});
test('movement, drift and duplicate responses cannot maintain readiness', () => {
  const tracker = createCaptureTracker();
  tracker.update(frame(),0,1); tracker.update(frame({yaw:2}),300,2);
  assert.equal(tracker.update(frame({yaw:4}),600,3).duration,0);
  assert.equal(tracker.update(frame(),900,3).stale,true);
  assert.equal(tracker.update(frame({face_bbox:[.5,.2,.4,.5]}),1000,4).stable,false);
});
test('missing same-view photos are never substituted; repeated followups stay separate', () => {
  const photos = [
    {id:'a',procedure_id:'p',visit_id:'v1',facial_view:'right_oblique',captured_at:'2026-01-01'},
    {id:'b',procedure_id:'p',visit_id:'v2',facial_view:'right_oblique_45',captured_at:'2026-02-01'},
    {id:'c',procedure_id:'q',visit_id:'v1',facial_view:'frontal_neutral',captured_at:'2026-01-01'}
  ];
  assert.equal(matchingPhotos(photos,'p','v1','right_oblique_45')[0].id,'a');
  assert.equal(matchingPhotos(photos,'p','v2','right_oblique_45')[0].id,'b');
  assert.deepEqual(matchingPhotos(photos,'p','v1','frontal_neutral'),[]);
  assert.equal(canonicalView('worms_view'),'basal');
  assert.equal(SIX_VIEWS.length,6);
});
test('protocol and camera differences produce limitations', () => {
  assert.equal(comparisonWarnings(null,{}).length,0);
  assert.ok(comparisonWarnings({framing_protocol:'full_face',capture_setup:{measured_distance_cm:100}},
    {framing_protocol:'nasal_focused',capture_setup:{measured_distance_cm:80}}).length >= 2);
});

test('automatic countdown requires continuous readiness and cancels on movement or delay', () => {
  const countdown = createAutoCountdown();
  const tick = (now, ready = true, stable = true, measuredAt = now) => countdown.update({ready, stable, now, measuredAt});
  assert.equal(tick(0),false); assert.equal(tick(1500),false);
  assert.equal(tick(1600,true,false),false);
  assert.equal(tick(2000),false); assert.equal(tick(3500),false);
  assert.equal(tick(3600,true,true,2000),false);
  assert.equal(tick(4000),false); assert.equal(tick(6000),true);
  countdown.reset(); assert.equal(tick(6100),false);
});

test('guidance persists before switching; multiple faces interrupt immediately', () => {
  const filter = createGuidanceFilter();
  assert.equal(filter({guidance_code:'CENTER',guidance:'Center'},0),'Center');
  assert.equal(filter({guidance_code:'SCALE',guidance:'Adjust distance'},100),'Center');
  assert.equal(filter({guidance_code:'SCALE',guidance:'Adjust distance'},550),'Adjust distance');
  assert.equal(filter({guidance_code:'MULTIPLE_FACES',guidance:'One patient only'},600),'One patient only');
});

const policy = {stability_ms:1000,countdown_ms:500,max_analysis_age_ms:700,max_gap_ms:500,angle_motion_deg:3,position_motion:.025};
const readyFrame = extra => frame({valid:true,capture_ready:true,auto_capture_eligible:true,...extra});
test('experimental webcam readiness captures once without claiming clinical validity', () => {
  const sample=readyFrame({valid:false,automation_mode:'experimental',experimental_capture_ready:true,
    pose_estimated:true,alignment_ok:true,anatomical_evidence:{passed:true}});
  assert.equal(isAutomaticFrameReady(sample),true);
  const controller=createAutoCaptureController(policy);
  let count=0;
  for(let t=0;t<=3000;t+=250) count+=Number(controller.update(sample,{now:t,measuredAt:t,frameId:t+1}).trigger);
  assert.equal(count,1);
  for(const change of [{pose_estimated:false},{alignment_ok:false},{quality_ok:false},{anatomical_evidence:{passed:false}}])
    assert.equal(isAutomaticFrameReady({...sample,...change}),false);
});
test('frontal countdown cancels when eyes look away and restarts only after renewed stability', () => {
  const sample=readyFrame({facial_view:'frontal_neutral',gaze_required:true,gaze_ok:true});
  const controller=createAutoCaptureController(policy);
  for(let t=0;t<=1250;t+=250) controller.update(sample,{now:t,measuredAt:t,frameId:t+1});
  assert.equal(isAutomaticFrameReady({...sample,gaze_ok:false}),false);
  assert.equal(isAutomaticFrameReady({...sample,gaze_ok:undefined}),false);
  const away=controller.update({...sample,gaze_ok:false},{now:1500,measuredAt:1500,frameId:1501});
  assert.equal(away.trigger,false);
  const resumed=controller.update(sample,{now:1750,measuredAt:1750,frameId:1751});
  assert.equal(resumed.progress,0);assert.equal(resumed.trigger,false);
});
test('automatic shutter waits for sustained valid alignment, countdown and latches exactly once', () => {
  const controller=createAutoCaptureController(policy);
  let fired=0;
  for (let time=0;time<=4000;time+=250) {
    const next=controller.update(readyFrame(),{now:time+50,measuredAt:time,frameId:time+1});
    if(time<1500) assert.equal(next.trigger,false);
    fired+=Number(next.trigger);
  }
  assert.equal(fired,1);
  controller.reset();
  assert.equal(controller.update(readyFrame(),{now:5000,measuredAt:5000,frameId:1}).trigger,false);
});
test('reviewable wrong alignment never contributes automatic stability; movement cancels countdown', () => {
  const controller=createAutoCaptureController(policy);
  for(let t=0;t<=2000;t+=250) assert.equal(controller.update(readyFrame({valid:false,capture_ready:false}),{now:t,measuredAt:t,frameId:t+1}).trigger,false);
  assert.equal(controller.update(readyFrame(),{now:2250,measuredAt:2250,frameId:2251}).progress,0);
  for(let t=2500;t<=3250;t+=250) controller.update(readyFrame(),{now:t,measuredAt:t,frameId:t+1});
  const moved=controller.update(readyFrame({yaw:8}),{now:3500,measuredAt:3500,frameId:3501});
  assert.equal(moved.trigger,false); assert.equal(moved.state,'STABILIZING');
});
test('stale acquisition, hidden/disconnected camera, missing pose and poor quality prevent shutter', () => {
  for(const change of [{valid:false},{quality_ok:false},{face_count:2},{capture_ready:false},{auto_capture_eligible:false}]) {
    const controller=createAutoCaptureController(policy);
    for(let t=0;t<=2500;t+=250) assert.equal(controller.update(readyFrame(change),{now:t,measuredAt:t,frameId:t+1}).trigger,false);
  }
  const controller=createAutoCaptureController(policy);
  assert.equal(controller.update(readyFrame(),{now:1000,measuredAt:0,frameId:1}).state,'UNVERIFIED');
  assert.equal(controller.update(readyFrame(),{now:1000,measuredAt:1000,frameId:2,connected:false}).state,'UNVERIFIED');
});
test('angular entry hysteresis avoids threshold chatter without expanding acceptance tolerance', () => {
  const controller=createAutoCaptureController({...policy,angular_entry_margin_deg:.5});
  const measured=error=>readyFrame({pose_errors:{yaw:error,pitch:0,roll:0},pose_tolerances:{yaw:5,pitch:5,roll:3}});
  for(let t=0;t<=2000;t+=250) assert.equal(controller.update(measured(4.9),{now:t,measuredAt:t,frameId:t+1}).trigger,false);
  assert.equal(controller.update(measured(4),{now:2250,measuredAt:2250,frameId:2251}).progress,0);
  assert.equal(controller.update(measured(4.9),{now:2500,measuredAt:2500,frameId:2501}).state,'STABILIZING');
  assert.equal(controller.update({...measured(5.1),valid:false,capture_ready:false},{now:2750,measuredAt:2750,frameId:2751}).trigger,false);
});
