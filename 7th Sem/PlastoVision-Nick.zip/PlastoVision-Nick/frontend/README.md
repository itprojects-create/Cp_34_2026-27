# PlastoVision

PlastoVision is a web-based platform designed to assist surgeons in efficiently managing patient records, monitoring treatment progress, and visualizing surgical outcomes.

## 🏗️ Project Structure

```
Project/
├── backend/                    # Backend configuration and database setup
│   ├── supabase/
│   │   └── migrations/        # SQL migration files for database schema
│   └── README.md              # Backend setup instructions
│
└── PlastoVision/              # Frontend React application
    ├── src/
    │   ├── components/        # Reusable UI components
    │   │   ├── layout/       # Layout components (Navbar, Sidebar)
    │   │   └── ui/           # UI components (Button, Card, Modal, etc.)
    │   ├── contexts/         # React contexts (Toast notifications)
    │   ├── lib/              # Library configurations (Supabase client)
    │   ├── pages/            # Application pages
    │   ├── routes/           # Route configuration
    │   ├── services/         # API service layer
    │   └── data/             # Mock data (legacy)
    └── public/               # Static assets
```

## ✨ Features Implemented (Phase 1)

### Patient Management
- ✅ Add new patients with comprehensive information
- ✅ View all patients in a searchable table
- ✅ Search patients by name, ID, phone, or email
- ✅ View detailed patient profiles
- ✅ Edit patient information
- ✅ Delete patient records (with cascade delete)
- ✅ Auto-generated patient codes (P-XXXXX format)

### Visit History
- ✅ Add visit records for patients
- ✅ View complete visit history
- ✅ Record diagnosis, doctor notes, and treatment plans
- ✅ Set follow-up dates
- ✅ Timeline view of all visits

### Document Management
- ✅ Upload patient documents (PDF, images, etc.)
- ✅ View all uploaded documents
- ✅ Download documents
- ✅ Delete documents
- ✅ Secure storage in Supabase Storage

### User Experience
- ✅ Loading states for all async operations
- ✅ Empty states with helpful messages
- ✅ Toast notifications for user feedback
- ✅ Responsive design for all screen sizes
- ✅ Error handling throughout the application

## 🛠️ Tech Stack

### Frontend
- **React 19** - UI framework
- **Vite** - Build tool and dev server
- **React Router DOM** - Client-side routing
- **Tailwind CSS** - Utility-first CSS framework
- **Lucide React** - Icon library
- **React Hot Toast** - Toast notifications

### Backend
- **Supabase PostgreSQL** - Database
- **Supabase Storage** - File storage
- **Row Level Security (RLS)** - Database security

## 📦 Installation & Setup

### Prerequisites
- Node.js 16+ and npm
- Supabase account (free tier works)

### Step 1: Clone and Install Frontend Dependencies

```bash
cd "PlastoVision"
npm install
```

### Step 2: Set Up Supabase

1. **Create a Supabase Project**
   - Go to [https://supabase.com](https://supabase.com)
   - Create a new project
   - Wait for the project to initialize

2. **Run Database Migrations**
   - Go to your Supabase Dashboard
   - Navigate to **SQL Editor**
   - Run each migration file from `backend/supabase/migrations/` in order:
     1. `001_create_patients_table.sql`
     2. `002_create_visits_table.sql`
     3. `003_create_medications_table.sql`
     4. `004_create_documents_table.sql`

3. **Create Storage Bucket**
   - Go to **Storage** in Supabase Dashboard
   - Create a new bucket named: `patient-documents`
   - Set it to **Public** (for development) or **Private** (for production)
   
   For public access (development), run this SQL:
   ```sql
   -- Make bucket public
   UPDATE storage.buckets 
   SET public = true 
   WHERE name = 'patient-documents';
   ```

4. **Get API Credentials**
   - Go to **Settings → API**
   - Copy your **Project URL** and **anon/public key**

### Step 3: Configure Environment Variables

Create/update `.env` file in the `PlastoVision` folder:

```env
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key-here
```

### Step 4: Start Development Server

```bash
cd PlastoVision
npm run dev
```

The application will be available at `http://localhost:5173`

## 🗄️ Database Schema

### Tables

#### `patients`
Stores patient demographic and medical information
- **Primary Key**: `id` (UUID)
- **Unique**: `patient_code` (auto-generated)
- **Key Fields**: name, contact info, medical history, allergies

#### `visits`
Stores patient visit records
- **Primary Key**: `id` (UUID)
- **Foreign Key**: `patient_id` → `patients(id)`
- **Key Fields**: visit date, diagnosis, doctor notes, treatment plan

#### `medications`
Stores medications prescribed during visits
- **Primary Key**: `id` (UUID)
- **Foreign Key**: `visit_id` → `visits(id)`
- **Key Fields**: medicine name, dosage, frequency, duration

#### `documents`
Stores metadata for uploaded documents
- **Primary Key**: `id` (UUID)
- **Foreign Key**: `patient_id` → `patients(id)`
- **Key Fields**: file name, file URL, file type, file size

## 📚 API Service Layer

All database operations are handled through service functions in `src/services/patientService.js`:

### Patient Operations
- `createPatient(patientData)` - Create new patient
- `getPatients(options)` - Get all patients with search/filter
- `getPatientById(patientId)` - Get single patient
- `updatePatient(patientId, updates)` - Update patient info
- `deletePatient(patientId)` - Delete patient

### Visit Operations
- `createVisit(visitData)` - Create new visit
- `getPatientVisits(patientId)` - Get all visits for a patient
- `getVisitById(visitId)` - Get single visit with medications
- `updateVisit(visitId, updates)` - Update visit info
- `deleteVisit(visitId)` - Delete visit

### Medication Operations
- `addMedications(medications)` - Add medications to a visit
- `getMedicationsByVisit(visitId)` - Get medications for a visit
- `deleteMedication(medicationId)` - Delete medication

### Document Operations
- `uploadPatientDocument(file, patientId)` - Upload document to storage
- `getPatientDocuments(patientId)` - Get all documents for a patient
- `deleteDocument(documentId, fileUrl)` - Delete document from storage and DB

### Statistics
- `getDashboardStats()` - Get dashboard statistics

## 🎨 UI Components

All UI components are located in `src/components/ui/`:

- **Button** - Versatile button with variants (primary, secondary, outline, ghost, danger)
- **Card** - Container component with optional title and actions
- **Modal** - Modal dialog with customizable size and footer
- **Table** - Data table with row click support
- **Tabs** - Tab navigation component

## 🔐 Security Features

- Row Level Security (RLS) enabled on all tables
- Cascade delete for related records
- Input validation on forms
- File size limits for uploads (10MB max)
- Error handling for all operations

## 🚀 Usage Guide

### Adding a New Patient

1. Click **"Add Patient"** button on the Patients page
2. Fill in the patient information (First Name and Last Name are required)
3. Date of Birth auto-calculates age
4. Add medical history, allergies, and other relevant information
5. Click **"Save Patient"** to create the record

### Viewing Patient Profile

1. Click on any patient row in the Patients table
2. View complete patient information across three tabs:
   - **Overview** - Personal info, medical history, allergies
   - **Visit History** - All recorded visits with timeline view
   - **Documents** - Uploaded files and reports

### Adding a Visit

1. Open a patient profile
2. Go to **"Visit History"** tab
3. Click **"Add Visit"** button
4. Fill in visit details (diagnosis is required)
5. Set follow-up date if needed
6. Click **"Add Visit"** to save

### Uploading Documents

1. Open a patient profile
2. Go to **"Documents"** tab
3. Click **"Upload Document"** button
4. Select a file (PDF, JPG, PNG, DOC, DOCX)
5. File will be uploaded to Supabase Storage automatically

### Editing Patient Information

1. Open a patient profile
2. Click **"Edit Profile"** button
3. Modify the information as needed
4. Click **"Save Changes"**

### Deleting a Patient

1. Open a patient profile
2. Click the trash icon next to "Edit Profile"
3. Confirm deletion
4. All related visits, medications, and document metadata will be deleted

## 🧪 Testing the Application

### Manual Testing Checklist

- [ ] Create a new patient
- [ ] Search for patients by name
- [ ] View patient profile
- [ ] Edit patient information
- [ ] Add a visit record
- [ ] Upload a document
- [ ] Download a document
- [ ] Delete a document
- [ ] Delete a patient
- [ ] Check empty states (no patients, no visits, no documents)
- [ ] Check loading states
- [ ] Check error handling (invalid data, network errors)

## 🐛 Troubleshooting

### "Failed to load patients"
- Check if migrations ran successfully
- Verify Supabase credentials in `.env`
- Check browser console for detailed error

### "Failed to upload document"
- Ensure storage bucket `patient-documents` exists
- Check file size (max 10MB)
- Verify bucket permissions

### "Cannot connect to Supabase"
- Verify `.env` variables are set correctly
- Ensure Supabase project is running
- Check network connectivity

## 📈 Future Enhancements (Upcoming Phases)

- [ ] Authentication system (Doctor/Admin roles)
- [ ] Photo tracking for procedures
- [ ] 3D visualization integration
- [ ] Appointment scheduling
- [ ] Dashboard analytics
- [ ] Report generation
- [ ] Multi-doctor support
- [ ] Patient portal

## 📝 Development Notes

### Code Organization
- Service layer handles all API calls
- Components are kept stateless where possible
- Context API for global state (Toast notifications)
- Consistent error handling pattern

### Design Patterns
- Material Design 3 inspired UI
- Responsive-first approach
- Accessible form inputs
- Loading and empty states for all data fetches

### Best Practices Followed
- ✅ No mock data in production code
- ✅ Proper error handling
- ✅ Loading states for async operations
- ✅ Input validation
- ✅ Modular, reusable components
- ✅ Clear separation of concerns
- ✅ Consistent naming conventions

## 👥 Contributing

This is a capstone project. For contribution guidelines, please contact the project maintainers.

## 📄 License

This project is part of an academic capstone project.

## 🙏 Acknowledgments

- Supabase for the excellent BaaS platform
- Tailwind CSS for the utility-first CSS framework
- Lucide React for beautiful icons
- React community for excellent tooling

---

**Project Status**: Phase 1 Complete ✅  
**Last Updated**: August 16, 2026  
**Version**: 1.0.0
