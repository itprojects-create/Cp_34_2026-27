import React from 'react';
import { Routes, Route } from 'react-router-dom';
import MainLayout from '../components/layout/MainLayout';
import Dashboard from '../pages/Dashboard';
import Patients from '../pages/Patients';
import PatientProfile from '../pages/PatientProfile';
import Appointments from '../pages/Appointments';
import Visualization from '../pages/Visualization';
import PhotoTracking from '../pages/PhotoTracking';
import Settings from '../pages/Settings';
import Reports from '../pages/Reports';

const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<MainLayout />}>
        <Route index element={<Dashboard />} />
        <Route path="patients" element={<Patients />} />
        <Route path="patients/:id" element={<PatientProfile />} />
        <Route path="appointments" element={<Appointments />} />
        <Route path="visualization" element={<Visualization />} />
        <Route path="photo-tracking" element={<PhotoTracking />} />
        {/* Placeholders for others */}
        <Route path="reports" element={<Reports />} />
        <Route path="settings" element={<Settings />} />
      </Route>
    </Routes>
  );
};

export default AppRoutes;
