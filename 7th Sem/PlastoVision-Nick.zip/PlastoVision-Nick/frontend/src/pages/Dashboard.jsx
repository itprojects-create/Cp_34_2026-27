import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import PageHeader from '../components/ui/PageHeader';
import EmptyState from '../components/ui/EmptyState';
import { getTodaysAppointments, getAppointmentStats, formatTime } from '../services/appointmentService';
import { getDashboardStats } from '../services/patientService';
import { Users, Calendar as CalendarIcon, ArrowUpRight, UserPlus, Clock, Loader, Activity } from 'lucide-react';

const Dashboard = () => {
  const navigate = useNavigate();
  const [todaysAppointments, setTodaysAppointments] = useState([]);
  const [stats, setStats] = useState({
    totalPatients: 0,
    todaysAppointments: 0,
    upcomingAppointments: 0,
    completedToday: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    setLoading(true);

    // Load today's appointments
    const { data: appointments } = await getTodaysAppointments();
    if (appointments) {
      setTodaysAppointments(appointments.slice(0, 5)); // Show only first 5
    }

    // Load appointment stats
    const { data: aptStats } = await getAppointmentStats();
    
    // Load patient stats
    const { data: patientStats } = await getDashboardStats();

    if (aptStats && patientStats) {
      setStats({
        totalPatients: patientStats.totalPatients,
        todaysAppointments: aptStats.today,
        upcomingAppointments: aptStats.upcoming,
        completedToday: appointments?.filter(a => a.status === 'Completed').length || 0
      });
    }

    setLoading(false);
  };

  const dashboardStats = [
    {
      title: 'Total Patients',
      value: stats.totalPatients.toString(),
      // trend: '+12.5%',
      // trendUp: true,
      icon: <Users className="w-5 h-5" />
    },
    {
      title: "Today's Appointments",
      value: stats.todaysAppointments.toString(),
      trend: stats.todaysAppointments > 0 ? `${stats.completedToday} completed` : 'No appointments',
      trendUp: stats.todaysAppointments > 0,
      icon: <CalendarIcon className="w-5 h-5" />
    },
    {
      title: 'Upcoming (7 Days)',
      value: stats.upcomingAppointments.toString(),
      trend: stats.upcomingAppointments > stats.todaysAppointments ? '+' + (stats.upcomingAppointments - stats.todaysAppointments) : '0',
      trendUp: stats.upcomingAppointments > stats.todaysAppointments,
      icon: <Clock className="w-5 h-5" />
    },
    {
      title: 'Completion Rate',
      value: stats.todaysAppointments > 0 ? `${Math.round((stats.completedToday / stats.todaysAppointments) * 100)}%` : '0%',
      trend: stats.completedToday > 0 ? `${stats.completedToday} / ${stats.todaysAppointments}` : 'N/A',
      trendUp: stats.completedToday > 0,
      icon: <Activity className="w-5 h-5" />
    }
  ];

  const statusBadge = (status) => {
    const map = {
      Confirmed: 'bg-success-container text-success',
      Scheduled: 'bg-tertiary-container text-tertiary',
      Completed: 'bg-surface-container text-on-surface-variant',
    };
    return map[status] || 'bg-warning-container text-warning';
  };

  return (
    <div className="space-y-8">
      <PageHeader
        title="Practice overview"
        subtitle="Welcome back, Dr. Yogesh. Here's your clinical schedule for today."
      />

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5">
        {dashboardStats.map((stat, i) => (
          <Card key={i} className="relative overflow-hidden group">
            <div className="flex items-start justify-between mb-3">
              <p className="text-sm font-medium text-on-surface-variant">{stat.title}</p>
              <div className="w-9 h-9 rounded-xl bg-primary-container text-primary flex items-center justify-center">
                {stat.icon}
              </div>
            </div>
            <div className="flex items-end gap-3">
              <h3 className="text-3xl font-bold font-headline tracking-tight">{loading ? '—' : stat.value}</h3>
              {stat.trend && (
                <span className={`flex items-center text-xs font-medium mb-1 ${stat.trendUp ? 'text-success' : 'text-on-surface-variant'}`}>
                  {stat.trendUp && <ArrowUpRight className="w-3.5 h-3.5 mr-0.5" />}
                  {stat.trend}
                </span>
              )}
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Today's Appointments */}
        <div className="xl:col-span-2 space-y-6">
          <Card 
            title="Today's Appointments" 
            action={
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => navigate('/appointments')}
              >
                View All
              </Button>
            }
          >
            {loading ? (
              <div className="flex justify-center py-8">
                <Loader className="w-6 h-6 animate-spin text-primary" />
              </div>
            ) : todaysAppointments.length === 0 ? (
              <EmptyState
                icon={<CalendarIcon className="w-6 h-6" />}
                title="No appointments today"
                description="No appointments scheduled for today."
                action={
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => navigate('/appointments')}
                  >
                    Schedule Appointment
                  </Button>
                }
              />
            ) : (
              <div className="space-y-3">
                {todaysAppointments.map(app => {
                  const patientName = app.patients 
                    ? `${app.patients.first_name} ${app.patients.last_name}`
                    : 'Unknown Patient';
                  
                  return (
                    <div 
                      key={app.id} 
                      onClick={() => navigate('/appointments')}
                      className="flex items-center gap-4 p-3.5 border border-outline-variant rounded-xl hover:bg-surface-container-low hover:border-primary/20 transition-colors cursor-pointer"
                    >
                      <div className="w-12 h-12 rounded-xl bg-primary-container text-primary flex items-center justify-center font-bold font-headline shrink-0">
                        {formatTime(app.start_time).split(':')[0]}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold text-on-surface truncate">{patientName}</h4>
                        <p className="text-sm text-on-surface-variant flex items-center gap-1.5 mt-0.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary"></span>
                          {app.appointment_type}
                        </p>
                      </div>
                      <div className="flex flex-col sm:flex-row items-end sm:items-center gap-2 shrink-0">
                        <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${statusBadge(app.status)}`}>
                          {app.status}
                        </span>
                        <div className="text-sm font-medium text-on-surface-variant bg-surface-container px-3 py-1.5 rounded-lg flex items-center gap-1.5">
                          <Clock className="w-4 h-4" />
                          {formatTime(app.start_time)}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </Card>
        </div>
        
        {/* Quick Actions */}
        <div>
          <Card title="Quick Actions">
            <div className="space-y-3">
               <Button 
                 className="w-full justify-start" 
                 variant="secondary" 
                 icon={<CalendarIcon className="w-5 h-5 mr-2" />}
                 onClick={() => navigate('/appointments')}
               >
                 Manage Schedule
               </Button>
               <Button 
                 className="w-full justify-start" 
                 variant="secondary" 
                 icon={<UserPlus className="w-5 h-5 mr-2" />}
                 onClick={() => navigate('/patients')}
               >
                 Add New Patient
               </Button>
            </div>
            
            <div className="mt-8 bg-surface-container-low p-4 rounded-xl border border-outline-variant">
               <h4 className="font-semibold text-sm text-on-surface mb-3">Quick Stats</h4>
               <ul className="space-y-2.5 text-sm">
                 <li className="flex justify-between">
                   <span className="text-on-surface-variant">Active Patients</span>
                   <span className="font-semibold">{stats.totalPatients}</span>
                 </li>
                 <li className="flex justify-between">
                   <span className="text-on-surface-variant">This Week</span>
                   <span className="font-semibold">{stats.upcomingAppointments} appointments</span>
                 </li>
                 <li className="flex justify-between">
                   <span className="text-on-surface-variant">Completed Today</span>
                   <span className="font-semibold">{stats.completedToday}</span>
                 </li>
               </ul>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
