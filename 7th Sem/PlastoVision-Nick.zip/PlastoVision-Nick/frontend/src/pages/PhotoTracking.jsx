import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { getPatientPhotos, getPatientProcedures, batchLoadPhotos, revokeBlobUrls } from '../services/photoService';
import { getFacialView } from '../services/validationService';
import { SIX_VIEWS, canonicalView, matchingPhotos, comparisonWarnings } from '../lib/photoComparison';
import PhotoComparison from '../components/photos/PhotoComparison';
import PageHeader from '../components/ui/PageHeader';
import Button from '../components/ui/Button';
import { ScanFace } from 'lucide-react';

export default function PhotoTracking() {
  const navigate = useNavigate();
  const [patients, setPatients] = useState([]);
  const [patient, setPatient] = useState('');
  const [photos, setPhotos] = useState([]);
  const [urls, setUrls] = useState({});
  const [visits, setVisits] = useState([]);
  const [procedures, setProcedures] = useState([]);
  const [procedure, setProcedure] = useState('legacy');
  const [leftVisit, setLeftVisit] = useState('');
  const [rightVisit, setRightVisit] = useState('');
  const [selections, setSelections] = useState({});
  const [pair, setPair] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [timelineView, setTimelineView] = useState('frontal_neutral');
  useEffect(() => {
    let active = true;
    supabase.from('patients').select('id,first_name,last_name,patient_code').order('last_name').then(({data,error}) => {
      if (!active) return;
      if (error) setError(error.message); else setPatients(data || []);
    });
    return () => { active = false; };
  }, []);
  useEffect(() => {
    let active = true;
    let loadedUrls = {};
    queueMicrotask(() => { if (active) { setPhotos([]); setUrls({}); setPair(null); setSelections({}); setVisits([]); setProcedures([]); } });
    if (!patient) return;
    queueMicrotask(() => { if (active) { setLoading(true); setError(''); } });
    Promise.all([
      getPatientPhotos(patient),
      supabase.from('visits').select('id,visit_date').eq('patient_id',patient).order('visit_date'),
      getPatientProcedures(patient)
    ]).then(async ([photos,v,p]) => {
      if (v.error) throw v.error;
      if (!active) return;
      setPhotos(photos); setVisits(v.data || []); setProcedures(p);
      setProcedure(p[0]?.id || 'legacy');
      setLeftVisit(v.data?.[0]?.id || 'unlinked'); setRightVisit(v.data?.at(-1)?.id || 'unlinked');
      loadedUrls = await batchLoadPhotos(photos.map(p => p.id));
      if (active) setUrls(loadedUrls); else revokeBlobUrls(Object.values(loadedUrls));
    }).catch(error => { if (active) setError(error.response?.data?.error || error.message); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; revokeBlobUrls(Object.values(loadedUrls)); };
  }, [patient]);
  const visitLabel = id => id === 'unlinked' ? 'Legacy photographs without visit' : new Date(visits.find(v => v.id === id)?.visit_date).toLocaleDateString();
  const selected = (view, side) => {
    const candidates = matchingPhotos(photos,procedure,side === 'left' ? leftVisit : rightVisit,view);
    return candidates.find(p => p.id === selections[`${view}-${side}`]) || candidates[0];
  };
  const renderPhoto = (view, side) => {
    const candidates = matchingPhotos(photos,procedure,side === 'left' ? leftVisit : rightVisit,view);
    const photo = selected(view,side);
    return <div className="space-y-2">
      {!photo ? <div className="p-8 rounded-xl bg-surface-container text-on-surface-variant text-sm">Missing photograph for this view and visit</div> : <>
        <select aria-label={`${view} ${side} photograph`} value={photo.id} onChange={e => setSelections({...selections,[`${view}-${side}`]:e.target.value})} className="w-full">
          {candidates.map(p => <option key={p.id} value={p.id}>{new Date(p.captured_at).toLocaleString()} — {p.treatment_stage}</option>)}
        </select>
        {urls[photo.id] ? <img src={urls[photo.id]} alt={`${getFacialView(view)?.name}, ${visitLabel(photo.visit_id || 'unlinked')}`} className="w-full h-64 object-contain bg-navy rounded-xl" /> : <p className="text-sm text-on-surface-variant">Image unavailable; check local storage.</p>}
        <p className="text-xs text-on-surface-variant">{photo.validation_status} · {photo.framing_protocol || 'Unknown protocol'} · Original photograph</p>
      </>}
    </div>;
  };
  const timeline = photos.filter(p => (p.procedure_id || 'legacy') === procedure && canonicalView(p.facial_view) === timelineView)
    .sort((a,b) => new Date(a.captured_at)-new Date(b.captured_at));
  return <div className="space-y-6">
    <PageHeader
      icon={<ScanFace className="w-7 h-7" />}
      title="Longitudinal facial photography"
      subtitle="Compare original photographs across visits without altering image content."
    />
    <div className="flex flex-wrap gap-4 items-end bg-surface-container-lowest border border-outline-variant rounded-2xl p-4">
      <label className="text-sm">Patient <select aria-label="Patient" value={patient} onChange={e => setPatient(e.target.value)} className="block mt-1 min-w-56"><option value="">Select patient</option>{patients.map(p => <option key={p.id} value={p.id}>{p.patient_code} — {p.first_name} {p.last_name}</option>)}</select></label>
      {patient && <Button size="sm" variant="outline" onClick={() => navigate(`/patients/${patient}`)}>Capture at patient profile</Button>}
      <label className="text-sm">Procedure <select aria-label="Procedure" value={procedure} onChange={e => { setProcedure(e.target.value); setSelections({}); }} className="block mt-1 min-w-48"><option value="legacy">Legacy / unspecified procedure</option>{procedures.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></label>
      {['left','right'].map(side => <label key={side} className="text-sm">{side === 'left' ? 'Earlier' : 'Later'} visit <select aria-label={`${side} visit`} className="block mt-1 min-w-48" value={side === 'left' ? leftVisit : rightVisit} onChange={e => { (side === 'left' ? setLeftVisit : setRightVisit)(e.target.value); setSelections({}); }}><option value="unlinked">Legacy / no visit</option>{visits.map(v => <option key={v.id} value={v.id}>{visitLabel(v.id)} — {v.id.slice(0,8)}</option>)}</select></label>)}
    </div>
    {error && <p role="alert" className="text-error bg-error-container rounded-xl px-4 py-3 text-sm">{error}</p>}{loading && <p className="text-sm text-on-surface-variant">Loading local photographs…</p>}
    {patient && SIX_VIEWS.map(view => {
      const left = selected(view,'left'), right = selected(view,'right');
      return <section key={view} className="p-5 rounded-2xl border border-outline-variant bg-surface-container-lowest shadow-[var(--shadow-card)] space-y-3"><div className="flex flex-wrap justify-between gap-3 items-center"><h2 className="font-semibold font-headline">{getFacialView(view)?.name}</h2><Button size="sm" disabled={!left || !right || !urls[left.id] || !urls[right.id]} onClick={() => setPair([left,right])}>Inspect / compare</Button></div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4"><div><p className="text-sm text-on-surface-variant mb-2">{visitLabel(leftVisit)}</p>{renderPhoto(view,'left')}</div><div><p className="text-sm text-on-surface-variant mb-2">{visitLabel(rightVisit)}</p>{renderPhoto(view,'right')}</div></div>
        {comparisonWarnings(left,right).map(message => <p key={message} className="text-sm text-warning bg-warning-container rounded-lg px-3 py-2">{message}</p>)}
      </section>;
    })}
    {patient && <section className="space-y-3 bg-surface-container-lowest border border-outline-variant rounded-2xl p-5"><h2 className="font-semibold font-headline">Same-view chronological timeline</h2>
      <select aria-label="Timeline view" value={timelineView} onChange={e => setTimelineView(e.target.value)}>{SIX_VIEWS.map(v => <option key={v} value={v}>{getFacialView(v)?.name}</option>)}</select>
      <div className="flex gap-4 overflow-auto pb-1">{timeline.map(p => <article key={p.id} className="min-w-48 max-w-64 border border-outline-variant rounded-xl p-2 bg-surface-container-low">{urls[p.id] && <img src={urls[p.id]} alt="Historical original" className="h-40 w-full object-contain rounded-lg bg-navy" />}<p className="text-sm mt-2">{new Date(p.captured_at).toLocaleDateString()} · {p.treatment_stage}</p><p className="text-xs text-on-surface-variant">{visitLabel(p.visit_id || 'unlinked')}</p></article>)}</div>
    </section>}
    {pair && <PhotoComparison isOpen onClose={() => setPair(null)} leftPhoto={pair[0]} rightPhoto={pair[1]} leftPhotoUrl={urls[pair[0].id]} rightPhotoUrl={urls[pair[1].id]} />}
  </div>;
}
