import React from 'react';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import PageHeader from '../components/ui/PageHeader';
import { Upload, Box, Eye, Maximize, Rotate3D, Layers } from 'lucide-react';

const Visualization = () => {
  return (
    <div className="space-y-6 h-[calc(100vh-8rem)] flex flex-col">
      <PageHeader
        icon={<Box className="w-7 h-7" />}
        title="3D Visualization"
        subtitle="Generate and manipulate patient 3D models. This workspace is a preview placeholder."
        action={
          <div className="flex gap-2">
            <Button variant="outline" icon={<Upload className="w-4 h-4 mr-2" />}>Import Scans</Button>
            <Button>Generate Model</Button>
          </div>
        }
      />

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-4 gap-6 min-h-0">
        {/* Sidebar Controls */}
        <div className="lg:col-span-1 flex flex-col gap-6 overflow-y-auto pr-1">
          <Card title="Input Images (3 Photos)" className="shrink-0">
            <div className="space-y-3">
              {['Front', 'Left Profile', 'Right Profile'].map((view, i) => (
                <div key={i} className="border-2 border-dashed border-outline-variant rounded-xl p-4 flex flex-col items-center justify-center text-center bg-surface-container-lowest hover:bg-surface-container-low hover:border-primary/50 transition-colors cursor-pointer group h-24">
                  <Upload className="w-5 h-5 text-on-surface-variant group-hover:text-primary mb-1" />
                  <p className="text-xs font-semibold text-on-surface">{view}</p>
                  <p className="text-[10px] text-on-surface-variant">Click to upload</p>
                </div>
              ))}
            </div>
          </Card>

          <Card title="Morph Controls" className="flex-1">
            <div className="space-y-6">
               <div className="space-y-2">
                 <div className="flex justify-between text-xs font-bold">
                   <label>Tip Projection</label>
                   <span className="text-primary">45%</span>
                 </div>
                 <input type="range" className="w-full h-1.5 bg-surface-variant rounded-lg appearance-none cursor-pointer accent-primary" defaultValue="45" />
               </div>
               
               <div className="space-y-2">
                 <div className="flex justify-between text-xs font-bold">
                   <label>Bridge Height</label>
                   <span className="text-primary">-20%</span>
                 </div>
                 <input type="range" className="w-full h-1.5 bg-surface-variant rounded-lg appearance-none cursor-pointer accent-primary" defaultValue="30" />
               </div>
               
               <div className="space-y-2">
                 <div className="flex justify-between text-xs font-bold">
                   <label>Nostril Width</label>
                   <span className="text-primary">10%</span>
                 </div>
                 <input type="range" className="w-full h-1.5 bg-surface-variant rounded-lg appearance-none cursor-pointer accent-primary" defaultValue="60" />
               </div>
            </div>
            
            <div className="mt-8 pt-4 border-t border-outline-variant grid grid-cols-2 gap-2">
               <Button variant="outline" size="sm">Reset</Button>
               <Button variant="secondary" size="sm">Compare</Button>
            </div>
          </Card>
        </div>

        {/* 3D Viewport Placeholder */}
        <Card noPadding className="lg:col-span-3 flex flex-col bg-surface-container-lowest border border-outline overflow-hidden relative">
           <div className="absolute top-4 left-4 z-10 flex gap-2">
              <div className="bg-surface/80 backdrop-blur-md border border-outline-variant rounded-lg p-1.5 flex gap-1 shadow-sm">
                 <button className="p-1.5 rounded bg-surface-container-high text-on-surface"><Rotate3D className="w-4 h-4" /></button>
                 <button className="p-1.5 rounded hover:bg-surface-container-high text-on-surface-variant hover:text-on-surface"><Eye className="w-4 h-4" /></button>
                 <button className="p-1.5 rounded hover:bg-surface-container-high text-on-surface-variant hover:text-on-surface"><Layers className="w-4 h-4" /></button>
              </div>
           </div>
           
           <div className="absolute top-4 right-4 z-10">
              <button className="bg-surface/80 backdrop-blur-md border border-outline-variant rounded-lg p-2 shadow-sm text-on-surface-variant hover:text-on-surface">
                 <Maximize className="w-4 h-4" />
              </button>
           </div>
        
           <div className="flex-1 w-full h-full bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-surface-container to-surface-container-highest flex flex-col items-center justify-center">
              
              {/* Interactive Dummy Mesh Graphic */}
              <div className="relative w-64 h-64 sm:w-96 sm:h-96 opacity-60">
                 <svg viewBox="0 0 100 100" className="w-full h-full text-primary drop-shadow-[0_0_15px_rgba(15,82,186,0.3)] stroke-current" fill="none" strokeWidth="0.5">
                   {/* Simplified geometric head placeholder */}
                   <path d="M50 10 C30 10, 20 30, 20 50 C20 70, 35 90, 50 90 C65 90, 80 70, 80 50 C80 30, 70 10, 50 10 Z" />
                   <path d="M35 45 C35 45, 50 60, 65 45" />
                   <path d="M50 40 L50 65 L45 70" />
                   <path d="M30 30 L70 30" />
                   <path d="M40 20 L60 20" />
                   <path d="M25 40 L75 40" />
                   <path d="M25 60 L75 60" />
                   <path d="M30 75 L70 75" />
                 </svg>
                 
                 <div className="absolute inset-0 flex items-center justify-center">
                    <div className="bg-surface/90 backdrop-blur px-4 py-2 rounded-full border border-primary/30 shadow-lg text-sm font-bold flex items-center gap-2">
                       <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
                       Model Rendered (Preview)
                    </div>
                 </div>
              </div>
              
           </div>
           
           <div className="h-12 border-t border-outline-variant bg-surface-container-lowest flex items-center justify-between px-4 text-xs font-semibold text-on-surface-variant">
              <span>Vertex Count: 24,592</span>
              <span>Render Engine: WebGL 2.0</span>
           </div>
        </Card>
      </div>
    </div>
  );
};

export default Visualization;
