import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Table from '../components/ui/Table';
import Modal from '../components/ui/Modal';
import { useToast } from '../contexts/ToastContext';
import { getPatients, createPatient, deletePatient } from '../services/patientService';
import PageHeader from '../components/ui/PageHeader';
import EmptyState from '../components/ui/EmptyState';
import { Search, UserPlus, Filter, MoreHorizontal, Loader } from 'lucide-react';

const Patients = () => {
  const navigate = useNavigate();
  const toast = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddPatientOpen, setIsAddPatientOpen] = useState(false);
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    gender: 'Male',
    date_of_birth: '',
    age: '',
    phone: '',
    email: '',
    address: '',
    city: '',
    state: '',
    country: '',
    blood_group: '',
    emergency_contact_name: '',
    emergency_contact_phone: '',
    occupation: '',
    chief_complaint: '',
    medical_history: '',
    allergies: ''
  });

  // Load patients on mount
  useEffect(() => {
    loadPatients();
  }, []);

  const loadPatients = async () => {
    setLoading(true);
    const { data, error } = await getPatients();
    if (error) {
      toast.error('Failed to load patients');
      console.error(error);
    } else {
      setPatients(data || []);
    }
    setLoading(false);
  };

  // Calculate age from date of birth
  const calculateAge = (dob) => {
    if (!dob) return '';
    const today = new Date();
    const birthDate = new Date(dob);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => {
      const updated = { ...prev, [name]: value };
      // Auto-calculate age when date of birth changes
      if (name === 'date_of_birth') {
        updated.age = calculateAge(value);
      }
      return updated;
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validate required fields
    if (!formData.first_name || !formData.last_name) {
      toast.error('First name and last name are required');
      return;
    }

    setSubmitting(true);
    const loadingToast = toast.loading('Creating patient...');

    const { data, error } = await createPatient(formData);
    
    toast.dismiss(loadingToast);
    setSubmitting(false);

    if (error) {
      toast.error(`Failed to create patient: ${error}`);
    } else {
      toast.success('Patient created successfully!');
      setIsAddPatientOpen(false);
      resetForm();
      loadPatients(); // Reload the list
    }
  };

  const resetForm = () => {
    setFormData({
      first_name: '',
      last_name: '',
      gender: 'Male',
      date_of_birth: '',
      age: '',
      phone: '',
      email: '',
      address: '',
      city: '',
      state: '',
      country: '',
      blood_group: '',
      emergency_contact_name: '',
      emergency_contact_phone: '',
      occupation: '',
      chief_complaint: '',
      medical_history: '',
      allergies: ''
    });
  };

  const filteredPatients = patients.filter(patient => {
    const search = searchTerm.toLowerCase();
    const fullName = `${patient.first_name} ${patient.last_name}`.toLowerCase();
    return (
      fullName.includes(search) ||
      patient.patient_code?.toLowerCase().includes(search) ||
      patient.phone?.toLowerCase().includes(search) ||
      patient.email?.toLowerCase().includes(search)
    );
  });

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const columns = [
    { 
      key: 'patient_code', 
      title: 'Patient ID', 
      render: (val) => <span className="font-mono text-xs bg-surface-container px-2 py-1 rounded">{val || 'N/A'}</span> 
    },
    { 
      key: 'first_name', 
      title: 'Name', 
      render: (_, row) => {
        const fullName = `${row.first_name} ${row.last_name}`;
        const initials = `${row.first_name[0]}${row.last_name[0]}`.toUpperCase();
        return (
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-primary-container text-primary flex items-center justify-center font-semibold text-xs">
              {initials}
            </div>
            <span className="font-semibold">{fullName}</span>
          </div>
        );
      }
    },
    { 
      key: 'age', 
      title: 'Age/Gender', 
      render: (_, row) => `${row.age || 'N/A'} / ${row.gender || 'N/A'}` 
    },
    { 
      key: 'phone', 
      title: 'Phone',
      render: (val) => val || 'N/A'
    },
    { 
      key: 'created_at', 
      title: 'Registered', 
      render: (val) => formatDate(val)
    },
    { 
      key: 'actions', 
      title: '', 
      render: () => (
        <Button variant="ghost" size="icon" className="text-on-surface-variant">
          <MoreHorizontal className="w-5 h-5" />
        </Button>
      ) 
    }
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Patient Management"
        subtitle="Manage records, consults, and post-op checkups."
        action={
          <Button onClick={() => setIsAddPatientOpen(true)} icon={<UserPlus className="w-5 h-5 mr-2" />}>
            Add Patient
          </Button>
        }
      />

      <Card className="flex-1 min-h-[500px] flex flex-col" noPadding>
        <div className="p-4 border-b border-outline-variant flex flex-col sm:flex-row gap-3 bg-surface-container-low">
           <div className="relative flex-1 max-w-md">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-on-surface-variant" />
             <input 
               type="text" 
               placeholder="Search by name, ID, phone, or email..."
               className="w-full pl-9 pr-4 py-2 bg-surface border border-outline-variant rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary"
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
             />
           </div>
           <Button variant="outline" icon={<Filter className="w-4 h-4 mr-2" />}>Filter</Button>
        </div>
        
        {loading ? (
          <div className="flex items-center justify-center h-64">
            <Loader className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : filteredPatients.length === 0 ? (
          <EmptyState
            icon={<UserPlus className="w-6 h-6" />}
            title="No Patients Found"
            description={searchTerm ? 'Try adjusting your search criteria' : 'Get started by adding your first patient'}
            action={!searchTerm ? (
              <Button onClick={() => setIsAddPatientOpen(true)} icon={<UserPlus className="w-5 h-5 mr-2" />}>
                Add Patient
              </Button>
            ) : null}
          />
        ) : (
          <Table 
            columns={columns} 
            data={filteredPatients} 
            onRowClick={(row) => navigate(`/patients/${row.id}`)}
          />
        )}
      </Card>

      <Modal 
        isOpen={isAddPatientOpen} 
        onClose={() => {
          setIsAddPatientOpen(false);
          resetForm();
        }}
        title="Add New Patient"
        size="xl"
        footer={
          <>
            <Button 
              variant="ghost" 
              onClick={() => {
                setIsAddPatientOpen(false);
                resetForm();
              }}
              disabled={submitting}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleSubmit}
              disabled={submitting}
            >
              {submitting ? 'Saving...' : 'Save Patient'}
            </Button>
          </>
        }
      >
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Personal Information */}
          <div>
            <h3 className="section-title mb-4">Personal Information</h3>
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-on-surface">First Name *</label>
                  <input 
                    type="text" 
                    name="first_name"
                    value={formData.first_name}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary" 
                    placeholder="John"
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-on-surface">Last Name *</label>
                  <input 
                    type="text" 
                    name="last_name"
                    value={formData.last_name}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary" 
                    placeholder="Doe"
                    required
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-on-surface">Date of Birth</label>
                  <input 
                    type="date" 
                    name="date_of_birth"
                    value={formData.date_of_birth}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-on-surface">Age</label>
                  <input 
                    type="number" 
                    name="age"
                    value={formData.age}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
                    placeholder="Auto-calculated"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-on-surface">Gender</label>
                  <select 
                    name="gender"
                    value={formData.gender}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 bg-surface text-on-surface border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
                  >
                    <option>Male</option>
                    <option>Female</option>
                    <option>Other</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-on-surface">Phone</label>
                  <input 
                    type="tel" 
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
                    placeholder="+1 (555) 123-4567"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-on-surface">Email</label>
                  <input 
                    type="email" 
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
                    placeholder="john.doe@example.com"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-sm font-medium text-on-surface">Blood Group</label>
                <select 
                  name="blood_group"
                  value={formData.blood_group}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 bg-surface text-on-surface border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
                >
                  <option value="">Select Blood Group</option>
                  <option>A+</option>
                  <option>A-</option>
                  <option>B+</option>
                  <option>B-</option>
                  <option>AB+</option>
                  <option>AB-</option>
                  <option>O+</option>
                  <option>O-</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-sm font-medium text-on-surface">Occupation</label>
                <input 
                  type="text" 
                  name="occupation"
                  value={formData.occupation}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
                  placeholder="Software Engineer"
                />
              </div>
            </div>
          </div>

          {/* Address Information */}
          <div>
            <h3 className="section-title mb-4">Address Information</h3>
            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-on-surface">Address</label>
                <input 
                  type="text" 
                  name="address"
                  value={formData.address}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
                  placeholder="123 Main Street"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-on-surface">City</label>
                  <input 
                    type="text" 
                    name="city"
                    value={formData.city}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
                    placeholder="San Francisco"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-on-surface">State</label>
                  <input 
                    type="text" 
                    name="state"
                    value={formData.state}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
                    placeholder="California"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-on-surface">Country</label>
                  <input 
                    type="text" 
                    name="country"
                    value={formData.country}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
                    placeholder="USA"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Emergency Contact */}
          <div>
            <h3 className="section-title mb-4">Emergency Contact</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-on-surface">Contact Name</label>
                <input 
                  type="text" 
                  name="emergency_contact_name"
                  value={formData.emergency_contact_name}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
                  placeholder="Jane Doe"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-on-surface">Contact Phone</label>
                <input 
                  type="tel" 
                  name="emergency_contact_phone"
                  value={formData.emergency_contact_phone}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
                  placeholder="+1 (555) 987-6543"
                />
              </div>
            </div>
          </div>

          {/* Medical Information */}
          <div>
            <h3 className="section-title mb-4">Medical Information</h3>
            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-on-surface">Chief Complaint</label>
                <textarea 
                  name="chief_complaint"
                  value={formData.chief_complaint}
                  onChange={handleInputChange}
                  rows="2"
                  className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
                  placeholder="Primary reason for visit..."
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-on-surface">Medical History</label>
                <textarea 
                  name="medical_history"
                  value={formData.medical_history}
                  onChange={handleInputChange}
                  rows="3"
                  className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
                  placeholder="Previous surgeries, chronic conditions, medications..."
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium text-on-surface">Allergies</label>
                <textarea 
                  name="allergies"
                  value={formData.allergies}
                  onChange={handleInputChange}
                  rows="2"
                  className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
                  placeholder="Drug allergies, food allergies, etc..."
                />
              </div>
            </div>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Patients;
