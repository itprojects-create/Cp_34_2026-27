import React, { useState, useEffect } from 'react';
import { User, Building2, Bell, Lock, Palette, Users, Database, Info } from 'lucide-react';
import ProfileSettings from '../components/settings/ProfileSettings';
import ClinicSettings from '../components/settings/ClinicSettings';
import NotificationSettings from '../components/settings/NotificationSettings';
import SecuritySettings from '../components/settings/SecuritySettings';
import AppearanceSettings from '../components/settings/AppearanceSettings';
import UserManagement from '../components/settings/UserManagement';
import DataStorageSettings from '../components/settings/DataStorageSettings';
import SystemInfo from '../components/settings/SystemInfo';
import { getProfile } from '../services/settingsService';

const Settings = () => {
  const [activeTab, setActiveTab] = useState('profile');
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // For now, using hardcoded user ID - will be replaced with auth
  const CURRENT_USER_ID = 'dr-michaels-001';

  useEffect(() => {
    loadCurrentUser();
  }, []);

  const loadCurrentUser = async () => {
    setLoading(true);
    const { data, error } = await getProfile(CURRENT_USER_ID);
    if (data) {
      setCurrentUser(data);
    }
    setLoading(false);
  };

  const settingsTabs = [
    { id: 'profile', label: 'Profile', icon: User, component: ProfileSettings },
    { id: 'clinic', label: 'Clinic Settings', icon: Building2, component: ClinicSettings },
    { id: 'notifications', label: 'Notifications', icon: Bell, component: NotificationSettings },
    { id: 'security', label: 'Security', icon: Lock, component: SecuritySettings },
    { id: 'appearance', label: 'Appearance', icon: Palette, component: AppearanceSettings },
    { id: 'users', label: 'User Management', icon: Users, component: UserManagement, adminOnly: true },
    { id: 'data', label: 'Data & Storage', icon: Database, component: DataStorageSettings },
    { id: 'system', label: 'System Info', icon: Info, component: SystemInfo }
  ];

  // Filter tabs based on user role
  const visibleTabs = settingsTabs.filter(tab => {
    if (tab.adminOnly) {
      return currentUser?.role === 'Admin';
    }
    return true;
  });

  const activeTabData = visibleTabs.find(tab => tab.id === activeTab);
  const ActiveComponent = activeTabData?.component;

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="page-title">Settings</h1>
        <p className="page-subtitle">
          Manage your profile, clinic settings, and preferences
        </p>
      </div>

      <div className="flex flex-col lg:flex-row gap-6 items-start">
        <aside className="w-full lg:w-64 bg-surface-container-lowest rounded-2xl border border-outline-variant overflow-x-auto lg:overflow-y-auto shrink-0">
          <nav className="p-2 flex lg:flex-col gap-1 min-w-max lg:min-w-0">
            {visibleTabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-3 px-4 py-2.5 rounded-xl text-left text-sm transition-colors whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-primary-container text-on-primary-container font-medium'
                    : 'text-on-surface-variant hover:bg-surface-container hover:text-on-surface'
                }`}
              >
                <tab.icon className="w-5 h-5" />
                <span>{tab.label}</span>
              </button>
            ))}
          </nav>
        </aside>

        <div className="flex-1 w-full min-w-0">
          <div className="bg-surface-container-lowest rounded-2xl border border-outline-variant p-5 md:p-6 shadow-[var(--shadow-card)]">
            {ActiveComponent && (
              <ActiveComponent 
                userId={CURRENT_USER_ID}
                currentUserId={CURRENT_USER_ID}
                currentUserRole={currentUser?.role}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
