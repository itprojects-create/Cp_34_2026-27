import React from 'react';
import PageHeader from '../components/ui/PageHeader';
import EmptyState from '../components/ui/EmptyState';
import { FileText } from 'lucide-react';

const Reports = () => {
  return (
    <div className="space-y-6">
      <PageHeader
        icon={<FileText className="w-7 h-7" />}
        title="Reports"
        subtitle="Reporting is not available in this build."
      />
      <div className="bg-surface-container-lowest border border-outline-variant rounded-2xl">
        <EmptyState
          icon={<FileText className="w-6 h-6" />}
          title="Reports"
          description="This section is a placeholder. Existing navigation is unchanged; no reporting data is generated here."
        />
      </div>
    </div>
  );
};

export default Reports;
