import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Tabs from '../components/ui/Tabs';
import Modal from '../components/ui/Modal';
import { useToast } from '../contexts/ToastContext';
import { 
  getPatientById, 
  updatePatient, 
  deletePatient,
  getPatientVisits,
  getPatientDocuments,
  uploadPatientDocument,
  deleteDocument,
  createVisit
} from '../services/patientService';
import { getPatientAppointments, formatTime, formatDate, getStatusColor, getTypeColor } from '../services/appointmentService';
import { 
  ArrowLeft, 
  Edit3, 
  Activity, 
  Phone, 
  Mail, 
  MapPin, 
  Calendar, 
  FileText, 
  Download, 
  Trash2, 
  Upload,
  Loader,
  User,
  Heart,
  AlertCircle,
  Plus,
  Clock,
  Camera
} from 'lucide-react';
import PhotoTimeline from '../components/photos/PhotoTimeline';
import PhotoUploadModal from '../components/photos/PhotoUploadModal';
import { getPhotoStats } from '../services/photoService';

const PatientProfile = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const toast = useToast();

  const [patient, setPatient] = useState(null);
  const [visits, setVisits] = useState([]);
  const [documents, setDocuments] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [photoStats, setPhotoStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [isAddVisitModalOpen, setIsAddVisitModalOpen] = useState(false);
  const [isPhotoUploadModalOpen, setIsPhotoUploadModalOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [formData, setFormData] = useState({});
  const [visitFormData, setVisitFormData] = useState({
    visit_date: new Date().toISOString().split('T')[0],
    diagnosis: '',
    doctor_notes: '',
    treatment_plan: '',
    follow_up_date: ''
  });

  useEffect(() => {
    loadPatientData();
  }, [id]);

  const loadPatientData = async () => {
    setLoading(true);
    
    // Load patient details
    const { data: patientData, error: patientError } = await getPatientById(id);
    if (patientError) {
      toast.error('Failed to load patient data');
      navigate('/patients');
      return;
    }
    setPatient(patientData);
    setFormData(patientData);

    // Load visits
    const { data: visitsData } = await getPatientVisits(id);
    setVisits(visitsData || []);

    // Load documents
    const { data: documentsData } = await getPatientDocuments(id);
    setDocuments(documentsData || []);

    // Load appointments
    const { data: appointmentsData } = await getPatientAppointments(id);
    setAppointments(appointmentsData || []);

    // Load photo statistics
    try {
      const stats = await getPhotoStats(id);
      setPhotoStats(stats);
    } catch (error) {
      console.error('Failed to load photo stats:', error);
      setPhotoStats({ total_photos: 0 });
    }

    setLoading(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleVisitInputChange = (e) => {
    const { name, value } = e.target;
    setVisitFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleUpdatePatient = async () => {
    const loadingToast = toast.loading('Updating patient...');
    
    const { data, error } = await updatePatient(id, formData);
    toast.dismiss(loadingToast);

    if (error) {
      toast.error('Failed to update patient');
    } else {
      toast.success('Patient updated successfully!');
      setPatient(data);
      setIsEditModalOpen(false);
      loadPatientData();
    }
  };

  const handleDeletePatient = async () => {
    const loadingToast = toast.loading('Deleting patient...');
    
    const { success, error } = await deletePatient(id);
    toast.dismiss(loadingToast);

    if (error) {
      toast.error('Failed to delete patient');
    } else {
      toast.success('Patient deleted successfully!');
      navigate('/patients');
    }
  };

  const handleAddVisit = async () => {
    if (!visitFormData.diagnosis) {
      toast.error('Diagnosis is required');
      return;
    }

    const loadingToast = toast.loading('Adding visit...');
    
    const visitData = {
      ...visitFormData,
      patient_id: id
    };

    const { data, error } = await createVisit(visitData);
    toast.dismiss(loadingToast);

    if (error) {
      toast.error('Failed to add visit');
    } else {
      toast.success('Visit added successfully!');
      setIsAddVisitModalOpen(false);
      setVisitFormData({
        visit_date: new Date().toISOString().split('T')[0],
        diagnosis: '',
        doctor_notes: '',
        treatment_plan: '',
        follow_up_date: ''
      });
      loadPatientData();
    }
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast.error('File size must be less than 10MB');
      return;
    }

    setUploading(true);
    const loadingToast = toast.loading('Uploading document...');

    const { data, error } = await uploadPatientDocument(file, id);
    
    toast.dismiss(loadingToast);
    setUploading(false);

    if (error) {
      toast.error(`Failed to upload document: ${error}`);
    } else {
      toast.success('Document uploaded successfully!');
      loadPatientData();
    }

    // Reset file input
    e.target.value = '';
  };

  const handleDeleteDocument = async (docId, fileUrl) => {
    if (!window.confirm('Are you sure you want to delete this document?')) {
      return;
    }

    const loadingToast = toast.loading('Deleting document...');
    
    const { success, error } = await deleteDocument(docId, fileUrl);
    toast.dismiss(loadingToast);

    if (error) {
      toast.error('Failed to delete document');
    } else {
      toast.success('Document deleted successfully!');
      loadPatientData();
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const formatFileSize = (bytes) => {
    if (!bytes) return 'N/A';
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!patient) {
    return (
      <div className="flex flex-col items-center justify-center h-screen">
        <AlertCircle className="w-16 h-16 text-error mb-4" />
        <h2 className="text-xl font-bold mb-2">Patient Not Found</h2>
        <Button onClick={() => navigate('/patients')}>Back to Patients</Button>
      </div>
    );
  }

  const OverviewTab = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <Card title="Personal Information">
        <div className="space-y-3 text-sm">
          <div className="flex justify-between">
            <span className="text-on-surface-variant">Date of Birth:</span>
            <span className="font-medium">{formatDate(patient.date_of_birth)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-on-surface-variant">Blood Group:</span>
            <span className="font-medium">{patient.blood_group || 'N/A'}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-on-surface-variant">Occupation:</span>
            <span className="font-medium">{patient.occupation || 'N/A'}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-on-surface-variant">Address:</span>
            <span className="font-medium text-right">{patient.address || 'N/A'}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-on-surface-variant">City, State:</span>
            <span className="font-medium">{patient.city && patient.state ? `${patient.city}, ${patient.state}` : 'N/A'}</span>
          </div>
        </div>
      </Card>

      <Card title="Emergency Contact">
        <div className="space-y-3 text-sm">
          <div className="flex justify-between">
            <span className="text-on-surface-variant">Contact Name:</span>
            <span className="font-medium">{patient.emergency_contact_name || 'N/A'}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-on-surface-variant">Contact Phone:</span>
            <span className="font-medium">{patient.emergency_contact_phone || 'N/A'}</span>
          </div>
        </div>
      </Card>

      <Card title="Chief Complaint" className="md:col-span-2">
        <p className="text-sm text-on-surface whitespace-pre-wrap">
          {patient.chief_complaint || 'No chief complaint recorded.'}
        </p>
      </Card>

      <Card title="Medical History">
        <p className="text-sm text-on-surface whitespace-pre-wrap">
          {patient.medical_history || 'No medical history recorded.'}
        </p>
      </Card>

      <Card title="Allergies">
        <p className="text-sm text-on-surface whitespace-pre-wrap">
          {patient.allergies || 'No known allergies.'}
        </p>
      </Card>
    </div>
  );

  const VisitHistoryTab = () => (
    <div className="space-y-4">
      <div className="flex justify-end mb-4">
        <Button 
          onClick={() => setIsAddVisitModalOpen(true)}
          icon={<Plus className="w-4 h-4 mr-2" />}
        >
          Add Visit
        </Button>
      </div>

      {visits.length === 0 ? (
        <div className="text-center py-12">
          <Calendar className="w-16 h-16 text-outline mx-auto mb-4" />
          <h3 className="text-lg font-bold mb-2">No Visits Recorded</h3>
          <p className="text-sm text-on-surface-variant mb-4">Start by adding the first visit for this patient</p>
          <Button onClick={() => setIsAddVisitModalOpen(true)} icon={<Plus className="w-4 h-4 mr-2" />}>
            Add Visit
          </Button>
        </div>
      ) : (
        <div className="space-y-6 relative before:absolute before:inset-y-0 before:left-[17px] before:w-[2px] before:bg-outline-variant pl-2">
          {visits.map((visit, i) => (
            <div key={visit.id} className="relative pl-10">
              <div className="absolute left-0 top-1.5 w-9 h-9 rounded-full bg-surface-container-lowest border-2 border-primary flex items-center justify-center shadow-sm">
                <div className="w-2.5 h-2.5 rounded-full bg-primary"></div>
              </div>
              <Card className="p-4 sm:p-5">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 mb-3">
                  <h4 className="font-bold font-headline text-lg">Visit {visits.length - i}</h4>
                  <div className="flex items-center text-sm text-on-surface-variant gap-1">
                    <Calendar className="w-4 h-4" />
                    {formatDate(visit.visit_date)}
                  </div>
                </div>
                
                <div className="space-y-2 text-sm">
                  <div>
                    <span className="font-medium text-on-surface-variant">Diagnosis: </span>
                    <span className="text-on-surface">{visit.diagnosis || 'N/A'}</span>
                  </div>
                  {visit.doctor_notes && (
                    <div>
                      <span className="font-medium text-on-surface-variant">Notes: </span>
                      <span className="text-on-surface">{visit.doctor_notes}</span>
                    </div>
                  )}
                  {visit.treatment_plan && (
                    <div>
                      <span className="font-medium text-on-surface-variant">Treatment Plan: </span>
                      <span className="text-on-surface">{visit.treatment_plan}</span>
                    </div>
                  )}
                  {visit.follow_up_date && (
                    <div>
                      <span className="font-medium text-on-surface-variant">Follow-up: </span>
                      <span className="text-on-surface">{formatDate(visit.follow_up_date)}</span>
                    </div>
                  )}
                </div>
              </Card>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  const DocumentsTab = () => (
    <div className="space-y-4">
      <div className="flex justify-end mb-4">
        <label>
          <input 
            type="file" 
            className="hidden" 
            onChange={handleFileUpload}
            accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
            disabled={uploading}
          />
          <Button 
            as="span" 
            icon={<Upload className="w-4 h-4 mr-2" />}
            disabled={uploading}
          >
            {uploading ? 'Uploading...' : 'Upload Document'}
          </Button>
        </label>
      </div>

      {documents.length === 0 ? (
        <div className="text-center py-12">
          <FileText className="w-16 h-16 text-outline mx-auto mb-4" />
          <h3 className="text-lg font-bold mb-2">No Documents</h3>
          <p className="text-sm text-on-surface-variant mb-4">Upload patient documents, reports, or prescriptions</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {documents.map((doc) => (
            <Card key={doc.id} className="flex flex-col p-4 gap-3 hover:border-primary/50 transition-colors group">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded bg-primary/10 text-primary flex items-center justify-center flex-shrink-0">
                  <FileText className="w-5 h-5" />
                </div>
                <div className="flex-1 overflow-hidden">
                  <h4 className="font-bold text-sm truncate">{doc.file_name}</h4>
                  <p className="text-xs text-on-surface-variant">
                    {formatFileSize(doc.file_size)} • {formatDate(doc.uploaded_at)}
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="flex-1"
                  onClick={() => window.open(doc.file_url, '_blank')}
                  icon={<Download className="w-3 h-3 mr-1" />}
                >
                  Download
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => handleDeleteDocument(doc.id, doc.file_url)}
                  icon={<Trash2 className="w-3 h-3" />}
                />
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );

  const AppointmentsTab = () => (
    <div className="space-y-4">
      {appointments.length === 0 ? (
        <div className="text-center py-12">
          <Calendar className="w-16 h-16 text-outline mx-auto mb-4" />
          <h3 className="text-lg font-bold mb-2">No Appointments</h3>
          <p className="text-sm text-on-surface-variant mb-4">Schedule appointments from the Appointments page</p>
          <Button onClick={() => navigate('/appointments')} icon={<Plus className="w-4 h-4 mr-2" />}>
            Schedule Appointment
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          {/* Upcoming Appointments */}
          <div>
            <h4 className="font-bold text-sm text-on-surface mb-3">Upcoming Appointments</h4>
            {appointments.filter(apt => {
              const aptDate = new Date(apt.appointment_date);
              const today = new Date();
              today.setHours(0, 0, 0, 0);
              return aptDate >= today && apt.status !== 'Cancelled' && apt.status !== 'Completed';
            }).length === 0 ? (
              <p className="text-sm text-on-surface-variant py-4">No upcoming appointments</p>
            ) : (
              appointments.filter(apt => {
                const aptDate = new Date(apt.appointment_date);
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                return aptDate >= today && apt.status !== 'Cancelled' && apt.status !== 'Completed';
              }).map(apt => (
                <Card key={apt.id} className="p-4 mb-3 hover:border-primary/50 transition-colors cursor-pointer">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h5 className="font-bold text-on-surface">{apt.appointment_type}</h5>
                      <p className="text-sm text-on-surface-variant">with {apt.doctor_name}</p>
                    </div>
                    <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${getStatusColor(apt.status)}`}>
                      {apt.status}
                    </span>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-on-surface-variant">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      {formatDate(apt.appointment_date)}
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {formatTime(apt.start_time)} - {formatTime(apt.end_time)}
                    </div>
                  </div>
                </Card>
              ))
            )}
          </div>

          {/* Past Appointments */}
          <div>
            <h4 className="font-bold text-sm text-on-surface mb-3 mt-6">Past Appointments</h4>
            {appointments.filter(apt => {
              const aptDate = new Date(apt.appointment_date);
              const today = new Date();
              today.setHours(0, 0, 0, 0);
              return aptDate < today || apt.status === 'Completed' || apt.status === 'Cancelled';
            }).length === 0 ? (
              <p className="text-sm text-on-surface-variant py-4">No past appointments</p>
            ) : (
              appointments.filter(apt => {
                const aptDate = new Date(apt.appointment_date);
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                return aptDate < today || apt.status === 'Completed' || apt.status === 'Cancelled';
              }).map(apt => (
                <Card key={apt.id} className="p-4 mb-3 opacity-75">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h5 className="font-bold text-on-surface">{apt.appointment_type}</h5>
                      <p className="text-sm text-on-surface-variant">with {apt.doctor_name}</p>
                    </div>
                    <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${getStatusColor(apt.status)}`}>
                      {apt.status}
                    </span>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-on-surface-variant">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      {formatDate(apt.appointment_date)}
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {formatTime(apt.start_time)}
                    </div>
                  </div>
                </Card>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );

  const FacialPhotographyTab = () => {
    // Get the most recent appointment for photo upload
    const recentAppointment = appointments.length > 0 
      ? [...appointments].sort((a, b) => new Date(b.appointment_date) - new Date(a.appointment_date))[0]
      : null;

    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h3 className="section-title">Facial Photography</h3>
            <p className="text-sm text-on-surface-variant">
              {photoStats ? `${photoStats.total_photos} photos captured` : 'Loading...'}
            </p>
          </div>
          <Button 
            onClick={() => setIsPhotoUploadModalOpen(true)}
            icon={<Camera className="w-4 h-4 mr-2" />}
          >
            Capture Photo
          </Button>
        </div>

        <PhotoTimeline 
          patientId={id}
          onPhotoDeleted={() => {
            loadPatientData();
          }}
        />

        {/* Photo Upload Modal */}
        {isPhotoUploadModalOpen && (
          <PhotoUploadModal
            isOpen={isPhotoUploadModalOpen}
            onClose={() => setIsPhotoUploadModalOpen(false)}
            patientId={id}
            appointmentId={recentAppointment?.id}
            onUploadSuccess={() => {
              toast.success('Photo uploaded successfully!');
              loadPatientData();
            }}
          />
        )}
      </div>
    );
  };

  const tabs = [
    { label: 'Overview', value: 'overview', content: <OverviewTab /> },
    { label: `Appointments (${appointments.length})`, value: 'appointments', content: <AppointmentsTab /> },
    { label: `Facial Photography${photoStats ? ` (${photoStats.total_photos})` : ''}`, value: 'photos', content: <FacialPhotographyTab /> },
    { label: `Visit History (${visits.length})`, value: 'visits', content: <VisitHistoryTab /> },
    { label: `Documents (${documents.length})`, value: 'documents', content: <DocumentsTab /> },
  ];

  const fullName = `${patient.first_name} ${patient.last_name}`;
  const initials = `${patient.first_name[0]}${patient.last_name[0]}`.toUpperCase();

  return (
    <div className="space-y-6">
      <Button variant="ghost" onClick={() => navigate('/patients')} className="mb-2 -ml-2" icon={<ArrowLeft className="w-4 h-4 mr-1" />}>
        Back to Patients
      </Button>
      
      <Card noPadding className="overflow-hidden bg-surface-container-lowest">
        <div className="h-16 bg-navy" />
        <div className="p-5 md:p-6 -mt-10">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 border-b border-outline-variant pb-6 mb-6">
            <div className="flex items-end gap-4 min-w-0">
              <div className="w-20 h-20 rounded-2xl bg-primary-container text-primary text-2xl flex items-center justify-center font-bold shadow-md border-4 border-surface-container-lowest shrink-0">
                {initials}
              </div>
              <div className="min-w-0 pb-1">
                <div className="flex flex-wrap items-center gap-2 mb-1">
                  <h1 className="text-2xl md:text-3xl font-bold font-headline truncate">{fullName}</h1>
                  <span className="font-mono text-xs bg-surface-container px-2 py-0.5 rounded-md text-on-surface-variant">
                    {patient.patient_code}
                  </span>
                </div>
                <p className="text-on-surface-variant flex gap-3 text-sm">
                  <span>{patient.age} yrs</span>
                  <span className="w-1 h-1 rounded-full bg-outline-variant mt-2"></span>
                  <span>{patient.gender}</span>
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                onClick={() => setIsEditModalOpen(true)}
                icon={<Edit3 className="w-4 h-4 mr-2" />}
              >
                Edit Profile
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setIsDeleteModalOpen(true)}
                icon={<Trash2 className="w-4 h-4" />}
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-sm">
             <div className="flex items-start gap-3">
               <Phone className="w-5 h-5 text-on-surface-variant mt-0.5" />
               <div>
                 <p className="font-medium text-on-surface-variant">Phone</p>
                 <p className="font-bold">{patient.phone || 'N/A'}</p>
               </div>
             </div>
             <div className="flex items-start gap-3">
               <Mail className="w-5 h-5 text-on-surface-variant mt-0.5" />
               <div>
                 <p className="font-medium text-on-surface-variant">Email</p>
                 <p className="font-bold break-all">{patient.email || 'N/A'}</p>
               </div>
             </div>
             <div className="flex items-start gap-3">
               <MapPin className="w-5 h-5 text-on-surface-variant mt-0.5" />
               <div>
                 <p className="font-medium text-on-surface-variant">Location</p>
                 <p className="font-bold">{patient.city && patient.country ? `${patient.city}, ${patient.country}` : 'N/A'}</p>
               </div>
             </div>
          </div>
        </div>
      </Card>

      <Card className="p-2 sm:p-6 pb-0">
        <Tabs tabs={tabs} defaultValue="overview" />
      </Card>

      {/* Edit Patient Modal */}
      <Modal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        title="Edit Patient Information"
        size="xl"
        footer={
          <>
            <Button variant="ghost" onClick={() => setIsEditModalOpen(false)}>Cancel</Button>
            <Button onClick={handleUpdatePatient}>Save Changes</Button>
          </>
        }
      >
        <form className="space-y-6">
          <div>
            <h3 className="text-lg font-bold mb-4 text-on-surface">Personal Information</h3>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-on-surface">First Name</label>
                  <input 
                    type="text" 
                    name="first_name"
                    value={formData.first_name || ''}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary" 
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-on-surface">Last Name</label>
                  <input 
                    type="text" 
                    name="last_name"
                    value={formData.last_name || ''}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary" 
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-on-surface">Phone</label>
                  <input 
                    type="tel" 
                    name="phone"
                    value={formData.phone || ''}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-on-surface">Email</label>
                  <input 
                    type="email" 
                    name="email"
                    value={formData.email || ''}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-sm font-medium text-on-surface">Address</label>
                <input 
                  type="text" 
                  name="address"
                  value={formData.address || ''}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-sm font-medium text-on-surface">Medical History</label>
                <textarea 
                  name="medical_history"
                  value={formData.medical_history || ''}
                  onChange={handleInputChange}
                  rows="3"
                  className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-sm font-medium text-on-surface">Allergies</label>
                <textarea 
                  name="allergies"
                  value={formData.allergies || ''}
                  onChange={handleInputChange}
                  rows="2"
                  className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
                />
              </div>
            </div>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        title="Delete Patient"
        footer={
          <>
            <Button variant="ghost" onClick={() => setIsDeleteModalOpen(false)}>Cancel</Button>
            <Button variant="danger" onClick={handleDeletePatient}>Delete Patient</Button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="flex items-center gap-3 p-4 bg-error/10 rounded-lg">
            <AlertCircle className="w-6 h-6 text-error flex-shrink-0" />
            <div>
              <p className="font-medium text-error">This action cannot be undone</p>
              <p className="text-sm text-on-surface-variant mt-1">
                All patient data including visits, medications, and document metadata will be permanently deleted.
              </p>
            </div>
          </div>
          <p className="text-sm text-on-surface">
            Are you sure you want to delete <strong>{fullName}</strong>?
          </p>
        </div>
      </Modal>

      {/* Add Visit Modal */}
      <Modal
        isOpen={isAddVisitModalOpen}
        onClose={() => setIsAddVisitModalOpen(false)}
        title="Add New Visit"
        size="lg"
        footer={
          <>
            <Button variant="ghost" onClick={() => setIsAddVisitModalOpen(false)}>Cancel</Button>
            <Button onClick={handleAddVisit}>Add Visit</Button>
          </>
        }
      >
        <form className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-sm font-medium text-on-surface">Visit Date</label>
            <input 
              type="date" 
              name="visit_date"
              value={visitFormData.visit_date}
              onChange={handleVisitInputChange}
              className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-sm font-medium text-on-surface">Diagnosis *</label>
            <input 
              type="text" 
              name="diagnosis"
              value={visitFormData.diagnosis}
              onChange={handleVisitInputChange}
              className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
              placeholder="Primary diagnosis..."
              required
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-sm font-medium text-on-surface">Doctor Notes</label>
            <textarea 
              name="doctor_notes"
              value={visitFormData.doctor_notes}
              onChange={handleVisitInputChange}
              rows="3"
              className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
              placeholder="Clinical observations, findings..."
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-sm font-medium text-on-surface">Treatment Plan</label>
            <textarea 
              name="treatment_plan"
              value={visitFormData.treatment_plan}
              onChange={handleVisitInputChange}
              rows="3"
              className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
              placeholder="Recommended treatment, procedures..."
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-sm font-medium text-on-surface">Follow-up Date</label>
            <input 
              type="date" 
              name="follow_up_date"
              value={visitFormData.follow_up_date}
              onChange={handleVisitInputChange}
              className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary"
            />
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default PatientProfile;
