import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Modal from '../components/ui/Modal';
import { useToast } from '../contexts/ToastContext';
import AppointmentForm from '../components/appointments/AppointmentForm';
import AppointmentCard from '../components/appointments/AppointmentCard';
import PageHeader from '../components/ui/PageHeader';
import EmptyState from '../components/ui/EmptyState';
import {
  getAppointmentsByDate,
  getAppointmentsByDateRange,
  createAppointment,
  updateAppointment,
  updateAppointmentStatus,
  formatTime,
  formatDate,
  getStatusColor,
  getTypeColor
} from '../services/appointmentService';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Plus,
  Clock,
  Loader,
  Search,
  Filter,
  X,
  Eye,
  Edit3,
  CheckCircle,
  XCircle,
  AlertCircle
} from 'lucide-react';

const Appointments = () => {
  const navigate = useNavigate();
  const toast = useToast();

  // State management
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [appointments, setAppointments] = useState([]);
  const [todaysAppointments, setTodaysAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  // Modal states
  const [isNewAppointmentOpen, setIsNewAppointmentOpen] = useState(false);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState(null);

  // View states
  const [viewMode, setViewMode] = useState('day'); // 'day', 'week', 'month'
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  // Load appointments on mount and when date changes
  useEffect(() => {
    loadAppointments();
  }, [selectedDate, viewMode]);

  const loadAppointments = async () => {
    setLoading(true);
    
    let result;
    if (viewMode === 'day') {
      const dateStr = selectedDate.toISOString().split('T')[0];
      result = await getAppointmentsByDate(dateStr);
    } else if (viewMode === 'week') {
      const start = new Date(selectedDate);
      start.setDate(start.getDate() - start.getDay());
      const end = new Date(start);
      end.setDate(end.getDate() + 6);
      
      result = await getAppointmentsByDateRange(
        start.toISOString().split('T')[0],
        end.toISOString().split('T')[0]
      );
    } else {
      // Month view
      const start = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), 1);
      const end = new Date(selectedDate.getFullYear(), selectedDate.getMonth() + 1, 0);
      
      result = await getAppointmentsByDateRange(
        start.toISOString().split('T')[0],
        end.toISOString().split('T')[0]
      );
    }

    if (result.error) {
      toast.error('Failed to load appointments');
    } else {
      setAppointments(result.data || []);
    }

    // Load today's appointments
    const today = new Date().toISOString().split('T')[0];
    const todayResult = await getAppointmentsByDate(today);
    if (!todayResult.error) {
      setTodaysAppointments(todayResult.data || []);
    }

    setLoading(false);
  };

  const handleCreateAppointment = async (formData) => {
    setSubmitting(true);
    const loadingToast = toast.loading('Creating appointment...');

    const { data, error } = await createAppointment(formData);

    toast.dismiss(loadingToast);
    setSubmitting(false);

    if (error) {
      toast.error(error);
    } else {
      toast.success('Appointment created successfully!');
      setIsNewAppointmentOpen(false);
      loadAppointments();
    }
  };

  const handleUpdateAppointment = async (formData) => {
    if (!selectedAppointment) return;

    setSubmitting(true);
    const loadingToast = toast.loading('Updating appointment...');

    const { data, error } = await updateAppointment(selectedAppointment.id, formData);

    toast.dismiss(loadingToast);
    setSubmitting(false);

    if (error) {
      toast.error(error);
    } else {
      toast.success('Appointment updated successfully!');
      setIsEditOpen(false);
      setSelectedAppointment(null);
      loadAppointments();
    }
  };

  const handleStatusChange = async (appointmentId, newStatus) => {
    const loadingToast = toast.loading('Updating status...');

    const { data, error } = await updateAppointmentStatus(appointmentId, newStatus);

    toast.dismiss(loadingToast);

    if (error) {
      toast.error('Failed to update status');
    } else {
      toast.success(`Appointment marked as ${newStatus}!`);
      loadAppointments();
      if (isDetailsOpen) {
        setSelectedAppointment(data);
      }
    }
  };

  const navigateDate = (direction) => {
    const newDate = new Date(selectedDate);
    
    if (viewMode === 'day') {
      newDate.setDate(newDate.getDate() + direction);
    } else if (viewMode === 'week') {
      newDate.setDate(newDate.getDate() + (direction * 7));
    } else {
      newDate.setMonth(newDate.getMonth() + direction);
    }
    
    setSelectedDate(newDate);
  };

  const goToToday = () => {
    setSelectedDate(new Date());
  };

  const openAppointmentDetails = (appointment) => {
    setSelectedAppointment(appointment);
    setIsDetailsOpen(true);
  };

  const openEditModal = () => {
    setIsDetailsOpen(false);
    setIsEditOpen(true);
  };

  // Filter appointments
  const filteredAppointments = appointments.filter(apt => {
    if (statusFilter !== 'all' && apt.status !== statusFilter) return false;
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      const patientName = `${apt.patients?.first_name || ''} ${apt.patients?.last_name || ''}`.toLowerCase();
      const patientCode = (apt.patients?.patient_code || '').toLowerCase();
      if (!patientName.includes(search) && !patientCode.includes(search)) return false;
    }
    return true;
  });

  const getDateString = () => {
    if (viewMode === 'day') {
      return selectedDate.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
    } else if (viewMode === 'week') {
      const start = new Date(selectedDate);
      start.setDate(start.getDate() - start.getDay());
      const end = new Date(start);
      end.setDate(end.getDate() + 6);
      return `${start.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${end.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}`;
    } else {
      return selectedDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        icon={<CalendarIcon className="w-7 h-7" />}
        title="Appointments"
        subtitle="Manage consultations, follow-ups and surgeries."
        action={
          <Button onClick={() => setIsNewAppointmentOpen(true)} icon={<Plus className="w-5 h-5 mr-1" />}>
            New Appointment
          </Button>
        }
      />

      {/* Navigation and Filters */}
      <Card className="p-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          {/* Date Navigation */}
          <div className="flex items-center gap-3">
            <Button variant="outline" size="sm" onClick={() => navigateDate(-1)}>
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <div className="font-medium text-on-surface min-w-[200px] text-center">
              {getDateString()}
            </div>
            <Button variant="outline" size="sm" onClick={() => navigateDate(1)}>
              <ChevronRight className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={goToToday}>
              Today
            </Button>
          </div>

          {/* View Mode Toggle */}
          <div className="flex items-center gap-2">
            <Button
              variant={viewMode === 'day' ? 'primary' : 'outline'}
              size="sm"
              onClick={() => setViewMode('day')}
            >
              Day
            </Button>
            <Button
              variant={viewMode === 'week' ? 'primary' : 'outline'}
              size="sm"
              onClick={() => setViewMode('week')}
            >
              Week
            </Button>
            <Button
              variant={viewMode === 'month' ? 'primary' : 'outline'}
              size="sm"
              onClick={() => setViewMode('month')}
            >
              Month
            </Button>
          </div>
        </div>

        {/* Search and Filter */}
        <div className="flex flex-col md:flex-row gap-3 mt-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-on-surface-variant" />
            <input
              type="text"
              placeholder="Search by patient name or ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-surface border border-outline-variant rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 bg-surface border border-outline-variant rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="all">All Status</option>
            <option value="Scheduled">Scheduled</option>
            <option value="Confirmed">Confirmed</option>
            <option value="Completed">Completed</option>
            <option value="Cancelled">Cancelled</option>
            <option value="No Show">No Show</option>
          </select>
        </div>
      </Card>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Today's Schedule Sidebar */}
        <div className="lg:col-span-1">
          <Card title="Today's Schedule">
            {loading ? (
              <div className="flex justify-center py-8">
                <Loader className="w-6 h-6 animate-spin text-primary" />
              </div>
            ) : todaysAppointments.length === 0 ? (
              <EmptyState
                icon={<CalendarIcon className="w-6 h-6" />}
                title="No appointments today"
              />
            ) : (
              <div className="space-y-3">
                {todaysAppointments.map(apt => (
                  <AppointmentCard
                    key={apt.id}
                    appointment={apt}
                    onClick={() => openAppointmentDetails(apt)}
                    compact
                  />
                ))}
              </div>
            )}
          </Card>
        </div>

        {/* Appointments List */}
        <Card className="lg:col-span-3" title={`Appointments (${filteredAppointments.length})`}>
          {loading ? (
            <div className="flex justify-center py-12">
              <Loader className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : filteredAppointments.length === 0 ? (
            <EmptyState
              icon={<CalendarIcon className="w-6 h-6" />}
              title="No Appointments Found"
              description={
                searchTerm || statusFilter !== 'all'
                  ? 'Try adjusting your search or filters'
                  : 'Get started by scheduling your first appointment'
              }
              action={!searchTerm && statusFilter === 'all' ? (
                <Button onClick={() => setIsNewAppointmentOpen(true)} icon={<Plus className="w-5 h-5 mr-2" />}>
                  New Appointment
                </Button>
              ) : null}
            />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredAppointments.map(apt => (
                <AppointmentCard
                  key={apt.id}
                  appointment={apt}
                  onClick={() => openAppointmentDetails(apt)}
                />
              ))}
            </div>
          )}
        </Card>
      </div>

      {/* New Appointment Modal */}
      <Modal
        isOpen={isNewAppointmentOpen}
        onClose={() => setIsNewAppointmentOpen(false)}
        title="Schedule New Appointment"
        size="xl"
      >
        <AppointmentForm
          onSubmit={handleCreateAppointment}
          onCancel={() => setIsNewAppointmentOpen(false)}
          submitting={submitting}
        />
      </Modal>

      {/* Appointment Details Modal */}
      {selectedAppointment && (
        <Modal
          isOpen={isDetailsOpen}
          onClose={() => {
            setIsDetailsOpen(false);
            setSelectedAppointment(null);
          }}
          title="Appointment Details"
          size="lg"
          footer={
            <>
              <Button variant="ghost" onClick={() => setIsDetailsOpen(false)}>Close</Button>
              <Button variant="outline" onClick={openEditModal} icon={<Edit3 className="w-4 h-4 mr-2" />}>
                Edit
              </Button>
            </>
          }
        >
          <div className="space-y-6">
            {/* Patient Info */}
            <div className="p-4 bg-surface-container-low rounded-lg">
              <h3 className="font-bold text-sm text-on-surface-variant mb-3">Patient Information</h3>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full bg-primary-container text-primary flex items-center justify-center font-bold">
                  {selectedAppointment.patients?.first_name?.[0]}{selectedAppointment.patients?.last_name?.[0]}
                </div>
                <div>
                  <h4 className="font-bold text-on-surface">
                    {selectedAppointment.patients?.first_name} {selectedAppointment.patients?.last_name}
                  </h4>
                  <p className="text-sm text-on-surface-variant font-mono">{selectedAppointment.patients?.patient_code}</p>
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate(`/patients/${selectedAppointment.patient_id}`)}
                icon={<Eye className="w-4 h-4 mr-2" />}
              >
                View Patient Profile
              </Button>
            </div>

            {/* Appointment Details */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-on-surface-variant">Date</p>
                <p className="font-bold text-on-surface">{formatDate(selectedAppointment.appointment_date)}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-on-surface-variant">Time</p>
                <p className="font-bold text-on-surface">
                  {formatTime(selectedAppointment.start_time)} - {formatTime(selectedAppointment.end_time)}
                </p>
              </div>
              <div>
                <p className="text-sm font-medium text-on-surface-variant">Doctor</p>
                <p className="font-bold text-on-surface">{selectedAppointment.doctor_name}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-on-surface-variant">Type</p>
                <p className={`inline-flex px-2 py-1 rounded text-xs font-medium ${getTypeColor(selectedAppointment.appointment_type)}`}>
                  {selectedAppointment.appointment_type}
                </p>
              </div>
              <div>
                <p className="text-sm font-medium text-on-surface-variant">Status</p>
                <p className={`inline-flex px-2 py-1 rounded text-xs font-semibold ${getStatusColor(selectedAppointment.status)}`}>
                  {selectedAppointment.status}
                </p>
              </div>
              <div>
                <p className="text-sm font-medium text-on-surface-variant">Created</p>
                <p className="font-bold text-on-surface text-sm">{formatDate(selectedAppointment.created_at?.split('T')[0])}</p>
              </div>
            </div>

            {/* Notes */}
            {selectedAppointment.notes && (
              <div>
                <p className="text-sm font-medium text-on-surface-variant mb-2">Notes</p>
                <p className="text-sm text-on-surface bg-surface-container-low p-3 rounded-lg whitespace-pre-wrap">
                  {selectedAppointment.notes}
                </p>
              </div>
            )}

            {/* Status Actions */}
            {selectedAppointment.status !== 'Cancelled' && selectedAppointment.status !== 'Completed' && (
              <div className="pt-4 border-t border-outline-variant">
                <p className="text-sm font-medium text-on-surface-variant mb-3">Quick Actions</p>
                <div className="flex flex-wrap gap-2">
                  {selectedAppointment.status !== 'Confirmed' && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleStatusChange(selectedAppointment.id, 'Confirmed')}
                      icon={<CheckCircle className="w-4 h-4 mr-2" />}
                    >
                      Mark Confirmed
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleStatusChange(selectedAppointment.id, 'Completed')}
                    icon={<CheckCircle className="w-4 h-4 mr-2" />}
                  >
                    Mark Completed
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleStatusChange(selectedAppointment.id, 'No Show')}
                    icon={<AlertCircle className="w-4 h-4 mr-2" />}
                  >
                    Mark No Show
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleStatusChange(selectedAppointment.id, 'Cancelled')}
                    icon={<XCircle className="w-4 h-4 mr-2" />}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </div>
        </Modal>
      )}

      {/* Edit Appointment Modal */}
      {selectedAppointment && (
        <Modal
          isOpen={isEditOpen}
          onClose={() => {
            setIsEditOpen(false);
            setSelectedAppointment(null);
          }}
          title="Edit Appointment"
          size="xl"
        >
          <AppointmentForm
            initialData={selectedAppointment}
            onSubmit={handleUpdateAppointment}
            onCancel={() => setIsEditOpen(false)}
            submitting={submitting}
          />
        </Modal>
      )}
    </div>
  );
};

export default Appointments;
