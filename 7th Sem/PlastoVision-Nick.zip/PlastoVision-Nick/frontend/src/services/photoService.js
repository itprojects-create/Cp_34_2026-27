/**
 * Photo Service
 * 
 * Handles all API calls related to patient facial photography.
 */

import axios from '../lib/photoApi';

const API_BASE_URL = import.meta.env.VITE_BACKEND_URL || 'http://localhost:3001';
const API_PREFIX = '/api/patient-photos';

/**
 * Upload a photo with validation
 * 
 * @param {File} photoFile - Image file to upload
 * @param {string} patientId - Patient UUID
 * @param {string} appointmentId - Appointment UUID
 * @param {string} facialView - Facial view identifier
 * @param {string} treatmentStage - Treatment stage
 * @param {Object} additionalData - Optional capture metadata
 * @returns {Promise<Object>} Upload result with photo metadata
 */
export const uploadPhoto = async (photoFile, patientId, appointmentId, facialView, treatmentStage, additionalData = {}) => {
  const formData = new FormData();
  formData.append('photo', photoFile);
  formData.append('patientId', patientId);
  if (appointmentId) formData.append('appointmentId', appointmentId);
  formData.append('facialView', facialView);
  formData.append('treatmentStage', treatmentStage);
  formData.append('captureMethod', additionalData.captureMethod || 'upload');
  formData.append('captureId', additionalData.captureId || crypto.randomUUID());
  if (additionalData.visitId) formData.append('visitId', additionalData.visitId);
  if (additionalData.procedureId) formData.append('procedureId', additionalData.procedureId);
  formData.append('setup', JSON.stringify(additionalData.setup || {}));
  if (additionalData.reviewReason) formData.append('reviewReason', additionalData.reviewReason);

  // Add optional fields
  if (additionalData.notes) {
    formData.append('notes', additionalData.notes);
  }

  const response = await axios.post(`${API_BASE_URL}${API_PREFIX}/upload`, formData, {
    headers: {

    }
  });

  return response.data;
};

/**
 * Validate a photo without saving
 * 
 * @param {File} photoFile - Image file to validate
 * @param {string} facialView - Facial view identifier
 * @returns {Promise<Object>} Validation result
 */
export const validatePhoto = async (photoFile, facialView, setup = {}) => {
  const formData = new FormData();
  formData.append('photo', photoFile);
  formData.append('facialView', facialView);
  formData.append('setup', JSON.stringify(setup));

  const response = await axios.post(`${API_BASE_URL}${API_PREFIX}/validate`, formData, {
    headers: {

    }
  });

  return response.data.validation;
};

/**
 * Get photo file (returns blob URL for display)
 * 
 * @param {string} photoId - Photo UUID
 * @returns {Promise<string>} Blob URL for image display
 */
export const getPhotoFile = async (photoId, sanitizedExport = false) => {
  const response = await axios.get(`${API_BASE_URL}${API_PREFIX}/${photoId}`, {
    params: sanitizedExport ? { export: true } : {},
    responseType: 'blob'
  });

  // Create blob URL for display
  const blobUrl = URL.createObjectURL(response.data);
  return blobUrl;
};

/**
 * Get photo metadata
 * 
 * @param {string} photoId - Photo UUID
 * @returns {Promise<Object>} Photo metadata
 */
export const getPhotoMetadata = async (photoId) => {
  const response = await axios.get(`${API_BASE_URL}${API_PREFIX}/metadata/${photoId}`);
  return response.data;
};

/**
 * Get all photos for a patient
 * 
 * @param {string} patientId - Patient UUID
 * @param {Object} filters - Optional filters (treatment_stage, facial_view, limit)
 * @returns {Promise<Array>} Array of photo metadata objects
 */
export const getPatientPhotos = async (patientId, filters = {}) => {
  const params = new URLSearchParams();
  const names = { treatment_stage: 'treatmentStage', facial_view: 'facialView', visit_id: 'visitId', procedure_id: 'procedureId' };
  Object.entries(filters).forEach(([key,value]) => { if (value != null) params.set(names[key] || key, value); });
  const all = [];
  let offset = 0;
  let hasMore = true;
  while (hasMore) {
    params.set('limit', String(filters.limit || 100));
    params.set('offset', String(filters.offset ?? offset));
    const { data } = await axios.get(`${API_BASE_URL}${API_PREFIX}/patient/${patientId}`, { params });
    const page = data.photos || [];
    all.push(...page);
    if (filters.limit || filters.offset != null || page.length < 100) break;
    offset += page.length;
    hasMore = page.length === 100;
  }
  return all;
};

/**
 * Get photos for a specific visit
 * 
 * @param {string} visitId - Visit UUID
 * @returns {Promise<Array>} Array of photo metadata objects
 */
export const getVisitPhotos = async (visitId) => {
  const response = await axios.get(`${API_BASE_URL}${API_PREFIX}/visit/${visitId}`);
  return response.data.photos || [];
};

/**
 * Get patient photo statistics
 * 
 * @param {string} patientId - Patient UUID
 * @returns {Promise<Object>} Photo statistics
 */
export const getPhotoStats = async (patientId) => {
  const response = await axios.get(`${API_BASE_URL}${API_PREFIX}/patient/${patientId}/stats`);
  return { ...response.data.stats, total_photos: response.data.stats?.total || 0 };
};

/**
 * Get photo count by treatment stage
 * 
 * @param {string} patientId - Patient UUID
 * @returns {Promise<Object>} Count by treatment stage
 */
export const getPhotoCountByStage = async (patientId) => {
  const response = await axios.get(`${API_BASE_URL}${API_PREFIX}/patient/${patientId}/count-by-stage`);
  return response.data;
};

/**
 * Get treatment stage completion status
 * 
 * @param {string} patientId - Patient UUID
 * @param {string} treatmentStage - Treatment stage
 * @returns {Promise<Object>} Completion status with missing views
 */
export const getStageCompletion = async (patientId, treatmentStage) => {
  const response = await axios.get(
    `${API_BASE_URL}${API_PREFIX}/patient/${patientId}/stage-completion?treatmentStage=${encodeURIComponent(treatmentStage)}`
  );
  return response.data;
};

/**
 * Delete a photo
 * 
 * @param {string} photoId - Photo UUID
 * @returns {Promise<Object>} Deletion result
 */
export const deletePhoto = async (photoId) => {
  const response = await axios.delete(`${API_BASE_URL}${API_PREFIX}/${photoId}`);
  return response.data;
};

/**
 * Find similar cases based on procedure and treatment stage
 * 
 * @param {string} procedureType - Procedure type
 * @param {string} treatmentStage - Treatment stage
 * @param {number} limit - Maximum results (default: 10)
 * @returns {Promise<Array>} Array of similar case photos
 */
export const findSimilarCases = async (procedureType, treatmentStage, limit = 10) => {
  const response = await axios.get(`${API_BASE_URL}${API_PREFIX}/similar-cases`, {
    params: {
      procedure_type: procedureType,
      treatment_stage: treatmentStage,
      limit
    }
  });

  return response.data;
};

/**
 * Check CV service health
 * 
 * @returns {Promise<Object>} CV service health status
 */
export const checkCVServiceHealth = async () => {
  const response = await axios.get(`${API_BASE_URL}${API_PREFIX}/cv-service/health`);
  return response.data;
};

/**
 * Batch download photos as URLs
 * Helper function to load multiple photo files at once
 * 
 * @param {Array<string>} photoIds - Array of photo UUIDs
 * @returns {Promise<Object>} Map of photoId -> blobUrl
 */
export const batchLoadPhotos = async (photoIds) => {
  const photoUrls = {};
  
  await Promise.all(
    photoIds.map(async (photoId) => {
      try {
        const blobUrl = await getPhotoFile(photoId);
        photoUrls[photoId] = blobUrl;
      } catch (error) {
        console.error(`Failed to load photo ${photoId}:`, error);
        photoUrls[photoId] = null;
      }
    })
  );

  return photoUrls;
};

/**
 * Revoke blob URLs to free memory
 * Should be called when photos are no longer displayed
 * 
 * @param {Array<string>} blobUrls - Array of blob URLs to revoke
 */
export const revokeBlobUrls = (blobUrls) => {
  blobUrls.forEach(url => {
    if (url && url.startsWith('blob:')) {
      URL.revokeObjectURL(url);
    }
  });
};

/**
 * Get photo timeline for a patient
 * Returns photos grouped by treatment stage and date
 * 
 * @param {string} patientId - Patient UUID
 * @returns {Promise<Object>} Timeline data structure
 */
export const getPhotoTimeline = async (patientId) => {
  const response = await getPatientPhotos(patientId);
  
  // Handle response - could be array or object with photos property
  const photos = Array.isArray(response) ? response : (response?.photos || []);
  
  // Group by treatment stage
  const timeline = {};
  
  photos.forEach(photo => {
    const stage = photo.treatment_stage;
    
    if (!timeline[stage]) {
      timeline[stage] = {
        stage,
        photos: [],
        dates: new Set()
      };
    }
    
    timeline[stage].photos.push(photo);
    timeline[stage].dates.add(new Date(photo.captured_at).toLocaleDateString());
  });

  // Convert sets to arrays and sort
  Object.values(timeline).forEach(stageData => {
    stageData.dates = Array.from(stageData.dates).sort();
    stageData.photos.sort((a, b) => 
      new Date(b.captured_at) - new Date(a.captured_at)
    );
  });

  return timeline;
};

export default {
  uploadPhoto,
  validatePhoto,
  getPhotoFile,
  getPhotoMetadata,
  getPatientPhotos,
  getVisitPhotos,
  getPhotoStats,
  getPhotoCountByStage,
  getStageCompletion,
  deletePhoto,
  findSimilarCases,
  checkCVServiceHealth,
  batchLoadPhotos,
  revokeBlobUrls,
  getPhotoTimeline
};

export const getPatientProcedures = async patientId => {
  const { data } = await axios.get(`${API_BASE_URL}${API_PREFIX}/patient/${patientId}/procedures`);
  return data.procedures || [];
};
export const createPatientProcedure = async (patientId, name) => {
  const { data } = await axios.post(`${API_BASE_URL}${API_PREFIX}/patient/${patientId}/procedures`, { name });
  return data.procedure;
};
