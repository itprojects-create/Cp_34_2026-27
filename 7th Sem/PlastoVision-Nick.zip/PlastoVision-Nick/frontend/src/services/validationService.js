/**
 * Validation Service
 * 
 * Client-side validation helpers and CV service integration.
 */

import { validatePhoto, checkCVServiceHealth } from './photoService';

/**
 * Facial view configurations matching backend
 * Reduced to 6 standardized views for the capture workflow
 */
export const FACIAL_VIEWS = [
  {
    id: 'frontal_neutral',
    name: 'Frontal Neutral',
    description: 'Face camera directly with neutral expression',
    icon: '😐',
    instructions: [
      'Face the camera directly',
      'Keep your expression neutral',
      'Eyes open, mouth closed',
      'Head level, not tilted'
    ]
  },
  {
    id: 'right_oblique_45',
    name: 'Right Oblique',
    description: 'Turn head approximately 45° to the right',
    icon: '↗️',
    instructions: [
      'Turn your head 45° to the right',
      'Keep your expression neutral',
      'Both eyes should be visible',
      'Head level, not tilted'
    ]
  },
  {
    id: 'left_oblique_45',
    name: 'Left Oblique',
    description: 'Turn head approximately 45° to the left',
    icon: '↖️',
    instructions: [
      'Turn your head 45° to the left',
      'Keep your expression neutral',
      'Both eyes should be visible',
      'Head level, not tilted'
    ]
  },
  {
    id: 'right_lateral',
    name: 'Right Lateral',
    description: 'Turn head approximately 90° to the right (side profile)',
    icon: '➡️',
    instructions: [
      'Turn your head completely to the right',
      'Show full right profile',
      'Keep your expression neutral',
      'Head level, not tilted'
    ]
  },
  {
    id: 'left_lateral',
    name: 'Left Lateral',
    description: 'Turn head approximately 90° to the left (side profile)',
    icon: '⬅️',
    instructions: [
      'Turn your head completely to the left',
      'Show full left profile',
      'Keep your expression neutral',
      'Head level, not tilted'
    ]
  },
  {
    id: 'basal',
    name: 'Basal / Worm’s-eye',
    description: 'Camera positioned below face, looking upward',
    icon: '⬆️',
    instructions: [
      'Position camera below your face',
      'Extend your head gently to expose the nasal base; clinician adjusts camera viewpoint',
      'Face forward, not turned to sides',
      'Keep head level (not tilted sideways)'
    ]
  }
];

// Also export as object for backwards compatibility
export const FACIAL_VIEWS_MAP = FACIAL_VIEWS.reduce((acc, view) => {
  acc[view.id] = view;
  return acc;
}, {});

/**
 * Treatment stage options
 */
export const TREATMENT_STAGES = [
  ['Pre-Surgery','Preoperative'], ['Post-Surgery','Postoperative'],
  ['Follow-Up 1','Follow-up 1'], ['Follow-Up 2','Follow-up 2'],
  ['Follow-Up 3','Follow-up 3'], ['Follow-Up 4','Follow-up 4'],
  ['Follow-Up 5','Follow-up 5'], ['Additional Follow-Up','Additional follow-up']
].map(([value,label]) => ({value,label}));

/**
 * Get facial view configuration
 * 
 * @param {string} viewId - View identifier
 * @returns {Object|null} View configuration or null
 */
export const getFacialView = (viewId) => {
  const aliases = { right_oblique: 'right_oblique_45', left_oblique: 'left_oblique_45', worms_view: 'basal' };
  return FACIAL_VIEWS_MAP[aliases[viewId] || viewId] || null;
};

/**
 * Get all facial views as array
 * 
 * @returns {Array<Object>} Array of facial view configurations
 */
export const getAllFacialViews = () => {
  return FACIAL_VIEWS;
};

/**
 * Validate file before upload
 * Client-side validation before sending to server
 * 
 * @param {File} file - File to validate
 * @returns {Object} { valid: boolean, errors: Array<string> }
 */
export const validatePhotoFile = (file) => {
  const errors = [];

  // Check if file exists
  if (!file) {
    errors.push('No file selected');
    return { valid: false, errors };
  }

  // Check file type
  const validTypes = ['image/jpeg', 'image/jpg', 'image/png'];
  if (!validTypes.includes(file.type)) {
    errors.push('File must be JPEG or PNG format');
  }

  // Check file size (max 10MB)
  const maxSize = 10 * 1024 * 1024; // 10MB
  if (file.size > maxSize) {
    errors.push('File size must be less than 10MB');
  }

  // Check minimum size (avoid tiny images)
  const minSize = 10 * 1024; // 10KB
  if (file.size < minSize) {
    errors.push('File size is too small. Image may be corrupted.');
  }

  return {
    valid: errors.length === 0,
    errors
  };
};

/**
 * Validate photo with CV service
 * 
 * @param {File} photoFile - Photo file
 * @param {string} facialView - Facial view identifier
 * @returns {Promise<Object>} Validation result from CV service
 */
export const validatePhotoWithCV = async (photoFile, facialView, setup = {}) => {
  // First do client-side validation
  const fileValidation = validatePhotoFile(photoFile);
  
  if (!fileValidation.valid) {
    return {
      valid: false,
      errors: fileValidation.errors,
      warnings: [],
      clientSideValidation: true
    };
  }

  // Then validate with CV service
  try {
    const result = await validatePhoto(photoFile, facialView, setup);
    return {
      ...result,
      clientSideValidation: false
    };
  } catch (error) {
    // Handle network/server errors
    return {
      valid: false,
      errors: [error.response?.data?.error || error.message || 'Validation failed'],
      warnings: [],
      networkError: true
    };
  }
};

/**
 * Check if CV service is available
 * 
 * @returns {Promise<Object>} { available: boolean, status: Object }
 */
export const isCVServiceAvailable = async () => {
  try {
    const status = await checkCVServiceHealth();
    return {
      available: status.healthy,
      status
    };
  } catch (error) {
    return {
      available: false,
      status: null,
      error: error.message
    };
  }
};

/**
 * Parse validation errors into user-friendly messages
 * 
 * @param {Object} validationResult - Result from CV validation
 * @returns {Object} { primary: string, secondary: Array<string> }
 */
export const parseValidationErrors = (validationResult) => {
  const { errors = [], warnings = [], guidance = '' } = validationResult;

  // Primary error (most important)
  const primary = errors.length > 0 
    ? errors[0] 
    : validationResult.reviewable ? 'Clinician confirmation required' : guidance || 'Photo validation failed';

  // Secondary messages (other errors + warnings + guidance)
  const secondary = [
    ...errors.slice(1),
    ...warnings
  ];

  if (guidance && guidance !== 'Position looks good!') {
    secondary.unshift(guidance);
  }

  return { primary, secondary };
};

/**
 * Get validation status color/severity
 * 
 * @param {Object} validationResult - Validation result
 * @returns {string} 'success' | 'warning' | 'error'
 */
export const getValidationSeverity = (validationResult) => {
  if (validationResult.reviewable && !validationResult.valid) return 'warning';
  if (validationResult.valid) {
    return validationResult.warnings?.length > 0 ? 'warning' : 'success';
  }
  return 'error';
};

/**
 * Format angle for display
 * 
 * @param {number} angle - Angle in degrees
 * @param {string} type - 'yaw' | 'pitch' | 'roll'
 * @returns {string} Formatted angle with direction
 */
export const formatAngle = (angle, type) => {
  if (!Number.isFinite(angle)) return 'Unavailable';
  const absAngle = Math.abs(angle).toFixed(1);
  
  if (type === 'yaw') {
    return `${absAngle}° ${angle >= 0 ? 'right' : 'left'}`;
  } else if (type === 'pitch') {
    return `${absAngle}° ${angle >= 0 ? 'down' : 'up'}`;
  } else if (type === 'roll') {
    return `${absAngle}° ${angle >= 0 ? 'right' : 'left'}`;
  }
  
  return `${absAngle}°`;
};

/**
 * Calculate completion percentage for a treatment stage
 * 
 * @param {Array<string>} capturedViews - Array of captured view IDs
 * @returns {number} Percentage (0-100)
 */
export const calculateStageCompletion = (capturedViews) => {
  const totalViews = FACIAL_VIEWS.length;
  const captured = new Set(capturedViews.map(id => getFacialView(id)?.id).filter(Boolean)).size;
  return Math.round((captured / totalViews) * 100);
};

/**
 * Get missing views for a treatment stage
 * 
 * @param {Array<string>} capturedViews - Array of captured view IDs
 * @returns {Array<Object>} Array of missing view configurations
 */
export const getMissingViews = (capturedViews) => {
  const allViewIds = FACIAL_VIEWS.map(v => v.id);
  const missingIds = allViewIds.filter(id => !capturedViews.some(value => getFacialView(value)?.id === id));
  return missingIds.map(id => FACIAL_VIEWS_MAP[id]);
};

/**
 * Format file size for display
 * 
 * @param {number} bytes - File size in bytes
 * @returns {string} Formatted file size
 */
export const formatFileSize = (bytes) => {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
};

export default {
  FACIAL_VIEWS,
  TREATMENT_STAGES,
  getFacialView,
  getAllFacialViews,
  validatePhotoFile,
  validatePhotoWithCV,
  isCVServiceAvailable,
  parseValidationErrors,
  getValidationSeverity,
  formatAngle,
  calculateStageCompletion,
  getMissingViews,
  formatFileSize
};

/**
 * Get color class for validation status
 * @param {string} status - Validation status
 * @returns {string} Tailwind CSS color classes
 */
export const getValidationStatusColor = (status) => {
  switch (status) {
    case 'valid':
    case 'clinician_confirmed':
      return 'bg-green-100 text-green-800 border-green-300';
    case 'needs_review':
    case 'needs_manual_review':
      return 'bg-yellow-100 text-yellow-800 border-yellow-300';
    case 'invalid':
    case 'rejected':
      return 'bg-red-100 text-red-800 border-red-300';
    default:
      return 'bg-gray-100 text-gray-800 border-gray-300';
  }
};

/**
 * Get icon component name for validation status
 * @param {string} status - Validation status
 * @returns {string} Lucide icon name
 */
export const getValidationStatusIcon = (status) => {
  switch (status) {
    case 'valid':
    case 'clinician_confirmed':
      return 'CheckCircle';
    case 'needs_review':
    case 'needs_manual_review':
      return 'AlertTriangle';
    case 'invalid':
    case 'rejected':
      return 'XCircle';
    default:
      return 'HelpCircle';
  }
};

/**
 * Get human-readable label for validation status
 * @param {string} status - Validation status
 * @returns {string} Display label
 */
export const getValidationStatusLabel = (status) => {
  switch (status) {
    case 'valid':
      return 'Valid';
    case 'clinician_confirmed':
      return 'Confirmed';
    case 'needs_review':
    case 'needs_manual_review':
      return 'Needs Review';
    case 'invalid':
      return 'Invalid';
    case 'rejected':
      return 'Rejected';
    default:
      return status;
  }
};
