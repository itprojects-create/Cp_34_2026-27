import { supabase } from '../lib/supabase';

/**
 * Settings Service
 * Handles all settings-related database operations
 */

// ==================== PROFILE OPERATIONS ====================

/**
 * Get user profile by user_id
 * @param {String} userId - User identifier
 * @returns {Object} Profile data
 */
export const getProfile = async (userId) => {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error fetching profile:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Get all profiles (for user management)
 * @param {Object} options - Filter options
 * @returns {Array} List of profiles
 */
export const getAllProfiles = async (options = {}) => {
  try {
    let query = supabase
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false });

    // Filter by role
    if (options.role) {
      query = query.eq('role', options.role);
    }

    // Filter by active status
    if (options.is_active !== undefined) {
      query = query.eq('is_active', options.is_active);
    }

    // Search by name or email
    if (options.search) {
      query = query.or(
        `full_name.ilike.%${options.search}%,` +
        `email.ilike.%${options.search}%`
      );
    }

    const { data, error } = await query;

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error fetching profiles:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Create a new profile
 * @param {Object} profileData - Profile information
 * @returns {Object} Created profile data
 */
export const createProfile = async (profileData) => {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .insert([profileData])
      .select()
      .single();

    if (error) throw error;
    
    // Also create default preferences for the new user
    await createDefaultPreferences(profileData.user_id);
    
    return { data, error: null };
  } catch (error) {
    console.error('Error creating profile:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Update profile information
 * @param {String} userId - User identifier
 * @param {Object} updates - Fields to update
 * @returns {Object} Updated profile data
 */
export const updateProfile = async (userId, updates) => {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('user_id', userId)
      .select()
      .single();

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error updating profile:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Delete a profile (soft delete by setting is_active = false)
 * @param {String} userId - User identifier
 * @returns {Boolean} Success status
 */
export const deactivateProfile = async (userId) => {
  try {
    const { error } = await supabase
      .from('profiles')
      .update({ is_active: false })
      .eq('user_id', userId);

    if (error) throw error;
    return { success: true, error: null };
  } catch (error) {
    console.error('Error deactivating profile:', error);
    return { success: false, error: error.message };
  }
};

/**
 * Activate a profile
 * @param {String} userId - User identifier
 * @returns {Boolean} Success status
 */
export const activateProfile = async (userId) => {
  try {
    const { error } = await supabase
      .from('profiles')
      .update({ is_active: true })
      .eq('user_id', userId);

    if (error) throw error;
    return { success: true, error: null };
  } catch (error) {
    console.error('Error activating profile:', error);
    return { success: false, error: error.message };
  }
};

/**
 * Upload avatar to Supabase Storage
 * @param {File} file - Avatar image file
 * @param {String} userId - User identifier
 * @returns {Object} Upload result with URL
 */
export const uploadAvatar = async (file, userId) => {
  try {
    // Generate unique file name
    const fileExt = file.name.split('.').pop();
    const fileName = `${userId}/avatar_${Date.now()}.${fileExt}`;

    // Upload file to storage
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('user-avatars')
      .upload(fileName, file, {
        cacheControl: '3600',
        upsert: true
      });

    if (uploadError) throw uploadError;

    // Get public URL
    const { data: { publicUrl } } = supabase.storage
      .from('user-avatars')
      .getPublicUrl(fileName);

    // Update profile with new avatar URL
    const { error: updateError } = await supabase
      .from('profiles')
      .update({ avatar_url: publicUrl })
      .eq('user_id', userId);

    if (updateError) throw updateError;

    return { data: { url: publicUrl }, error: null };
  } catch (error) {
    console.error('Error uploading avatar:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Delete avatar from storage
 * @param {String} userId - User identifier
 * @param {String} avatarUrl - Current avatar URL
 * @returns {Boolean} Success status
 */
export const deleteAvatar = async (userId, avatarUrl) => {
  try {
    // Extract file path from URL
    const urlParts = avatarUrl.split('/');
    const bucketIndex = urlParts.findIndex(part => part === 'user-avatars');
    const filePath = urlParts.slice(bucketIndex + 1).join('/');

    // Delete from storage
    const { error: storageError } = await supabase.storage
      .from('user-avatars')
      .remove([filePath]);

    if (storageError) console.warn('Storage deletion warning:', storageError);

    // Update profile to remove avatar URL
    const { error: updateError } = await supabase
      .from('profiles')
      .update({ avatar_url: null })
      .eq('user_id', userId);

    if (updateError) throw updateError;

    return { success: true, error: null };
  } catch (error) {
    console.error('Error deleting avatar:', error);
    return { success: false, error: error.message };
  }
};

// ==================== CLINIC SETTINGS OPERATIONS ====================

/**
 * Get clinic settings
 * @returns {Object} Clinic settings data
 */
export const getClinicSettings = async () => {
  try {
    const { data, error } = await supabase
      .from('clinic_settings')
      .select('*')
      .limit(1)
      .single();

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error fetching clinic settings:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Update clinic settings
 * @param {String} settingsId - Clinic settings UUID
 * @param {Object} updates - Fields to update
 * @returns {Object} Updated clinic settings data
 */
export const updateClinicSettings = async (settingsId, updates) => {
  try {
    const { data, error } = await supabase
      .from('clinic_settings')
      .update(updates)
      .eq('id', settingsId)
      .select()
      .single();

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error updating clinic settings:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Upload clinic logo to Supabase Storage
 * @param {File} file - Logo image file
 * @returns {Object} Upload result with URL
 */
export const uploadClinicLogo = async (file) => {
  try {
    // Generate unique file name
    const fileExt = file.name.split('.').pop();
    const fileName = `logo_${Date.now()}.${fileExt}`;

    // Upload file to storage
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('clinic-logos')
      .upload(fileName, file, {
        cacheControl: '3600',
        upsert: true
      });

    if (uploadError) throw uploadError;

    // Get public URL
    const { data: { publicUrl } } = supabase.storage
      .from('clinic-logos')
      .getPublicUrl(fileName);

    return { data: { url: publicUrl }, error: null };
  } catch (error) {
    console.error('Error uploading clinic logo:', error);
    return { data: null, error: error.message };
  }
};

// ==================== NOTIFICATION PREFERENCES OPERATIONS ====================

/**
 * Get notification preferences for a user
 * @param {String} userId - User identifier
 * @returns {Object} Notification preferences data
 */
export const getNotificationPreferences = async (userId) => {
  try {
    const { data, error } = await supabase
      .from('notification_preferences')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (error) {
      // If no preferences exist, create default ones
      if (error.code === 'PGRST116') {
        return await createNotificationPreferences(userId);
      }
      throw error;
    }
    return { data, error: null };
  } catch (error) {
    console.error('Error fetching notification preferences:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Create notification preferences for a user
 * @param {String} userId - User identifier
 * @returns {Object} Created notification preferences data
 */
export const createNotificationPreferences = async (userId) => {
  try {
    const { data, error } = await supabase
      .from('notification_preferences')
      .insert([{ user_id: userId }])
      .select()
      .single();

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error creating notification preferences:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Update notification preferences
 * @param {String} userId - User identifier
 * @param {Object} updates - Fields to update
 * @returns {Object} Updated notification preferences data
 */
export const updateNotificationPreferences = async (userId, updates) => {
  try {
    const { data, error } = await supabase
      .from('notification_preferences')
      .update(updates)
      .eq('user_id', userId)
      .select()
      .single();

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error updating notification preferences:', error);
    return { data: null, error: error.message };
  }
};

// ==================== USER PREFERENCES OPERATIONS ====================

/**
 * Get user preferences
 * @param {String} userId - User identifier
 * @returns {Object} User preferences data
 */
export const getUserPreferences = async (userId) => {
  try {
    const { data, error } = await supabase
      .from('user_preferences')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (error) {
      // If no preferences exist, create default ones
      if (error.code === 'PGRST116') {
        return await createUserPreferences(userId);
      }
      throw error;
    }
    return { data, error: null };
  } catch (error) {
    console.error('Error fetching user preferences:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Create user preferences
 * @param {String} userId - User identifier
 * @returns {Object} Created user preferences data
 */
export const createUserPreferences = async (userId) => {
  try {
    const { data, error } = await supabase
      .from('user_preferences')
      .insert([{ user_id: userId }])
      .select()
      .single();

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error creating user preferences:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Update user preferences
 * @param {String} userId - User identifier
 * @param {Object} updates - Fields to update
 * @returns {Object} Updated user preferences data
 */
export const updateUserPreferences = async (userId, updates) => {
  try {
    const { data, error } = await supabase
      .from('user_preferences')
      .update(updates)
      .eq('user_id', userId)
      .select()
      .single();

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error updating user preferences:', error);
    return { data: null, error: error.message };
  }
};

// ==================== HELPER FUNCTIONS ====================

/**
 * Create default preferences for a new user
 * @param {String} userId - User identifier
 * @returns {Boolean} Success status
 */
const createDefaultPreferences = async (userId) => {
  try {
    // Create notification preferences
    await createNotificationPreferences(userId);
    
    // Create user preferences
    await createUserPreferences(userId);
    
    return { success: true, error: null };
  } catch (error) {
    console.error('Error creating default preferences:', error);
    return { success: false, error: error.message };
  }
};

/**
 * Check Supabase connection status
 * @returns {Object} Connection status
 */
export const checkSupabaseConnection = async () => {
  try {
    const { data, error } = await supabase
      .from('clinic_settings')
      .select('id')
      .limit(1);

    if (error) throw error;
    
    return { 
      connected: true, 
      status: 'Connected',
      error: null 
    };
  } catch (error) {
    console.error('Supabase connection check failed:', error);
    return { 
      connected: false, 
      status: 'Disconnected',
      error: error.message 
    };
  }
};

/**
 * Get storage usage statistics
 * @returns {Object} Storage usage data
 */
export const getStorageStats = async () => {
  try {
    // Get counts from all major tables
    const [patientsCount, visitsCount, appointmentsCount, documentsCount, profilesCount] = await Promise.all([
      supabase.from('patients').select('*', { count: 'exact', head: true }),
      supabase.from('visits').select('*', { count: 'exact', head: true }),
      supabase.from('appointments').select('*', { count: 'exact', head: true }),
      supabase.from('documents').select('*', { count: 'exact', head: true }),
      supabase.from('profiles').select('*', { count: 'exact', head: true })
    ]);

    return {
      data: {
        patients: patientsCount.count || 0,
        visits: visitsCount.count || 0,
        appointments: appointmentsCount.count || 0,
        documents: documentsCount.count || 0,
        users: profilesCount.count || 0
      },
      error: null
    };
  } catch (error) {
    console.error('Error fetching storage stats:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Change user password (using Supabase Auth)
 * Note: This requires Supabase Auth to be properly set up
 * For now, this is a placeholder for future implementation
 * @param {String} newPassword - New password
 * @returns {Boolean} Success status
 */
export const changePassword = async (newPassword) => {
  try {
    // This will be implemented when Supabase Auth is enabled
    // const { error } = await supabase.auth.updateUser({ password: newPassword });
    
    // Placeholder for now
    console.warn('Password change requires Supabase Auth to be configured');
    
    return { 
      success: false, 
      error: 'Password change feature requires Supabase Auth configuration' 
    };
  } catch (error) {
    console.error('Error changing password:', error);
    return { success: false, error: error.message };
  }
};

/**
 * Export all data (for data portability)
 * @returns {Object} All user data
 */
export const exportAllData = async () => {
  try {
    const [patients, visits, appointments, documents] = await Promise.all([
      supabase.from('patients').select('*'),
      supabase.from('visits').select('*'),
      supabase.from('appointments').select('*'),
      supabase.from('documents').select('*')
    ]);

    const exportData = {
      export_date: new Date().toISOString(),
      patients: patients.data || [],
      visits: visits.data || [],
      appointments: appointments.data || [],
      documents: documents.data || []
    };

    return { data: exportData, error: null };
  } catch (error) {
    console.error('Error exporting data:', error);
    return { data: null, error: error.message };
  }
};
