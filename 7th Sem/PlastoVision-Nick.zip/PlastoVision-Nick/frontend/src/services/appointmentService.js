import { supabase } from '../lib/supabase';

/**
 * Appointment Service
 * Handles all appointment-related database operations
 */

// ==================== APPOINTMENT OPERATIONS ====================

/**
 * Check for appointment conflicts
 * @param {Object} appointmentData - Appointment details to check
 * @returns {Object} Conflict status
 */
export const checkAppointmentConflict = async (appointmentData) => {
  try {
    const { doctor_id, appointment_date, start_time, end_time, id } = appointmentData;
    
    // Call the database function to check for conflicts
    const { data, error } = await supabase.rpc('check_appointment_conflict', {
      p_doctor_id: doctor_id,
      p_appointment_date: appointment_date,
      p_start_time: start_time,
      p_end_time: end_time,
      p_appointment_id: id || null
    });

    if (error) throw error;
    
    return { hasConflict: data, error: null };
  } catch (error) {
    console.error('Error checking appointment conflict:', error);
    // If the function doesn't exist yet, do a manual check
    return await checkAppointmentConflictManual(appointmentData);
  }
};

/**
 * Manual conflict check (fallback if database function not available)
 * @param {Object} appointmentData - Appointment details to check
 * @returns {Object} Conflict status
 */
const checkAppointmentConflictManual = async (appointmentData) => {
  try {
    const { doctor_id, appointment_date, start_time, end_time, id } = appointmentData;
    
    let query = supabase
      .from('appointments')
      .select('id, start_time, end_time')
      .eq('doctor_id', doctor_id)
      .eq('appointment_date', appointment_date)
      .neq('status', 'Cancelled');
    
    // Exclude current appointment if updating
    if (id) {
      query = query.neq('id', id);
    }
    
    const { data, error } = await query;
    
    if (error) throw error;
    
    // Check for time overlaps
    const hasConflict = data.some(existing => {
      const existingStart = existing.start_time;
      const existingEnd = existing.end_time;
      
      // Check if times overlap
      return (
        (start_time >= existingStart && start_time < existingEnd) ||
        (end_time > existingStart && end_time <= existingEnd) ||
        (start_time <= existingStart && end_time >= existingEnd)
      );
    });
    
    return { hasConflict, error: null };
  } catch (error) {
    console.error('Error in manual conflict check:', error);
    return { hasConflict: false, error: error.message };
  }
};

/**
 * Create a new appointment
 * @param {Object} appointmentData - Appointment information
 * @returns {Object} Created appointment data
 */
export const createAppointment = async (appointmentData) => {
  try {
    // First check for conflicts
    const { hasConflict, error: conflictError } = await checkAppointmentConflict(appointmentData);
    
    if (conflictError) {
      console.warn('Conflict check failed, proceeding with creation:', conflictError);
    }
    
    if (hasConflict) {
      return { 
        data: null, 
        error: 'This doctor already has an appointment scheduled during this time. Please select another time slot.' 
      };
    }
    
    const { data, error } = await supabase
      .from('appointments')
      .insert([appointmentData])
      .select(`
        *,
        patients (
          id,
          patient_code,
          first_name,
          last_name,
          phone,
          email
        )
      `)
      .single();

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error creating appointment:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Get all appointments with optional filters
 * @param {Object} options - Filter options
 * @returns {Array} List of appointments
 */
export const getAppointments = async (options = {}) => {
  try {
    let query = supabase
      .from('appointments')
      .select(`
        *,
        patients (
          id,
          patient_code,
          first_name,
          last_name,
          phone,
          email
        )
      `)
      .order('appointment_date', { ascending: true })
      .order('start_time', { ascending: true });

    // Apply filters
    if (options.date) {
      query = query.eq('appointment_date', options.date);
    }
    
    if (options.dateFrom && options.dateTo) {
      query = query.gte('appointment_date', options.dateFrom)
                   .lte('appointment_date', options.dateTo);
    }
    
    if (options.status) {
      query = query.eq('status', options.status);
    }
    
    if (options.doctor_id) {
      query = query.eq('doctor_id', options.doctor_id);
    }
    
    if (options.patient_id) {
      query = query.eq('patient_id', options.patient_id);
    }
    
    if (options.appointment_type) {
      query = query.eq('appointment_type', options.appointment_type);
    }
    
    // Search by patient name or ID
    if (options.search) {
      // Note: This requires fetching and filtering client-side
      // For better performance, consider full-text search in PostgreSQL
    }
    
    if (options.limit) {
      query = query.limit(options.limit);
    }

    const { data, error } = await query;

    if (error) throw error;
    
    // Client-side search filter if provided
    let filteredData = data;
    if (options.search && data) {
      const searchLower = options.search.toLowerCase();
      filteredData = data.filter(apt => {
        const patientName = `${apt.patients?.first_name || ''} ${apt.patients?.last_name || ''}`.toLowerCase();
        const patientCode = (apt.patients?.patient_code || '').toLowerCase();
        return patientName.includes(searchLower) || patientCode.includes(searchLower);
      });
    }
    
    return { data: filteredData, error: null };
  } catch (error) {
    console.error('Error fetching appointments:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Get appointments for a specific date
 * @param {String} date - Date in YYYY-MM-DD format
 * @returns {Array} List of appointments
 */
export const getAppointmentsByDate = async (date) => {
  return getAppointments({ date });
};

/**
 * Get appointments for a date range
 * @param {String} dateFrom - Start date in YYYY-MM-DD format
 * @param {String} dateTo - End date in YYYY-MM-DD format
 * @returns {Array} List of appointments
 */
export const getAppointmentsByDateRange = async (dateFrom, dateTo) => {
  return getAppointments({ dateFrom, dateTo });
};

/**
 * Get today's appointments
 * @returns {Array} List of today's appointments
 */
export const getTodaysAppointments = async () => {
  const today = new Date().toISOString().split('T')[0];
  return getAppointmentsByDate(today);
};

/**
 * Get a single appointment by ID
 * @param {String} appointmentId - Appointment UUID
 * @returns {Object} Appointment data with patient details
 */
export const getAppointmentById = async (appointmentId) => {
  try {
    const { data, error } = await supabase
      .from('appointments')
      .select(`
        *,
        patients (
          id,
          patient_code,
          first_name,
          last_name,
          phone,
          email,
          date_of_birth,
          age,
          gender,
          address,
          city,
          state,
          country
        )
      `)
      .eq('id', appointmentId)
      .single();

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error fetching appointment:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Get all appointments for a specific patient
 * @param {String} patientId - Patient UUID
 * @returns {Array} List of appointments
 */
export const getPatientAppointments = async (patientId) => {
  return getAppointments({ patient_id: patientId });
};

/**
 * Update appointment information
 * @param {String} appointmentId - Appointment UUID
 * @param {Object} updates - Fields to update
 * @returns {Object} Updated appointment data
 */
export const updateAppointment = async (appointmentId, updates) => {
  try {
    // If updating time/date, check for conflicts
    if (updates.appointment_date || updates.start_time || updates.end_time || updates.doctor_id) {
      // Get current appointment data
      const { data: current } = await getAppointmentById(appointmentId);
      
      if (current) {
        const checkData = {
          id: appointmentId,
          doctor_id: updates.doctor_id || current.doctor_id,
          appointment_date: updates.appointment_date || current.appointment_date,
          start_time: updates.start_time || current.start_time,
          end_time: updates.end_time || current.end_time
        };
        
        const { hasConflict } = await checkAppointmentConflict(checkData);
        
        if (hasConflict) {
          return { 
            data: null, 
            error: 'This doctor already has an appointment scheduled during this time. Please select another time slot.' 
          };
        }
      }
    }
    
    const { data, error } = await supabase
      .from('appointments')
      .update(updates)
      .eq('id', appointmentId)
      .select(`
        *,
        patients (
          id,
          patient_code,
          first_name,
          last_name,
          phone,
          email
        )
      `)
      .single();

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error updating appointment:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Update appointment status
 * @param {String} appointmentId - Appointment UUID
 * @param {String} status - New status
 * @returns {Object} Updated appointment data
 */
export const updateAppointmentStatus = async (appointmentId, status) => {
  return updateAppointment(appointmentId, { status });
};

/**
 * Cancel an appointment (sets status to Cancelled)
 * @param {String} appointmentId - Appointment UUID
 * @returns {Object} Updated appointment data
 */
export const cancelAppointment = async (appointmentId) => {
  return updateAppointmentStatus(appointmentId, 'Cancelled');
};

/**
 * Mark appointment as completed
 * @param {String} appointmentId - Appointment UUID
 * @returns {Object} Updated appointment data
 */
export const completeAppointment = async (appointmentId) => {
  return updateAppointmentStatus(appointmentId, 'Completed');
};

/**
 * Mark appointment as no-show
 * @param {String} appointmentId - Appointment UUID
 * @returns {Object} Updated appointment data
 */
export const markNoShow = async (appointmentId) => {
  return updateAppointmentStatus(appointmentId, 'No Show');
};

/**
 * Mark appointment as confirmed
 * @param {String} appointmentId - Appointment UUID
 * @returns {Object} Updated appointment data
 */
export const confirmAppointment = async (appointmentId) => {
  return updateAppointmentStatus(appointmentId, 'Confirmed');
};

/**
 * Reschedule an appointment
 * @param {String} appointmentId - Appointment UUID
 * @param {Object} newSchedule - New date and time
 * @returns {Object} Updated appointment data
 */
export const rescheduleAppointment = async (appointmentId, newSchedule) => {
  return updateAppointment(appointmentId, newSchedule);
};

/**
 * Delete an appointment (physical delete - not recommended, use cancel instead)
 * @param {String} appointmentId - Appointment UUID
 * @returns {Boolean} Success status
 */
export const deleteAppointment = async (appointmentId) => {
  try {
    const { error } = await supabase
      .from('appointments')
      .delete()
      .eq('id', appointmentId);

    if (error) throw error;
    return { success: true, error: null };
  } catch (error) {
    console.error('Error deleting appointment:', error);
    return { success: false, error: error.message };
  }
};

// ==================== STATISTICS ====================

/**
 * Get appointment statistics
 * @returns {Object} Statistics data
 */
export const getAppointmentStats = async () => {
  try {
    const today = new Date().toISOString().split('T')[0];
    
    // Get today's appointments count
    const { count: todayCount, error: todayError } = await supabase
      .from('appointments')
      .select('*', { count: 'exact', head: true })
      .eq('appointment_date', today)
      .neq('status', 'Cancelled');

    if (todayError) throw todayError;

    // Get upcoming appointments count (next 7 days)
    const nextWeek = new Date();
    nextWeek.setDate(nextWeek.getDate() + 7);
    const nextWeekDate = nextWeek.toISOString().split('T')[0];
    
    const { count: upcomingCount, error: upcomingError } = await supabase
      .from('appointments')
      .select('*', { count: 'exact', head: true })
      .gte('appointment_date', today)
      .lte('appointment_date', nextWeekDate)
      .neq('status', 'Cancelled');

    if (upcomingError) throw upcomingError;

    // Get total appointments this month
    const firstDayOfMonth = new Date();
    firstDayOfMonth.setDate(1);
    const firstDay = firstDayOfMonth.toISOString().split('T')[0];
    
    const { count: monthCount, error: monthError } = await supabase
      .from('appointments')
      .select('*', { count: 'exact', head: true })
      .gte('appointment_date', firstDay)
      .neq('status', 'Cancelled');

    if (monthError) throw monthError;

    // Get completed appointments count
    const { count: completedCount, error: completedError } = await supabase
      .from('appointments')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'Completed');

    if (completedError) throw completedError;

    return {
      data: {
        today: todayCount || 0,
        upcoming: upcomingCount || 0,
        thisMonth: monthCount || 0,
        completed: completedCount || 0
      },
      error: null
    };
  } catch (error) {
    console.error('Error fetching appointment stats:', error);
    return { data: null, error: error.message };
  }
};

// ==================== HELPER FUNCTIONS ====================

/**
 * Format appointment time for display
 * @param {String} time - Time in HH:MM format
 * @returns {String} Formatted time (e.g., "09:00 AM")
 */
export const formatTime = (time) => {
  if (!time) return '';
  const [hours, minutes] = time.split(':');
  const hour = parseInt(hours);
  const ampm = hour >= 12 ? 'PM' : 'AM';
  const displayHour = hour % 12 || 12;
  return `${displayHour}:${minutes} ${ampm}`;
};

/**
 * Format date for display
 * @param {String} date - Date in YYYY-MM-DD format
 * @returns {String} Formatted date (e.g., "Oct 24, 2024")
 */
export const formatDate = (date) => {
  if (!date) return '';
  const d = new Date(date + 'T00:00:00');
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
};

/**
 * Get appointment status color
 * @param {String} status - Appointment status
 * @returns {String} Tailwind color classes
 */
export const getStatusColor = (status) => {
  const colors = {
    'Scheduled': 'bg-blue-100 text-blue-800',
    'Confirmed': 'bg-green-100 text-green-800',
    'Completed': 'bg-gray-100 text-gray-800',
    'Cancelled': 'bg-red-100 text-red-800',
    'No Show': 'bg-orange-100 text-orange-800'
  };
  return colors[status] || 'bg-gray-100 text-gray-800';
};

/**
 * Get appointment type color
 * @param {String} type - Appointment type
 * @returns {String} Tailwind color classes
 */
export const getTypeColor = (type) => {
  const colors = {
    'Initial Consultation': 'bg-primary/10 text-primary',
    'Follow-up': 'bg-secondary-container text-secondary',
    'Post-operative Checkup': 'bg-green-100 text-green-800',
    'Pre-operative Consultation': 'bg-orange-100 text-orange-800',
    'Surgery': 'bg-error/10 text-error',
    'Rhinoplasty Consultation': 'bg-purple-100 text-purple-800',
    'General Consultation': 'bg-blue-100 text-blue-800',
    'Emergency': 'bg-red-100 text-red-800',
    'Other': 'bg-gray-100 text-gray-800'
  };
  return colors[type] || 'bg-gray-100 text-gray-800';
};
