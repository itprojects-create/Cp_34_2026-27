import { supabase } from '../lib/supabase';

/**
 * Patient Service
 * Handles all patient-related database operations
 */

// ==================== PATIENT OPERATIONS ====================

/**
 * Create a new patient
 * @param {Object} patientData - Patient information
 * @returns {Object} Created patient data
 */
export const createPatient = async (patientData) => {
  try {
    const { data, error } = await supabase
      .from('patients')
      .insert([patientData])
      .select()
      .single();

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error creating patient:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Get all patients with optional search and filter
 * @param {Object} options - Search and filter options
 * @returns {Array} List of patients
 */
export const getPatients = async (options = {}) => {
  try {
    let query = supabase
      .from('patients')
      .select('*')
      .order('created_at', { ascending: false });

    // Apply search filter if provided
    if (options.search) {
      query = query.or(
        `first_name.ilike.%${options.search}%,` +
        `last_name.ilike.%${options.search}%,` +
        `patient_code.ilike.%${options.search}%,` +
        `phone.ilike.%${options.search}%,` +
        `email.ilike.%${options.search}%`
      );
    }

    // Apply pagination if provided
    if (options.limit) {
      query = query.limit(options.limit);
    }
    if (options.offset) {
      query = query.range(options.offset, options.offset + (options.limit || 10) - 1);
    }

    const { data, error } = await query;

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error fetching patients:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Get a single patient by ID
 * @param {String} patientId - Patient UUID
 * @returns {Object} Patient data
 */
export const getPatientById = async (patientId) => {
  try {
    const { data, error } = await supabase
      .from('patients')
      .select('*')
      .eq('id', patientId)
      .single();

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error fetching patient:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Update patient information
 * @param {String} patientId - Patient UUID
 * @param {Object} updates - Fields to update
 * @returns {Object} Updated patient data
 */
export const updatePatient = async (patientId, updates) => {
  try {
    const { data, error } = await supabase
      .from('patients')
      .update(updates)
      .eq('id', patientId)
      .select()
      .single();

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error updating patient:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Delete a patient and all related data
 * @param {String} patientId - Patient UUID
 * @returns {Boolean} Success status
 */
export const deletePatient = async (patientId) => {
  try {
    // Delete patient (cascade will handle related records)
    const { error } = await supabase
      .from('patients')
      .delete()
      .eq('id', patientId);

    if (error) throw error;
    return { success: true, error: null };
  } catch (error) {
    console.error('Error deleting patient:', error);
    return { success: false, error: error.message };
  }
};

// ==================== VISIT OPERATIONS ====================

/**
 * Create a new visit for a patient
 * @param {Object} visitData - Visit information
 * @returns {Object} Created visit data
 */
export const createVisit = async (visitData) => {
  try {
    const { data, error } = await supabase
      .from('visits')
      .insert([visitData])
      .select()
      .single();

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error creating visit:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Get all visits for a patient
 * @param {String} patientId - Patient UUID
 * @returns {Array} List of visits
 */
export const getPatientVisits = async (patientId) => {
  try {
    const { data, error } = await supabase
      .from('visits')
      .select('*')
      .eq('patient_id', patientId)
      .order('visit_date', { ascending: false });

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error fetching visits:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Get visit by ID with medications
 * @param {String} visitId - Visit UUID
 * @returns {Object} Visit data with medications
 */
export const getVisitById = async (visitId) => {
  try {
    const { data, error } = await supabase
      .from('visits')
      .select(`
        *,
        medications (*)
      `)
      .eq('id', visitId)
      .single();

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error fetching visit:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Update visit information
 * @param {String} visitId - Visit UUID
 * @param {Object} updates - Fields to update
 * @returns {Object} Updated visit data
 */
export const updateVisit = async (visitId, updates) => {
  try {
    const { data, error } = await supabase
      .from('visits')
      .update(updates)
      .eq('id', visitId)
      .select()
      .single();

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error updating visit:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Delete a visit
 * @param {String} visitId - Visit UUID
 * @returns {Boolean} Success status
 */
export const deleteVisit = async (visitId) => {
  try {
    const { error } = await supabase
      .from('visits')
      .delete()
      .eq('id', visitId);

    if (error) throw error;
    return { success: true, error: null };
  } catch (error) {
    console.error('Error deleting visit:', error);
    return { success: false, error: error.message };
  }
};

// ==================== MEDICATION OPERATIONS ====================

/**
 * Add medications to a visit
 * @param {Array} medications - Array of medication objects with visit_id
 * @returns {Array} Created medication data
 */
export const addMedications = async (medications) => {
  try {
    const { data, error } = await supabase
      .from('medications')
      .insert(medications)
      .select();

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error adding medications:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Get medications for a visit
 * @param {String} visitId - Visit UUID
 * @returns {Array} List of medications
 */
export const getMedicationsByVisit = async (visitId) => {
  try {
    const { data, error } = await supabase
      .from('medications')
      .select('*')
      .eq('visit_id', visitId);

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error fetching medications:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Delete a medication
 * @param {String} medicationId - Medication UUID
 * @returns {Boolean} Success status
 */
export const deleteMedication = async (medicationId) => {
  try {
    const { error } = await supabase
      .from('medications')
      .delete()
      .eq('id', medicationId);

    if (error) throw error;
    return { success: true, error: null };
  } catch (error) {
    console.error('Error deleting medication:', error);
    return { success: false, error: error.message };
  }
};

// ==================== DOCUMENT OPERATIONS ====================

/**
 * Upload a document to Supabase Storage
 * @param {File} file - File to upload
 * @param {String} patientId - Patient UUID
 * @returns {Object} Uploaded file data with URL
 */
export const uploadPatientDocument = async (file, patientId) => {
  try {
    // Generate unique file name
    const fileExt = file.name.split('.').pop();
    const fileName = `${patientId}/${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`;

    // Upload file to storage
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('patient-documents')
      .upload(fileName, file, {
        cacheControl: '3600',
        upsert: false
      });

    if (uploadError) throw uploadError;

    // Get public URL
    const { data: { publicUrl } } = supabase.storage
      .from('patient-documents')
      .getPublicUrl(fileName);

    // Save document metadata to database
    const documentData = {
      patient_id: patientId,
      file_name: file.name,
      file_url: publicUrl,
      file_type: file.type,
      file_size: file.size
    };

    const { data: docData, error: docError } = await supabase
      .from('documents')
      .insert([documentData])
      .select()
      .single();

    if (docError) throw docError;

    return { data: docData, error: null };
  } catch (error) {
    console.error('Error uploading document:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Get all documents for a patient
 * @param {String} patientId - Patient UUID
 * @returns {Array} List of documents
 */
export const getPatientDocuments = async (patientId) => {
  try {
    const { data, error } = await supabase
      .from('documents')
      .select('*')
      .eq('patient_id', patientId)
      .order('uploaded_at', { ascending: false });

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error fetching documents:', error);
    return { data: null, error: error.message };
  }
};

/**
 * Delete a document from storage and database
 * @param {String} documentId - Document UUID
 * @param {String} fileUrl - File URL to extract path
 * @returns {Boolean} Success status
 */
export const deleteDocument = async (documentId, fileUrl) => {
  try {
    // Extract file path from URL
    const urlParts = fileUrl.split('/');
    const bucketIndex = urlParts.findIndex(part => part === 'patient-documents');
    const filePath = urlParts.slice(bucketIndex + 1).join('/');

    // Delete from storage
    const { error: storageError } = await supabase.storage
      .from('patient-documents')
      .remove([filePath]);

    if (storageError) console.warn('Storage deletion warning:', storageError);

    // Delete from database
    const { error: dbError } = await supabase
      .from('documents')
      .delete()
      .eq('id', documentId);

    if (dbError) throw dbError;

    return { success: true, error: null };
  } catch (error) {
    console.error('Error deleting document:', error);
    return { success: false, error: error.message };
  }
};

// ==================== STATISTICS ====================

/**
 * Get dashboard statistics
 * @returns {Object} Statistics data
 */
export const getDashboardStats = async () => {
  try {
    // Get total patients count
    const { count: totalPatients, error: patientsError } = await supabase
      .from('patients')
      .select('*', { count: 'exact', head: true });

    if (patientsError) throw patientsError;

    // Get total visits count
    const { count: totalVisits, error: visitsError } = await supabase
      .from('visits')
      .select('*', { count: 'exact', head: true });

    if (visitsError) throw visitsError;

    // Get upcoming visits (visits with follow-up dates in the future)
    const today = new Date().toISOString().split('T')[0];
    const { count: upcomingVisits, error: upcomingError } = await supabase
      .from('visits')
      .select('*', { count: 'exact', head: true })
      .gte('follow_up_date', today);

    if (upcomingError) throw upcomingError;

    return {
      data: {
        totalPatients: totalPatients || 0,
        totalVisits: totalVisits || 0,
        upcomingVisits: upcomingVisits || 0
      },
      error: null
    };
  } catch (error) {
    console.error('Error fetching dashboard stats:', error);
    return { data: null, error: error.message };
  }
};
