import React, { createContext, useContext } from 'react';
import { Toaster, toast as hotToast } from 'react-hot-toast';

const ToastContext = createContext();

export const useToast = () => {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within ToastProvider');
  }
  return context;
};

export const ToastProvider = ({ children }) => {
  const toast = {
    success: (message) => {
      hotToast.success(message, {
        duration: 3000,
        position: 'top-right',
        style: {
          background: '#047857',
          color: '#fff',
          fontWeight: '500',
          borderRadius: '12px',
        },
      });
    },
    error: (message) => {
      hotToast.error(message, {
        duration: 4000,
        position: 'top-right',
        style: {
          background: '#B91C1C',
          color: '#fff',
          fontWeight: '500',
          borderRadius: '12px',
        },
      });
    },
    loading: (message) => {
      return hotToast.loading(message, {
        position: 'top-right',
      });
    },
    dismiss: (toastId) => {
      hotToast.dismiss(toastId);
    },
  };

  return (
    <ToastContext.Provider value={toast}>
      {children}
      <Toaster toastOptions={{ className: 'font-body text-sm' }} />
    </ToastContext.Provider>
  );
};
