export const mockPatients = [
  {
    id: "P-10482",
    name: "Sarah Jenkins",
    age: 34,
    gender: "Female",
    procedure: "Rhinoplasty Revision",
    status: "Pre-Op",
    date: "Oct 24, 2024",
    surgeon: "Dr. Michaels"
  },
  {
    id: "P-10484",
    name: "Michael Chen",
    age: 42,
    gender: "Male",
    procedure: "Facial Reconstruction",
    status: "Post-Op",
    date: "Oct 22, 2024",
    surgeon: "Dr. Sarah Lee"
  },
  {
    id: "P-10485",
    name: "Emma Watson",
    age: 28,
    gender: "Female",
    procedure: "Breast Augmentation",
    status: "Consultation",
    date: "Oct 28, 2024",
    surgeon: "Dr. Michaels"
  },
  {
    id: "P-10486",
    name: "James Rodriguez",
    age: 55,
    gender: "Male",
    procedure: "Blepharoplasty",
    status: "Cleared",
    date: "Nov 02, 2024",
    surgeon: "Dr. Sarah Lee"
  }
];

export const mockAppointments = [
  {
    id: "A-1",
    patientName: "Sarah Jenkins",
    type: "Pre-Op Consult",
    time: "09:00 AM",
    date: "2024-10-24"
  },
  {
    id: "A-2",
    patientName: "Michael Chen",
    type: "Post-Op Checkup",
    time: "11:30 AM",
    date: "2024-10-24"
  },
  {
    id: "A-3",
    patientName: "Emma Watson",
    type: "Initial Consult",
    time: "02:00 PM",
    date: "2024-10-24"
  }
];

export const dashboardStats = [
  {
    title: "Total Patients",
    value: "1,248",
    trend: "+12.5%",
    trendUp: true
  },
  {
    title: "Active Procedures",
    value: "42",
    trend: "+4.1%",
    trendUp: true
  },
  {
    title: "Upcoming Consults",
    value: "18",
    trend: "-2.4%",
    trendUp: false
  },
  {
    title: "Success Rate",
    value: "99.2%",
    trend: "+0.1%",
    trendUp: true
  }
];
