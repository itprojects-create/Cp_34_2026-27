import React, { useState, useEffect } from 'react';
import { Building2, Mail, Phone, Globe, MapPin, Upload, Clock } from 'lucide-react';
import Button from '../ui/Button';
import { useToast } from '../../contexts/ToastContext';
import { getClinicSettings, updateClinicSettings, uploadClinicLogo } from '../../services/settingsService';

const DAYS_OF_WEEK = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];

const ClinicSettings = () => {
  const toast = useToast();
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [settings, setSettings] = useState(null);
  const [formData, setFormData] = useState({
    clinic_name: '',
    address: '',
    city: '',
    state: '',
    country: '',
    postal_code: '',
    phone: '',
    email: '',
    website: '',
    timezone: 'UTC',
    appointment_duration: 30
  });
  const [workingHours, setWorkingHours] = useState({});

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    setLoading(true);
    const { data, error } = await getClinicSettings();
    
    if (error) {
      toast.error('Failed to load clinic settings');
    } else if (data) {
      setSettings(data);
      setFormData({
        clinic_name: data.clinic_name || '',
        address: data.address || '',
        city: data.city || '',
        state: data.state || '',
        country: data.country || '',
        postal_code: data.postal_code || '',
        phone: data.phone || '',
        email: data.email || '',
        website: data.website || '',
        timezone: data.timezone || 'UTC',
        appointment_duration: data.appointment_duration || 30
      });
      setWorkingHours(data.working_hours || {});
    }
    setLoading(false);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleWorkingHoursChange = (day, field, value) => {
    setWorkingHours(prev => ({
      ...prev,
      [day]: {
        ...prev[day],
        [field]: value
      }
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const updates = {
      ...formData,
      working_hours: workingHours
    };

    const { data, error } = await updateClinicSettings(settings.id, updates);

    if (error) {
      toast.error('Failed to update clinic settings');
    } else {
      toast.success('Clinic settings updated successfully');
      setSettings(data);
    }
    setLoading(false);
  };

  const handleLogoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('Please upload an image file');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast.error('Image size should be less than 5MB');
      return;
    }

    setUploading(true);
    const { data, error } = await uploadClinicLogo(file);

    if (error) {
      toast.error('Failed to upload logo');
    } else {
      // Update the logo URL
      const { error: updateError } = await updateClinicSettings(settings.id, { logo_url: data.url });
      
      if (updateError) {
        toast.error('Failed to update logo');
      } else {
        toast.success('Logo updated successfully');
        setSettings(prev => ({ ...prev, logo_url: data.url }));
      }
    }
    setUploading(false);
  };

  if (loading && !settings) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Logo Section */}
      <div>
        <h3 className="text-lg font-semibold text-on-surface mb-4">Clinic Logo</h3>
        <div className="flex items-center gap-6">
          <div className="relative w-32 h-32 border-2 border-dashed border-outline rounded-lg flex items-center justify-center overflow-hidden">
            {settings?.logo_url ? (
              <img 
                src={settings.logo_url} 
                alt="Clinic Logo" 
                className="w-full h-full object-contain"
              />
            ) : (
              <Building2 className="w-12 h-12 text-on-surface-variant" />
            )}
            {uploading && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
              </div>
            )}
          </div>
          <label>
            <input
              type="file"
              accept="image/*"
              onChange={handleLogoUpload}
              className="hidden"
              disabled={uploading}
            />
            <Button
              variant="outline"
              size="sm"
              icon={<Upload className="w-4 h-4" />}
              disabled={uploading}
              as="span"
            >
              Upload Logo
            </Button>
          </label>
        </div>
      </div>

      {/* Clinic Information Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Information */}
        <div>
          <h3 className="text-lg font-semibold text-on-surface mb-4">Clinic Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-on-surface mb-2">
                Clinic Name *
              </label>
              <div className="relative">
                <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant" />
                <input
                  type="text"
                  name="clinic_name"
                  value={formData.clinic_name}
                  onChange={handleChange}
                  required
                  className="w-full pl-10 pr-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
                />
              </div>
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-on-surface mb-2">
                Address
              </label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant" />
                <input
                  type="text"
                  name="address"
                  value={formData.address}
                  onChange={handleChange}
                  className="w-full pl-10 pr-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-on-surface mb-2">
                City
              </label>
              <input
                type="text"
                name="city"
                value={formData.city}
                onChange={handleChange}
                className="w-full px-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-on-surface mb-2">
                State/Province
              </label>
              <input
                type="text"
                name="state"
                value={formData.state}
                onChange={handleChange}
                className="w-full px-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-on-surface mb-2">
                Country
              </label>
              <input
                type="text"
                name="country"
                value={formData.country}
                onChange={handleChange}
                className="w-full px-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-on-surface mb-2">
                Postal Code
              </label>
              <input
                type="text"
                name="postal_code"
                value={formData.postal_code}
                onChange={handleChange}
                className="w-full px-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-on-surface mb-2">
                Phone Number
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant" />
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full pl-10 pr-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-on-surface mb-2">
                Email
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant" />
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full pl-10 pr-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
                />
              </div>
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-on-surface mb-2">
                Website
              </label>
              <div className="relative">
                <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant" />
                <input
                  type="url"
                  name="website"
                  value={formData.website}
                  onChange={handleChange}
                  placeholder="https://"
                  className="w-full pl-10 pr-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-on-surface mb-2">
                Default Appointment Duration (minutes)
              </label>
              <input
                type="number"
                name="appointment_duration"
                value={formData.appointment_duration}
                onChange={handleChange}
                min="15"
                step="15"
                className="w-full px-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-on-surface mb-2">
                Timezone
              </label>
              <input
                type="text"
                name="timezone"
                value={formData.timezone}
                onChange={handleChange}
                className="w-full px-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
              />
            </div>
          </div>
        </div>

        {/* Working Hours */}
        <div>
          <h3 className="text-lg font-semibold text-on-surface mb-4 flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Working Hours
          </h3>
          <div className="space-y-3">
            {DAYS_OF_WEEK.map(day => (
              <div key={day} className="flex items-center gap-4">
                <div className="w-28">
                  <span className="text-sm font-medium text-on-surface capitalize">{day}</span>
                </div>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={!workingHours[day]?.closed}
                    onChange={(e) => handleWorkingHoursChange(day, 'closed', !e.target.checked)}
                    className="w-4 h-4 text-primary border-outline rounded focus:ring-2 focus:ring-primary"
                  />
                  <span className="text-sm text-on-surface-variant">Open</span>
                </label>
                {!workingHours[day]?.closed && (
                  <>
                    <input
                      type="time"
                      value={workingHours[day]?.open || '09:00'}
                      onChange={(e) => handleWorkingHoursChange(day, 'open', e.target.value)}
                      className="px-3 py-2 border border-outline rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
                    />
                    <span className="text-sm text-on-surface-variant">to</span>
                    <input
                      type="time"
                      value={workingHours[day]?.close || '17:00'}
                      onChange={(e) => handleWorkingHoursChange(day, 'close', e.target.value)}
                      className="px-3 py-2 border border-outline rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
                    />
                  </>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end gap-3 pt-4 border-t border-outline-variant">
          <Button
            type="button"
            variant="outline"
            onClick={loadSettings}
            disabled={loading}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={loading}
          >
            {loading ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default ClinicSettings;
