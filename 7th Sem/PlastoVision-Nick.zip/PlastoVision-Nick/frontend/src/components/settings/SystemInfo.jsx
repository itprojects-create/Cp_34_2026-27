import React, { useState, useEffect } from 'react';
import { Server, Database, CheckCircle, XCircle, Activity, RefreshCw } from 'lucide-react';
import Button from '../ui/Button';
import { useToast } from '../../contexts/ToastContext';
import { checkSupabaseConnection } from '../../services/settingsService';

const SystemInfo = () => {
  const toast = useToast();
  const [loading, setLoading] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState(null);

  useEffect(() => {
    checkConnection();
  }, []);

  const checkConnection = async () => {
    setLoading(true);
    const { connected, status, error } = await checkSupabaseConnection();
    setConnectionStatus({ connected, status, error });
    setLoading(false);
  };

  const systemInfo = [
    { label: 'Application', value: 'PlastoVision', icon: Activity },
    { label: 'Version', value: '1.0.0', icon: Server },
    { label: 'Environment', value: import.meta.env.MODE || 'development', icon: Server },
    { label: 'Database', value: 'Supabase PostgreSQL', icon: Database }
  ];

  const features = [
    { name: 'Patient Management', status: 'operational', description: 'Create, view, update, and delete patient records' },
    { name: 'Appointment Scheduling', status: 'operational', description: 'Schedule and manage appointments with conflict detection' },
    { name: 'Visit Tracking', status: 'operational', description: 'Track patient visits and medical history' },
    { name: 'Document Management', status: 'operational', description: 'Upload and manage patient documents' },
    { name: 'Settings & Configuration', status: 'operational', description: 'Customize clinic and user preferences' },
    { name: 'Photo Tracking', status: 'coming-soon', description: 'Track patient progress with photos' },
    { name: '3D Visualization', status: 'coming-soon', description: 'Interactive 3D visualization of procedures' },
    { name: 'Reports & Analytics', status: 'planned', description: 'Generate comprehensive reports and analytics' }
  ];

  return (
    <div className="space-y-6">
      {/* System Information */}
      <div>
        <h3 className="text-lg font-semibold text-on-surface mb-4">System Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {systemInfo.map((item) => (
            <div key={item.label} className="p-4 bg-surface-container-low rounded-lg border border-outline">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <item.icon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <div className="text-sm text-on-surface-variant">{item.label}</div>
                  <div className="font-medium text-on-surface">{item.value}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Connection Status */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-on-surface">Connection Status</h3>
          <Button
            variant="outline"
            size="sm"
            onClick={checkConnection}
            disabled={loading}
            icon={<RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />}
          >
            Refresh
          </Button>
        </div>

        {connectionStatus && (
          <div className={`p-4 rounded-lg border flex items-start gap-3 ${
            connectionStatus.connected
              ? 'bg-green-50 border-green-200'
              : 'bg-red-50 border-red-200'
          }`}>
            {connectionStatus.connected ? (
              <CheckCircle className="w-6 h-6 text-green-600 mt-0.5" />
            ) : (
              <XCircle className="w-6 h-6 text-red-600 mt-0.5" />
            )}
            <div>
              <div className={`font-semibold ${
                connectionStatus.connected ? 'text-green-900' : 'text-red-900'
              }`}>
                Database {connectionStatus.status}
              </div>
              <div className={`text-sm mt-1 ${
                connectionStatus.connected ? 'text-green-700' : 'text-red-700'
              }`}>
                {connectionStatus.connected
                  ? 'Successfully connected to Supabase'
                  : `Connection failed: ${connectionStatus.error}`
                }
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Feature Status */}
      <div>
        <h3 className="text-lg font-semibold text-on-surface mb-4">Feature Status</h3>
        <div className="space-y-3">
          {features.map((feature) => (
            <div key={feature.name} className="p-4 bg-surface-container-low rounded-lg border border-outline">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="font-medium text-on-surface">{feature.name}</div>
                  <div className="text-sm text-on-surface-variant mt-1">{feature.description}</div>
                </div>
                <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${
                  feature.status === 'operational' ? 'bg-green-100 text-green-800' :
                  feature.status === 'coming-soon' ? 'bg-blue-100 text-blue-800' :
                  'bg-gray-100 text-gray-800'
                }`}>
                  {feature.status === 'operational' ? 'Operational' :
                   feature.status === 'coming-soon' ? 'Coming Soon' :
                   'Planned'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Environment Variables */}
      <div>
        <h3 className="text-lg font-semibold text-on-surface mb-4">Environment Configuration</h3>
        <div className="space-y-3">
          <div className="p-4 bg-surface-container-low rounded-lg">
            <div className="font-medium text-on-surface">Supabase URL</div>
            <div className="text-sm text-on-surface-variant mt-1 font-mono break-all">
              {import.meta.env.VITE_SUPABASE_URL ? '✓ Configured' : '✗ Not configured'}
            </div>
          </div>

          <div className="p-4 bg-surface-container-low rounded-lg">
            <div className="font-medium text-on-surface">Supabase Anon Key</div>
            <div className="text-sm text-on-surface-variant mt-1 font-mono">
              {import.meta.env.VITE_SUPABASE_ANON_KEY ? '✓ Configured' : '✗ Not configured'}
            </div>
          </div>
        </div>
      </div>

      {/* Technical Details */}
      <div>
        <h3 className="text-lg font-semibold text-on-surface mb-4">Technical Stack</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-surface-container-low rounded-lg">
            <div className="font-medium text-on-surface mb-2">Frontend</div>
            <ul className="space-y-1 text-sm text-on-surface-variant">
              <li>• React 18</li>
              <li>• Vite</li>
              <li>• TailwindCSS</li>
              <li>• React Router</li>
              <li>• Lucide Icons</li>
            </ul>
          </div>

          <div className="p-4 bg-surface-container-low rounded-lg">
            <div className="font-medium text-on-surface mb-2">Backend</div>
            <ul className="space-y-1 text-sm text-on-surface-variant">
              <li>• Supabase PostgreSQL</li>
              <li>• Supabase Storage</li>
              <li>• Row Level Security (RLS)</li>
              <li>• Real-time subscriptions (coming soon)</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Support Information */}
      <div>
        <h3 className="text-lg font-semibold text-on-surface mb-4">Support & Documentation</h3>
        <div className="p-4 bg-surface-container-low rounded-lg border border-outline">
          <div className="space-y-3">
            <div>
              <div className="font-medium text-on-surface">Documentation</div>
              <div className="text-sm text-on-surface-variant mt-1">
                Refer to the project documentation in the root directory for setup guides and feature documentation.
              </div>
            </div>
            <div>
              <div className="font-medium text-on-surface">Build Information</div>
              <div className="text-sm text-on-surface-variant mt-1">
                Last updated: {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SystemInfo;
