import React, { useState } from 'react';
import { Lock, Shield, Key, AlertTriangle } from 'lucide-react';
import Button from '../ui/Button';
import { useToast } from '../../contexts/ToastContext';
import { changePassword } from '../../services/settingsService';

const SecuritySettings = () => {
  const toast = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate passwords
    if (formData.newPassword.length < 8) {
      toast.error('Password must be at least 8 characters long');
      return;
    }

    if (formData.newPassword !== formData.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }

    setLoading(true);
    const { success, error } = await changePassword(formData.newPassword);

    if (error) {
      toast.error(error);
    } else {
      toast.success('Password changed successfully');
      setFormData({
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
      });
    }
    setLoading(false);
  };

  return (
    <div className="space-y-6">
      {/* Change Password */}
      <div>
        <h3 className="text-lg font-semibold text-on-surface mb-4 flex items-center gap-2">
          <Lock className="w-5 h-5" />
          Change Password
        </h3>

        {/* Auth Not Configured Warning */}
        <div className="mb-4 p-4 bg-orange-50 border border-orange-200 rounded-lg flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-orange-600 mt-0.5" />
          <div>
            <div className="font-medium text-orange-800">Authentication Setup Required</div>
            <div className="text-sm text-orange-700 mt-1">
              Password management requires Supabase Authentication to be configured. This feature will be available once authentication is enabled.
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-on-surface mb-2">
              Current Password
            </label>
            <div className="relative">
              <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant" />
              <input
                type="password"
                name="currentPassword"
                value={formData.currentPassword}
                onChange={handleChange}
                disabled
                className="w-full pl-10 pr-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface disabled:opacity-50"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-on-surface mb-2">
              New Password
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant" />
              <input
                type="password"
                name="newPassword"
                value={formData.newPassword}
                onChange={handleChange}
                disabled
                className="w-full pl-10 pr-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface disabled:opacity-50"
              />
            </div>
            <p className="text-xs text-on-surface-variant mt-1">
              Password must be at least 8 characters long
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-on-surface mb-2">
              Confirm New Password
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant" />
              <input
                type="password"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleChange}
                disabled
                className="w-full pl-10 pr-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface disabled:opacity-50"
              />
            </div>
          </div>

          <div className="flex justify-end">
            <Button
              type="submit"
              disabled={true}
            >
              Update Password
            </Button>
          </div>
        </form>
      </div>

      {/* Security Information */}
      <div>
        <h3 className="text-lg font-semibold text-on-surface mb-4 flex items-center gap-2">
          <Shield className="w-5 h-5" />
          Security Best Practices
        </h3>
        <div className="space-y-3">
          <div className="p-4 bg-surface-container-low rounded-lg">
            <div className="font-medium text-on-surface">Use Strong Passwords</div>
            <div className="text-sm text-on-surface-variant mt-1">
              Create passwords with at least 8 characters, including uppercase, lowercase, numbers, and special characters.
            </div>
          </div>

          <div className="p-4 bg-surface-container-low rounded-lg">
            <div className="font-medium text-on-surface">Enable Two-Factor Authentication</div>
            <div className="text-sm text-on-surface-variant mt-1">
              Add an extra layer of security by enabling 2FA. This feature will be available when authentication is configured.
            </div>
          </div>

          <div className="p-4 bg-surface-container-low rounded-lg">
            <div className="font-medium text-on-surface">Regular Password Updates</div>
            <div className="text-sm text-on-surface-variant mt-1">
              Change your password periodically to maintain security.
            </div>
          </div>

          <div className="p-4 bg-surface-container-low rounded-lg">
            <div className="font-medium text-on-surface">Secure Device Access</div>
            <div className="text-sm text-on-surface-variant mt-1">
              Always log out when using shared or public computers.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SecuritySettings;
