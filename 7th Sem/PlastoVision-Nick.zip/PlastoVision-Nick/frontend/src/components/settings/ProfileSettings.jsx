import React, { useState, useEffect } from 'react';
import { User, Mail, Phone, Briefcase, Upload, X } from 'lucide-react';
import Button from '../ui/Button';
import { useToast } from '../../contexts/ToastContext';
import { getProfile, updateProfile, uploadAvatar, deleteAvatar } from '../../services/settingsService';

const ProfileSettings = ({ userId }) => {
  const toast = useToast();
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [profile, setProfile] = useState(null);
  const [formData, setFormData] = useState({
    full_name: '',
    email: '',
    phone: '',
    designation: '',
    department: '',
    bio: '',
    specialization: '',
    license_number: ''
  });

  useEffect(() => {
    loadProfile();
  }, [userId]);

  const loadProfile = async () => {
    setLoading(true);
    const { data, error } = await getProfile(userId);
    
    if (error) {
      toast.error('Failed to load profile');
    } else if (data) {
      setProfile(data);
      setFormData({
        full_name: data.full_name || '',
        email: data.email || '',
        phone: data.phone || '',
        designation: data.designation || '',
        department: data.department || '',
        bio: data.bio || '',
        specialization: data.specialization || '',
        license_number: data.license_number || ''
      });
    }
    setLoading(false);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const { data, error } = await updateProfile(userId, formData);

    if (error) {
      toast.error('Failed to update profile');
    } else {
      toast.success('Profile updated successfully');
      setProfile(data);
    }
    setLoading(false);
  };

  const handleAvatarUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast.error('Please upload an image file');
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error('Image size should be less than 5MB');
      return;
    }

    setUploading(true);
    const { data, error } = await uploadAvatar(file, userId);

    if (error) {
      toast.error('Failed to upload avatar');
    } else {
      toast.success('Avatar updated successfully');
      setProfile(prev => ({ ...prev, avatar_url: data.url }));
    }
    setUploading(false);
  };

  const handleRemoveAvatar = async () => {
    if (!profile?.avatar_url) return;

    setUploading(true);
    const { success, error } = await deleteAvatar(userId, profile.avatar_url);

    if (error) {
      toast.error('Failed to remove avatar');
    } else {
      toast.success('Avatar removed successfully');
      setProfile(prev => ({ ...prev, avatar_url: null }));
    }
    setUploading(false);
  };

  if (loading && !profile) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Avatar Section */}
      <div className="flex items-center gap-6">
        <div className="relative">
          {profile?.avatar_url ? (
            <img 
              src={profile.avatar_url} 
              alt="Profile" 
              className="w-24 h-24 rounded-full object-cover"
            />
          ) : (
            <div className="w-24 h-24 rounded-full bg-primary flex items-center justify-center text-white text-3xl font-bold">
              {profile?.full_name?.charAt(0)?.toUpperCase() || 'U'}
            </div>
          )}
          {uploading && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
            </div>
          )}
        </div>
        <div className="flex gap-3">
          <label>
            <input
              type="file"
              accept="image/*"
              onChange={handleAvatarUpload}
              className="hidden"
              disabled={uploading}
            />
            <Button
              variant="outline"
              size="sm"
              icon={<Upload className="w-4 h-4" />}
              disabled={uploading}
              as="span"
            >
              Upload Photo
            </Button>
          </label>
          {profile?.avatar_url && (
            <Button
              variant="ghost"
              size="sm"
              icon={<X className="w-4 h-4" />}
              onClick={handleRemoveAvatar}
              disabled={uploading}
            >
              Remove
            </Button>
          )}
        </div>
      </div>

      {/* Profile Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Information */}
        <div>
          <h3 className="text-lg font-semibold text-on-surface mb-4">Basic Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-on-surface mb-2">
                Full Name *
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant" />
                <input
                  type="text"
                  name="full_name"
                  value={formData.full_name}
                  onChange={handleChange}
                  required
                  className="w-full pl-10 pr-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-on-surface mb-2">
                Email Address *
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant" />
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full pl-10 pr-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-on-surface mb-2">
                Phone Number
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant" />
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full pl-10 pr-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-on-surface mb-2">
                Designation
              </label>
              <div className="relative">
                <Briefcase className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant" />
                <input
                  type="text"
                  name="designation"
                  value={formData.designation}
                  onChange={handleChange}
                  placeholder="e.g., Lead Surgeon"
                  className="w-full pl-10 pr-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-on-surface mb-2">
                Department
              </label>
              <input
                type="text"
                name="department"
                value={formData.department}
                onChange={handleChange}
                placeholder="e.g., Plastic Surgery"
                className="w-full px-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-on-surface mb-2">
                Specialization
              </label>
              <input
                type="text"
                name="specialization"
                value={formData.specialization}
                onChange={handleChange}
                placeholder="e.g., Reconstructive Surgery"
                className="w-full px-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-on-surface mb-2">
                License Number
              </label>
              <input
                type="text"
                name="license_number"
                value={formData.license_number}
                onChange={handleChange}
                placeholder="e.g., MED-12345-NY"
                className="w-full px-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-on-surface mb-2">
                Bio
              </label>
              <textarea
                name="bio"
                value={formData.bio}
                onChange={handleChange}
                rows={4}
                placeholder="Brief professional biography..."
                className="w-full px-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface resize-none"
              />
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-end gap-3 pt-4 border-t border-outline-variant">
          <Button
            type="button"
            variant="outline"
            onClick={loadProfile}
            disabled={loading}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={loading}
          >
            {loading ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default ProfileSettings;
