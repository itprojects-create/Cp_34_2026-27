import React, { useState, useEffect } from 'react';
import { Sun, Moon, Monitor, Layout } from 'lucide-react';
import Button from '../ui/Button';
import { useToast } from '../../contexts/ToastContext';
import { getUserPreferences, updateUserPreferences } from '../../services/settingsService';

const AppearanceSettings = ({ userId }) => {
  const toast = useToast();
  const [loading, setLoading] = useState(false);
  const [preferences, setPreferences] = useState({
    theme: 'light',
    compact_mode: false,
    language: 'en',
    date_format: 'MM/DD/YYYY',
    time_format: '12h'
  });

  useEffect(() => {
    loadPreferences();
  }, [userId]);

  const loadPreferences = async () => {
    setLoading(true);
    const { data, error } = await getUserPreferences(userId);
    
    if (error) {
      toast.error('Failed to load appearance preferences');
    } else if (data) {
      setPreferences(data);
    }
    setLoading(false);
  };

  const handleChange = (key, value) => {
    setPreferences(prev => ({ ...prev, [key]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const { data, error } = await updateUserPreferences(userId, preferences);

    if (error) {
      toast.error('Failed to update appearance preferences');
    } else {
      toast.success('Appearance preferences updated successfully');
    }
    setLoading(false);
  };

  if (loading && !preferences.id) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  const themes = [
    { value: 'light', label: 'Light', icon: Sun, description: 'Light theme for daytime use' },
    { value: 'dark', label: 'Dark', icon: Moon, description: 'Dark theme for low-light environments (Coming Soon)', disabled: true },
    { value: 'auto', label: 'Auto', icon: Monitor, description: 'Automatically switch based on system settings (Coming Soon)', disabled: true }
  ];

  const dateFormats = [
    { value: 'MM/DD/YYYY', label: 'MM/DD/YYYY', example: '12/31/2024' },
    { value: 'DD/MM/YYYY', label: 'DD/MM/YYYY', example: '31/12/2024' },
    { value: 'YYYY-MM-DD', label: 'YYYY-MM-DD', example: '2024-12-31' }
  ];

  const timeFormats = [
    { value: '12h', label: '12-hour', example: '02:30 PM' },
    { value: '24h', label: '24-hour', example: '14:30' }
  ];

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Theme Selection */}
      <div>
        <h3 className="text-lg font-semibold text-on-surface mb-4">Theme</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {themes.map((theme) => (
            <button
              key={theme.value}
              type="button"
              onClick={() => !theme.disabled && handleChange('theme', theme.value)}
              disabled={theme.disabled}
              className={`p-4 border-2 rounded-lg text-left transition-all ${
                preferences.theme === theme.value
                  ? 'border-primary bg-primary/5'
                  : 'border-outline hover:border-primary/50'
              } ${theme.disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
            >
              <div className="flex items-center gap-3 mb-2">
                <div className={`p-2 rounded-lg ${
                  preferences.theme === theme.value ? 'bg-primary text-white' : 'bg-surface-container-low'
                }`}>
                  <theme.icon className="w-5 h-5" />
                </div>
                <div className="font-medium text-on-surface">{theme.label}</div>
              </div>
              <div className="text-sm text-on-surface-variant">{theme.description}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Display Settings */}
      <div>
        <h3 className="text-lg font-semibold text-on-surface mb-4 flex items-center gap-2">
          <Layout className="w-5 h-5" />
          Display Settings
        </h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 border border-outline rounded-lg">
            <div>
              <div className="font-medium text-on-surface">Compact Mode</div>
              <div className="text-sm text-on-surface-variant mt-1">
                Reduce spacing and padding for a more compact interface
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={preferences.compact_mode}
                onChange={(e) => handleChange('compact_mode', e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary/20 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
            </label>
          </div>
        </div>
      </div>

      {/* Date & Time Format */}
      <div>
        <h3 className="text-lg font-semibold text-on-surface mb-4">Date & Time Format</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-on-surface mb-2">
              Date Format
            </label>
            <select
              value={preferences.date_format}
              onChange={(e) => handleChange('date_format', e.target.value)}
              className="w-full px-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
            >
              {dateFormats.map((format) => (
                <option key={format.value} value={format.value}>
                  {format.label} ({format.example})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-on-surface mb-2">
              Time Format
            </label>
            <select
              value={preferences.time_format}
              onChange={(e) => handleChange('time_format', e.target.value)}
              className="w-full px-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
            >
              {timeFormats.map((format) => (
                <option key={format.value} value={format.value}>
                  {format.label} ({format.example})
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Language (Coming Soon) */}
      <div>
        <h3 className="text-lg font-semibold text-on-surface mb-4">Language</h3>
        <div className="p-4 bg-surface-container-low rounded-lg border border-outline">
          <div className="font-medium text-on-surface mb-2">English (US)</div>
          <div className="text-sm text-on-surface-variant">
            Additional languages coming soon
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex justify-end gap-3 pt-4 border-t border-outline-variant">
        <Button
          type="button"
          variant="outline"
          onClick={loadPreferences}
          disabled={loading}
        >
          Cancel
        </Button>
        <Button
          type="submit"
          disabled={loading}
        >
          {loading ? 'Saving...' : 'Save Changes'}
        </Button>
      </div>
    </form>
  );
};

export default AppearanceSettings;
