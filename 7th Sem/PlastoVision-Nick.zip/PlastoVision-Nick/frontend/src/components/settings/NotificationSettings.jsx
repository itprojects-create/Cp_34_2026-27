import React, { useState, useEffect } from 'react';
import { Bell, Mail, MessageSquare, Smartphone } from 'lucide-react';
import Button from '../ui/Button';
import { useToast } from '../../contexts/ToastContext';
import { getNotificationPreferences, updateNotificationPreferences } from '../../services/settingsService';

const NotificationSettings = ({ userId }) => {
  const toast = useToast();
  const [loading, setLoading] = useState(false);
  const [preferences, setPreferences] = useState({
    appointment_created: true,
    appointment_updated: true,
    appointment_cancelled: true,
    appointment_reminder: true,
    system_updates: true,
    system_maintenance: true,
    email_notifications: true,
    sms_notifications: false,
    push_notifications: true
  });

  useEffect(() => {
    loadPreferences();
  }, [userId]);

  const loadPreferences = async () => {
    setLoading(true);
    const { data, error } = await getNotificationPreferences(userId);
    
    if (error) {
      toast.error('Failed to load notification preferences');
    } else if (data) {
      setPreferences(data);
    }
    setLoading(false);
  };

  const handleToggle = (key) => {
    setPreferences(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const { data, error } = await updateNotificationPreferences(userId, preferences);

    if (error) {
      toast.error('Failed to update notification preferences');
    } else {
      toast.success('Notification preferences updated successfully');
    }
    setLoading(false);
  };

  if (loading && !preferences.id) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  const notificationGroups = [
    {
      title: 'Appointment Notifications',
      icon: Bell,
      items: [
        { key: 'appointment_created', label: 'New Appointment Created', description: 'Get notified when a new appointment is scheduled' },
        { key: 'appointment_updated', label: 'Appointment Updated', description: 'Get notified when an appointment is modified' },
        { key: 'appointment_cancelled', label: 'Appointment Cancelled', description: 'Get notified when an appointment is cancelled' },
        { key: 'appointment_reminder', label: 'Appointment Reminders', description: 'Receive reminders before appointments' }
      ]
    },
    {
      title: 'System Notifications',
      icon: Bell,
      items: [
        { key: 'system_updates', label: 'System Updates', description: 'Get notified about new features and updates' },
        { key: 'system_maintenance', label: 'Maintenance Alerts', description: 'Get notified about scheduled maintenance' }
      ]
    },
    {
      title: 'Notification Channels',
      icon: MessageSquare,
      items: [
        { key: 'email_notifications', label: 'Email Notifications', description: 'Receive notifications via email', icon: Mail },
        { key: 'sms_notifications', label: 'SMS Notifications', description: 'Receive notifications via SMS (Coming Soon)', icon: Smartphone, disabled: true },
        { key: 'push_notifications', label: 'Push Notifications', description: 'Receive browser push notifications (Coming Soon)', icon: Bell, disabled: true }
      ]
    }
  ];

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {notificationGroups.map((group, idx) => (
        <div key={idx}>
          <h3 className="text-lg font-semibold text-on-surface mb-4 flex items-center gap-2">
            <group.icon className="w-5 h-5" />
            {group.title}
          </h3>
          <div className="space-y-4">
            {group.items.map((item) => (
              <div
                key={item.key}
                className={`flex items-start justify-between p-4 border border-outline rounded-lg ${
                  item.disabled ? 'opacity-50' : ''
                }`}
              >
                <div className="flex items-start gap-3 flex-1">
                  {item.icon && <item.icon className="w-5 h-5 text-on-surface-variant mt-0.5" />}
                  <div>
                    <div className="font-medium text-on-surface">{item.label}</div>
                    <div className="text-sm text-on-surface-variant mt-1">{item.description}</div>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={preferences[item.key] || false}
                    onChange={() => !item.disabled && handleToggle(item.key)}
                    disabled={item.disabled}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary/20 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                </label>
              </div>
            ))}
          </div>
        </div>
      ))}

      {/* Action Buttons */}
      <div className="flex justify-end gap-3 pt-4 border-t border-outline-variant">
        <Button
          type="button"
          variant="outline"
          onClick={loadPreferences}
          disabled={loading}
        >
          Cancel
        </Button>
        <Button
          type="submit"
          disabled={loading}
        >
          {loading ? 'Saving...' : 'Save Changes'}
        </Button>
      </div>
    </form>
  );
};

export default NotificationSettings;
