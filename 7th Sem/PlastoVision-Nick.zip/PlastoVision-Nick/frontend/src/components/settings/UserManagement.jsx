import React, { useState, useEffect } from 'react';
import { UserPlus, Search, Edit2, Trash2, CheckCircle, XCircle } from 'lucide-react';
import Button from '../ui/Button';
import Modal from '../ui/Modal';
import { useToast } from '../../contexts/ToastContext';
import { getAllProfiles, createProfile, updateProfile, deactivateProfile, activateProfile } from '../../services/settingsService';

const UserManagement = ({ currentUserId, currentUserRole }) => {
  const toast = useToast();
  const [loading, setLoading] = useState(false);
  const [users, setUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [formData, setFormData] = useState({
    user_id: '',
    full_name: '',
    email: '',
    phone: '',
    designation: '',
    department: '',
    role: 'Doctor',
    specialization: '',
    license_number: ''
  });

  useEffect(() => {
    loadUsers();
  }, [filterRole]);

  const loadUsers = async () => {
    setLoading(true);
    const { data, error } = await getAllProfiles({ 
      role: filterRole || undefined,
      search: searchTerm || undefined
    });
    
    if (error) {
      toast.error('Failed to load users');
    } else {
      setUsers(data || []);
    }
    setLoading(false);
  };

  const handleSearch = () => {
    loadUsers();
  };

  const handleAddUser = () => {
    setEditingUser(null);
    setFormData({
      user_id: `user-${Date.now()}`,
      full_name: '',
      email: '',
      phone: '',
      designation: '',
      department: '',
      role: 'Doctor',
      specialization: '',
      license_number: ''
    });
    setShowModal(true);
  };

  const handleEditUser = (user) => {
    setEditingUser(user);
    setFormData({
      user_id: user.user_id,
      full_name: user.full_name,
      email: user.email,
      phone: user.phone || '',
      designation: user.designation || '',
      department: user.department || '',
      role: user.role,
      specialization: user.specialization || '',
      license_number: user.license_number || ''
    });
    setShowModal(true);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    let result;
    if (editingUser) {
      result = await updateProfile(editingUser.user_id, formData);
    } else {
      result = await createProfile(formData);
    }

    if (result.error) {
      toast.error(`Failed to ${editingUser ? 'update' : 'create'} user`);
    } else {
      toast.success(`User ${editingUser ? 'updated' : 'created'} successfully`);
      setShowModal(false);
      loadUsers();
    }
    setLoading(false);
  };

  const handleToggleActive = async (user) => {
    const action = user.is_active ? deactivateProfile : activateProfile;
    const { success, error } = await action(user.user_id);

    if (error) {
      toast.error(`Failed to ${user.is_active ? 'deactivate' : 'activate'} user`);
    } else {
      toast.success(`User ${user.is_active ? 'deactivated' : 'activated'} successfully`);
      loadUsers();
    }
  };

  const isAdmin = currentUserRole === 'Admin';

  if (!isAdmin) {
    return (
      <div className="text-center py-12">
        <div className="text-on-surface-variant mb-4">
          <XCircle className="w-16 h-16 mx-auto mb-4 text-error" />
          <h3 className="text-xl font-semibold text-on-surface mb-2">Access Denied</h3>
          <p>You need administrator privileges to manage users.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between gap-4">
        <div>
          <h3 className="text-lg font-semibold text-on-surface">User Management</h3>
          <p className="text-sm text-on-surface-variant mt-1">
            Manage user accounts and permissions
          </p>
        </div>
        <Button
          onClick={handleAddUser}
          icon={<UserPlus className="w-4 h-4" />}
        >
          Add User
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-on-surface-variant" />
          <input
            type="text"
            placeholder="Search by name or email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            className="w-full pl-10 pr-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
          />
        </div>
        <select
          value={filterRole}
          onChange={(e) => setFilterRole(e.target.value)}
          className="px-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
        >
          <option value="">All Roles</option>
          <option value="Admin">Admin</option>
          <option value="Doctor">Doctor</option>
          <option value="Receptionist">Receptionist</option>
        </select>
        <Button onClick={handleSearch} variant="outline">
          Search
        </Button>
      </div>

      {/* Users List */}
      {loading ? (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      ) : users.length === 0 ? (
        <div className="text-center py-12 bg-surface-container-low rounded-lg">
          <p className="text-on-surface-variant">No users found</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-outline-variant">
                <th className="text-left py-3 px-4 font-semibold text-on-surface">Name</th>
                <th className="text-left py-3 px-4 font-semibold text-on-surface">Email</th>
                <th className="text-left py-3 px-4 font-semibold text-on-surface">Role</th>
                <th className="text-left py-3 px-4 font-semibold text-on-surface">Department</th>
                <th className="text-left py-3 px-4 font-semibold text-on-surface">Status</th>
                <th className="text-right py-3 px-4 font-semibold text-on-surface">Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.id} className="border-b border-outline-variant hover:bg-surface-container-low">
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-3">
                      {user.avatar_url ? (
                        <img src={user.avatar_url} alt="" className="w-10 h-10 rounded-full" />
                      ) : (
                        <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-white font-bold">
                          {user.full_name?.charAt(0)?.toUpperCase()}
                        </div>
                      )}
                      <div>
                        <div className="font-medium text-on-surface">{user.full_name}</div>
                        <div className="text-sm text-on-surface-variant">{user.designation}</div>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-on-surface-variant">{user.email}</td>
                  <td className="py-3 px-4">
                    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${
                      user.role === 'Admin' ? 'bg-purple-100 text-purple-800' :
                      user.role === 'Doctor' ? 'bg-blue-100 text-blue-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {user.role}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-on-surface-variant">{user.department || '-'}</td>
                  <td className="py-3 px-4">
                    {user.is_active ? (
                      <span className="inline-flex items-center gap-1 text-green-600">
                        <CheckCircle className="w-4 h-4" />
                        Active
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-gray-500">
                        <XCircle className="w-4 h-4" />
                        Inactive
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => handleEditUser(user)}
                        className="p-2 text-primary hover:bg-primary/10 rounded-lg transition-colors"
                        title="Edit user"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      {user.user_id !== currentUserId && (
                        <button
                          onClick={() => handleToggleActive(user)}
                          className={`p-2 rounded-lg transition-colors ${
                            user.is_active 
                              ? 'text-error hover:bg-error/10' 
                              : 'text-green-600 hover:bg-green-50'
                          }`}
                          title={user.is_active ? 'Deactivate user' : 'Activate user'}
                        >
                          {user.is_active ? <Trash2 className="w-4 h-4" /> : <CheckCircle className="w-4 h-4" />}
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Add/Edit User Modal */}
      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title={editingUser ? 'Edit User' : 'Add New User'}
        size="lg"
        footer={
          <>
            <Button variant="outline" onClick={() => setShowModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleSubmit} disabled={loading}>
              {loading ? 'Saving...' : editingUser ? 'Update User' : 'Create User'}
            </Button>
          </>
        }
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-on-surface mb-2">
                Full Name *
              </label>
              <input
                type="text"
                name="full_name"
                value={formData.full_name}
                onChange={handleChange}
                required
                className="w-full px-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-on-surface mb-2">
                Email *
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                disabled={!!editingUser}
                className="w-full px-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface disabled:opacity-50"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-on-surface mb-2">
                Phone
              </label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                className="w-full px-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-on-surface mb-2">
                Role *
              </label>
              <select
                name="role"
                value={formData.role}
                onChange={handleChange}
                required
                className="w-full px-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
              >
                <option value="Doctor">Doctor</option>
                <option value="Admin">Admin</option>
                <option value="Receptionist">Receptionist</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-on-surface mb-2">
                Designation
              </label>
              <input
                type="text"
                name="designation"
                value={formData.designation}
                onChange={handleChange}
                placeholder="e.g., Lead Surgeon"
                className="w-full px-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-on-surface mb-2">
                Department
              </label>
              <input
                type="text"
                name="department"
                value={formData.department}
                onChange={handleChange}
                placeholder="e.g., Plastic Surgery"
                className="w-full px-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
              />
            </div>

            {formData.role === 'Doctor' && (
              <>
                <div>
                  <label className="block text-sm font-medium text-on-surface mb-2">
                    Specialization
                  </label>
                  <input
                    type="text"
                    name="specialization"
                    value={formData.specialization}
                    onChange={handleChange}
                    className="w-full px-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-on-surface mb-2">
                    License Number
                  </label>
                  <input
                    type="text"
                    name="license_number"
                    value={formData.license_number}
                    onChange={handleChange}
                    className="w-full px-4 py-2.5 border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-surface"
                  />
                </div>
              </>
            )}
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default UserManagement;
