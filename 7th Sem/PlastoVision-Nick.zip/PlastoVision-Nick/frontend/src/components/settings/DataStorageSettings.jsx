import React, { useState, useEffect } from 'react';
import { Database, Download, Trash2, AlertTriangle } from 'lucide-react';
import Button from '../ui/Button';
import Modal from '../ui/Modal';
import { useToast } from '../../contexts/ToastContext';
import { getStorageStats, exportAllData } from '../../services/settingsService';

const DataStorageSettings = () => {
  const toast = useToast();
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState(null);
  const [showExportModal, setShowExportModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    setLoading(true);
    const { data, error } = await getStorageStats();
    
    if (error) {
      toast.error('Failed to load storage statistics');
    } else {
      setStats(data);
    }
    setLoading(false);
  };

  const handleExportData = async () => {
    setLoading(true);
    const { data, error } = await exportAllData();

    if (error) {
      toast.error('Failed to export data');
    } else {
      // Create and download JSON file
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `plastovision-data-export-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast.success('Data exported successfully');
      setShowExportModal(false);
    }
    setLoading(false);
  };

  const handleDeleteData = async () => {
    toast.error('Data deletion is a destructive operation and requires additional confirmation');
    setShowDeleteModal(false);
  };

  if (loading && !stats) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  const storageItems = [
    { label: 'Patients', count: stats?.patients || 0, icon: '👤' },
    { label: 'Visits', count: stats?.visits || 0, icon: '📋' },
    { label: 'Appointments', count: stats?.appointments || 0, icon: '📅' },
    { label: 'Documents', count: stats?.documents || 0, icon: '📄' },
    { label: 'Users', count: stats?.users || 0, icon: '👥' }
  ];

  return (
    <div className="space-y-6">
      {/* Storage Overview */}
      <div>
        <h3 className="text-lg font-semibold text-on-surface mb-4 flex items-center gap-2">
          <Database className="w-5 h-5" />
          Storage Overview
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {storageItems.map((item) => (
            <div key={item.label} className="p-4 bg-surface-container-low rounded-lg border border-outline">
              <div className="text-2xl mb-2">{item.icon}</div>
              <div className="text-2xl font-bold text-on-surface">{item.count.toLocaleString()}</div>
              <div className="text-sm text-on-surface-variant">{item.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Data Management */}
      <div>
        <h3 className="text-lg font-semibold text-on-surface mb-4">Data Management</h3>
        <div className="space-y-4">
          {/* Export Data */}
          <div className="p-4 bg-surface-container-low rounded-lg border border-outline">
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <Download className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <div className="font-medium text-on-surface">Export All Data</div>
                  <div className="text-sm text-on-surface-variant mt-1">
                    Download a complete backup of all your data in JSON format. This includes patients, visits, appointments, and documents metadata.
                  </div>
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowExportModal(true)}
                icon={<Download className="w-4 h-4" />}
              >
                Export
              </Button>
            </div>
          </div>

          {/* Delete Data Warning */}
          <div className="p-4 bg-red-50 rounded-lg border border-red-200">
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="p-2 bg-red-100 rounded-lg">
                  <Trash2 className="w-5 h-5 text-red-600" />
                </div>
                <div>
                  <div className="font-medium text-red-900">Delete All Data</div>
                  <div className="text-sm text-red-700 mt-1">
                    Permanently delete all data from the database. This action cannot be undone. Please export your data before proceeding.
                  </div>
                </div>
              </div>
              <Button
                variant="danger"
                size="sm"
                onClick={() => setShowDeleteModal(true)}
                icon={<Trash2 className="w-4 h-4" />}
              >
                Delete
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Data Privacy */}
      <div>
        <h3 className="text-lg font-semibold text-on-surface mb-4">Data Privacy & Compliance</h3>
        <div className="space-y-3">
          <div className="p-4 bg-surface-container-low rounded-lg">
            <div className="font-medium text-on-surface">HIPAA Compliance</div>
            <div className="text-sm text-on-surface-variant mt-1">
              All patient data is stored securely in accordance with HIPAA regulations. Ensure proper access controls and user management.
            </div>
          </div>

          <div className="p-4 bg-surface-container-low rounded-lg">
            <div className="font-medium text-on-surface">Data Retention</div>
            <div className="text-sm text-on-surface-variant mt-1">
              Patient records are retained indefinitely unless explicitly deleted. Consider implementing a data retention policy for your clinic.
            </div>
          </div>

          <div className="p-4 bg-surface-container-low rounded-lg">
            <div className="font-medium text-on-surface">Backup Recommendation</div>
            <div className="text-sm text-on-surface-variant mt-1">
              Export and backup your data regularly to prevent data loss. Store backups securely in compliance with healthcare data regulations.
            </div>
          </div>
        </div>
      </div>

      {/* Export Confirmation Modal */}
      <Modal
        isOpen={showExportModal}
        onClose={() => setShowExportModal(false)}
        title="Export All Data"
        footer={
          <>
            <Button variant="outline" onClick={() => setShowExportModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleExportData} disabled={loading} icon={<Download className="w-4 h-4" />}>
              {loading ? 'Exporting...' : 'Export Data'}
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <p className="text-on-surface">
            This will export all data from the following tables:
          </p>
          <ul className="list-disc list-inside space-y-2 text-on-surface-variant">
            <li>Patients ({stats?.patients || 0} records)</li>
            <li>Visits ({stats?.visits || 0} records)</li>
            <li>Appointments ({stats?.appointments || 0} records)</li>
            <li>Documents Metadata ({stats?.documents || 0} records)</li>
          </ul>
          <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="text-sm text-blue-800">
              Note: This export includes metadata only. Document files stored in Supabase Storage must be backed up separately.
            </p>
          </div>
        </div>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={showDeleteModal}
        onClose={() => setShowDeleteModal(false)}
        title="Delete All Data"
        footer={
          <>
            <Button variant="outline" onClick={() => setShowDeleteModal(false)}>
              Cancel
            </Button>
            <Button variant="danger" onClick={handleDeleteData} icon={<Trash2 className="w-4 h-4" />}>
              I Understand, Delete All Data
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <div className="p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
            <AlertTriangle className="w-6 h-6 text-red-600 mt-0.5" />
            <div>
              <div className="font-semibold text-red-900 mb-2">⚠️ Critical Warning</div>
              <div className="text-sm text-red-700">
                This action will permanently delete ALL data from the database and CANNOT be undone.
              </div>
            </div>
          </div>

          <div className="text-on-surface">
            <p className="font-medium mb-2">The following data will be permanently deleted:</p>
            <ul className="list-disc list-inside space-y-1 text-on-surface-variant">
              <li>All patient records ({stats?.patients || 0})</li>
              <li>All visit records ({stats?.visits || 0})</li>
              <li>All appointment records ({stats?.appointments || 0})</li>
              <li>All document metadata ({stats?.documents || 0})</li>
              <li>Document files in storage</li>
            </ul>
          </div>

          <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
            <p className="text-sm text-orange-800 font-medium">
              Have you exported your data? Make sure to create a backup before proceeding.
            </p>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default DataStorageSettings;
