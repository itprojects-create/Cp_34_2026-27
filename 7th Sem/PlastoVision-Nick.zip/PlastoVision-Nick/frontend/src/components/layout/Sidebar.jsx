import React, { useState, useEffect } from 'react';
import { NavLink, Link } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  Calendar, 
  ScanFace, 
  Box, 
  FileText, 
  Settings 
} from 'lucide-react';
import { getProfile } from '../../services/settingsService';

const Sidebar = ({ isMobile = false, onNavigate }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const CURRENT_USER_ID = 'dr-michaels-001'; // Will be replaced with auth

  useEffect(() => {
    loadCurrentUser();
  }, []);

  const loadCurrentUser = async () => {
    const { data } = await getProfile(CURRENT_USER_ID);
    if (data) {
      setCurrentUser(data);
    }
  };

  const navItems = [
    { name: 'Dashboard', path: '/', icon: LayoutDashboard, end: true },
    { name: 'Patients', path: '/patients', icon: Users },
    { name: 'Appointments', path: '/appointments', icon: Calendar },
    { name: 'Photo Tracking', path: '/photo-tracking', icon: ScanFace },
    { name: 'Visualization', path: '/visualization', icon: Box },
    { name: 'Reports', path: '/reports', icon: FileText },
    { name: 'Settings', path: '/settings', icon: Settings },
  ];

  return (
    <aside className={`${isMobile ? 'flex' : 'hidden md:flex'} w-64 bg-navy text-white flex-col h-full shrink-0`}>
      <div className="p-6 flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center shadow-sm">
           <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
          </svg>
        </div>
        <div>
          <span className="font-headline font-bold text-lg tracking-tight block">PlastoVision</span>
          <span className="text-[11px] uppercase tracking-[0.14em] text-white/50">Clinical workspace</span>
        </div>
      </div>
      <nav className="flex-1 px-3 py-2 space-y-1 overflow-y-auto">
        {navItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            end={item.end}
            onClick={onNavigate}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                isActive
                  ? 'bg-primary text-white shadow-sm'
                  : 'text-white/70 hover:bg-white/10 hover:text-white'
              }`
            }
          >
            <item.icon className="w-5 h-5" />
            {item.name}
          </NavLink>
        ))}
      </nav>
      <div className="p-4 border-t border-white/10">
        <Link 
          to="/settings"
          onClick={onNavigate}
          className="flex items-center gap-3 px-3 py-2 text-sm text-white/70 hover:bg-white/10 rounded-xl transition-colors"
        >
          {currentUser?.avatar_url ? (
            <img 
              src={currentUser.avatar_url} 
              alt="Profile" 
              className="w-8 h-8 rounded-full object-cover"
            />
          ) : (
            <div className="w-8 h-8 rounded-full bg-primary/30 text-white flex items-center justify-center font-bold">
              {currentUser?.full_name?.split(' ').map(n => n.charAt(0)).join('').toUpperCase() || 'DM'}
            </div>
          )}
          <div className="min-w-0">
            <p className="font-medium text-white truncate">
              {currentUser?.full_name || 'Dr. Michaels'}
            </p>
            <p className="text-xs text-white/50 truncate">
              {currentUser?.designation || 'Lead Surgeon'}
            </p>
          </div>
        </Link>
      </div>
    </aside>
  );
};

export default Sidebar;
