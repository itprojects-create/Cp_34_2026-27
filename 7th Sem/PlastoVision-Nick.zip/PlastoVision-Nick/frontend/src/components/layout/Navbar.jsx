import React, { useState, useEffect } from 'react';
import { Search, Bell, Menu, User } from 'lucide-react';
import { Link } from 'react-router-dom';
import { getProfile } from '../../services/settingsService';

const Navbar = ({ onMenuClick }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const CURRENT_USER_ID = 'dr-michaels-001'; // Will be replaced with auth

  useEffect(() => {
    loadCurrentUser();
  }, []);

  const loadCurrentUser = async () => {
    const { data } = await getProfile(CURRENT_USER_ID);
    if (data) {
      setCurrentUser(data);
    }
  };

  return (
    <header className="h-16 bg-surface-container-lowest/90 backdrop-blur border-b border-outline-variant flex items-center justify-between px-4 lg:px-8 shrink-0">
      <div className="flex items-center gap-4 min-w-0">
        <button 
          onClick={onMenuClick}
          className="md:hidden p-2 text-on-surface hover:bg-surface-container rounded-xl"
          aria-label="Open navigation"
        >
          <Menu className="w-5 h-5" />
        </button>
        <div className="relative hidden sm:block">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-on-surface-variant" />
          <input 
            type="text" 
            placeholder="Search patients, appointments..." 
            className="pl-10 pr-4 py-2 w-64 lg:w-80 bg-surface-container border-none rounded-full text-sm font-body"
          />
        </div>
      </div>
      
      <div className="flex items-center gap-2 sm:gap-3">
        <button className="relative p-2 text-on-surface-variant hover:text-on-surface hover:bg-surface-container rounded-xl transition-colors" aria-label="Notifications">
          <Bell className="w-5 h-5" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-error rounded-full outline outline-2 outline-surface-container-lowest"></span>
        </button>
        
        {/* User Profile Button */}
        <Link 
          to="/settings"
          className="flex items-center gap-2 px-2 sm:px-3 py-1.5 hover:bg-surface-container rounded-xl transition-colors"
        >
          {currentUser?.avatar_url ? (
            <img 
              src={currentUser.avatar_url} 
              alt="Profile" 
              className="w-8 h-8 rounded-full object-cover"
            />
          ) : (
            <div className="w-8 h-8 rounded-full bg-navy flex items-center justify-center text-white text-sm font-bold">
              {currentUser?.full_name?.charAt(0)?.toUpperCase() || <User className="w-4 h-4" />}
            </div>
          )}
          <div className="hidden md:block text-left">
            <div className="text-sm font-medium text-on-surface leading-tight">
              {currentUser?.full_name || 'Loading...'}
            </div>
            <div className="text-xs text-on-surface-variant">
              {currentUser?.designation || 'User'}
            </div>
          </div>
        </Link>
      </div>
    </header>
  );
};

export default Navbar;
