/**
 * Photo Upload Modal Component
 * 
 * Multi-step workflow for uploading and validating patient photos.
 */

import React, { useState, useRef, useEffect } from 'react';
import { X, Upload, Camera, Check, CheckCircle, AlertTriangle } from 'lucide-react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import FacialViewSelector from './FacialViewSelector';
import ValidationFeedback from './ValidationFeedback';
import CameraCaptureDebugStyle from './CameraCaptureDebugStyle';
import photoApi from '../../lib/photoApi';
import { getPatientVisits } from '../../services/patientService';
import { TREATMENT_STAGES, validatePhotoFile, validatePhotoWithCV, formatFileSize } from '../../services/validationService';
import { uploadPhoto, getPatientPhotos, getPatientProcedures } from '../../services/photoService';

const STEPS = {
  SELECT_VIEW: 'select_view',
  SELECT_STAGE: 'select_stage',
  UPLOAD_FILE: 'upload_file',
  CAMERA_SETUP: 'camera_setup',
  VALIDATE: 'validate',
  CONFIRM: 'confirm'
};

const PhotoUploadModal = ({ isOpen, onClose, patientId, appointmentId, onUploadSuccess }) => {
  const [currentStep, setCurrentStep] = useState(STEPS.SELECT_VIEW);
  const [selectedView, setSelectedView] = useState(null);
  const [treatmentStage, setTreatmentStage] = useState('');
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [isValidating, setIsValidating] = useState(false);
  const [validationResult, setValidationResult] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [notes, setNotes] = useState('');
  const [showCamera, setShowCamera] = useState(false);
  const fileInputRef = useRef(null);
  const saved = useRef(false);
  const [reviewReason, setReviewReason] = useState('');
  const [captureMethod, setCaptureMethod] = useState('upload');
  // Use the default setup; no measured distance or calibrated camera is claimed.
  const [setup, setSetup] = useState({ framing_protocol: 'full_face', position: 'seated' });
  const [sessionPhotos, setSessionPhotos] = useState([]);
  const [visits, setVisits] = useState([]);
  const [visitId, setVisitId] = useState('');
  const [config, setConfig] = useState(null);
  const [procedures, setProcedures] = useState([]);
  const [procedureId, setProcedureId] = useState('');
  const [setupError, setSetupError] = useState('');
  const captureId = useRef(null);
  const completedViews = sessionPhotos.filter(photo => photo.visit_id === visitId && photo.treatment_stage === treatmentStage).map(photo => photo.facial_view);
  useEffect(() => {
    let active = true;
    if (isOpen) Promise.all([getPatientVisits(patientId), photoApi.get('/api/patient-photos/capture-config'), getPatientPhotos(patientId), getPatientProcedures(patientId).catch(() => [])])
      .then(([result, response, photos, episodes]) => {
        if (!active) return;
        if (result.error) throw new Error(result.error);
        setVisits(result.data || []); setConfig(response.data); setSessionPhotos(photos); setProcedures(episodes); setSetupError('');
      }).catch(error => { if (active) setSetupError(error.response?.data?.error || error.message); });
    return () => { active = false; };
  }, [isOpen, patientId]);

  // Reset modal state
  const resetModal = () => {
    setCurrentStep(STEPS.SELECT_VIEW);
    setSelectedView(null);
    setTreatmentStage('');
    setSelectedFile(null);
    setPreviewUrl(null);
    setValidationResult(null);
    setNotes('');
    setReviewReason('');
    setShowCamera(false);
    setSessionPhotos([]); setVisitId(''); captureId.current = null;
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleClose = () => {
    resetModal();
    onClose();
    if (saved.current) { saved.current = false; onUploadSuccess?.(); }
  };

  // Step 1: Select View
  const handleViewSelect = (viewId) => {
    setSelectedView(viewId);
    setSetup(previous => ({ ...previous, physical_setup_confirmed: false }));
  };

  const handleViewContinue = () => {
    if (selectedView) {
      setCurrentStep(STEPS.SELECT_STAGE);
    }
  };

  // Step 2: Select Treatment Stage
  const handleStageSelect = (stage) => {
    setTreatmentStage(stage);
  };

  const handleStageContinue = () => {
    if (treatmentStage) {
      // Visit is optional - auto-create if not selected
      setCurrentStep(STEPS.UPLOAD_FILE);
    }
  };

  // Camera capture handlers
  const handleCameraSave = async (file, metadata) => {
    const result = await uploadPhoto(file, patientId, appointmentId, selectedView, treatmentStage,
      { ...metadata, visitId, procedureId });
    saved.current = true;
    setSessionPhotos(previous => [...previous.filter(p => p.id !== result.photo.id), result.photo]);
    return result;
  };

  const handleCameraClose = () => {
    setShowCamera(false);
    setSetup(previous => ({ ...previous, physical_setup_confirmed: false }));
    setCurrentStep(STEPS.SELECT_VIEW);
  };

  // Handle "Use Camera" selection - go to camera setup
  const handleUseCameraClick = () => {
    setCurrentStep(STEPS.CAMERA_SETUP);
  };

  // Handle camera setup completion
  const handleCameraSetupContinue = () => {
    if (setup.physical_setup_confirmed) {
      setShowCamera(true);
    }
  };

  // Step 3: Upload File
  const handleFileSelect = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      setCaptureMethod('upload');
      processFile(file);
    }
  };

  const handleFileDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) {
      setCaptureMethod('upload');
      processFile(file);
    }
  };

  const processFile = (file) => {
    // Client-side validation
    const validation = validatePhotoFile(file);
    
    if (!validation.valid) {
      alert(validation.errors.join('\n'));
      return;
    }

    setSelectedFile(file);
    captureId.current = crypto.randomUUID();

    // Create preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreviewUrl(e.target.result);
    };
    reader.readAsDataURL(file);

    // Auto-advance to validation
    setCurrentStep(STEPS.VALIDATE);
    performValidation(file);
  };

  // Step 4: Validate
  const performValidation = async (file) => {
    setIsValidating(true);
    setValidationResult(null);

    try {
      const result = await validatePhotoWithCV(file, selectedView, setup);
      setValidationResult(result);
      
      // If validation passes, auto-advance to confirm
      if (result.valid) {
        setTimeout(() => {
          setCurrentStep(STEPS.CONFIRM);
        }, 1500);
      }
    } catch (error) {
      console.error('Validation error:', error);
      setValidationResult({
        valid: false,
        errors: ['Failed to validate photo. Please try again.'],
        warnings: []
      });
    } finally {
      setIsValidating(false);
    }
  };

  const handleRetakePhoto = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    setValidationResult(null);
    setCurrentStep(STEPS.UPLOAD_FILE);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Step 5: Confirm and Upload
  const handleUpload = async () => {
    if (!selectedFile || (!validationResult?.valid && !(validationResult?.reviewable && reviewReason.trim().length >= 15))) {
      return;
    }

    setIsUploading(true);

    try {
      const result = await uploadPhoto(
        selectedFile,
        patientId,
        appointmentId,
        selectedView,
        treatmentStage,
        { notes, setup, reviewReason, captureMethod, visitId, procedureId, captureId: captureId.current }
      );

      // Success!
      saved.current = true;

      setSessionPhotos(previous => [...previous, result.photo]);
      setSelectedFile(null); setPreviewUrl(null); setValidationResult(null); setReviewReason('');
      setCurrentStep(STEPS.SELECT_VIEW);
    } catch (error) {
      console.error('Upload error:', error);
      
      // Handle view mismatch error specifically
      if (error.response?.data?.error === 'View Mismatch') {
        const validation = error.response.data.validation;
        const confidence = validation.confidence || 'unknown';
        alert(
          `❌ View Mismatch Detected (${confidence} confidence)!\n\n` +
          `You selected: ${validation.requested_view}\n` +
          `But the photo shows: ${validation.detected_view}\n\n` +
          `Detection reasoning: ${validation.reasoning || 'Based on pose angles'}\n\n` +
          `Detected angles:\n` +
          `- Yaw: ${validation.yaw?.toFixed(1) || 'N/A'}°\n` +
          `- Pitch: ${validation.pitch?.toFixed(1) || 'N/A'}°\n` +
          `- Roll: ${validation.roll?.toFixed(1) || 'N/A'}°\n\n` +
          `Please either:\n` +
          `1. Upload a different photo that matches ${validation.requested_view}, OR\n` +
          `2. Change your view selection to ${validation.detected_view}`
        );
      } else {
        alert(error.response?.data?.message || error.response?.data?.error || 'Failed to upload photo. Please try again.');
      }
    } finally {
      setIsUploading(false);
    }
  };

  // Render step content
  const renderStepContent = () => {
    switch (currentStep) {
      case STEPS.SELECT_VIEW:
        return (
          <div className="space-y-4">
            {setupError && <p role="alert" className="text-error bg-error-container rounded-xl px-3 py-2 text-sm">{setupError}. Check the local backend and CV services, then reopen capture.</p>}
            <p className="text-sm text-on-surface-variant">Saved for selected visit: {new Set(completedViews).size}/6 views. Choose the next view or close.</p>
            <FacialViewSelector
              selectedView={selectedView}
              onSelect={handleViewSelect}
              capturedViews={completedViews}
              profiles={config?.views}
            />
            <div className="flex justify-end pt-4">
              <Button
                onClick={handleViewContinue}
                disabled={!selectedView}
              >
                Continue
              </Button>
            </div>
          </div>
        );

      case STEPS.SELECT_STAGE:
        return (
          <div className="space-y-4">
            <div>
              <h3 className="section-title mb-3">
                Select Treatment Stage
              </h3>
              <div className="space-y-2">
                {TREATMENT_STAGES.map((stage) => (
                  <button
                    key={stage.value}
                    onClick={() => handleStageSelect(stage.value)}
                    className={`
                      w-full text-left px-4 py-3 rounded-xl border-2 transition-all
                      ${
                        treatmentStage === stage.value
                          ? 'border-primary bg-primary-container/60'
                          : 'border-outline-variant bg-surface-container-lowest hover:border-primary/40'
                      }
                    `}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-on-surface">{stage.label}</span>
                      {treatmentStage === stage.value && (
                        <Check className="w-5 h-5 text-primary" />
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>
            {/* Optional Visit Selection */}
            <div className="bg-tertiary-container/50 border border-tertiary/20 rounded-2xl p-4">
              <h4 className="text-sm font-semibold text-on-surface mb-2">
                Associate with Visit (Optional)
              </h4>
              <p className="text-xs text-on-surface-variant mb-3">
                Link this photo to an existing patient visit, or leave blank to auto-create a photography session.
              </p>
              <label className="block">
                <span className="text-sm">Patient Visit</span>
                <select 
                  aria-label="Photography visit" 
                  className="w-full mt-1" 
                  value={visitId}  
                  onChange={e => setVisitId(e.target.value)}
                >
                  <option value="">Auto-create photography session</option>
                  {visits.map(visit => (
                    <option key={visit.id} value={visit.id}>
                      {new Date(visit.visit_date).toLocaleString()} — {visit.diagnosis || 'Consultation'}
                    </option>
                  ))}
                </select>
              </label>
            </div>
            {procedures.length > 0 && <label className="block text-sm">Procedure episode (optional)
              <select className="w-full mt-1" value={procedureId} onChange={e => {
                setProcedureId(e.target.value);
                const reference = sessionPhotos.filter(p => p.procedure_id === e.target.value).sort((a,b) => new Date(a.captured_at)-new Date(b.captured_at))[0];
                if (reference?.capture_setup) {
                  const { framing_protocol, position, measured_distance_cm, camera_height_cm, camera_profile_id, setup_notes, camera_preset } = reference.capture_setup;
                  setSetup({ framing_protocol: framing_protocol || 'full_face', position: position || 'seated', measured_distance_cm, camera_height_cm, camera_profile_id, setup_notes, camera_preset, physical_setup_confirmed: false });
                }
              }}><option value="">No procedure link</option>{procedures.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select>
            </label>}
            <div className="flex justify-between pt-4">
              <Button
                variant="outline"
                onClick={() => setCurrentStep(STEPS.SELECT_VIEW)}
              >
                Back
              </Button>
              <Button
                onClick={handleStageContinue}
                disabled={!treatmentStage}
              >
                Continue
              </Button>
            </div>
          </div>
        );

      case STEPS.UPLOAD_FILE:
        return (
          <div className="space-y-4">
            <div>
              <h3 className="section-title mb-3">
                Upload Photo
              </h3>

              {/* Option Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                {/* Camera Capture Option */}
                <button
                  onClick={() => setShowCamera(true)}
                  className="flex flex-col items-center justify-center p-6 border-2 border-outline-variant rounded-2xl hover:border-primary/50 hover:bg-primary-container/30 transition-all group"
                >
                  <Camera className="w-12 h-12 text-on-surface-variant group-hover:text-primary mb-3" />
                  <span className="text-sm font-medium text-on-surface group-hover:text-primary">
                    Use Camera
                  </span>
                  <span className="text-xs text-on-surface-variant mt-1">
                    Capture with live guidance
                  </span>
                </button>

                {/* File Upload Option */}
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="flex flex-col items-center justify-center p-6 border-2 border-outline-variant rounded-2xl hover:border-primary/50 hover:bg-primary-container/30 transition-all group"
                >
                  <Upload className="w-12 h-12 text-on-surface-variant group-hover:text-primary mb-3" />
                  <span className="text-sm font-medium text-on-surface group-hover:text-primary">
                    Upload File
                  </span>
                  <span className="text-xs text-on-surface-variant mt-1">
                    Select from device
                  </span>
                </button>
              </div>

              {/* File Input (hidden) */}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/jpg,image/png"
                onChange={handleFileSelect}
                className="hidden"
              />

              {/* Drop Zone */}
              <div
                onDrop={handleFileDrop}
                onDragOver={(e) => e.preventDefault()}
                className="border-2 border-dashed border-outline-variant rounded-2xl p-6 text-center bg-surface-container-low"
              >
                <p className="text-sm text-on-surface-variant">
                  Or drag and drop a file here
                </p>
                <p className="text-xs text-on-surface-variant/80 mt-1">
                  JPEG or PNG (max 10MB)
                </p>
              </div>
            </div>

            <div className="flex justify-start pt-4">
              <Button
                variant="outline"
                onClick={() => setCurrentStep(STEPS.SELECT_STAGE)}
              >
                Back
              </Button>
            </div>
          </div>
        );

      case STEPS.VALIDATE:
        return (
          <div className="space-y-4">
            <h3 className="section-title">
              Photo Validation
            </h3>

            {/* Preview */}
            {previewUrl && (
              <div className="relative">
                <img
                  src={previewUrl}
                  alt="Preview"
                  className="w-full h-64 object-contain bg-navy/90 rounded-2xl"
                />
                {selectedFile && (
                  <div className="mt-2 text-sm text-on-surface-variant">
                    {selectedFile.name} ({formatFileSize(selectedFile.size)})
                  </div>
                )}
              </div>
            )}

            {/* Enhanced Validation Feedback with Review Input */}
            <ValidationFeedback
              validationResult={validationResult}
              isValidating={isValidating}
              reviewReason={reviewReason}
              onReviewReasonChange={setReviewReason}
              showReviewInput={validationResult?.reviewable && !validationResult?.valid}
            />

            {/* Actions */}
            {validationResult && !isValidating && (
              <div className="flex justify-between pt-4">
                <Button
                  variant="outline"
                  onClick={handleRetakePhoto}
                >
                  Replace Photo
                </Button>
                
                {/* Show Continue button for valid photos */}
                {validationResult.valid && (
                  <Button onClick={() => setCurrentStep(STEPS.CONFIRM)}>
                    Continue to Approval
                  </Button>
                )}
                
                {/* Show Review button for reviewable photos */}
                {validationResult.reviewable && !validationResult.valid && (
                  <Button 
                    disabled={reviewReason.trim().length < 15}
                    onClick={() => setCurrentStep(STEPS.CONFIRM)}
                    title={reviewReason.trim().length < 15 ? 'Please enter at least 15 characters documenting your clinical review' : 'Proceed with clinician-approved photo'}
                  >
                    {reviewReason.trim().length < 15 ? 'Complete Review Notes' : 'Approve & Continue'}
                  </Button>
                )}
                
                {/* Show warning for invalid non-reviewable photos */}
                {!validationResult.valid && !validationResult.reviewable && (
                  <div className="text-right">
                    <p className="text-sm text-error mb-2">
                      This photo cannot be used. Please retake.
                    </p>
                    <Button variant="outline" onClick={handleRetakePhoto}>
                      Try Again
                    </Button>
                  </div>
                )}
              </div>
            )}
          </div>
        );

      case STEPS.CONFIRM:
        return (
          <div className="space-y-4">
            <h3 className="section-title">
              Final Approval
            </h3>

            {/* Preview */}
            {previewUrl && (
              <img
                src={previewUrl}
                alt="Preview"
                className="w-full h-48 object-contain bg-navy/90 rounded-2xl"
              />
            )}

            {/* Summary */}
            <div className="bg-surface-container rounded-2xl p-4 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-on-surface-variant">Facial View:</span>
                <span className="font-medium text-on-surface">{selectedView}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-on-surface-variant">Treatment Stage:</span>
                <span className="font-medium text-on-surface">
                  {TREATMENT_STAGES.find(s => s.value === treatmentStage)?.label}
                </span>
              </div>
              {visitId && (
                <div className="flex justify-between">
                  <span className="text-on-surface-variant">Associated Visit:</span>
                  <span className="font-medium text-on-surface">
                    {visits.find(v => v.id === visitId)?.diagnosis || 'Selected'}
                  </span>
                </div>
              )}
              {!visitId && (
                <div className="flex justify-between">
                  <span className="text-on-surface-variant">Session:</span>
                  <span className="font-medium text-primary">Auto-create photography session</span>
                </div>
              )}
            </div>

            {/* Validation Status */}
            {validationResult && (
              <div className={`rounded-lg p-4 ${
                validationResult.valid 
                  ? 'bg-success-container/70 border border-success/20' 
                  : 'bg-warning-container/80 border border-warning/20'
              }`}>
                <div className="flex items-start">
                  {validationResult.valid ? (
                    <CheckCircle className="w-5 h-5 text-success mr-2 flex-shrink-0 mt-0.5" />
                  ) : (
                    <AlertTriangle className="w-5 h-5 text-warning mr-2 flex-shrink-0 mt-0.5" />
                  )}
                  <div className="flex-1">
                    <h4 className={`font-semibold text-sm mb-1 ${
                      validationResult.valid ? 'text-green-900' : 'text-yellow-900'
                    }`}>
                      {validationResult.valid 
                        ? 'Automated Validation Passed' 
                        : 'Clinician Review Completed'}
                    </h4>
                    <p className={`text-xs ${
                      validationResult.valid ? 'text-green-800' : 'text-yellow-800'
                    }`}>
                      {validationResult.valid 
                        ? 'All automated checks passed. Photo meets technical requirements.' 
                        : 'Photo reviewed and approved by clinician with documented justification.'}
                    </p>
                  </div>
                </div>

                {/* Show review reason if present */}
                {reviewReason && reviewReason.trim().length > 0 && (
                  <div className="mt-3 pt-3 border-t border-warning/20">
                    <p className="text-xs font-semibold text-on-surface mb-1">
                      Clinical Review Notes:
                    </p>
                    <p className="text-xs text-on-surface-variant italic">
                      "{reviewReason}"
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Notes */}
            <div>
              <label className="block text-sm font-medium mb-1">
                Additional Notes (Optional)
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={3}
                className="w-full"
                placeholder="Add any additional notes about this photo session..."
              />
            </div>

            {/* Actions */}
            <div className="flex justify-between pt-4">
              <Button
                variant="outline"
                onClick={handleRetakePhoto}
                disabled={isUploading}
              >
                Retake Photo
              </Button>
              <Button
                onClick={handleUpload}
                disabled={isUploading}
              >
                {isUploading ? 'Saving...' : 'Save Photo'}
              </Button>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  // Progress indicator
  const steps = [
    { key: STEPS.SELECT_VIEW, label: 'View' },
    { key: STEPS.SELECT_STAGE, label: 'Stage' },
    { key: STEPS.UPLOAD_FILE, label: 'Upload' },
    { key: STEPS.VALIDATE, label: 'Validate' },
    { key: STEPS.CONFIRM, label: 'Confirm' }
  ];

  const currentStepIndex = steps.findIndex(s => s.key === currentStep);

  return (
    <>
      <Modal isOpen={isOpen} onClose={handleClose} size="large" title="Upload Patient Photo">
        <div>
          {/* Progress Steps */}
          <div className="mb-6">
            <div className="flex items-center justify-between">
              {steps.map((step, idx) => (
                <React.Fragment key={step.key}>
                  <div className="flex flex-col items-center">
                    <div
                      className={`
                        w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium
                        ${
                          idx < currentStepIndex
                            ? 'bg-success text-white'
                            : idx === currentStepIndex
                            ? 'bg-primary text-white'
                            : 'bg-surface-container text-on-surface-variant'
                        }
                      `}
                    >
                      {idx < currentStepIndex ? (
                        <Check className="w-4 h-4" />
                      ) : (
                        idx + 1
                      )}
                    </div>
                    <span className="text-xs text-on-surface-variant mt-1">{step.label}</span>
                  </div>
                  {idx < steps.length - 1 && (
                    <div
                      className={`flex-1 h-0.5 mx-2 ${
                        idx < currentStepIndex ? 'bg-success' : 'bg-surface-container-highest'
                      }`}
                    />
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>

          {/* Step Content */}
          <div className="min-h-[400px]">
            {renderStepContent()}
          </div>
        </div>
      </Modal>

      {/* Camera Capture (Full Screen Overlay) - Debug Style Interface */}
      {showCamera && (
        <CameraCaptureDebugStyle
          selectedView={selectedView}
          setup={setup}
          patientId={patientId}
          config={config}
          onSave={handleCameraSave}
          onClose={handleCameraClose}
        />
      )}
    </>
  );
};

export default PhotoUploadModal;
