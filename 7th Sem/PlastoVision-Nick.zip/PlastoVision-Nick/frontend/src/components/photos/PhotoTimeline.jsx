/**
 * Photo Timeline Component
 * 
 * Displays patient photos organized by treatment stage and visit.
 * Phase 4: Enhanced with visit grouping, validation status display, and missing view indicators.
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Calendar, Eye, Trash2, Download, 
  CheckCircle, AlertTriangle, XCircle, HelpCircle 
} from 'lucide-react';
import { getPhotoTimeline, getPhotoFile, deletePhoto } from '../../services/photoService';
import { 
  getFacialView, TREATMENT_STAGES, FACIAL_VIEWS,
  getValidationStatusColor, getValidationStatusIcon, getValidationStatusLabel
} from '../../services/validationService';
import PhotoViewer from './PhotoViewer';

// Required facial views for complete documentation
const REQUIRED_VIEWS = FACIAL_VIEWS.map(v => v.id);

const PhotoTimeline = ({ patientId, onPhotoDeleted }) => {
  const [groupedPhotos, setGroupedPhotos] = useState({});
  const [photoUrls, setPhotoUrls] = useState({});
  const [loading, setLoading] = useState(true);
  const [selectedPhoto, setSelectedPhoto] = useState(null);
  const [viewerOpen, setViewerOpen] = useState(false);

  const urlsRef = useRef({});
  const loadGeneration = useRef({value:0});

  const loadTimeline = useCallback(async () => {
    const generation = ++loadGeneration.current.value;
    try {
      setLoading(true);
      const data = await getPhotoTimeline(patientId);
      if (generation !== loadGeneration.current.value) return;
      
      // Transform data to group by stage -> visit -> photos
      const grouped = transformToVisitGrouping(data);
      setGroupedPhotos(grouped);

      // Load photo URLs
      const urls = {};
      const allPhotos = Object.values(data).flatMap(stage => stage.photos);
      
      await Promise.all(
        allPhotos.map(async (photo) => {
          try {
            const url = await getPhotoFile(photo.id);
            urls[photo.id] = url;
          } catch (error) {
            console.error(`Failed to load photo ${photo.id}:`, error);
          }
        })
      );

      if (generation !== loadGeneration.current.value) { 
        Object.values(urls).forEach(URL.revokeObjectURL); 
        return; 
      }
      Object.values(urlsRef.current).forEach(URL.revokeObjectURL);
      urlsRef.current = urls;
      setPhotoUrls(urls);
    } catch (error) {
      console.error('Failed to load timeline:', error);
    } finally {
      if (generation === loadGeneration.current.value) setLoading(false);
    }
  }, [patientId]);

  useEffect(() => {
    const counter = loadGeneration.current;
    loadTimeline();
    
    // Cleanup blob URLs on unmount
    return () => {
      counter.value++;
      Object.values(urlsRef.current).forEach(url => {
        if (url) URL.revokeObjectURL(url);
      });
    };
  }, [patientId, loadTimeline]);

  const handleViewPhoto = (photo) => {
    setSelectedPhoto(photo);
    setViewerOpen(true);
  };

  const handleDeletePhoto = async (photoId) => {
    if (!confirm('Are you sure you want to delete this photo? This action cannot be undone.')) {
      return;
    }

    try {
      await deletePhoto(photoId);
      
      // Revoke blob URL
      if (photoUrls[photoId]) {
        URL.revokeObjectURL(photoUrls[photoId]);
      }

      // Reload timeline
      await loadTimeline();
      
      if (onPhotoDeleted) {
        onPhotoDeleted(photoId);
      }
    } catch (error) {
      console.error('Failed to delete photo:', error);
      alert('Failed to delete photo. Please try again.');
    }
  };

  const handleDownloadPhoto = async (photoId) => {
    try {
      const url = await getPhotoFile(photoId, true);
      const a = document.createElement('a');
      a.href = url;
      a.download = `photo_${photoId}_export.jpg`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (error) {
      console.error('Failed to download photo:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        <span className="ml-3 text-gray-600">Loading photos...</span>
      </div>
    );
  }

  const stageEntries = Object.entries(groupedPhotos);

  if (stageEntries.length === 0) {
    return (
      <div className="text-center py-12">
        <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-3" />
        <h3 className="text-lg font-medium text-gray-900 mb-1">No Photos Yet</h3>
        <p className="text-gray-600">
          Upload photos to start tracking treatment progress
        </p>
      </div>
    );
  }

  // Sort stages by standard order
  const stageOrder = TREATMENT_STAGES.map(s => s.value);
  const sortedStageEntries = stageEntries.sort((a, b) => {
    const aIndex = stageOrder.indexOf(a[0]);
    const bIndex = stageOrder.indexOf(b[0]);
    return aIndex - bIndex;
  });

  return (
    <>
      <div className="space-y-8">
        {sortedStageEntries.map(([stage, stageData]) => {
          const stageInfo = TREATMENT_STAGES.find(s => s.value === stage);
          const stageLabel = stageInfo?.label || stage;
          const visitEntries = Object.entries(stageData.visits);
          
          // Sort visits by date (newest first)
          const sortedVisitEntries = visitEntries.sort((a, b) => 
            new Date(b[1].visitDate) - new Date(a[1].visitDate)
          );

          return (
            <div key={stage} className="border-l-4 border-blue-500 pl-4">
              {/* Stage Header */}
              <div className="mb-4">
                <h3 className="text-lg font-semibold text-gray-900">
                  {stageLabel}
                </h3>
                <p className="text-sm text-gray-600">
                  {stageData.totalPhotos} photo{stageData.totalPhotos !== 1 ? 's' : ''} across {visitEntries.length} session{visitEntries.length !== 1 ? 's' : ''}
                </p>
              </div>

              {/* Visit Groups */}
              <div className="space-y-6">
                {sortedVisitEntries.map(([visitId, visitData]) => (
                  <VisitGroup
                    key={visitId}
                    visitData={visitData}
                    photoUrls={photoUrls}
                    onView={handleViewPhoto}
                    onDelete={handleDeletePhoto}
                    onDownload={handleDownloadPhoto}
                  />
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Photo Viewer Modal */}
      {selectedPhoto && (
        <PhotoViewer
          isOpen={viewerOpen}
          onClose={() => {
            setViewerOpen(false);
            setSelectedPhoto(null);
          }}
          photo={selectedPhoto}
          photoUrl={photoUrls[selectedPhoto.id]}
        />
      )}
    </>
  );
};

/**
 * Transform timeline data to group by visit within each stage
 */
function transformToVisitGrouping(timelineData) {
  const grouped = {};
  
  Object.entries(timelineData).forEach(([stage, stageInfo]) => {
    grouped[stage] = {
      stage,
      totalPhotos: stageInfo.photos.length,
      visits: {}
    };
    
    // Group photos by visit
    stageInfo.photos.forEach(photo => {
      const visitId = photo.visit_id || 'no-visit';
      
      if (!grouped[stage].visits[visitId]) {
        grouped[stage].visits[visitId] = {
          visitId: photo.visit_id,
          visitDate: photo.visit?.visit_date || photo.captured_at,
          visitDiagnosis: photo.visit?.diagnosis || 'Photography Session',
          photos: [],
          missingViews: []
        };
      }
      
      grouped[stage].visits[visitId].photos.push(photo);
    });
    
    // Calculate missing views for each visit
    Object.values(grouped[stage].visits).forEach(visit => {
      const capturedViews = new Set(visit.photos.map(p => p.facial_view));
      visit.missingViews = REQUIRED_VIEWS.filter(view => !capturedViews.has(view));
      
      // Sort photos by facial view order
      visit.photos.sort((a, b) => {
        const aIndex = REQUIRED_VIEWS.indexOf(a.facial_view);
        const bIndex = REQUIRED_VIEWS.indexOf(b.facial_view);
        return aIndex - bIndex;
      });
    });
  });
  
  return grouped;
}

/**
 * Visit Group Component
 * Shows photos for a single visit/photography session
 */
const VisitGroup = ({ visitData, photoUrls, onView, onDelete, onDownload }) => {
  // Count DISTINCT views (not total photos) for completion
  const distinctViews = new Set(visitData.photos.map(p => p.facial_view));
  const completionPercent = Math.min(100, Math.round((distinctViews.size / REQUIRED_VIEWS.length) * 100));
  
  return (
    <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
      {/* Visit Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h4 className="font-medium text-gray-900">
            {visitData.visitDiagnosis}
          </h4>
          <p className="text-sm text-gray-600">
            {new Date(visitData.visitDate).toLocaleString('en-US', {
              month: 'short',
              day: 'numeric',
              year: 'numeric',
              hour: 'numeric',
              minute: '2-digit'
            })}
          </p>
        </div>
        <div className="text-right">
          <div className="text-sm font-medium text-gray-900">
            {distinctViews.size} / {REQUIRED_VIEWS.length} views
          </div>
          <div className="text-xs text-gray-600">
            {completionPercent}% complete
          </div>
          {visitData.photos.length > distinctViews.size && (
            <div className="text-xs text-yellow-600 mt-1">
              ({visitData.photos.length} total photos)
            </div>
          )}
        </div>
      </div>

      {/* Photos Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
        {/* Captured Photos */}
        {visitData.photos.map((photo) => (
          <PhotoCard
            key={photo.id}
            photo={photo}
            photoUrl={photoUrls[photo.id]}
            onView={() => onView(photo)}
            onDelete={() => onDelete(photo.id)}
            onDownload={() => onDownload(photo.id)}
          />
        ))}
        
        {/* Missing View Placeholders */}
        {visitData.missingViews.map((viewId) => (
          <MissingViewCard key={viewId} viewId={viewId} />
        ))}
      </div>
    </div>
  );
};

/**
 * Photo Card Component
 */
const PhotoCard = ({ photo, photoUrl, onView, onDelete, onDownload }) => {
  const viewInfo = getFacialView(photo.facial_view);
  const viewName = viewInfo?.name || photo.facial_view;
  const statusColor = getValidationStatusColor(photo.validation_status);
  const statusLabel = getValidationStatusLabel(photo.validation_status);
  
  // Get icon component
  const StatusIcon = {
    CheckCircle,
    AlertTriangle,
    XCircle,
    HelpCircle
  }[getValidationStatusIcon(photo.validation_status)] || HelpCircle;

  return (
    <div className="group relative bg-white rounded-lg border-2 border-gray-200 overflow-hidden hover:shadow-lg transition-all">
      {/* Photo */}
      <div className="aspect-square bg-gray-100 relative">
        {photoUrl ? (
          <img
            src={photoUrl}
            alt={viewName}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
          </div>
        )}

        {/* Overlay Actions */}
        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-60 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
          <div className="flex space-x-2">
            <button
              onClick={onView}
              className="p-2 bg-white rounded-full hover:bg-gray-100 transition-colors"
              title="View Photo"
            >
              <Eye className="w-4 h-4 text-gray-700" />
            </button>
            <button
              onClick={onDownload}
              className="p-2 bg-white rounded-full hover:bg-gray-100 transition-colors"
              title="Download Photo"
            >
              <Download className="w-4 h-4 text-gray-700" />
            </button>
            <button
              onClick={onDelete}
              className="p-2 bg-white rounded-full hover:bg-red-100 transition-colors"
              title="Delete Photo"
            >
              <Trash2 className="w-4 h-4 text-red-600" />
            </button>
          </div>
        </div>

        {/* Validation Status Badge */}
        <div className={`absolute top-1 right-1 px-2 py-1 rounded-full text-xs font-medium border flex items-center gap-1 ${statusColor}`}>
          <StatusIcon className="w-3 h-3" />
          <span className="hidden sm:inline">{statusLabel}</span>
        </div>
        
        {/* Override Badge */}
        {photo.clinician_override && (
          <div className="absolute top-1 left-1 z-10">
            <div 
              className="flex items-center gap-0.5 px-1.5 py-0.5 bg-amber-100 border border-amber-400 rounded text-xs font-medium text-amber-900 shadow-sm"
              title={`Clinician Override: ${photo.override_reason || 'Approved despite validation concerns'}\n\nDetected: ${photo.detected_view || 'Unknown'} (${photo.view_confidence || 'uncertain'})\nSelected: ${photo.facial_view}`}
            >
              <AlertTriangle size={10} />
              <span className="text-[10px]">Override</span>
            </div>
          </div>
        )}
      </div>

      {/* Info */}
      <div className="p-2">
        <h4 className="font-medium text-xs text-gray-900 truncate">
          {viewInfo?.icon || ''} {viewName.split(' — ')[0]}
        </h4>
        
        {/* Review Reason if present */}
        {photo.review_reason && (
          <div className="mt-1 p-1.5 bg-yellow-50 border border-yellow-200 rounded text-xs">
            <div className="font-medium text-yellow-800 mb-0.5">Review:</div>
            <div className="text-yellow-700 line-clamp-2">{photo.review_reason}</div>
          </div>
        )}
      </div>
    </div>
  );
};

/**
 * Missing View Card Component
 * Placeholder for uncaptured facial views
 */
const MissingViewCard = ({ viewId }) => {
  const viewInfo = getFacialView(viewId);
  const viewName = viewInfo?.name || viewId;

  return (
    <div className="bg-white rounded-lg border-2 border-dashed border-gray-300 overflow-hidden opacity-50">
      <div className="aspect-square bg-gray-50 flex items-center justify-center">
        <div className="text-center p-2">
          <div className="text-2xl mb-1">{viewInfo?.icon || '📷'}</div>
          <div className="text-xs text-gray-500 font-medium">Missing</div>
        </div>
      </div>
      <div className="p-2 bg-gray-50">
        <h4 className="text-xs text-gray-600 truncate text-center">
          {viewName.split(' — ')[0]}
        </h4>
      </div>
    </div>
  );
};

export default PhotoTimeline;
