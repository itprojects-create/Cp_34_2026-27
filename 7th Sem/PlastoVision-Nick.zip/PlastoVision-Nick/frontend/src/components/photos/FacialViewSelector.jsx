/**
 * Facial View Selector Component
 * 
 * Allows user to select from 8 standardized facial views.
 */

import React from 'react';
import { Check } from 'lucide-react';
import { FACIAL_VIEWS, getFacialView } from '../../services/validationService';

const FacialViewSelector = ({ selectedView, onSelect, disabled = false, capturedViews = [], profiles = {} }) => {
  const selectedViewData = getFacialView(selectedView);
  const selectedProfile = profiles[selectedView];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <h3 className="section-title">
          Select Facial View
        </h3>
        {selectedViewData && (
          <span className="text-sm text-on-surface-variant">
            {selectedViewData.name}
          </span>
        )}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {FACIAL_VIEWS.map((view) => (
          <button
            key={view.id}
            onClick={() => onSelect(view.id)}
            disabled={disabled}
            className={`
              relative p-4 rounded-2xl border-2 transition-all text-left
              ${
                selectedView === view.id
                  ? 'border-primary bg-primary-container/60 shadow-sm'
                  : 'border-outline-variant bg-surface-container-lowest hover:border-primary/40 hover:bg-primary-container/20'
              }
              ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
            `}
          >
            {capturedViews.includes(view.id) && <span className="text-success text-[11px] font-medium">Saved this visit ✓</span>}
            {/* Icon/Emoji */}
            <div className="text-3xl mb-2 text-center">
              {view.icon}
            </div>

            {/* View Name */}
            <div className="text-sm font-semibold text-on-surface text-center mb-1">
              {view.name.split(' — ')[0]}
            </div>
            <div className="text-xs text-on-surface-variant text-center">
              {view.name.split(' — ')[1] || ''}
            </div>

            {/* Selection Indicator */}
            {selectedView === view.id && (
              <div className="absolute top-2 right-2 w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                <Check className="w-3.5 h-3.5 text-white" />
              </div>
            )}
          </button>
        ))}
      </div>

      {/* Instructions */}
      {selectedViewData && (
        <div className="bg-tertiary-container/60 border border-tertiary/20 rounded-2xl p-4">
          <h4 className="text-sm font-semibold text-on-tertiary-container mb-2">
            Instructions for {selectedViewData.name}
          </h4>
          <ul className="space-y-1">
            {selectedViewData.instructions.map((instruction, idx) => (
              <li key={idx} className="text-sm text-on-tertiary-container flex items-start">
                <span className="mr-2">•</span>
                <span>{instruction}</span>
              </li>
            ))}
          </ul>

          {/* Angle Info */}
          <div className="mt-3 pt-3 border-t border-tertiary/20">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
              <div>
                <span className="font-medium text-on-tertiary-container">Yaw:</span>{' '}
                <span className="text-on-surface-variant">
                  {selectedProfile?.yaw == null ? 'Unverified' : `${selectedProfile.yaw}° (nominal)`}
                </span>
              </div>
              <div>
                <span className="font-medium text-on-tertiary-container">Pitch:</span>{' '}
                <span className="text-on-surface-variant">
                  {selectedProfile?.pitch == null ? 'Clinician defined' : `${selectedProfile.pitch}° (nominal)`}
                </span>
              </div>
              <div>
                <span className="font-medium text-on-tertiary-container">Roll:</span>{' '}
                <span className="text-on-surface-variant">
                  {selectedProfile?.roll == null ? 'Unverified' : `${selectedProfile.roll}° (nominal)`}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FacialViewSelector;
