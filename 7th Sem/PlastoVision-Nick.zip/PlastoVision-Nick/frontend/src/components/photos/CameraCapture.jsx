/**
 * Camera Capture Component with REAL-TIME CV-Guided Validation
 * 
 * This component implements GUIDED CLINICAL PHOTOGRAPHY:
 * - Continuous computer vision analysis of live camera feed
 * - Real-time pose estimation and validation
 * - RED/GREEN state management
 * - Stability checking before enabling capture
 * - Doctor guidance based on actual CV measurements
 * 
 * The capture button is DISABLED until the patient achieves the correct
 * standardized pose and maintains it for a stability duration.
 */

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Camera, X, Check, RotateCcw, AlertTriangle, AlertCircle } from 'lucide-react';
import Button from '../ui/Button';
import { getFacialView } from '../../services/validationService';

// Configuration constants
const LIVE_VALIDATION_FPS = 8; // Validate 8 frames per second
const VALIDATION_FRAME_WIDTH = 480; // Low resolution for performance
const STABILITY_DURATION_MS = 800; // Must hold correct pose for 800ms
const FINAL_CAPTURE_QUALITY = 0.95; // High quality for final image

const CameraCapture = ({ 
  selectedView, 
  onCapture, 
  onClose 
}) => {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const validationIntervalRef = useRef(null);
  const stabilityTimerRef = useRef(null);
  const lastValidationRef = useRef(0);
  const processingRef = useRef(false);
  const abortControllerRef = useRef(null);
  
  // State management
  const [isReady, setIsReady] = useState(false);
  const [error, setError] = useState(null);
  const [capturedImage, setCapturedImage] = useState(null);
  
  // Validation state
  const [validationState, setValidationState] = useState('initializing'); // initializing, no_face, analyzing, incorrect_pose, ready, captured, error
  const [validationResult, setValidationResult] = useState(null);
  const [guidance, setGuidance] = useState('Starting camera...');
  const [isValid, setIsValid] = useState(false);
  const [stabilityProgress, setStabilityProgress] = useState(0);
  const [captureEnabled, setCaptureEnabled] = useState(false);
  
  // Debug state (optional - can be hidden in production)
  const [debugInfo, setDebugInfo] = useState(null);

  // Get view configuration
  const viewConfig = getFacialView(selectedView);

  // Start camera
  const startCamera = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: 'user'
        },
        audio: false
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
        setIsReady(true);
        setError(null);
        setValidationState('analyzing');
        setGuidance('Position your face inside the guide');
      }
    } catch (err) {
      console.error('Camera access error:', err);
      setError('Cannot access camera. Please check permissions.');
      setValidationState('error');
    }
  }, []);

  // Stop camera
  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (validationIntervalRef.current) {
      clearInterval(validationIntervalRef.current);
    }
    if (stabilityTimerRef.current) {
      clearTimeout(stabilityTimerRef.current);
    }
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    setIsReady(false);
  }, []);

  // Capture frame from video as base64 for validation
  const captureValidationFrame = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return null;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');

    // Set small canvas size for validation (performance)
    const aspectRatio = video.videoHeight / video.videoWidth;
    canvas.width = VALIDATION_FRAME_WIDTH;
    canvas.height = VALIDATION_FRAME_WIDTH * aspectRatio;

    // Draw current video frame to canvas (unmirrored for CV)
    context.save();
    context.scale(-1, 1); // Unmirror for CV processing
    context.drawImage(video, -canvas.width, 0, canvas.width, canvas.height);
    context.restore();

    // Convert to base64 JPEG
    return canvas.toDataURL('image/jpeg', 0.7);
  }, []);

  // Validate frame with Python CV service
  const validateFrame = useCallback(async (frameData) => {
    // Don't validate if already processing
    if (processingRef.current) return;
    
    processingRef.current = true;

    try {
      // Create abort controller for this request
      abortControllerRef.current = new AbortController();

      const response = await fetch('http://localhost:3001/api/patient-photos/validate-live', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          frame: frameData,
          facial_view: selectedView
        }),
        signal: abortControllerRef.current.signal
      });

      const result = await response.json();
      
      // Update validation state
      setValidationResult(result);
      setDebugInfo(result);
      
      // Determine if pose is valid
      const poseValid = result.valid && result.state === 'ready';
      setIsValid(poseValid);
      
      // Update guidance message
      if (result.guidance) {
        setGuidance(result.guidance);
      } else if (result.errors && result.errors.length > 0) {
        setGuidance(result.errors[0]);
      } else if (poseValid) {
        setGuidance('Position correct — hold still');
      } else {
        setGuidance('Adjust position');
      }
      
      // Update state
      setValidationState(result.state || 'analyzing');
      
      // Handle stability checking
      if (poseValid) {
        // Start or continue stability timer
        if (!stabilityTimerRef.current) {
          const startTime = Date.now();
          stabilityTimerRef.current = setInterval(() => {
            const elapsed = Date.now() - startTime;
            const progress = Math.min(100, (elapsed / STABILITY_DURATION_MS) * 100);
            setStabilityProgress(progress);
            
            if (elapsed >= STABILITY_DURATION_MS) {
              clearInterval(stabilityTimerRef.current);
              stabilityTimerRef.current = null;
              setCaptureEnabled(true);
              setGuidance('Ready to capture!');
            }
          }, 50);
        }
      } else {
        // Reset stability if pose becomes invalid
        if (stabilityTimerRef.current) {
          clearInterval(stabilityTimerRef.current);
          stabilityTimerRef.current = null;
        }
        setStabilityProgress(0);
        setCaptureEnabled(false);
      }
      
    } catch (error) {
      if (error.name !== 'AbortError') {
        console.error('Validation error:', error);
        setValidationState('error');
        setGuidance('Validation service unavailable');
      }
    } finally {
      processingRef.current = false;
    }
  }, [selectedView]);

  // Live validation loop
  useEffect(() => {
    if (!isReady || capturedImage) return;

    const validationInterval = 1000 / LIVE_VALIDATION_FPS;
    
    validationIntervalRef.current = setInterval(() => {
      const now = Date.now();
      
      // Throttle validation
      if (now - lastValidationRef.current < validationInterval) {
        return;
      }
      
      lastValidationRef.current = now;
      
      // Capture and validate frame
      const frameData = captureValidationFrame();
      if (frameData) {
        validateFrame(frameData);
      }
    }, validationInterval);

    return () => {
      if (validationIntervalRef.current) {
        clearInterval(validationIntervalRef.current);
      }
    };
  }, [isReady, capturedImage, captureValidationFrame, validateFrame]);

  // Initialize camera on mount
  useEffect(() => {
    startCamera();
    return () => stopCamera();
  }, [startCamera, stopCamera]);

  // Capture high-resolution photo
  const handleCapture = useCallback(async () => {
    if (!videoRef.current || !canvasRef.current || !captureEnabled) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');

    // Set canvas to full video resolution
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    // Draw current video frame (unmirrored)
    context.save();
    context.scale(-1, 1); // Unmirror
    context.drawImage(video, -canvas.width, 0, canvas.width, canvas.height);
    context.restore();

    // Stop live validation
    if (validationIntervalRef.current) {
      clearInterval(validationIntervalRef.current);
    }

    setValidationState('captured');
    setGuidance('Validating captured photo...');

    // Convert to blob
    canvas.toBlob(async (blob) => {
      if (blob) {
        // Create preview URL
        const url = URL.createObjectURL(blob);
        
        // Create File object from blob
        const file = new File([blob], `capture_${Date.now()}.jpg`, {
          type: 'image/jpeg'
        });
        
        // Store captured image
        setCapturedImage({ url, file });
        
        // Final validation will happen when user confirms
      }
    }, 'image/jpeg', FINAL_CAPTURE_QUALITY);
  }, [captureEnabled]);

  // Retake photo
  const handleRetake = () => {
    if (capturedImage?.url) {
      URL.revokeObjectURL(capturedImage.url);
    }
    setCapturedImage(null);
    setCaptureEnabled(false);
    setStabilityProgress(0);
    setValidationState('analyzing');
    setGuidance('Position your face inside the guide');
    
    // Restart live validation
    lastValidationRef.current = 0;
  };

  // Confirm and use captured photo
  const handleConfirm = () => {
    if (capturedImage?.file) {
      onCapture(capturedImage.file);
    }
  };

  // Handle close
  const handleClose = () => {
    if (capturedImage?.url) {
      URL.revokeObjectURL(capturedImage.url);
    }
    stopCamera();
    onClose();
  };

  // Determine RED/GREEN state
  const isGreenState = validationState === 'ready' && captureEnabled;
  const stateColor = isGreenState ? 'green' : 'red';
  const stateIcon = isGreenState ? Check : AlertCircle;
  const StateIcon = stateIcon;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-95 z-50 flex items-center justify-center">
      <div className="relative w-full h-full max-w-7xl max-h-screen p-4 flex flex-col">
        {/* Header */}
        <div className="flex justify-between items-center mb-4">
          <div>
            <h2 className="text-2xl font-bold text-white">
              Guided Camera Capture
            </h2>
            <p className="text-gray-300">
              {viewConfig?.name || 'Select a view'}
            </p>
          </div>
          <button
            onClick={handleClose}
            className="text-white hover:text-gray-300 transition-colors"
          >
            <X className="w-8 h-8" />
          </button>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex gap-4 overflow-hidden">
          {/* Camera/Preview Area */}
          <div className="flex-1 bg-gray-900 rounded-lg overflow-hidden relative">
            {error && (
              <div className="absolute inset-0 flex items-center justify-center bg-red-900 bg-opacity-50 z-10">
                <div className="text-center text-white px-4">
                  <AlertTriangle className="w-16 h-16 mx-auto mb-4" />
                  <p className="text-lg font-semibold mb-2">Camera Error</p>
                  <p className="text-sm">{error}</p>
                  <Button
                    onClick={startCamera}
                    className="mt-4"
                    variant="outline"
                  >
                    Retry
                  </Button>
                </div>
              </div>
            )}

            {!capturedImage ? (
              <>
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  className="w-full h-full object-contain"
                  style={{ transform: 'scaleX(-1)' }} // Mirror for user comfort
                />
                
                {/* Live Validation Status Overlay */}
                {isReady && (
                  <div className={`absolute top-4 left-4 right-4 rounded-lg p-4 ${
                    isGreenState 
                      ? 'bg-green-600 bg-opacity-90' 
                      : 'bg-red-600 bg-opacity-90'
                  }`}>
                    <div className="flex items-center gap-3 text-white">
                      <StateIcon className="w-8 h-8 flex-shrink-0" />
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <div className={`w-3 h-3 rounded-full ${
                            isGreenState ? 'bg-green-300 animate-pulse' : 'bg-red-300'
                          }`}></div>
                          <span className="font-bold text-lg">
                            {isGreenState ? 'READY' : 'ADJUST POSITION'}
                          </span>
                        </div>
                        <p className="text-sm text-white">
                          {guidance}
                        </p>
                        
                        {/* Stability Progress */}
                        {stabilityProgress > 0 && !captureEnabled && (
                          <div className="mt-2">
                            <div className="w-full bg-white bg-opacity-30 rounded-full h-2">
                              <div 
                                className="bg-white h-2 rounded-full transition-all duration-100"
                                style={{ width: `${stabilityProgress}%` }}
                              ></div>
                            </div>
                            <p className="text-xs mt-1">Hold position...</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {/* Face Guide Overlay */}
                {isReady && (
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div 
                      className={`border-4 rounded-lg transition-all duration-300 ${
                        isGreenState 
                          ? 'border-green-500 border-opacity-80' 
                          : 'border-white border-opacity-40'
                      }`}
                      style={{ 
                        width: '60%', 
                        height: '75%',
                        maxWidth: '500px',
                        maxHeight: '700px'
                      }}
                    >
                      {/* Corner markers */}
                      <div className={`absolute top-0 left-0 w-12 h-12 border-t-4 border-l-4 ${
                        isGreenState ? 'border-green-400' : 'border-white'
                      }`}></div>
                      <div className={`absolute top-0 right-0 w-12 h-12 border-t-4 border-r-4 ${
                        isGreenState ? 'border-green-400' : 'border-white'
                      }`}></div>
                      <div className={`absolute bottom-0 left-0 w-12 h-12 border-b-4 border-l-4 ${
                        isGreenState ? 'border-green-400' : 'border-white'
                      }`}></div>
                      <div className={`absolute bottom-0 right-0 w-12 h-12 border-b-4 border-r-4 ${
                        isGreenState ? 'border-green-400' : 'border-white'
                      }`}></div>
                    </div>
                  </div>
                )}
              </>
            ) : (
              <img
                src={capturedImage.url}
                alt="Captured"
                className="w-full h-full object-contain"
              />
            )}

            <canvas ref={canvasRef} style={{ display: 'none' }} />
          </div>

          {/* Side Panel - Instructions and Debug */}
          <div className="w-80 bg-gray-800 rounded-lg p-6 text-white overflow-y-auto space-y-4">
            <h3 className="text-xl font-bold">Live Guidance</h3>
            
            {viewConfig && (
              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold text-green-400 mb-1">
                    Target: {viewConfig.name}
                  </h4>
                  <p className="text-xs text-gray-300">
                    {viewConfig.description}
                  </p>
                </div>

                <div className="border-t border-gray-700 pt-3">
                  <h4 className="font-semibold mb-2 text-blue-400 text-sm">
                    Position Requirements
                  </h4>
                  <ul className="text-xs text-gray-300 space-y-1">
                    {viewConfig.instructions.map((tip, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-blue-400 mt-0.5">•</span>
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Debug Info */}
                {debugInfo && (
                  <div className="border-t border-gray-700 pt-3 text-xs">
                    <h4 className="font-semibold mb-2 text-yellow-400">
                      Live Analysis
                    </h4>
                    <div className="space-y-1 font-mono text-gray-400">
                      <div>Face: {debugInfo.face_detected ? '✓' : '✗'}</div>
                      <div>Yaw: {debugInfo.yaw !== null && debugInfo.yaw !== undefined ? `${debugInfo.yaw.toFixed(1)}°` : '—'} {debugInfo.yaw_valid ? '✓' : '✗'}</div>
                      <div>Pitch: {debugInfo.pitch !== null && debugInfo.pitch !== undefined ? `${debugInfo.pitch.toFixed(1)}°` : '—'} {debugInfo.pitch_valid ? '✓' : '✗'}</div>
                      <div>Roll: {debugInfo.roll !== null && debugInfo.roll !== undefined ? `${debugInfo.roll.toFixed(1)}°` : '—'} {debugInfo.roll_valid ? '✓' : '✗'}</div>
                      <div>Framing: {debugInfo.framing_ok ? '✓' : '✗'}</div>
                      <div>Quality: {debugInfo.quality_ok ? '✓' : '✗'}</div>
                      <div>Confidence: {debugInfo.confidence !== null && debugInfo.confidence !== undefined ? `${(debugInfo.confidence * 100).toFixed(0)}%` : '—'}</div>
                      <div className="text-gray-500 text-[10px] mt-2">
                        Processing: {debugInfo.processing_time_ms || 0}ms
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Controls */}
        <div className="mt-4 flex justify-center gap-4">
          {!capturedImage ? (
            <>
              <Button
                onClick={handleClose}
                variant="outline"
                className="bg-gray-700 text-white border-gray-600 hover:bg-gray-600"
              >
                Cancel
              </Button>
              <Button
                onClick={handleCapture}
                disabled={!captureEnabled}
                className={`px-8 ${
                  captureEnabled
                    ? 'bg-green-600 hover:bg-green-700 text-white'
                    : 'bg-gray-600 text-gray-400 cursor-not-allowed'
                }`}
              >
                <Camera className="w-5 h-5 mr-2" />
                {captureEnabled ? 'Capture Photo' : 'Position Required'}
              </Button>
            </>
          ) : (
            <>
              <Button
                onClick={handleRetake}
                variant="outline"
                className="bg-gray-700 text-white border-gray-600 hover:bg-gray-600"
              >
                <RotateCcw className="w-5 h-5 mr-2" />
                Retake
              </Button>
              <Button
                onClick={handleConfirm}
                className="bg-green-600 hover:bg-green-700 text-white px-8"
              >
                <Check className="w-5 h-5 mr-2" />
                Use This Photo
              </Button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default CameraCapture;
