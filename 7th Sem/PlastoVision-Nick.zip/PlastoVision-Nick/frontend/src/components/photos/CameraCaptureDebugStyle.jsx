import { useEffect, useRef, useState, useId } from 'react';
import photoApi from '../../lib/photoApi';
import { createCaptureTracker, createAutoCaptureController, createGuidanceFilter, isAutomaticFrameReady } from '../../lib/captureState';
import { getFacialView } from '../../services/validationService';
import { validatePhoto } from '../../services/photoService';
import { captureGuideGeometry, trackedFaceGuide } from '../../lib/captureGuide';

export default function CameraCaptureDebugStyle({ selectedView, onSave, onClose, setup = {}, config }) {
  const video = useRef(null), stream = useRef(null), latest = useRef(null);
  const busy = useRef(false), generation = useRef(0), capture = useRef(null), automation = useRef(null);
  const reviewTracker = useRef(null);
  const autoEnabled = useRef(true);
  const [devices, setDevices] = useState([]), [device, setDevice] = useState('');
  const [state, setState] = useState('CAMERA_INITIALIZING'), [data, setData] = useState(null);
  const [error, setError] = useState(''), [saved, setSaved] = useState(null), [pending, setPending] = useState(null);
  const [auto, setAuto] = useState(true), [mirrored, setMirrored] = useState(false);
  const [progress, setProgress] = useState(0), [guidance, setGuidance] = useState('Starting camera…');
  const [reviewReason, setReviewReason] = useState('');
  const setupKey = JSON.stringify(setup), policy = config?.policy;
  const [actualCamera, setActualCamera] = useState(null);
  const [videoSize, setVideoSize] = useState({ width: 1920, height: 1080 });
  const arrowId = useId();
  const view = getFacialView(selectedView);
  const capturedUrl = saved?.url;
  useEffect(() => () => { if (capturedUrl) URL.revokeObjectURL(capturedUrl); }, [capturedUrl]);
  useEffect(() => {
    const lifetime = generation;
    return () => { lifetime.current++; };
  }, []);

  useEffect(() => {
    if (!policy || saved || pending) return;
    const epoch = ++generation.current;
    let active = true, timer, controller, watchdog, frameId = 0, lastGoodAt = null;
    const tracker = createCaptureTracker({ duration: policy.stability_ms, maxGap: policy.max_gap_ms,
      angleMotion: policy.angle_motion_deg, positionMotion: policy.position_motion });
    const machine = createAutoCaptureController(policy);
    reviewTracker.current = tracker;
    automation.current = machine;
    const filter = createGuidanceFilter();
    latest.current = null; setState('CAMERA_INITIALIZING'); setError(''); setData(null);
    const connected = () => stream.current?.getVideoTracks()[0]?.readyState === 'live' && !video.current?.paused;
    function invalidate(message) {
      tracker.reset(); machine.invalidate(); latest.current = null; setProgress(0); setData(null);
      setState('UNVERIFIED'); setGuidance(message);
    }
    async function analyze() {
      const started = performance.now();
      try {
        if (!active || busy.current || saved || pending) return;
        if (!connected() || !video.current?.videoWidth || document.hidden) { invalidate('Camera paused or disconnected'); return; }
        const canvas = document.createElement('canvas');
        canvas.width = Math.min(policy.analysis_width, video.current.videoWidth);
        canvas.height = Math.round(canvas.width*video.current.videoHeight/video.current.videoWidth);
        canvas.getContext('2d').drawImage(video.current, 0, 0, canvas.width, canvas.height);
        const id = ++frameId;
        const captureSetup = { ...JSON.parse(setupKey), capture_session_id: `${epoch}-${sessionId}`,
          actual_camera: stream.current.getVideoTracks()[0].getSettings() };
        controller = new AbortController();
        const { data: result } = await photoApi.post('/api/patient-photos/validate-live', {
          frame: canvas.toDataURL('image/jpeg', .85), facial_view: selectedView,
          setup: captureSetup, frame_id: id, timestamp: Date.now()
        }, { signal: controller.signal, timeout: 3000 });
        if (!active || busy.current || generation.current !== epoch) return;
        const now = performance.now();
        if (result.frame_id !== id || now-started > policy.max_analysis_age_ms || result.state === 'BUSY') {
          invalidate('Feedback delayed — waiting for fresh measurements'); return;
        }
        lastGoodAt = started; setError(''); setData(result);
        setGuidance(filter(result, now));
        const reviewStability = tracker.update(result, started, id);
        latest.current = { result, stable: reviewStability.stable, at: started, setup: captureSetup };
        const next = machine.update(result, { now, measuredAt: started, frameId: id, connected: connected(), enabled: autoEnabled.current });
        setProgress(result.auto_capture_eligible ? next.progress : reviewStability.duration/policy.stability_ms);
        setState(result.auto_capture_eligible ? next.state : reviewStability.stable ? 'UNVERIFIED' : result.reviewable ? 'STABILIZING' : next.state);
        if (next.trigger) capture.current?.(true);
      } catch (failure) {
        if (!active) return;
        invalidate('Live analysis unavailable');
        setError(failure.response?.data?.error || 'Check the local backend and CV service');
      } finally {
        // Exactly one outstanding request. Fast analysis approaches 10 Hz; slow analysis applies backpressure.
        if (active) timer = setTimeout(analyze, Math.max(0, policy.analysis_interval_ms-(performance.now()-started)));
      }
    }
    const sessionId = crypto.randomUUID();
    async function start() {
      try {
        const profile = config.camera_profiles?.[JSON.parse(setupKey).camera_profile_id];
        const selectedDevice = device || profile?.device_id;
        const media = await navigator.mediaDevices.getUserMedia({ audio: false, video: {
          ...(selectedDevice ? { deviceId: { exact: selectedDevice } } : { facingMode: 'user' }),
          width: { ideal: profile?.image_size?.[0] || 1920 }, height: { ideal: profile?.image_size?.[1] || 1080 }
        } });
        if (!active) { media.getTracks().forEach(track => track.stop()); return; }
        stream.current = media; video.current.srcObject = media;
        await video.current.play();
        if (!active) return;
        setActualCamera(media.getVideoTracks()[0].getSettings());
        setDevices((await navigator.mediaDevices.enumerateDevices()).filter(d => d.kind === 'videoinput'));
        media.getVideoTracks()[0].addEventListener('ended', () => { if (active) invalidate('Camera disconnected'); });
        setState('SEARCHING_FOR_FACE'); analyze();
        watchdog = setInterval(() => {
          if (!busy.current && !saved && !pending && (!connected() || (lastGoodAt !== null && performance.now()-lastGoodAt > policy.max_analysis_age_ms)))
            invalidate('Waiting for fresh camera measurements');
        }, 100);
      } catch (failure) { if (active) { setState('ERROR'); setError(`Camera unavailable: ${failure.message}`); } }
    }
    if (!saved && !pending) start();
    return () => {
      active = false; generation.current = epoch+1; clearTimeout(timer); clearInterval(watchdog); controller?.abort();
      stream.current?.getTracks().forEach(track => track.stop()); stream.current = null; latest.current = null;
    };
  }, [selectedView, device, setupKey, config, policy, saved, pending]);

  async function persist(record, epoch) {
    setState('SAVING');
    try {
      const result = await onSave(record.file, record.metadata);
      if (generation.current !== epoch) return;
      setPending(null); setSaved({ ...record, photo: result.photo, url: URL.createObjectURL(record.file) });
      setState('CAPTURE_COMPLETE'); setGuidance(result.photo.validation_status === 'pending' ? 'Photograph saved locally — pending clinical review' : 'Photograph saved locally');
    } catch (failure) {
      if (generation.current !== epoch) return;
      if (failure.response?.status === 422) {
        automation.current?.reset(); reviewTracker.current?.reset(); latest.current = null;
        setState('RETAKE_REQUIRED'); setError(failure.response.data.error || 'Final server checks failed; retake required');
      } else {
        // Keep the exact bytes, context and UUID for a safe retry after ambiguous network failures.
        const message = failure.response?.data?.message || failure.response?.data?.error || 'Save failed. Retry the same image or retake.';
        setPending(record); setState('ERROR'); setProgress(0); setGuidance('Image captured — saving failed; retry the same image');
        setError(message);
      }
    }
  }
  capture.current = async (automatic = false) => {
    const current = latest.current, epoch = generation.current;
    if (!policy || busy.current || saved || pending || !current?.stable || document.hidden ||
        performance.now()-current.at > policy.max_analysis_age_ms || stream.current?.getVideoTracks()[0]?.readyState !== 'live') return;
    if (automatic && !isAutomaticFrameReady(current.result)) { automation.current?.reset(); return; }
    if (!automatic && !isAutomaticFrameReady(current.result) && reviewReason.trim().length < 15) return;
    busy.current = true; setError(''); setState('CAPTURING');
    try {
      const canvas = document.createElement('canvas');
      canvas.width = video.current.videoWidth; canvas.height = video.current.videoHeight;
      canvas.getContext('2d').drawImage(video.current, 0, 0);
      const capturedAt = new Date().toISOString();
      let blob, imageSource = 'native_video_frame';
      const stillGeometryVerified = !setup.camera_profile_id || config.camera_profiles?.[setup.camera_profile_id]?.still_capture_verified === true;
      if (typeof window.ImageCapture === 'function' && stillGeometryVerified) {
        try {
          const still = await new window.ImageCapture(stream.current.getVideoTracks()[0]).takePhoto();
          if (['image/jpeg','image/png'].includes(still.type)) { blob = still; imageSource = 'device_still'; }
        } catch { /* Device/browser lacks supported still capture; use native video resolution. */ }
      }
      blob ||= await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg', .97));
      if (!blob || epoch !== generation.current) return;
      const file = new File([blob], blob.type === 'image/png' ? 'capture.png' : 'capture.jpg', { type: blob.type });
      setState('FINAL_VALIDATION');
      const validation = await validatePhoto(file, selectedView, current.setup);
      if (epoch !== generation.current) return;
      setData(validation);
      if (automatic ? !isAutomaticFrameReady(validation) : !isAutomaticFrameReady(validation) && !validation.reviewable) {
        automation.current?.reset(); reviewTracker.current?.reset(); latest.current = null;
        setState('RETAKE_REQUIRED'); setError(validation.guidance || 'Final image failed verification; adjust and retake'); return;
      }
      await persist({ file, metadata: { setup: { ...current.setup, captured_at: capturedAt, image_source: imageSource,
        capture_mode: validation.experimental_capture_ready ? automatic ? 'experimental_automatic' : 'experimental_manual' : automatic ? 'automatic' : validation.valid ? 'manual_verified' : 'clinician_confirmed' },
        captureId: crypto.randomUUID(), captureMethod: 'camera', automatic,
        reviewReason: isAutomaticFrameReady(validation) ? '' : reviewReason.trim() } }, epoch);
    } catch (failure) {
      if (epoch === generation.current) { automation.current?.reset(); reviewTracker.current?.reset(); latest.current = null; setState('ERROR'); setError(failure.message); }
    } finally { busy.current = false; }
  };
  const framing = config?.framing?.[selectedView === 'basal' ? 'basal' : setup.framing_protocol || 'full_face'];
  const guide = data?.guide ? { ...data.guide, height: data.framing?.reference_face_height_ratio ?? data.guide.height }
    : framing && { center_x: framing.center_x, center_y: framing.center_y, height: (framing.min_height+framing.max_height)/2 };
  const target = captureGuideGeometry({ guide, framing, view: selectedView, protocol: setup.framing_protocol,
    width: videoSize.width, height: videoSize.height, mirrored });
  const tracked = trackedFaceGuide({ tracking: data?.tracking, bbox: data?.face_bbox, center: data?.framing?.center, target, mirrored, aligned: data?.spatial_alignment_ok === true });
  const ready = ['READY','AUTO_CAPTURE_COUNTDOWN'].includes(state);
  const green = ready && data?.valid === true;
  const red = ['ERROR','RETAKE_REQUIRED','ADJUST_POSITION','SEARCHING_FOR_FACE','CHECKING_QUALITY'].includes(state);
  const statusMessage = ready ? data?.valid ? 'Correct position — hold still' : 'Experimental checks passed — hold still for automatic capture'
    : state === 'STABILIZING' ? data?.gaze_required ? 'Hold still and keep looking at the camera lens' : 'Hold still while alignment is checked' : guidance;
  const statusColor = green ? 'text-green-300 border-green-500/40 bg-green-950/70' : red ? 'text-red-200 border-red-500/40 bg-red-950/70'
    : state === 'UNVERIFIED' ? 'text-slate-200 border-slate-500/40 bg-slate-800' : 'text-amber-200 border-amber-500/40 bg-amber-950/70';
  return <div className="fixed inset-0 z-[100] bg-slate-950 text-white overflow-auto p-4">
    <div className="max-w-5xl mx-auto space-y-3">
      <div className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 sm:gap-6">
        <h2 className="text-base sm:text-xl font-semibold">{view?.name}</h2>
        <div className={`min-w-0 rounded-lg border px-3 py-2 text-center ${statusColor}`} role="status" aria-live="polite">
          <div className="text-[10px] sm:text-xs font-semibold tracking-wide">{state.replaceAll('_',' ')}</div>
          <p className="text-sm sm:text-base font-medium">{statusMessage}</p>
          <div className="mx-auto mt-2 h-1.5 max-w-xs overflow-hidden rounded-full bg-white/15" role="progressbar"
            aria-label="Stability progress" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(progress*100)}>
            <div className={`h-full rounded-full transition-[width] duration-100 ${green ? 'bg-green-400' : 'bg-amber-400'}`} style={{ width: `${progress*100}%` }} />
          </div>
        </div>
        <button disabled={busy.current} onClick={onClose}>Close</button>
      </div>
      {error && <p role="alert" className="bg-red-900 p-3">{error}</p>}
      <div className="relative mx-auto overflow-hidden rounded-lg">
        <video ref={video} autoPlay playsInline muted onLoadedMetadata={event => setVideoSize({ width: event.currentTarget.videoWidth, height: event.currentTarget.videoHeight })}
          className={`block w-full h-auto ${saved || pending ? 'hidden' : ''}`} style={{ transform: mirrored ? 'scaleX(-1)' : undefined }} />
        {saved && <img src={saved.url} alt="Saved original photograph" className="max-h-[60vh] w-full object-contain" />}
        {!saved && !pending && <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 100 100" preserveAspectRatio="none" aria-label="Positioning guide">
          <defs><marker id={arrowId} viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 Z" fill="#fbbf24" /></marker></defs>
          {tracked && <g stroke={green ? '#22c55e' : '#fbbf24'} fill="none">
            {tracked.path ? <path d={tracked.path} strokeWidth="2.5" strokeDasharray="9 7" vectorEffect="non-scaling-stroke" />
              : <ellipse {...tracked.ellipse} strokeWidth="2.5" strokeDasharray="9 7" vectorEffect="non-scaling-stroke" />}
            {tracked.arrow && <line {...tracked.arrow} strokeWidth="2.5" markerEnd={`url(#${arrowId})`} vectorEffect="non-scaling-stroke" />}
            {tracked.eyes.map(([cx,cy],i)=><ellipse key={`eye-${i}`} cx={cx} cy={cy} rx={.35*videoSize.height/videoSize.width} ry=".35" fill="#7dd3fc" stroke="none" />)}
            {tracked.irises.map(([cx,cy],i)=><ellipse key={`iris-${i}`} cx={cx} cy={cy} rx={.6*videoSize.height/videoSize.width} ry=".6" stroke={data?.gaze_ok ? '#86efac' : '#fbbf24'} strokeWidth="1.5" vectorEffect="non-scaling-stroke" />)}
          </g>}
          {target && <path d={`M${target.cx-1.2} ${target.cy} H${target.cx+1.2} M${target.cx} ${target.cy-2} V${target.cy+2}`} fill="none" stroke="white" strokeOpacity=".7" strokeWidth="1.5" vectorEffect="non-scaling-stroke" />}
          {selectedView === 'basal' && <path d="M35 50 Q50 70 65 50 M50 45 L50 65" fill="none" stroke="#fbbf24" strokeWidth=".5" />}
        </svg>}
        {!saved && !pending && target && <div className="absolute inset-x-0 top-3 flex justify-center pointer-events-none">
          <span className="rounded-full bg-slate-950/75 px-4 py-1.5 text-sm text-white">{!tracked ? 'Bring your face into view to start tracking' : tracked.arrow ? 'Follow the arrow toward the crosshair' : data?.gaze_required ? 'Keep your eyes on the camera lens' : 'Keep your face centered and follow the guidance'}</span>
        </div>}
      </div>
      <p className="text-sm">{selectedView === 'basal' ? 'Clinician: verify nasal base, both nostrils and columella; align tip to upper eyelid reference where visible.' : setup.framing_protocol === 'nasal_focused' ? 'Place eyebrows near the upper boundary; center the nose and include the appropriate nasal/lip boundary.' : 'Include the head and relevant surrounding anatomy; center ears vertically. Confirm scalp and neck boundaries.'} Guides are relative image scale. Originals are unmirrored.</p>
      {!saved && !pending && <>
        <div className="flex flex-wrap gap-4 items-center">
          <label>Camera <select disabled={busy.current} className="text-black" value={device} onChange={e => setDevice(e.target.value)}><option value="">Default</option>{devices.map(d => <option key={d.deviceId} value={d.deviceId}>{d.label || 'Camera'}</option>)}</select></label>
          <label><input type="checkbox" checked={mirrored} onChange={e => setMirrored(e.target.checked)} /> Mirror preview</label>
          <label><input type="checkbox" checked={auto} onChange={e => { autoEnabled.current = e.target.checked; setAuto(e.target.checked); automation.current?.invalidate(); }} /> Automatic capture after live checks</label>
        </div>
        {(!data?.auto_capture_eligible || data?.automation_mode === 'experimental') && <p className="text-amber-300">{data?.automation_reason || 'Automatic validation unverified for this camera/view'}</p>}
        <label className="block">Clinician confirmation for manual fallback: verify side/view, expression, anatomical boundaries, camera height and lighting. Record findings/limitations.
          <textarea maxLength={2000} className="block w-full border p-2 text-black bg-white" aria-label="Clinician capture confirmation" value={reviewReason} onChange={e => setReviewReason(e.target.value)} />
        </label>
        <button className="bg-blue-700 p-3 rounded disabled:opacity-40" disabled={busy.current || !latest.current?.stable || (!isAutomaticFrameReady(data) && reviewReason.trim().length < 15)} onClick={() => capture.current(false)}>{isAutomaticFrameReady(data) ? 'Capture and save' : 'Capture clinician-confirmed image'}</button>
      </>}
      {pending && <div className="flex gap-4"><button disabled={busy.current} onClick={async () => {
        busy.current = true; const epoch = generation.current;
        try { await persist(pending, epoch); } finally { busy.current = false; }
      }}>Retry saving the same image</button><button disabled={busy.current} onClick={() => { setPending(null); setProgress(0); setReviewReason(''); }}>Retake</button></div>}
      {saved && <div className="flex gap-4"><span>Saved ✓</span><button onClick={() => { setSaved(null); setProgress(0); setReviewReason(''); }}>Retake this view</button><button className="bg-blue-700 p-3 rounded" onClick={onClose}>Next view</button></div>}
      <details><summary>Camera setup and live measurements</summary><p>Focus, exposure, ISO, aperture, focal length and flash are not automatically controlled. Use fixed physical settings where supported.</p><pre className="text-xs whitespace-pre-wrap">{JSON.stringify({ actual_camera: actualCamera, analysis: data }, null, 2)}</pre></details>
    </div>
  </div>;
}
