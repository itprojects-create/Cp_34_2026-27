/**
 * Photo Viewer Component
 * 
 * Lightbox modal for viewing photo with metadata.
 */

import React from 'react';
import { X, Download, Calendar, User } from 'lucide-react';
import Modal from '../ui/Modal';
import { getPhotoFile } from '../../services/photoService';
import { getFacialView, TREATMENT_STAGES, formatAngle } from '../../services/validationService';

const PhotoViewer = ({ isOpen, onClose, photo, photoUrl }) => {
  if (!photo) return null;

  const viewInfo = getFacialView(photo.facial_view);
  const stageInfo = TREATMENT_STAGES.find(s => s.value === photo.treatment_stage);
  const validationResult = photo.validation_metadata;

  const handleDownload = async () => {
    try {
      const url = await getPhotoFile(photo.id, true);
      const a = document.createElement('a'); a.href = url; a.download = `${photo.facial_view}_export.jpg`;
      a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch { alert('Export failed; check the backend and local storage'); }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="large">
      <div className="relative">
        {/* Header */}
        <div className="absolute top-0 left-0 right-0 z-10 bg-gradient-to-b from-black to-transparent p-6">
          <div className="flex items-center justify-between">
            <div className="text-white">
              <h3 className="text-xl font-semibold mb-1">
                {viewInfo?.icon || ''} {viewInfo?.name || photo.facial_view}
              </h3>
              <p className="text-sm text-gray-200">
                {stageInfo?.label || photo.treatment_stage}
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={handleDownload}
                className="p-2 bg-white bg-opacity-20 hover:bg-opacity-30 rounded-lg transition-colors"
                title="Download Photo"
              >
                <Download className="w-5 h-5 text-white" />
              </button>
              <button
                onClick={onClose}
                className="p-2 bg-white bg-opacity-20 hover:bg-opacity-30 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-white" />
              </button>
            </div>
          </div>
        </div>

        {/* Photo */}
        <div className="bg-black">
          {photoUrl ? (
            <img
              src={photoUrl}
              alt={viewInfo?.name || photo.facial_view}
              className="w-full max-h-[70vh] object-contain"
            />
          ) : (
            <div className="w-full h-96 flex items-center justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
            </div>
          )}
        </div>

        {/* Metadata */}
        <div className="p-6 bg-white space-y-4">
          {/* Basic Info */}
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-start space-x-3">
              <Calendar className="w-5 h-5 text-gray-400 mt-0.5" />
              <div>
                <div className="text-sm font-medium text-gray-900">Captured</div>
                <div className="text-sm text-gray-600">
                  {new Date(photo.captured_at).toLocaleString()}
                </div>
              </div>
            </div>

            {photo.clinician_name && (
              <div className="flex items-start space-x-3">
                <User className="w-5 h-5 text-gray-400 mt-0.5" />
                <div>
                  <div className="text-sm font-medium text-gray-900">Clinician</div>
                  <div className="text-sm text-gray-600">{photo.clinician_name}</div>
                </div>
              </div>
            )}
          </div>

          <div className="p-4 bg-gray-50 rounded">
            <p>Validation: {photo.validation_status}</p>
            {photo.clinician_confirmation && <p>Clinician review: {photo.clinician_confirmation.reason}</p>}
            <p>Framing: {photo.framing_protocol || 'Historical / unknown'} · {photo.image_width} × {photo.image_height}</p>
            <p className="text-xs">Viewed image is the original. Download creates a JPEG export without identifying EXIF metadata; confirm consent before sharing.</p>
          </div>
          {/* Validation Details */}
          {validationResult && (
            <div className="border-t border-gray-200 pt-4">
              <h4 className="text-sm font-semibold text-gray-900 mb-3">
                Validation Details
              </h4>

              {/* Head Pose */}
              {validationResult.yaw !== undefined && (
                <div className="mb-4">
                  <div className="text-sm font-medium text-gray-700 mb-2">Head Pose</div>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="bg-gray-50 rounded-lg p-3">
                      <div className="text-xs text-gray-600 mb-1">Yaw</div>
                      <div className={`text-sm font-medium ${validationResult.yaw_valid ? 'text-green-700' : 'text-red-700'}`}>
                        {formatAngle(validationResult.yaw, 'yaw')}
                      </div>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-3">
                      <div className="text-xs text-gray-600 mb-1">Pitch</div>
                      <div className={`text-sm font-medium ${validationResult.pitch_valid ? 'text-green-700' : 'text-red-700'}`}>
                        {formatAngle(validationResult.pitch, 'pitch')}
                      </div>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-3">
                      <div className="text-xs text-gray-600 mb-1">Roll</div>
                      <div className={`text-sm font-medium ${validationResult.roll_valid ? 'text-green-700' : 'text-red-700'}`}>
                        {formatAngle(validationResult.roll, 'roll')}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Image Quality */}
              {(validationResult.blur_score || validationResult.brightness) && (
                <div className="mb-4">
                  <div className="text-sm font-medium text-gray-700 mb-2">Image Quality</div>
                  <div className="grid grid-cols-2 gap-2">
                    {validationResult.blur_score !== undefined && (
                      <div className="bg-gray-50 rounded-lg p-3">
                        <div className="text-xs text-gray-600 mb-1">Sharpness</div>
                        <div className={`text-sm font-medium ${validationResult.blur_detected ? 'text-red-700' : 'text-green-700'}`}>
                          {validationResult.blur_detected ? 'Blurry' : 'Sharp'}
                        </div>
                      </div>
                    )}
                    {validationResult.brightness !== undefined && (
                      <div className="bg-gray-50 rounded-lg p-3">
                        <div className="text-xs text-gray-600 mb-1">Brightness</div>
                        <div className="text-sm font-medium text-gray-900">
                          {Math.round(validationResult.brightness)}/255
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Confidence */}
              {validationResult.confidence !== undefined && (
                <div>
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="font-medium text-gray-700">Confidence</span>
                    <span className="text-gray-600">
                      {(validationResult.confidence * 100).toFixed(0)}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full ${
                        validationResult.confidence > 0.8
                          ? 'bg-green-500'
                          : validationResult.confidence > 0.6
                          ? 'bg-yellow-500'
                          : 'bg-red-500'
                      }`}
                      style={{ width: `${validationResult.confidence * 100}%` }}
                    ></div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Notes */}
          {photo.notes && (
            <div className="border-t border-gray-200 pt-4">
              <h4 className="text-sm font-semibold text-gray-900 mb-2">Notes</h4>
              <p className="text-sm text-gray-700 whitespace-pre-wrap">{photo.notes}</p>
            </div>
          )}

          {/* Technical Details */}
          <div className="border-t border-gray-200 pt-4">
            <details className="cursor-pointer">
              <summary className="text-sm font-semibold text-gray-900">
                Technical Details
              </summary>
              <div className="mt-3 space-y-1 text-sm text-gray-600">
                <div>Photo ID: {photo.id}</div>
                <div>File Path: {photo.file_path}</div>
                {photo.thumbnail_path && <div>Thumbnail: {photo.thumbnail_path}</div>}
                {validationResult?.landmark_count && (
                  <div>Landmarks Detected: {validationResult.landmark_count}</div>
                )}
                {validationResult?.processing_time_ms && (
                  <div>Processing Time: {validationResult.processing_time_ms}ms</div>
                )}
              </div>
            </details>
          </div>
        </div>
      </div>
    </Modal>
  );
};

export default PhotoViewer;
