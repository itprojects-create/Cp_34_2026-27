import { useState } from 'react';

export default function CameraSetupWizard({ config, setup, onChange }) {
  const [step, setStep] = useState(0);
  const update = values => onChange({ ...setup, ...values, physical_setup_confirmed: false });
  const profiles = Object.entries(config?.camera_profiles || {});
  return <fieldset className="border rounded p-4 space-y-3">
    <legend>Camera setup — {step+1}/3</legend>
    {step === 0 && <>
      <label className="block">Automatic capture mode <select className="border p-2" value={setup.automatic_capture_mode || 'experimental'} onChange={e => update({ automatic_capture_mode: e.target.value })}>
        <option value="experimental">Development webcam — save pending clinical review</option>
        <option value="approved">Approved calibrated setup only</option>
      </select></label>
      <label className="block">Framing protocol <select className="border p-2" value={setup.framing_protocol} onChange={e => update({ framing_protocol: e.target.value })}>
        <option value="full_face">Full-face series</option><option value="nasal_focused">Nasal-focused close-up series</option>
      </select></label>
      <p className="text-sm">Published conventional-format references: full-face 24 × 36 cm vertical (1:10); close-up 15 × 10 cm horizontal (1:4). Webcam cropping does not establish either physical ratio. Preserve anatomical height when adapting aspect ratio.</p>
      <label>Equipment preset <select className="border p-2" value={setup.camera_preset || 'webcam'} onChange={e => update({ camera_preset: e.target.value })}><option value="webcam">Webcam</option><option value="clinical">Clinical camera with fixed external settings</option></select></label>
      <p className="text-sm">Clinical setup recommendation: suitable portrait lens (approximately 90–105 mm full-frame), fixed mount, neutral background and consistent illumination. Browser support for ISO, aperture, shutter, focal length and flash is unavailable unless the device explicitly exposes controls; this workflow does not set them.</p>
    </>}
    {step === 1 && <>
      <label className="block">Local calibration profile <select className="border p-2" value={setup.camera_profile_id || ''} onChange={e => {
        const p = config?.camera_profiles[e.target.value];
        update({ camera_profile_id: e.target.value || null, measured_distance_cm: p?.reference_distance_cm || null,
          camera_height_cm: p?.camera_height_cm || null, setup_notes: p?.setup_notes || setup.setup_notes });
      }}><option value="">Webcam — approximate intrinsics</option>{profiles.map(([id]) => <option key={id} value={id}>{id}</option>)}</select></label>
      <p className="text-sm">For measured intrinsics, use the local checkerboard calibration command in docs/LIVE_CAPTURE_REPORT.md. Record device, resolution, focus and zoom. Profile selection does not measure distance.</p>
      <label className="block">Measured camera-to-patient distance (cm, optional) <input className="border p-2" type="number" min="1" max="10000" value={setup.measured_distance_cm || ''} onChange={e => update({ measured_distance_cm: e.target.value ? Number(e.target.value) : null })} /></label>
      <label className="block">Measured camera height (cm, optional) <input className="border p-2" type="number" min="1" max="500" value={setup.camera_height_cm || ''} onChange={e => update({ camera_height_cm: e.target.value ? Number(e.target.value) : null })} /></label>
      <label>Patient position <select value={setup.position} onChange={e => update({ position: e.target.value })}><option value="seated">Seated upright</option><option value="standing">Standing</option></select></label>
      <label className="block">Floor/reference marks, camera height relationship, lens/focus, lighting and background notes <textarea className="border p-2 w-full" value={setup.setup_notes || ''} onChange={e => update({ setup_notes: e.target.value })} /></label>
    </>}
    {step === 2 && <>
      <p className="text-sm">Development mode automatically captures frontal/oblique images only after measurable checks and stability pass. These images remain pending clinical review. Lateral/basal require confirmation.</p>
      <label className="block"><input type="checkbox" checked={setup.side_directions_confirmed === true} onChange={e => onChange({ ...setup, side_directions_confirmed: e.target.checked })} /> I physically checked that selected left/right view labels match the patient’s side (required for development oblique auto-capture)</label>
      <p>Reproduce the recorded camera/patient floor marks and setup. Retract hair, remove glasses and distractions, use a neutral expression, confirm required head/nasal boundaries, camera height and consistent illumination. For obliques/profiles rotate shoulders with the head. Basal requires separate camera/viewpoint review.</p>
      <label><input type="checkbox" checked={setup.physical_setup_confirmed === true} onChange={e => onChange({ ...setup, physical_setup_confirmed: e.target.checked, setup_confirmed_at: new Date().toISOString() })} /> Photographer confirms this setup and selected framing protocol</label>
    </>}
    <div className="flex gap-4"><button type="button" disabled={step === 0} onClick={() => setStep(step-1)}>Previous setup step</button><button type="button" disabled={step === 2} onClick={() => setStep(step+1)}>Next setup step</button></div>
  </fieldset>;
}
