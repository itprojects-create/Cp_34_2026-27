/**
 * Validation Feedback Component
 * 
 * Displays validation results with visual feedback.
 * Enhanced for Phase 2: Clear review requirements and inline review reason input.
 */

import React, { useState } from 'react';
import { AlertCircle, CheckCircle, AlertTriangle, Info, ChevronDown, ChevronUp } from 'lucide-react';
import { parseValidationErrors, getValidationSeverity, formatAngle } from '../../services/validationService';

const ValidationFeedback = ({ 
  validationResult, 
  isValidating = false,
  reviewReason = '',
  onReviewReasonChange = null,
  showReviewInput = false
}) => {
  const [showTechnicalDetails, setShowTechnicalDetails] = useState(false);
  if (isValidating) {
    return (
      <div className="bg-tertiary-container/70 border border-tertiary/20 rounded-2xl p-4">
        <div className="flex items-center">
          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-primary mr-3"></div>
          <span className="text-on-tertiary-container font-medium">Validating photo...</span>
        </div>
      </div>
    );
  }

  if (!validationResult) {
    return null;
  }

  const severity = getValidationSeverity(validationResult);
  const { primary, secondary } = parseValidationErrors(validationResult);

  // Color schemes for different severities
  const colorSchemes = {
    success: {
      bg: 'bg-success-container/70',
      border: 'border-success/20',
      text: 'text-on-surface',
      icon: 'text-success',
      IconComponent: CheckCircle
    },
    warning: {
      bg: 'bg-warning-container/80',
      border: 'border-warning/20',
      text: 'text-on-surface',
      icon: 'text-warning',
      IconComponent: AlertTriangle
    },
    error: {
      bg: 'bg-error-container',
      border: 'border-error/20',
      text: 'text-on-error-container',
      icon: 'text-error',
      IconComponent: AlertCircle
    }
  };

  const scheme = colorSchemes[severity];
  const Icon = scheme.IconComponent;

  return (
    <div className={`${scheme.bg} border ${scheme.border} rounded-2xl p-4 space-y-3`}>
      {/* Main Status */}
      <div className="flex items-start">
        <Icon className={`${scheme.icon} w-5 h-5 mr-3 flex-shrink-0 mt-0.5`} />
        <div className="flex-1">
          <h4 className={`${scheme.text} font-semibold mb-1`}>
            {validationResult.valid 
              ? 'Photo Validated Successfully' 
              : validationResult.reviewable 
                ? 'Clinical Review Required' 
                : 'Photo Does Not Meet Requirements'}
          </h4>
          <p className={`${scheme.text} text-sm`}>
            {primary}
          </p>
        </div>
      </div>

      {/* Review Required Explanation */}
      {validationResult.reviewable && !validationResult.valid && (
        <div className="bg-surface-container-lowest border border-tertiary/20 rounded-xl p-3">
          <h5 className="text-sm font-semibold text-on-tertiary-container mb-2">
            Why is review needed?
          </h5>
          <p className="text-xs text-on-surface-variant mb-2">
            The automated system cannot fully verify all clinical requirements for this view. 
            As the clinician, you must visually confirm:
          </p>
          <ul className="text-xs text-on-surface-variant space-y-1 ml-4">
            <li>• Correct anatomical side (left/right) matches selected view</li>
            <li>• All required facial/nasal boundaries are visible</li>
            <li>• Neutral expression maintained</li>
            <li>• No obstructions (hair, glasses, shadows)</li>
            <li>• Appropriate camera distance and framing</li>
            {validationResult.facial_view === 'basal' && (
              <li>• Nasal base anatomy clearly visible (for basal view)</li>
            )}
          </ul>
        </div>
      )}

      {/* Review Reason Input */}
      {showReviewInput && validationResult.reviewable && !validationResult.valid && onReviewReasonChange && (
        <div className="bg-surface-container-lowest border border-tertiary/20 rounded-xl p-3">
          <label className="block">
            <span className="text-sm font-semibold text-on-surface mb-2 block">
              Clinical Review Notes (Required - minimum 15 characters)
            </span>
            <p className="text-xs text-on-surface-variant mb-2">
              Document your clinical assessment and any limitations or deviations from the standard protocol:
            </p>
            <textarea
              value={reviewReason}
              onChange={(e) => onReviewReasonChange(e.target.value)}
              rows={3}
              className={`w-full px-3 py-2 border rounded-lg text-sm ${
                reviewReason.trim().length >= 15 
                  ? 'border-success' 
                  : 'border-outline-variant'
              }`}
              placeholder="Example: Frontal view confirmed. Minor head tilt present but acceptable. All nasal anatomy visible. Patient unable to fully straighten posture due to comfort."
            />
            <div className="mt-1 flex items-center justify-between">
              <span className={`text-xs ${
                reviewReason.trim().length >= 15 ? 'text-success' : 'text-on-surface-variant'
              }`}>
                {reviewReason.trim().length} / 15 characters
              </span>
              {reviewReason.trim().length >= 15 && (
                <span className="text-xs text-success flex items-center">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Ready to proceed
                </span>
              )}
            </div>
          </label>
        </div>
      )}

      {/* Secondary Messages */}
      {secondary.length > 0 && (
        <ul className="space-y-1 ml-8">
          {secondary.map((message, idx) => (
            <li key={idx} className={`${scheme.text} text-sm flex items-start`}>
              <span className="mr-2">•</span>
              <span>{message}</span>
            </li>
          ))}
        </ul>
      )}

      {/* Technical Details (Collapsible) */}
      {(validationResult.yaw !== undefined || validationResult.blur_score !== undefined) && (
        <div className="border-t border-black/5 pt-3">
          <button
            onClick={() => setShowTechnicalDetails(!showTechnicalDetails)}
            className="flex items-center text-sm text-on-surface-variant hover:text-on-surface transition-colors"
          >
            {showTechnicalDetails ? (
              <ChevronUp className="w-4 h-4 mr-1" />
            ) : (
              <ChevronDown className="w-4 h-4 mr-1" />
            )}
            {showTechnicalDetails ? 'Hide' : 'Show'} Technical Details
          </button>
          
          {showTechnicalDetails && (
            <div className="mt-3 space-y-3">
              {/* Detected Angles */}
              {validationResult.yaw !== undefined && (
                <div>
                  <h5 className={`${scheme.text} text-sm font-medium mb-2`}>Detected Head Pose:</h5>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="bg-surface-container-lowest rounded-xl px-3 py-2 border border-outline-variant">
                      <div className="text-xs text-on-surface-variant mb-1">Yaw (Rotation)</div>
                      <div className={`text-sm font-medium ${validationResult.yaw_valid ? 'text-success' : 'text-error'}`}>
                        {formatAngle(validationResult.yaw, 'yaw')}
                        {validationResult.yaw_valid && ' ✓'}
                      </div>
                    </div>
                    <div className="bg-surface-container-lowest rounded-xl px-3 py-2 border border-outline-variant">
                      <div className="text-xs text-on-surface-variant mb-1">Pitch (Tilt)</div>
                      <div className={`text-sm font-medium ${validationResult.pitch_valid ? 'text-success' : 'text-error'}`}>
                        {formatAngle(validationResult.pitch, 'pitch')}
                        {validationResult.pitch_valid && ' ✓'}
                      </div>
                    </div>
                    <div className="bg-surface-container-lowest rounded-xl px-3 py-2 border border-outline-variant">
                      <div className="text-xs text-on-surface-variant mb-1">Roll (Level)</div>
                      <div className={`text-sm font-medium ${validationResult.roll_valid ? 'text-success' : 'text-error'}`}>
                        {formatAngle(validationResult.roll, 'roll')}
                        {validationResult.roll_valid && ' ✓'}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Quality Info */}
              {(validationResult.blur_score !== undefined || validationResult.brightness !== undefined) && (
                <div>
                  <h5 className={`${scheme.text} text-sm font-medium mb-2`}>Image Quality:</h5>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {validationResult.blur_score !== undefined && (
                      <div className="bg-surface-container-lowest rounded-xl px-3 py-2 border border-outline-variant">
                        <span className="text-on-surface-variant">Sharpness:</span>{' '}
                        <span className={validationResult.blur_detected ? 'text-error' : 'text-success'}>
                          {validationResult.blur_detected ? 'Blurry' : 'Sharp'} ({validationResult.blur_score.toFixed(0)})
                        </span>
                      </div>
                    )}
                    {validationResult.brightness !== undefined && (
                      <div className="bg-surface-container-lowest rounded-xl px-3 py-2 border border-outline-variant">
                        <span className="text-on-surface-variant">Brightness:</span>{' '}
                        <span className="text-on-surface">
                          {validationResult.brightness.toFixed(0)}/255
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Processing Time */}
              {validationResult.processing_time_ms && (
                <div className="flex items-center justify-end pt-2">
                  <Info className="w-3 h-3 text-on-surface-variant mr-1" />
                  <span className="text-xs text-on-surface-variant">
                    Processed in {validationResult.processing_time_ms}ms
                  </span>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ValidationFeedback;
