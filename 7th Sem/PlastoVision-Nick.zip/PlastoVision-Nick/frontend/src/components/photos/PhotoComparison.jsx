/**
 * Photo Comparison Component
 * 
 * Side-by-side comparison of patient photos for treatment progress tracking.
 */

import React, { useState, useRef } from 'react';
import { X, ArrowLeftRight, ZoomIn, ZoomOut, RotateCw } from 'lucide-react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import { TREATMENT_STAGES } from '../../services/validationService';

const PhotoComparison = ({ isOpen, onClose, leftPhoto, rightPhoto, leftPhotoUrl, rightPhotoUrl }) => {
  const [comparisonMode, setComparisonMode] = useState('side-by-side'); // 'side-by-side', 'slider', 'overlay'
  const [sliderPosition, setSliderPosition] = useState(50);
  const [overlayOpacity, setOverlayOpacity] = useState(50);
  const [zoom, setZoom] = useState(100);
  const [pan, setPan] = useState({x:0,y:0});
  const drag = useRef(null);

  if (!leftPhoto || !rightPhoto) return null;

  const leftStage = TREATMENT_STAGES.find(s => s.value === leftPhoto.treatment_stage);
  const rightStage = TREATMENT_STAGES.find(s => s.value === rightPhoto.treatment_stage);

  const handleSliderDrag = (e) => {
    if (comparisonMode !== 'slider') return;
    
    const container = e.currentTarget;
    const rect = container.getBoundingClientRect();
    const x = e.clientX || (e.touches && e.touches[0].clientX);
    const position = ((x - rect.left) / rect.width) * 100;
    setSliderPosition(Math.max(0, Math.min(100, position)));
  };

  const renderSideBySide = () => (
    <div className="grid grid-cols-2 gap-4 h-full">
      {/* Left Photo */}
      <div className="relative bg-black rounded-lg overflow-hidden flex flex-col">
        <div className="absolute top-0 left-0 right-0 z-10 bg-gradient-to-b from-black/70 to-transparent p-4">
          <h4 className="text-white font-semibold">{leftStage?.label || leftPhoto.treatment_stage}</h4>
          <p className="text-white/80 text-sm">{new Date(leftPhoto.captured_at).toLocaleDateString()}</p>
        </div>
        <div className="flex-1 flex items-center justify-center p-4">
          {leftPhotoUrl ? (
            <img
              src={leftPhotoUrl}
              alt="Left comparison"
              className="max-w-full max-h-full object-contain"
              style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom / 100})` }}
            />
          ) : (
            <div className="text-white">Loading...</div>
          )}
        </div>
      </div>

      {/* Right Photo */}
      <div className="relative bg-black rounded-lg overflow-hidden flex flex-col">
        <div className="absolute top-0 left-0 right-0 z-10 bg-gradient-to-b from-black/70 to-transparent p-4">
          <h4 className="text-white font-semibold">{rightStage?.label || rightPhoto.treatment_stage}</h4>
          <p className="text-white/80 text-sm">{new Date(rightPhoto.captured_at).toLocaleDateString()}</p>
        </div>
        <div className="flex-1 flex items-center justify-center p-4">
          {rightPhotoUrl ? (
            <img
              src={rightPhotoUrl}
              alt="Right comparison"
              className="max-w-full max-h-full object-contain"
              style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom / 100})` }}
            />
          ) : (
            <div className="text-white">Loading...</div>
          )}
        </div>
      </div>
    </div>
  );

  const renderSlider = () => (
    <div 
      className="relative w-full h-full bg-black rounded-lg overflow-hidden cursor-col-resize"
      onMouseMove={handleSliderDrag}
      onTouchMove={handleSliderDrag}
    >
      {/* Right Photo (Background) */}
      <div className="absolute inset-0">
        {rightPhotoUrl && (
          <img
            src={rightPhotoUrl}
            alt="Right comparison"
            className="w-full h-full object-contain"
            style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom / 100})` }}
          />
        )}
        <div className="absolute top-4 right-4 bg-black/70 px-3 py-2 rounded-lg">
          <p className="text-white font-semibold text-sm">{rightStage?.label || rightPhoto.treatment_stage}</p>
          <p className="text-white/80 text-xs">{new Date(rightPhoto.captured_at).toLocaleDateString()}</p>
        </div>
      </div>

      {/* Left Photo (Clipped) */}
      <div 
        className="absolute inset-0 overflow-hidden"
        style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
      >
        {leftPhotoUrl && (
          <img
            src={leftPhotoUrl}
            alt="Left comparison"
            className="w-full h-full object-contain"
            style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom / 100})` }}
          />
        )}
        <div className="absolute top-4 left-4 bg-black/70 px-3 py-2 rounded-lg">
          <p className="text-white font-semibold text-sm">{leftStage?.label || leftPhoto.treatment_stage}</p>
          <p className="text-white/80 text-xs">{new Date(leftPhoto.captured_at).toLocaleDateString()}</p>
        </div>
      </div>

      {/* Slider Handle */}
      <div 
        className="absolute top-0 bottom-0 w-1 bg-white shadow-lg"
        style={{ left: `${sliderPosition}%` }}
      >
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-10 h-10 bg-white rounded-full shadow-lg flex items-center justify-center">
          <ArrowLeftRight className="w-5 h-5 text-gray-800" />
        </div>
      </div>
    </div>
  );

  const renderOverlay = () => (
    <div className="relative w-full h-full bg-black rounded-lg overflow-hidden">
      {/* Bottom Photo */}
      <div className="absolute inset-0 flex items-center justify-center p-4">
        {leftPhotoUrl && (
          <img
            src={leftPhotoUrl}
            alt="Bottom layer"
            className="max-w-full max-h-full object-contain"
            style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom / 100})` }}
          />
        )}
        <div className="absolute top-4 left-4 bg-black/70 px-3 py-2 rounded-lg">
          <p className="text-white font-semibold text-sm">{leftStage?.label || leftPhoto.treatment_stage}</p>
          <p className="text-white/80 text-xs">{new Date(leftPhoto.captured_at).toLocaleDateString()}</p>
        </div>
      </div>

      {/* Top Photo (with opacity) */}
      <div 
        className="absolute inset-0 flex items-center justify-center p-4"
        style={{ opacity: overlayOpacity / 100 }}
      >
        {rightPhotoUrl && (
          <img
            src={rightPhotoUrl}
            alt="Top layer"
            className="max-w-full max-h-full object-contain"
            style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom / 100})` }}
          />
        )}
        <div className="absolute top-4 right-4 bg-black/70 px-3 py-2 rounded-lg">
          <p className="text-white font-semibold text-sm">{rightStage?.label || rightPhoto.treatment_stage}</p>
          <p className="text-white/80 text-xs">{new Date(rightPhoto.captured_at).toLocaleDateString()}</p>
        </div>
      </div>

      {/* Opacity Control */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-black/70 px-4 py-2 rounded-lg">
        <div className="flex items-center space-x-3">
          <span className="text-white text-sm">Opacity:</span>
          <input
            type="range"
            min="0"
            max="100"
            value={overlayOpacity}
            onChange={(e) => setOverlayOpacity(Number(e.target.value))}
            className="w-32"
          />
          <span className="text-white text-sm font-mono">{overlayOpacity}%</span>
        </div>
      </div>
    </div>
  );

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="full">
      <div className="flex flex-col h-[80vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Photo Comparison</h2>
            <p className="text-sm text-gray-600">Unaltered originals; presentation zoom and pan only. Drag to pan at increased zoom.</p>
          </div>
          
          {/* Mode Selector */}
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setComparisonMode('side-by-side')}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                comparisonMode === 'side-by-side'
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Side by Side
            </button>
            <button
              onClick={() => setComparisonMode('slider')}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                comparisonMode === 'slider'
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Slider
            </button>
            <button
              onClick={() => setComparisonMode('overlay')}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                comparisonMode === 'overlay'
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Overlay
            </button>
          </div>

          {/* Zoom Controls */}
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setZoom(Math.max(50, zoom - 10))}
              className="p-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
              title="Zoom Out"
            >
              <ZoomOut className="w-5 h-5" />
            </button>
            <span className="text-sm font-mono text-gray-700 min-w-[60px] text-center">
              {zoom}%
            </span>
            <button
              onClick={() => setZoom(Math.min(200, zoom + 10))}
              className="p-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
              title="Zoom In"
            >
              <ZoomIn className="w-5 h-5" />
            </button>
            <button
              onClick={() => { setZoom(100); setPan({x:0,y:0}); }}
              className="p-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
              title="Reset Zoom"
            >
              <RotateCw className="w-5 h-5" />
            </button>
          </div>

          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Comparison View */}
        <div className="flex-1 min-h-0 p-6 overflow-hidden touch-none"
          onPointerDown={e => { if (zoom > 100 && comparisonMode !== 'slider') { drag.current = {x:e.clientX,y:e.clientY,pan}; e.currentTarget.setPointerCapture(e.pointerId); } }}
          onPointerMove={e => { if (drag.current) setPan({x:drag.current.pan.x+e.clientX-drag.current.x,y:drag.current.pan.y+e.clientY-drag.current.y}); }}
          onPointerUp={() => { drag.current = null; }} onPointerCancel={() => { drag.current = null; }}>
          {comparisonMode === 'side-by-side' && renderSideBySide()}
          {comparisonMode === 'slider' && renderSlider()}
          {comparisonMode === 'overlay' && renderOverlay()}
        </div>
      </div>
    </Modal>
  );
};

export default PhotoComparison;
