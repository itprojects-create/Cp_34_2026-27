/**
 * Enhanced Camera Capture Component
 * 
 * Features:
 * - Automatic capture when positioned correctly (toggle-able)
 * - Manual capture always available
 * - Real-time positioning guidance using CV pipeline
 * - Validation temporarily bypassed for capture workflow
 * - View-specific instructions and feedback
 * - Local storage to uploads folder
 */

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Camera, X, Check, RotateCcw, AlertCircle, ZapOff, Zap } from 'lucide-react';
import Button from '../ui/Button';
import { getFacialView } from '../../services/validationService';

// Configuration
const LIVE_GUIDANCE_FPS = 8;
const VALIDATION_FRAME_WIDTH = 480;
const STABILITY_DURATION_MS = 1500; // 1.5 seconds to reduce accidental captures
const FINAL_CAPTURE_QUALITY = 0.95;

const CameraCaptureEnhanced = ({ 
  selectedView, 
  onCapture, 
  onClose,
  patientId
}) => {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const guidanceIntervalRef = useRef(null);
  const stabilityTimerRef = useRef(null);
  const lastGuidanceRef = useRef(0);
  const processingRef = useRef(false);
  const abortControllerRef = useRef(null);
  
  // State
  const [isReady, setIsReady] = useState(false);
  const [error, setError] = useState(null);
  const [capturedImage, setCapturedImage] = useState(null);
  
  // Guidance state
  const [guidanceMessage, setGuidanceMessage] = useState('Starting camera...');
  const [isCorrectlyPositioned, setIsCorrectlyPositioned] = useState(false);
  const [stabilityProgress, setStabilityProgress] = useState(0);
  const [autoReadyToCapture, setAutoReadyToCapture] = useState(false);
  
  // Auto-capture toggle
  const [autoCaptureEnabled, setAutoCaptureEnabled] = useState(true);
  
  // Debug/metrics
  const [metrics, setMetrics] = useState({
    yaw: null,
    pitch: null,
    roll: null,
    distance: null,
    centered: null,
    faceDetected: false
  });

  const viewConfig = getFacialView(selectedView);

  // Start camera
  const startCamera = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 1920 },
          height: { ideal: 1080 },
          facingMode: 'user'
        },
        audio: false
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
        setIsReady(true);
        setError(null);
        setGuidanceMessage('Position your face in the frame');
      }
    } catch (err) {
      console.error('Camera access error:', err);
      setError('Cannot access camera. Please check permissions.');
    }
  }, []);

  // Stop camera
  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (guidanceIntervalRef.current) {
      clearInterval(guidanceIntervalRef.current);
    }
    if (stabilityTimerRef.current) {
      clearTimeout(stabilityTimerRef.current);
    }
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    setIsReady(false);
  }, []);

  // Capture validation frame
  const captureGuidanceFrame = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return null;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');

    const aspectRatio = video.videoHeight / video.videoWidth;
    canvas.width = VALIDATION_FRAME_WIDTH;
    canvas.height = VALIDATION_FRAME_WIDTH * aspectRatio;

    context.save();
    context.scale(-1, 1);
    context.drawImage(video, -canvas.width, 0, canvas.width, canvas.height);
    context.restore();

    return canvas.toDataURL('image/jpeg', 0.7);
  }, []);

  // Get positioning guidance from CV service
  const getPositioningGuidance = useCallback(async (frameData) => {
    if (processingRef.current) return;
    
    processingRef.current = true;

    try {
      abortControllerRef.current = new AbortController();

      const response = await fetch('http://localhost:3001/api/patient-photos/validate-live', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          frame: frameData,
          facial_view: selectedView
        }),
        signal: abortControllerRef.current.signal
      });

      const result = await response.json();
      
      // Update metrics for display
      setMetrics({
        yaw: result.yaw,
        pitch: result.pitch,
        roll: result.roll,
        distance: result.face_size_ratio ? (result.face_size_ratio * 100).toFixed(1) : null,
        centered: result.framing_ok,
        faceDetected: result.face_detected
      });
      
      // Use guidance message from CV pipeline
      const guidance = result.guidance || 'Adjust your position';
      setGuidanceMessage(guidance);
      
      // Determine if positioned correctly (but don't block manual capture)
      const correctlyPositioned = result.valid && result.state === 'ready';
      setIsCorrectlyPositioned(correctlyPositioned);
      
      // Handle automatic capture stability
      if (correctlyPositioned && autoCaptureEnabled) {
        if (!stabilityTimerRef.current) {
          const startTime = Date.now();
          stabilityTimerRef.current = setInterval(() => {
            const elapsed = Date.now() - startTime;
            const progress = Math.min(100, (elapsed / STABILITY_DURATION_MS) * 100);
            setStabilityProgress(progress);
            
            if (elapsed >= STABILITY_DURATION_MS) {
              clearInterval(stabilityTimerRef.current);
              stabilityTimerRef.current = null;
              setAutoReadyToCapture(true);
              // Auto-capture after stability period
              setTimeout(() => {
                handleAutomaticCapture();
              }, 100);
            }
          }, 50);
        }
      } else {
        // Reset stability
        if (stabilityTimerRef.current) {
          clearInterval(stabilityTimerRef.current);
          stabilityTimerRef.current = null;
        }
        setStabilityProgress(0);
        setAutoReadyToCapture(false);
      }
      
    } catch (error) {
      if (error.name !== 'AbortError') {
        console.error('Guidance error:', error);
        setGuidanceMessage('Guidance temporarily unavailable');
      }
    } finally {
      processingRef.current = false;
    }
  }, [selectedView, autoCaptureEnabled]);

  // Live guidance loop
  useEffect(() => {
    if (!isReady || capturedImage) return;

    const guidanceInterval = 1000 / LIVE_GUIDANCE_FPS;
    
    guidanceIntervalRef.current = setInterval(() => {
      const now = Date.now();
      
      if (now - lastGuidanceRef.current < guidanceInterval) {
        return;
      }
      
      lastGuidanceRef.current = now;
      
      const frameData = captureGuidanceFrame();
      if (frameData) {
        getPositioningGuidance(frameData);
      }
    }, guidanceInterval);

    return () => {
      if (guidanceIntervalRef.current) {
        clearInterval(guidanceIntervalRef.current);
      }
    };
  }, [isReady, capturedImage, captureGuidanceFrame, getPositioningGuidance]);

  // Initialize camera
  useEffect(() => {
    startCamera();
    return () => stopCamera();
  }, [startCamera, stopCamera]);

  // Capture high-resolution photo (manual)
  const handleManualCapture = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    context.save();
    context.scale(-1, 1);
    context.drawImage(video, -canvas.width, 0, canvas.width, canvas.height);
    context.restore();

    // Stop live guidance
    if (guidanceIntervalRef.current) {
      clearInterval(guidanceIntervalRef.current);
    }
    if (stabilityTimerRef.current) {
      clearInterval(stabilityTimerRef.current);
    }

    canvas.toBlob((blob) => {
      if (blob) {
        const url = URL.createObjectURL(blob);
        const file = new File([blob], `${selectedView}_${Date.now()}.jpg`, {
          type: 'image/jpeg'
        });
        
        setCapturedImage({ url, file });
        setGuidanceMessage('Photo captured');
      }
    }, 'image/jpeg', FINAL_CAPTURE_QUALITY);
  }, [selectedView]);

  // Automatic capture (triggered after stability)
  const handleAutomaticCapture = useCallback(() => {
    if (!autoReadyToCapture || capturedImage) return;
    handleManualCapture();
  }, [autoReadyToCapture, capturedImage, handleManualCapture]);

  // Retake
  const handleRetake = () => {
    if (capturedImage?.url) {
      URL.revokeObjectURL(capturedImage.url);
    }
    setCapturedImage(null);
    setAutoReadyToCapture(false);
    setStabilityProgress(0);
    setIsCorrectlyPositioned(false);
    setGuidanceMessage('Position your face in the frame');
    lastGuidanceRef.current = 0;
  };

  // Confirm and save
  const handleConfirm = async () => {
    if (!capturedImage?.file) return;

    try {
      // Create FormData for upload
      const formData = new FormData();
      formData.append('photo', capturedImage.file);
      formData.append('patient_id', patientId);
      formData.append('facial_view', selectedView);
      
      // Upload to backend (saves to local uploads folder - bypasses validation)
      const response = await fetch('http://localhost:3001/api/patient-photos/upload-direct', {
        method: 'POST',
        body: formData
      });

      if (!response.ok) {
        throw new Error('Upload failed');
      }

      const result = await response.json();
      
      // Notify parent
      onCapture(result);
      
    } catch (error) {
      console.error('Save error:', error);
      alert('Failed to save photo. Please try again.');
    }
  };

  // Handle close
  const handleClose = () => {
    if (capturedImage?.url) {
      URL.revokeObjectURL(capturedImage.url);
    }
    stopCamera();
    onClose();
  };

  // Toggle auto-capture
  const toggleAutoCapture = () => {
    setAutoCaptureEnabled(!autoCaptureEnabled);
    if (stabilityTimerRef.current) {
      clearInterval(stabilityTimerRef.current);
      stabilityTimerRef.current = null;
    }
    setStabilityProgress(0);
    setAutoReadyToCapture(false);
  };

  // Determine state color
  const isGreenState = isCorrectlyPositioned;
  const stateColor = isGreenState ? 'green' : 'red';

  return (
    <div className="fixed inset-0 bg-black bg-opacity-95 z-50 flex items-center justify-center">
      <div className="relative w-full h-full max-w-7xl max-h-screen p-4 flex flex-col">
        {/* Header */}
        <div className="flex justify-between items-center mb-4">
          <div>
            <h2 className="text-2xl font-bold text-white">
              Camera Capture
            </h2>
            <p className="text-gray-300">
              {viewConfig?.name || 'Select a view'}
            </p>
          </div>
          <div className="flex items-center gap-4">
            {/* Auto-capture toggle */}
            <button
              onClick={toggleAutoCapture}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                autoCaptureEnabled
                  ? 'bg-green-600 hover:bg-green-700 text-white'
                  : 'bg-gray-600 hover:bg-gray-700 text-white'
              }`}
            >
              {autoCaptureEnabled ? (
                <>
                  <Zap className="w-4 h-4" />
                  Auto
                </>
              ) : (
                <>
                  <ZapOff className="w-4 h-4" />
                  Manual
                </>
              )}
            </button>
            <button
              onClick={handleClose}
              className="text-white hover:text-gray-300 transition-colors"
            >
              <X className="w-8 h-8" />
            </button>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex gap-4 overflow-hidden">
          {/* Camera/Preview Area */}
          <div className="flex-1 bg-gray-900 rounded-lg overflow-hidden relative">
            {error && (
              <div className="absolute inset-0 flex items-center justify-center bg-red-900 bg-opacity-80 z-10">
                <div className="text-center text-white px-4">
                  <AlertCircle className="w-16 h-16 mx-auto mb-4" />
                  <p className="text-lg font-semibold mb-2">Camera Error</p>
                  <p className="text-sm">{error}</p>
                  <Button
                    onClick={startCamera}
                    className="mt-4"
                    variant="outline"
                  >
                    Retry
                  </Button>
                </div>
              </div>
            )}

            {!capturedImage ? (
              <>
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-contain"
                  style={{ transform: 'scaleX(-1)' }}
                />
                
                {/* Guidance Overlay */}
                {isReady && (
                  <div className={`absolute top-4 left-4 right-4 rounded-lg p-4 ${
                    isGreenState 
                      ? 'bg-green-600 bg-opacity-90' 
                      : 'bg-red-600 bg-opacity-90'
                  }`}>
                    <div className="flex items-start gap-3 text-white">
                      <div className={`w-3 h-3 rounded-full mt-1 flex-shrink-0 ${
                        isGreenState ? 'bg-green-300 animate-pulse' : 'bg-red-300'
                      }`}></div>
                      <div className="flex-1">
                        <div className="font-bold text-lg mb-1">
                          {isGreenState ? 'POSITION CORRECT' : 'ADJUST POSITION'}
                        </div>
                        <p className="text-sm text-white leading-relaxed">
                          {guidanceMessage}
                        </p>
                        
                        {/* Stability Progress */}
                        {autoCaptureEnabled && stabilityProgress > 0 && !autoReadyToCapture && (
                          <div className="mt-3">
                            <div className="w-full bg-white bg-opacity-30 rounded-full h-2">
                              <div 
                                className="bg-white h-2 rounded-full transition-all duration-100"
                                style={{ width: `${stabilityProgress}%` }}
                              ></div>
                            </div>
                            <p className="text-xs mt-1">Hold steady... capturing soon</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {/* Face Guide Frame */}
                {isReady && (
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div 
                      className={`border-4 rounded-lg transition-all duration-300 ${
                        isGreenState 
                          ? 'border-green-400 border-opacity-80' 
                          : 'border-white border-opacity-50'
                      }`}
                      style={{ 
                        width: '55%', 
                        height: '70%',
                        maxWidth: '480px',
                        maxHeight: '640px'
                      }}
                    >
                      {/* Corner markers */}
                      <div className={`absolute -top-1 -left-1 w-12 h-12 border-t-4 border-l-4 ${
                        isGreenState ? 'border-green-400' : 'border-white'
                      }`}></div>
                      <div className={`absolute -top-1 -right-1 w-12 h-12 border-t-4 border-r-4 ${
                        isGreenState ? 'border-green-400' : 'border-white'
                      }`}></div>
                      <div className={`absolute -bottom-1 -left-1 w-12 h-12 border-b-4 border-l-4 ${
                        isGreenState ? 'border-green-400' : 'border-white'
                      }`}></div>
                      <div className={`absolute -bottom-1 -right-1 w-12 h-12 border-b-4 border-r-4 ${
                        isGreenState ? 'border-green-400' : 'border-white'
                      }`}></div>
                    </div>
                  </div>
                )}
              </>
            ) : (
              <img
                src={capturedImage.url}
                alt="Captured"
                className="w-full h-full object-contain"
              />
            )}

            <canvas ref={canvasRef} style={{ display: 'none' }} />
          </div>

          {/* Side Panel */}
          <div className="w-80 bg-gray-800 rounded-lg p-6 text-white overflow-y-auto space-y-4">
            <h3 className="text-xl font-bold">Instructions</h3>
            
            {viewConfig && (
              <div className="space-y-3">
                <div>
                  <h4 className="font-semibold text-green-400 mb-1">
                    {viewConfig.name}
                  </h4>
                  <p className="text-xs text-gray-300">
                    {viewConfig.description}
                  </p>
                </div>

                <div className="border-t border-gray-700 pt-3">
                  <h4 className="font-semibold mb-2 text-blue-400 text-sm">
                    Positioning Guide
                  </h4>
                  <ul className="text-xs text-gray-300 space-y-1">
                    {viewConfig.instructions.map((tip, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-blue-400 mt-0.5">•</span>
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Live Metrics */}
                {metrics.faceDetected && (
                  <div className="border-t border-gray-700 pt-3 text-xs">
                    <h4 className="font-semibold mb-2 text-yellow-400">
                      Live Measurements
                    </h4>
                    <div className="space-y-1 font-mono text-gray-400">
                      <div>Face: {metrics.faceDetected ? '✓ Detected' : '✗ Not detected'}</div>
                      {metrics.yaw !== null && <div>Yaw: {metrics.yaw.toFixed(1)}°</div>}
                      {metrics.pitch !== null && <div>Pitch: {metrics.pitch.toFixed(1)}°</div>}
                      {metrics.roll !== null && <div>Roll: {metrics.roll.toFixed(1)}°</div>}
                      {metrics.distance && <div>Distance: {metrics.distance}%</div>}
                      <div>Centered: {metrics.centered ? '✓' : '✗'}</div>
                    </div>
                  </div>
                )}

                {/* Capture Mode Info */}
                <div className="border-t border-gray-700 pt-3 text-xs">
                  <h4 className="font-semibold mb-2 text-purple-400">
                    Capture Mode
                  </h4>
                  <p className="text-gray-400 leading-relaxed">
                    {autoCaptureEnabled 
                      ? 'Auto-capture is enabled. Photo will be taken automatically when positioned correctly for 1.5 seconds. You can still capture manually anytime.'
                      : 'Manual capture only. Press the capture button when ready. Auto-capture is disabled.'
                    }
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Controls */}
        <div className="mt-4 flex justify-center gap-4">
          {!capturedImage ? (
            <>
              <Button
                onClick={handleClose}
                variant="outline"
                className="bg-gray-700 text-white border-gray-600 hover:bg-gray-600"
              >
                Cancel
              </Button>
              <Button
                onClick={handleManualCapture}
                className="px-8 bg-blue-600 hover:bg-blue-700 text-white"
              >
                <Camera className="w-5 h-5 mr-2" />
                Capture Photo
              </Button>
            </>
          ) : (
            <>
              <Button
                onClick={handleRetake}
                variant="outline"
                className="bg-gray-700 text-white border-gray-600 hover:bg-gray-600"
              >
                <RotateCcw className="w-5 h-5 mr-2" />
                Retake
              </Button>
              <Button
                onClick={handleConfirm}
                className="bg-green-600 hover:bg-green-700 text-white px-8"
              >
                <Check className="w-5 h-5 mr-2" />
                Save Photo
              </Button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default CameraCaptureEnhanced;
