import React from 'react';

const Table = ({ columns, data, keyField = "id", onRowClick }) => {
  return (
    <div className="overflow-x-auto w-full">
      <table className="w-full text-left text-sm whitespace-nowrap">
        <thead className="bg-surface-container/80 text-on-surface-variant font-medium border-y border-outline-variant">
          <tr>
            {columns.map((col, index) => (
              <th key={col.key || index} className="px-5 md:px-6 py-3.5 text-xs uppercase tracking-wide">
                {col.title}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-outline-variant/80 text-on-surface bg-surface-container-lowest">
          {data.length === 0 ? (
            <tr>
              <td colSpan={columns.length} className="px-6 py-10 text-center text-on-surface-variant">
                No data available.
              </td>
            </tr>
          ) : (
            data.map((row) => (
              <tr 
                key={row[keyField]} 
                onClick={() => onRowClick && onRowClick(row)}
                className={`hover:bg-primary-container/30 transition-colors ${onRowClick ? 'cursor-pointer' : ''}`}
              >
                {columns.map((col, index) => (
                  <td key={col.key || index} className="px-5 md:px-6 py-4 align-middle">
                    {col.render ? col.render(row[col.key], row) : row[col.key]}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default Table;
