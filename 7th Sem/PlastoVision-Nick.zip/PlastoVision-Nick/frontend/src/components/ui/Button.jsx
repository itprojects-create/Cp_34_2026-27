import React from 'react';

const Button = ({ 
  children, 
  variant = 'primary', 
  size = 'md', 
  className = '', 
  icon,
  ...props 
}) => {
  const baseClasses = "inline-flex items-center justify-center font-medium font-headline rounded-xl transition-all duration-150 outline-none focus-visible:ring-2 focus-visible:ring-primary/40 focus-visible:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-none";
  
  const variants = {
    primary: "bg-primary text-on-primary hover:bg-primary/90 shadow-sm hover:shadow",
    secondary: "bg-secondary-container text-on-secondary-container hover:bg-secondary-container/80",
    outline: "border border-outline-variant bg-surface-container-lowest text-on-surface hover:bg-surface-container hover:border-primary/30",
    ghost: "text-on-surface-variant hover:bg-surface-container hover:text-on-surface",
    danger: "bg-error text-on-error hover:bg-error/90 shadow-sm"
  };
  
  const sizes = {
    sm: "text-xs px-3 py-1.5 gap-1.5",
    md: "text-sm px-5 py-2.5 gap-2",
    lg: "text-base px-6 py-3 gap-2",
    icon: "p-2"
  };

  return (
    <button 
      className={`${baseClasses} ${variants[variant]} ${sizes[size]} ${className}`}
      {...props}
    >
      {icon && <span className="flex items-center justify-center">{icon}</span>}
      {children}
    </button>
  );
};

export default Button;
