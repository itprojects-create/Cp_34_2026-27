import React from 'react';

const Card = ({ children, className = '', title, subtitle, action, noPadding = false, ...props }) => {
  return (
    <div 
      className={`bg-surface-container-lowest rounded-2xl shadow-[var(--shadow-card)] border border-outline-variant/80 overflow-hidden flex flex-col ${className}`}
      {...props}
    >
      {(title || subtitle || action) && (
        <div className="px-5 md:px-6 py-4 border-b border-outline-variant/80 flex justify-between items-center gap-3 bg-surface-container-low/50">
          <div className="min-w-0">
            {title && <h3 className="font-headline font-semibold text-base text-on-surface truncate">{title}</h3>}
            {subtitle && <p className="text-sm text-on-surface-variant mt-0.5">{subtitle}</p>}
          </div>
          {action && <div className="shrink-0">{action}</div>}
        </div>
      )}
      <div className={`${noPadding ? '' : 'p-5 md:p-6'} flex-1`}>
        {children}
      </div>
    </div>
  );
};

export default Card;
