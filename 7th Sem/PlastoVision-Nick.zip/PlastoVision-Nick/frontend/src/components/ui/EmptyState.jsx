import React from 'react';

const EmptyState = ({ icon, title, description, action }) => {
  return (
    <div className="flex flex-col items-center justify-center text-center py-12 px-4">
      {icon && (
        <div className="w-14 h-14 rounded-2xl bg-surface-container flex items-center justify-center text-on-surface-variant mb-4">
          {icon}
        </div>
      )}
      {title && <h3 className="text-base font-headline font-semibold text-on-surface mb-1">{title}</h3>}
      {description && <p className="text-sm text-on-surface-variant max-w-sm mb-4">{description}</p>}
      {action}
    </div>
  );
};

export default EmptyState;
