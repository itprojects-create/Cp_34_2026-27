import React, { useState } from 'react';

const Tabs = ({ tabs, defaultValue }) => {
  const [activeTab, setActiveTab] = useState(defaultValue || tabs[0].value);

  return (
    <div className="w-full">
      <div className="flex gap-1 overflow-x-auto border-b border-outline-variant" role="tablist">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.value;
          return (
            <button
              key={tab.value}
              role="tab"
              aria-selected={isActive}
              onClick={() => setActiveTab(tab.value)}
              className={`px-4 md:px-5 py-3 font-medium text-sm whitespace-nowrap border-b-2 transition-colors ${
                isActive 
                  ? 'border-primary text-primary' 
                  : 'border-transparent text-on-surface-variant hover:text-on-surface hover:border-outline-variant'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>
      <div className="py-6">
        {tabs.find((tab) => tab.value === activeTab)?.content}
      </div>
    </div>
  );
};

export default Tabs;
