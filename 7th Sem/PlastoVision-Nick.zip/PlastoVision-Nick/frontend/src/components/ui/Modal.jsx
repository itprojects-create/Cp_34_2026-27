import React, { useEffect } from 'react';
import { X } from 'lucide-react';
import Button from './Button';

const Modal = ({ isOpen, onClose, title, children, footer, size = 'md' }) => {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const sizes = {
    full: "max-w-none h-[90vh]",
    large: "max-w-3xl",
    sm: "max-w-md",
    md: "max-w-lg",
    lg: "max-w-3xl",
    xl: "max-w-5xl",
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-navy/45 backdrop-blur-[2px] p-3 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby={title ? 'modal-title' : undefined}
    >
      <div 
        className={`bg-surface-container-lowest w-full rounded-2xl shadow-[var(--shadow-elevated)] flex flex-col max-h-[90vh] overflow-hidden border border-white/40 motion-safe:animate-[fadeIn_160ms_ease-out] ${sizes[size]}`}
      >
        <div className="flex items-center justify-between gap-4 px-5 md:px-6 py-4 border-b border-outline-variant">
          <h2 id="modal-title" className="font-headline font-semibold text-lg text-on-surface">{title}</h2>
          <Button variant="ghost" size="icon" onClick={onClose} icon={<X className="w-5 h-5" />} aria-label="Close" />
        </div>
        
        <div className="p-5 md:p-6 overflow-y-auto flex-1 text-on-surface">
          {children}
        </div>
        
        {footer && (
          <div className="px-5 md:px-6 py-4 border-t border-outline-variant bg-surface-container-low flex flex-wrap justify-end gap-3 rounded-b-2xl">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
};

export default Modal;
