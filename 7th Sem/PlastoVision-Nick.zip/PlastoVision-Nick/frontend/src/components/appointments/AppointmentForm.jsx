import React, { useState, useEffect } from 'react';
import Button from '../ui/Button';
import { getPatients } from '../../services/patientService';
import { Search, User, Calendar as CalendarIcon, Clock, FileText, AlertCircle } from 'lucide-react';

const APPOINTMENT_TYPES = [
  'Initial Consultation',
  'Follow-up',
  'Post-operative Checkup',
  'Pre-operative Consultation',
  'Surgery',
  'Rhinoplasty Consultation',
  'General Consultation',
  'Emergency',
  'Other'
];

const DOCTORS = [
  { id: 'dr-yogesh', name: 'Dr. Yogesh' },
  { id: 'dr-michaels', name: 'Dr. Michaels' },
  { id: 'dr-sarah-lee', name: 'Dr. Sarah Lee' },
];

const AppointmentForm = ({ onSubmit, onCancel, initialData = null, submitting = false }) => {
  const [formData, setFormData] = useState({
    patient_id: '',
    doctor_id: 'dr-yogesh',
    doctor_name: 'Dr. Yogesh',
    appointment_type: 'Initial Consultation',
    appointment_date: '',
    start_time: '',
    end_time: '',
    notes: '',
    status: 'Scheduled'
  });

  const [patients, setPatients] = useState([]);
  const [filteredPatients, setFilteredPatients] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showPatientDropdown, setShowPatientDropdown] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [loadingPatients, setLoadingPatients] = useState(false);
  const [errors, setErrors] = useState({});

  // Load patients on mount
  useEffect(() => {
    loadPatients();
  }, []);

  // Populate form with initial data (for editing)
  useEffect(() => {
    if (initialData) {
      setFormData({
        patient_id: initialData.patient_id || '',
        doctor_id: initialData.doctor_id || 'dr-yogesh',
        doctor_name: initialData.doctor_name || 'Dr. Yogesh',
        appointment_type: initialData.appointment_type || 'Initial Consultation',
        appointment_date: initialData.appointment_date || '',
        start_time: initialData.start_time || '',
        end_time: initialData.end_time || '',
        notes: initialData.notes || '',
        status: initialData.status || 'Scheduled'
      });

      if (initialData.patients) {
        setSelectedPatient(initialData.patients);
        setSearchTerm(`${initialData.patients.first_name} ${initialData.patients.last_name}`);
      }
    }
  }, [initialData]);

  // Auto-calculate end time based on appointment type
  useEffect(() => {
    if (formData.start_time && formData.appointment_type) {
      const defaultDurations = {
        'Initial Consultation': 60,
        'Follow-up': 30,
        'Post-operative Checkup': 30,
        'Pre-operative Consultation': 45,
        'Surgery': 120,
        'Rhinoplasty Consultation': 60,
        'General Consultation': 30,
        'Emergency': 60,
        'Other': 30
      };

      const duration = defaultDurations[formData.appointment_type] || 30;
      const [hours, minutes] = formData.start_time.split(':');
      const startDate = new Date();
      startDate.setHours(parseInt(hours), parseInt(minutes), 0);
      startDate.setMinutes(startDate.getMinutes() + duration);

      const endTime = `${String(startDate.getHours()).padStart(2, '0')}:${String(startDate.getMinutes()).padStart(2, '0')}`;
      setFormData(prev => ({ ...prev, end_time: endTime }));
    }
  }, [formData.start_time, formData.appointment_type]);

  const loadPatients = async () => {
    setLoadingPatients(true);
    const { data, error } = await getPatients();
    if (!error && data) {
      setPatients(data);
      setFilteredPatients(data);
    }
    setLoadingPatients(false);
  };

  const handleSearchChange = (e) => {
    const value = e.target.value;
    setSearchTerm(value);
    setShowPatientDropdown(true);

    if (value.trim() === '') {
      setFilteredPatients(patients);
      setSelectedPatient(null);
      setFormData(prev => ({ ...prev, patient_id: '' }));
    } else {
      const filtered = patients.filter(p => {
        const fullName = `${p.first_name} ${p.last_name}`.toLowerCase();
        const code = p.patient_code?.toLowerCase() || '';
        const phone = p.phone?.toLowerCase() || '';
        return fullName.includes(value.toLowerCase()) ||
               code.includes(value.toLowerCase()) ||
               phone.includes(value.toLowerCase());
      });
      setFilteredPatients(filtered);
    }
  };

  const handlePatientSelect = (patient) => {
    setSelectedPatient(patient);
    setSearchTerm(`${patient.first_name} ${patient.last_name}`);
    setFormData(prev => ({ ...prev, patient_id: patient.id }));
    setShowPatientDropdown(false);
    setErrors(prev => ({ ...prev, patient_id: '' }));
  };

  const handleDoctorChange = (e) => {
    const doctorId = e.target.value;
    const doctor = DOCTORS.find(d => d.id === doctorId);
    setFormData(prev => ({
      ...prev,
      doctor_id: doctorId,
      doctor_name: doctor?.name || doctorId
    }));
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    setErrors(prev => ({ ...prev, [name]: '' }));
  };

  const validate = () => {
    const newErrors = {};

    if (!formData.patient_id) {
      newErrors.patient_id = 'Please select a patient';
    }
    if (!formData.doctor_id) {
      newErrors.doctor_id = 'Please select a doctor';
    }
    if (!formData.appointment_type) {
      newErrors.appointment_type = 'Please select appointment type';
    }
    if (!formData.appointment_date) {
      newErrors.appointment_date = 'Please select a date';
    }
    if (!formData.start_time) {
      newErrors.start_time = 'Please select start time';
    }
    if (!formData.end_time) {
      newErrors.end_time = 'Please select end time';
    }

    // Validate end time is after start time
    if (formData.start_time && formData.end_time) {
      if (formData.end_time <= formData.start_time) {
        newErrors.end_time = 'End time must be after start time';
      }
    }

    // Validate date is not in the past (for new appointments)
    if (!initialData && formData.appointment_date) {
      const today = new Date().toISOString().split('T')[0];
      if (formData.appointment_date < today) {
        newErrors.appointment_date = 'Cannot schedule appointments in the past';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      onSubmit(formData);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Patient Selection */}
      <div className="space-y-1.5">
        <label className="text-sm font-medium text-on-surface flex items-center gap-2">
          <User className="w-4 h-4" />
          Patient *
        </label>
        <div className="relative">
          <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant" />
          <input
            type="text"
            value={searchTerm}
            onChange={handleSearchChange}
            onFocus={() => setShowPatientDropdown(true)}
            className={`w-full pl-10 pr-3 py-2 border rounded-lg focus:outline-none focus:border-primary bg-surface-container-low text-sm ${
              errors.patient_id ? 'border-error' : 'border-outline-variant'
            }`}
            placeholder="Search patient by name, ID, or phone..."
            disabled={loadingPatients}
          />
          
          {showPatientDropdown && filteredPatients.length > 0 && (
            <div className="absolute z-50 w-full mt-1 bg-surface-container-lowest border border-outline-variant rounded-lg shadow-lg max-h-60 overflow-y-auto">
              {filteredPatients.map(patient => (
                <div
                  key={patient.id}
                  onClick={() => handlePatientSelect(patient)}
                  className="px-4 py-3 hover:bg-surface-container cursor-pointer border-b border-outline-variant last:border-b-0"
                >
                  <div className="font-medium text-on-surface">
                    {patient.first_name} {patient.last_name}
                  </div>
                  <div className="text-xs text-on-surface-variant mt-0.5 flex gap-3">
                    <span className="font-mono">{patient.patient_code}</span>
                    {patient.phone && <span>{patient.phone}</span>}
                  </div>
                </div>
              ))}
            </div>
          )}
          
          {selectedPatient && (
            <div className="mt-2 p-3 bg-primary/5 border border-primary/20 rounded-lg">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-primary-container text-primary flex items-center justify-center font-bold text-xs">
                  {selectedPatient.first_name[0]}{selectedPatient.last_name[0]}
                </div>
                <div>
                  <div className="font-medium text-sm">{selectedPatient.first_name} {selectedPatient.last_name}</div>
                  <div className="text-xs text-on-surface-variant">{selectedPatient.patient_code}</div>
                </div>
              </div>
            </div>
          )}
        </div>
        {errors.patient_id && (
          <p className="text-xs text-error flex items-center gap-1 mt-1">
            <AlertCircle className="w-3 h-3" />
            {errors.patient_id}
          </p>
        )}
      </div>

      {/* Doctor Selection */}
      <div className="space-y-1.5">
        <label className="text-sm font-medium text-on-surface">Doctor *</label>
        <select
          name="doctor_id"
          value={formData.doctor_id}
          onChange={handleDoctorChange}
          className={`w-full px-3 py-2 bg-surface text-on-surface border rounded-lg focus:outline-none focus:border-primary text-sm ${
            errors.doctor_id ? 'border-error' : 'border-outline-variant'
          }`}
        >
          {DOCTORS.map(doctor => (
            <option key={doctor.id} value={doctor.id}>{doctor.name}</option>
          ))}
        </select>
        {errors.doctor_id && (
          <p className="text-xs text-error flex items-center gap-1 mt-1">
            <AlertCircle className="w-3 h-3" />
            {errors.doctor_id}
          </p>
        )}
      </div>

      {/* Appointment Type */}
      <div className="space-y-1.5">
        <label className="text-sm font-medium text-on-surface">Appointment Type *</label>
        <select
          name="appointment_type"
          value={formData.appointment_type}
          onChange={handleInputChange}
          className={`w-full px-3 py-2 bg-surface text-on-surface border rounded-lg focus:outline-none focus:border-primary text-sm ${
            errors.appointment_type ? 'border-error' : 'border-outline-variant'
          }`}
        >
          {APPOINTMENT_TYPES.map(type => (
            <option key={type} value={type}>{type}</option>
          ))}
        </select>
        {errors.appointment_type && (
          <p className="text-xs text-error flex items-center gap-1 mt-1">
            <AlertCircle className="w-3 h-3" />
            {errors.appointment_type}
          </p>
        )}
      </div>

      {/* Date and Time */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="space-y-1.5">
          <label className="text-sm font-medium text-on-surface flex items-center gap-2">
            <CalendarIcon className="w-4 h-4" />
            Date *
          </label>
          <input
            type="date"
            name="appointment_date"
            value={formData.appointment_date}
            onChange={handleInputChange}
            className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:border-primary text-sm bg-surface-container-lowest ${
              errors.appointment_date ? 'border-error' : 'border-outline-variant'
            }`}
          />
          {errors.appointment_date && (
            <p className="text-xs text-error flex items-center gap-1 mt-1">
              <AlertCircle className="w-3 h-3" />
              {errors.appointment_date}
            </p>
          )}
        </div>

        <div className="space-y-1.5">
          <label className="text-sm font-medium text-on-surface flex items-center gap-2">
            <Clock className="w-4 h-4" />
            Start Time *
          </label>
          <input
            type="time"
            name="start_time"
            value={formData.start_time}
            onChange={handleInputChange}
            className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:border-primary text-sm bg-surface-container-lowest ${
              errors.start_time ? 'border-error' : 'border-outline-variant'
            }`}
          />
          {errors.start_time && (
            <p className="text-xs text-error flex items-center gap-1 mt-1">
              <AlertCircle className="w-3 h-3" />
              {errors.start_time}
            </p>
          )}
        </div>

        <div className="space-y-1.5">
          <label className="text-sm font-medium text-on-surface flex items-center gap-2">
            <Clock className="w-4 h-4" />
            End Time *
          </label>
          <input
            type="time"
            name="end_time"
            value={formData.end_time}
            onChange={handleInputChange}
            className={`w-full px-3 py-2 border rounded-lg focus:outline-none focus:border-primary text-sm bg-surface-container-lowest ${
              errors.end_time ? 'border-error' : 'border-outline-variant'
            }`}
          />
          {errors.end_time && (
            <p className="text-xs text-error flex items-center gap-1 mt-1">
              <AlertCircle className="w-3 h-3" />
              {errors.end_time}
            </p>
          )}
        </div>
      </div>

      {/* Notes */}
      <div className="space-y-1.5">
        <label className="text-sm font-medium text-on-surface flex items-center gap-2">
          <FileText className="w-4 h-4" />
          Notes (Optional)
        </label>
        <textarea
          name="notes"
          value={formData.notes}
          onChange={handleInputChange}
          rows="3"
          className="w-full px-3 py-2 border border-outline-variant rounded-lg focus:outline-none focus:border-primary text-sm bg-surface-container-lowest"
          placeholder="Add any additional notes or special instructions..."
        />
      </div>

      {/* Form Actions */}
      <div className="flex justify-end gap-3 pt-4 border-t border-outline-variant">
        <Button
          type="button"
          variant="ghost"
          onClick={onCancel}
          disabled={submitting}
        >
          Cancel
        </Button>
        <Button
          type="submit"
          disabled={submitting}
        >
          {submitting ? 'Saving...' : (initialData ? 'Update Appointment' : 'Book Appointment')}
        </Button>
      </div>
    </form>
  );
};

export default AppointmentForm;
