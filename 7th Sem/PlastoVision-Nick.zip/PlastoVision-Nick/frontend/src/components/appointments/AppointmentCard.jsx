import React from 'react';
import { Clock, User, Calendar as CalendarIcon } from 'lucide-react';
import { formatTime, formatDate, getStatusColor, getTypeColor } from '../../services/appointmentService';

const AppointmentCard = ({ appointment, onClick, compact = false }) => {
  const patientName = appointment.patients 
    ? `${appointment.patients.first_name} ${appointment.patients.last_name}`
    : 'Unknown Patient';

  if (compact) {
    return (
      <div
        onClick={onClick}
        className="flex items-start gap-3 p-3 border-l-2 border-primary hover:bg-surface-container-low transition-colors cursor-pointer rounded-r-xl"
      >
        <div className="flex-1">
          <p className="text-sm font-bold text-on-surface">{formatTime(appointment.start_time)}</p>
          <p className="text-sm text-on-surface-variant mt-0.5">{patientName}</p>
          <div className="flex items-center gap-2 mt-1">
            <span className={`text-xs px-2 py-0.5 rounded ${getTypeColor(appointment.appointment_type)}`}>
              {appointment.appointment_type}
            </span>
            <span className={`text-xs px-2 py-0.5 rounded ${getStatusColor(appointment.status)}`}>
              {appointment.status}
            </span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      onClick={onClick}
      className="p-4 border border-outline-variant rounded-2xl hover:bg-surface-container-low hover:border-primary/30 hover:shadow-[var(--shadow-card)] transition-all cursor-pointer group"
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-primary-container text-primary flex items-center justify-center font-bold text-sm">
            {appointment.patients?.first_name?.[0]}{appointment.patients?.last_name?.[0]}
          </div>
          <div>
            <h4 className="font-bold text-on-surface group-hover:text-primary transition-colors">
              {patientName}
            </h4>
            <p className="text-xs text-on-surface-variant font-mono">
              {appointment.patients?.patient_code}
            </p>
          </div>
        </div>
        <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${getStatusColor(appointment.status)}`}>
          {appointment.status}
        </span>
      </div>

      <div className="space-y-2 text-sm text-on-surface-variant">
        <div className="flex items-center gap-2">
          <CalendarIcon className="w-4 h-4" />
          <span>{formatDate(appointment.appointment_date)}</span>
        </div>
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4" />
          <span>{formatTime(appointment.start_time)} - {formatTime(appointment.end_time)}</span>
        </div>
        <div className="flex items-center gap-2">
          <User className="w-4 h-4" />
          <span>{appointment.doctor_name}</span>
        </div>
      </div>

      <div className="mt-3 pt-3 border-t border-outline-variant">
        <span className={`inline-flex items-center px-2.5 py-1 rounded text-xs font-medium ${getTypeColor(appointment.appointment_type)}`}>
          {appointment.appointment_type}
        </span>
      </div>
    </div>
  );
};

export default AppointmentCard;
