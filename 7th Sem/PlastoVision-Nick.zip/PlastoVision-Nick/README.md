# PlastoVision 📸

<div align="center">

![PlastoVision Banner](https://img.shields.io/badge/PlastoVision-Medical%20Photography%20System-blue?style=for-the-badge)

[![React](https://img.shields.io/badge/React-19-61DAFB?logo=react&logoColor=white)](https://reactjs.org/)
[![Node.js](https://img.shields.io/badge/Node.js-16+-339933?logo=node.js&logoColor=white)](https://nodejs.org/)
[![Python](https://img.shields.io/badge/Python-3.9+-3776AB?logo=python&logoColor=white)](https://www.python.org/)
[![PostgreSQL](https://img.shields.io/badge/PostgreSQL-15-4169E1?logo=postgresql&logoColor=white)](https://www.postgresql.org/)
[![License](https://img.shields.io/badge/License-Academic-green)](LICENSE)

**AI-Powered Standardized Clinical Facial Photography for Plastic Surgery**

[Features](#-key-features) • [Architecture](#-system-architecture) • [Installation](#-installation--setup) • [Demo](#-screenshots--demo) • [Documentation](#-documentation)

</div>

---

## 📋 Table of Contents

- [Overview](#-overview)
- [Key Features](#-key-features)
- [Unique Innovations](#-unique-innovations)
- [Tech Stack](#-tech-stack)
- [System Architecture](#-system-architecture)
- [How It Works](#-how-it-works)
- [Installation & Setup](#-installation--setup)
- [Project Structure](#-project-structure)
- [Screenshots & Demo](#-screenshots--demo)
- [Current Status](#-current-status--limitations)
- [Future Enhancements](#-future-enhancements)
- [Documentation](#-documentation)
- [Contributing](#-contributing)
- [License](#-license)
- [Disclaimer](#️-disclaimer)

---

## 🎯 Overview

**PlastoVision** is a comprehensive patient management and standardized clinical facial photography system designed specifically for plastic surgery practices. It integrates advanced computer vision with traditional patient records to solve a critical challenge: **capturing consistent, high-quality before/after photographs** that meet medical documentation standards.

### The Problem

Traditional medical photography relies on manual techniques, resulting in:
- ❌ Inconsistent camera angles and patient positioning
- ❌ Time-consuming retakes and quality reviews
- ❌ Difficulty comparing photos across different time periods
- ❌ Lack of standardization between practices
- ❌ High training requirements for new staff

### The Solution

PlastoVision provides **real-time computer vision guidance** during photo capture, automatically validating facial pose angles, image quality, and view classification. It enforces a standardized six-view photography protocol while managing complete patient records, appointments, and treatment timelines.

---

## ✨ Key Features

### 📸 **Intelligent Facial Photography**

- **Six-View Standardized Protocol**
  - Frontal Neutral (0° yaw)
  - Right & Left Oblique 45° (40-50° yaw)
  - Right & Left Lateral Profile (85-95° yaw)
  - Basal/Bottom View (anatomical validation)

- **Real-Time Computer Vision Validation**
  - 468-point facial landmark detection (MediaPipe)
  - 3D head pose estimation (OpenCV solvePnP)
  - Automatic yaw/pitch/roll angle calculation
  - Blur detection (Laplacian variance)
  - Exposure analysis (brightness histogram)
  - Face clipping detection
  - Gaze direction validation

- **Live Camera Guidance** ⭐
  - 8 FPS real-time feedback
  - Colored border indicators (🔴 Red → 🟡 Yellow → 🟢 Green)
  - Dynamic text instructions ("Turn left", "Tilt chin up", "Perfect!")
  - Pose angle overlay (live yaw/pitch/roll display)
  - Automatic capture with stability timer (experimental)
  - Manual capture fallback

- **Photo Approval Workflow**
  - Auto-approved (meets all standards)
  - Review required (acceptable quality, requires clinician confirmation)
  - Must retake (fails quality standards)
  - Clinician override tracking with audit trail

### 📊 **Comprehensive Patient Management**

- **Patient Records**
  - Complete demographic information
  - Medical history and allergies
  - Auto-generated patient codes (P-XXXXX format)
  - Search and filter capabilities

- **Visit History**
  - Detailed visit notes and diagnosis
  - Treatment plans and doctor notes
  - Follow-up date tracking
  - Timeline visualization

- **Appointment Scheduling**
  - Conflict detection
  - Multiple appointment types
  - Status tracking (Scheduled/Confirmed/Cancelled/Completed)
  - Calendar integration

- **Document Management**
  - Secure file uploads (Supabase Storage)
  - Multiple file type support (PDF, images, documents)
  - File preview and download

### 🔍 **Advanced Photo Analysis**

- **Photo Timeline Organization**
  - Grouped by treatment stage (Baseline, 1 Month, 6 Months, 12 Months, etc.)
  - Six-view grid per stage
  - Completion tracking (e.g., "4/6 views captured")
  - Visual progress tracking

- **Three-Mode Photo Comparison** 🔥
  - **Side-by-Side:** Compare photos with synchronized zoom
  - **Slider:** Interactive reveal with draggable handle
  - **Overlay:** Adjustable opacity blending (0-100%)
  - Zoom (50-200%) and pan controls
  - Before/after labeling with dates

### 🔐 **Security & Privacy**

- **Local-First Architecture**
  - High-resolution photos stored locally (never uploaded to cloud)
  - Only metadata stored in cloud database
  - Full data residency control

- **Four-Layer Storage Security**
  - Path sanitization (blocks directory traversal)
  - Component validation
  - Real path verification (symlink protection)
  - Restrictive permissions (0o600 files, 0o700 directories)

- **Data Integrity**
  - SHA-256 checksum verification
  - Idempotent uploads (network retry safety)
  - Foreign key constraints and cascade deletes

---

## 🚀 Unique Innovations

PlastoVision stands out from traditional patient management systems through several technical innovations:

### 1. **Real-Time Pose Estimation for Medical Photography** ⭐⭐⭐⭐⭐

First system to integrate 3D facial pose estimation (OpenCV solvePnP) into live medical photography guidance. Calculates precise yaw/pitch/roll angles in real-time (8 FPS) to guide users toward standardized views.

**Technical Sophistication:**
- Custom 3D canonical face model (68 key landmarks from 468-point mesh)
- Perspective-n-Point algorithm with iterative optimization
- Rotation matrix to Euler angle conversion
- View-specific angle tolerances

### 2. **Anatomical Evidence-Based View Validation** ⭐⭐⭐⭐

Goes beyond simple angle checking by validating anatomical features:
- Columella visibility (nasal tip position relative to eyes)
- Nostril prominence (width measurement)
- Face ellipse orientation (height vs width ratio)
- Multi-check validation (requires 3/5 checks to pass)

**Why It Matters:** Pose estimation can be unreliable at extreme angles. Anatomical evidence provides ground truth.

### 3. **Hybrid Local-Cloud Architecture** ⭐⭐⭐⭐

Unique storage design: high-resolution images stay local, metadata syncs to cloud.

**Benefits:**
- Patient photos never leave doctor's control (privacy compliance)
- Remote database access for metadata (convenience)
- Backup responsibility remains with clinic
- No vendor lock-in for sensitive image data

### 4. **Idempotent Upload System** ⭐⭐⭐⭐

Network-resilient design with SHA-256 request fingerprinting:
- Detects duplicate uploads from network failures
- Allows safe retries without creating duplicates
- Collision detection (same ID, different content)

**Why It Matters:** Medical records must be reliable. Network failures are common. This ensures exactly-once semantics.

### 5. **Four-Layer Path Security** ⭐⭐⭐⭐

Defense-in-depth security for local photo storage:
1. **Path Sanitization** → Rejects `../`, absolute paths, null bytes
2. **Component Validation** → Checks each path segment
3. **Real Path Verification** → Resolves symlinks, ensures within base directory
4. **Permission Enforcement** → Owner-only read/write

**Protection Against:** Directory traversal, symlink attacks, race conditions, unauthorized access

---

## 🛠 Tech Stack

### **Frontend**
- **Framework:** React 19
- **Build Tool:** Vite 8
- **Styling:** Tailwind CSS 4
- **Routing:** React Router DOM 7
- **HTTP Client:** Axios
- **State Management:** React Hooks + Context API
- **UI Components:** Lucide React (icons)
- **Notifications:** React Hot Toast

### **Backend**
- **Runtime:** Node.js 16+
- **Framework:** Express.js 4
- **Database Client:** Supabase JS Client
- **File Upload:** Multer
- **Image Processing:** Sharp
- **Security:** Helmet, CORS
- **Logging:** Morgan
- **Validation:** Express Validator

### **Computer Vision Service**
- **Language:** Python 3.9+
- **Framework:** Flask 3
- **Face Detection:** MediaPipe 0.10.9
- **Image Processing:** OpenCV 4.11
- **Numerical Computing:** NumPy 1.24.3
- **Additional:** Pillow, python-dotenv

### **Database & Storage**
- **Database:** PostgreSQL 15 (Supabase)
- **Cloud Storage:** Supabase Storage (documents only)
- **Local Storage:** Node.js `fs` module (photos)
- **Migrations:** SQL migration files (9 migrations)

### **Testing**
- **Backend:** Jest + Supertest (~38 tests)
- **Python CV:** Pytest (~64 tests)
- **Coverage:** ~40% backend, ~70% Python CV

---

## 🏗 System Architecture

```mermaid
graph TB
    subgraph "Frontend - React SPA"
        UI[User Interface<br/>React 19 + Tailwind]
        Camera[Camera Capture<br/>WebRTC + Canvas]
        Timeline[Photo Timeline<br/>Comparison Tools]
    end

    subgraph "Backend - Express API"
        API[REST API<br/>Express.js]
        Upload[Photo Upload<br/>Multer + Validation]
        Storage[Local Storage Service<br/>4-Layer Security]
    end

    subgraph "Python CV Service"
        Flask[Flask API<br/>Port 5002]
        MediaPipe[MediaPipe Face Mesh<br/>468 Landmarks]
        OpenCV[OpenCV solvePnP<br/>Pose Estimation]
        Validator[View Validator<br/>Classification]
    end

    subgraph "Data Layer"
        DB[(PostgreSQL<br/>Supabase)]
        LocalFS[Local Filesystem<br/>Patient Photos]
        CloudStorage[Supabase Storage<br/>Documents]
    end

    UI -->|HTTP Requests| API
    Camera -->|Live Frames<br/>8 FPS| API
    Timeline -->|Photo Retrieval| API
    
    API -->|Photo Validation| Flask
    Upload -->|Store Images| Storage
    Storage -->|Write Files| LocalFS
    
    Flask --> MediaPipe
    MediaPipe --> OpenCV
    OpenCV --> Validator
    Validator -->|Results| Flask
    
    API -->|Metadata CRUD| DB
    API -->|Document Upload| CloudStorage
    DB -.->|References| LocalFS

    style UI fill:#61DAFB,stroke:#333,stroke-width:2px,color:#000
    style API fill:#68A063,stroke:#333,stroke-width:2px,color:#fff
    style Flask fill:#000,stroke:#333,stroke-width:2px,color:#fff
    style DB fill:#336791,stroke:#333,stroke-width:2px,color:#fff
    style LocalFS fill:#F7931E,stroke:#333,stroke-width:2px,color:#000
```

### **Data Flow: Live Camera Capture**

```
1. User opens camera capture interface
2. WebRTC streams video at 1080p
3. Frontend captures frame every 125ms (8 FPS)
4. Canvas converts frame to JPEG (480×360, 70% quality)
5. Base64-encoded frame sent to backend
6. Backend forwards to Python CV service
7. MediaPipe detects 468 facial landmarks
8. OpenCV calculates 3D pose (yaw, pitch, roll)
9. View validator classifies facial view
10. Image quality checks (blur, exposure, clipping)
11. Guidance engine generates feedback message
12. JSON response returns to backend
13. Backend returns to frontend
14. UI updates (<100ms total latency):
    - Colored border (red/yellow/green)
    - Text guidance ("Turn left 5°")
    - Pose angle overlay (Yaw: 2.3°, Pitch: -1.8°)
15. If stable for 1.5s → auto-capture (experimental)
16. Manual capture always available
17. Full validation on final capture
18. Photo saved locally with 4-layer security
19. Metadata inserted into PostgreSQL
20. UI displays approval decision
```

---

## 📥 Installation & Setup

### **Prerequisites**

- **Node.js** 16+ and npm ([Download](https://nodejs.org/))
- **Python** 3.9+ and pip ([Download](https://www.python.org/))
- **PostgreSQL** (via [Supabase](https://supabase.com) free tier)
- **Git** ([Download](https://git-scm.com/))

### **Step 1: Clone the Repository**

```bash
git clone https://github.com/yourusername/plastovision.git
cd plastovision
```

### **Step 2: Database Setup**

1. **Create a Supabase Project**
   - Go to [https://supabase.com](https://supabase.com)
   - Create a new project (free tier works)
   - Wait for initialization (~2 minutes)

2. **Run Database Migrations**
   - Navigate to **SQL Editor** in Supabase Dashboard
   - Run each migration file in order from `backend/supabase/migrations/`:
     ```
     000_combined_setup.sql        (core setup)
     001_create_patients_table.sql
     002_create_visits_table.sql
     003_create_medications_table.sql
     004_create_documents_table.sql
     005_create_appointments_table.sql
     006_create_settings_tables.sql
     007_create_patient_photos_table.sql
     008_standardized_capture.sql
     009_add_override_tracking.sql
     ```

3. **Create Storage Bucket**
   - Go to **Storage** in Supabase Dashboard
   - Create bucket: `patient-documents`
   - Set to **Public** (for development) or **Private** (for production)

4. **Get API Credentials**
   - Go to **Settings → API**
   - Copy **Project URL** and **anon/public key**

### **Step 3: Environment Configuration**

#### **Frontend Configuration**

Create `frontend/.env`:

```bash
# Supabase Configuration
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key-here

# Backend API URL
VITE_BACKEND_URL=http://localhost:3001
```

#### **Backend Configuration**

Create `backend/.env`:

```bash
# Server Configuration
PORT=3001
NODE_ENV=development

# Supabase Configuration
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your-anon-key-here
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key-here

# Local Storage Configuration
# Absolute path to photo storage directory
PHOTO_STORAGE_PATH=/absolute/path/to/plastovision/uploads

# Python CV Service Configuration
PYTHON_CV_SERVICE_URL=http://localhost:5002

# File Upload Limits
MAX_FILE_SIZE_MB=10
ALLOWED_MIME_TYPES=image/jpeg,image/jpg,image/png,image/webp

# CORS Configuration
CORS_ORIGINS=http://localhost:5173,http://localhost:3000

# Security
ENFORCE_HTTPS=false

# Logging
LOG_LEVEL=info
```

#### **Python CV Service Configuration**

Create `python-cv/.env`:

```bash
# Server Configuration
PORT=5002
HOST=0.0.0.0
DEBUG=False

# Processing Configuration
MAX_IMAGE_SIZE_MB=10
ENABLE_GPU=False
```

### **Step 4: Install Dependencies**

#### **Frontend**

```bash
cd frontend
npm install
```

#### **Backend**

```bash
cd backend
npm install
```

#### **Python CV Service**

```bash
cd python-cv
pip install -r requirements.txt
```

### **Step 5: Start All Services**

You need **three terminal windows**:

#### **Terminal 1: Frontend**

```bash
cd frontend
npm run dev
```

Frontend runs at: **http://localhost:5173**

#### **Terminal 2: Backend**

```bash
cd backend
npm run dev
```

Backend API runs at: **http://localhost:3001**

#### **Terminal 3: Python CV Service**

```bash
cd python-cv
python app.py
```

Python CV service runs at: **http://localhost:5002**

### **Step 6: Access the Application**

Open your browser and navigate to:

```
http://localhost:5173
```

You should see the PlastoVision dashboard. 🎉

### **Optional: Run Tests**

#### **Backend Tests**

```bash
cd backend
npm test
```

#### **Python CV Tests**

```bash
cd python-cv
pytest tests/ -v
```

---

## 📁 Project Structure

```
PlastoVision/
├── frontend/                 # React frontend application
│   ├── src/
│   │   ├── components/      # Reusable UI components
│   │   │   ├── layout/      # Navbar, Sidebar
│   │   │   ├── photos/      # Camera capture, timeline, comparison
│   │   │   └── ui/          # Button, Card, Modal, Table
│   │   ├── pages/           # Main application pages
│   │   │   ├── Dashboard.jsx
│   │   │   ├── Patients.jsx
│   │   │   ├── PatientProfile.jsx
│   │   │   ├── Appointments.jsx
│   │   │   ├── PhotoTracking.jsx
│   │   │   ├── Visualization.jsx
│   │   │   └── Settings.jsx
│   │   ├── routes/          # React Router configuration
│   │   ├── services/        # API service layer
│   │   ├── contexts/        # React Context (Toast, Auth)
│   │   ├── lib/             # Supabase client
│   │   └── main.jsx         # Application entry point
│   ├── package.json
│   └── vite.config.js
│
├── backend/                  # Express backend API
│   ├── config/
│   │   ├── supabase.js      # Supabase client configuration
│   │   └── facialViews.js   # Six-view definitions
│   ├── controllers/
│   │   └── patientPhotoController.js  # Photo API logic
│   ├── middleware/
│   │   ├── upload.js        # Multer file upload
│   │   ├── validation.js    # Request validation
│   │   ├── patientExists.js # Patient verification
│   │   └── photoAudit.js    # Audit logging
│   ├── routes/
│   │   └── patientPhotos.js # Photo API routes
│   ├── services/
│   │   ├── cvValidationService.js        # Python CV client
│   │   ├── localPhotoStorageService.js   # Local storage (4-layer security)
│   │   ├── photoMetadataService.js       # Metadata management
│   │   ├── photoReview.js                # Approval workflow
│   │   └── photoMetadataCompatibility.js # Schema evolution
│   ├── tests/               # Jest + Supertest tests
│   ├── supabase/migrations/ # SQL migration files (9 migrations)
│   ├── server.js            # Express server entry point
│   └── package.json
│
├── python-cv/                # Python computer vision service
│   ├── services/
│   │   ├── face_detection.py       # MediaPipe integration
│   │   ├── landmark_detection.py   # 468-point landmarks
│   │   ├── pose_estimation.py      # OpenCV solvePnP
│   │   ├── view_validator.py       # Six-view classification
│   │   ├── image_quality.py        # Blur & exposure checks
│   │   ├── eye_direction.py        # Gaze validation
│   │   ├── guidance_engine.py      # Dynamic feedback messages
│   │   ├── capture_acceptance.py   # Approval logic
│   │   ├── validation_pipeline.py  # Main validation orchestrator
│   │   └── camera_calibration.py   # Calibration utilities
│   ├── config/
│   │   └── protocol.py      # Validation thresholds
│   ├── tests/               # Pytest tests (64 tests)
│   ├── app.py               # Flask application
│   ├── requirements.txt
│   └── calibrate_camera.py  # Calibration script
│
├── uploads/                  # Local photo storage (created on first run)
├── docs/                     # Technical documentation
│   ├── LIVE_CAPTURE_REPORT.md
│   ├── PHASE_*_*.md         # Development phase reports
│   └── *.md                 # Additional documentation
├── Project_Overview/         # Comprehensive technical analysis (150+ pages)
│   ├── PLASTOVISION_TECHNICAL_OVERVIEW_SECTIONS_7-10.md
│   ├── PLASTOVISION_TECHNICAL_OVERVIEW_SECTIONS_11-13.md
│   ├── PLASTOVISION_TECHNICAL_OVERVIEW_SECTIONS_14-16.md
│   └── PLASTOVISION_TECHNICAL_OVERVIEW_SECTIONS_17-20.md
├── .gitignore
└── README.md                 # This file
```

---

## 🖼 Screenshots & Demo

> **Note:** Screenshots and demo videos to be added. Below are placeholders for key features.

### **Dashboard**
![Dashboard](docs/screenshots/dashboard.png)
*Main dashboard showing patient statistics, recent activity, and quick actions*

### **Live Camera Guidance**
![Live Guidance](docs/screenshots/live-guidance.png)
*Real-time facial pose guidance with colored borders and angle overlay*

### **Photo Timeline**
![Timeline](docs/screenshots/timeline.png)
*Photo timeline organized by treatment stage with completion tracking*

### **Photo Comparison (Side-by-Side)**
![Comparison](docs/screenshots/comparison-sidebyside.png)
*Before/after comparison with synchronized zoom controls*

### **Photo Comparison (Slider)**
![Slider](docs/screenshots/comparison-slider.png)
*Interactive slider comparison with draggable reveal*

### **Photo Comparison (Overlay)**
![Overlay](docs/screenshots/comparison-overlay.png)
*Overlay comparison with adjustable opacity blending*

### **Patient Profile**
![Patient Profile](docs/screenshots/patient-profile.png)
*Complete patient profile with demographics, visits, photos, and documents*

### **Appointment Scheduling**
![Appointments](docs/screenshots/appointments.png)
*Appointment calendar with conflict detection*

---

## 📊 Current Status & Limitations

### **✅ Fully Implemented Features**

| **Module** | **Completion** | **Status** |
|-----------|---------------|-----------|
| Patient Management | 100% | ✅ Production-Ready |
| Visit History | 100% | ✅ Production-Ready |
| Medication Tracking | 100% | ✅ Production-Ready |
| Document Management | 100% | ✅ Production-Ready |
| Appointment Scheduling | 91% | ✅ Mostly Complete |
| Photo Upload & Validation | 100% | ✅ Production-Ready |
| Live Camera Guidance | 90% | ⚠️ Manual Capture Ready |
| Photo Timeline | 100% | ✅ Production-Ready |
| Photo Comparison (3 modes) | 100% | ✅ Production-Ready |
| Approval Workflow | 100% | ✅ Production-Ready |

**Overall Completion: 81%**

### **⚠️ Experimental Features**

- **Auto-Capture:** Works for frontal and oblique views only. Lateral and basal views require manual capture button.
- **Stability Timer:** 1.5-second stability detection is functional but marked experimental.

### **🔴 Known Limitations**

1. **No Authentication System**
   - Status: Explicitly deferred
   - Impact: Suitable for single-clinician local deployment only
   - Not suitable for: Multi-user clinics, remote access

2. **Frontend Testing**
   - Status: 0% test coverage
   - Impact: Higher deployment risk for UI changes
   - Backend and Python CV have good test coverage

3. **Camera Calibration**
   - Status: Infrastructure exists, not enforced
   - Impact: Uses default camera parameters
   - Calibration profiles can be created but aren't required

4. **Clinical Validation**
   - Status: Thresholds are "provisional engineering values"
   - Impact: Not validated with clinical dataset
   - Requires medical professional review before clinical use

5. **HIPAA Compliance**
   - Status: Not compliant
   - Required for compliance: Authentication, encryption at rest, BAA, complete audit trail
   - Current: Suitable for academic/research use only

### **🚫 Not Implemented**

- Multi-user authentication and authorization
- Automated backup system
- DICOM export
- PDF report generation
- Batch photo operations
- Mobile camera integration
- 3D face reconstruction

### **Deployment Readiness**

| **Use Case** | **Status** |
|-------------|-----------|
| Development Demo | ✅ Ready |
| Academic Project Presentation | ✅ Ready |
| Supervised Prototype Testing | ⚠️ Conditional (IRB required, local only) |
| Clinical Deployment | 🔴 Not Ready (requires auth + HIPAA compliance) |

---

## 🔮 Future Enhancements

### **Phase 1: Production Essentials** (7 weeks)
- [ ] Authentication and authorization system
- [ ] Automated backup and disaster recovery
- [ ] Comprehensive frontend test suite
- [ ] Multi-user support

### **Phase 2: Feature Enhancements** (6 weeks)
- [ ] Enhanced auto-capture for lateral and basal views
- [ ] Camera calibration workflow and enforcement
- [ ] PDF report generation
- [ ] Contact sheet export

### **Phase 3: Mobile & Advanced** (10 weeks)
- [ ] Mobile device camera support (iOS/Android)
- [ ] Automated change highlighting (image registration)
- [ ] DICOM export for PACS integration
- [ ] Batch operations (download/delete multiple photos)

### **Phase 4: Research Features** (6+ months)
- [ ] Machine learning for view classification
- [ ] 3D face reconstruction from six views
- [ ] Quantitative outcome measurements
- [ ] Advanced analytics and reporting

**Estimated Development Time to Production-Ready:** ~3.5 months (Phases 1-2)

---

## 📚 Documentation

Comprehensive technical documentation is available in the `Project_Overview/` directory:

- **[Sections 7-10](Project_Overview/PLASTOVISION_TECHNICAL_OVERVIEW_SECTIONS_7-10.md):** System architecture, data model, API reference, workflows
- **[Sections 11-13](Project_Overview/PLASTOVISION_TECHNICAL_OVERVIEW_SECTIONS_11-13.md):** Computer vision pipeline, photo management, live capture implementation
- **[Sections 14-16](Project_Overview/PLASTOVISION_TECHNICAL_OVERVIEW_SECTIONS_14-16.md):** Security analysis, testing coverage, complete user journeys
- **[Sections 17-20](Project_Overview/PLASTOVISION_TECHNICAL_OVERVIEW_SECTIONS_17-20.md):** Project completion assessment, strengths, future opportunities, final summary

**Additional Documentation:**
- `docs/LIVE_CAPTURE_REPORT.md` - Live camera capture technical report
- `docs/PHASE_*_*.md` - Development phase reports
- `backend/supabase/migrations/` - Database schema documentation

**Total Documentation:** ~150 pages, ~50,000 words, 200+ code examples

---

## 🤝 Contributing

This is an academic/research project. Contributions are welcome for:

- Bug fixes and improvements
- Additional test coverage
- Documentation enhancements
- Feature suggestions

Please ensure any contributions:
- Include tests where applicable
- Follow existing code style and structure
- Update documentation as needed
- Do not include real patient data or credentials

---

## 📄 License

This project is developed as an academic capstone project. See [LICENSE](LICENSE) for details.

---

## ⚠️ Disclaimer

**PlastoVision is an academic/research prototype and is NOT:**

- ❌ A clinically validated medical device
- ❌ FDA-approved or CE-marked
- ❌ HIPAA-compliant (in current state)
- ❌ Intended for clinical decision-making
- ❌ A replacement for professional medical judgment

**Current Status:**
- ✅ Suitable for academic evaluation and demonstration
- ✅ Suitable for supervised research (with IRB approval)
- ✅ Technical proof-of-concept
- ❌ NOT suitable for production clinical deployment without significant additional work

**Before Clinical Use:**
- Implement authentication and authorization
- Obtain clinical validation with medical professionals
- Ensure HIPAA compliance
- Conduct user testing with actual clinicians
- Obtain appropriate regulatory approvals
- Implement automated backup and disaster recovery

**Privacy Note:**
- Photos are stored locally (not in cloud) by design
- No patient-identifying information should be committed to version control
- Always use test/synthetic data for development and demonstration

---

## 👥 Authors

**PlastoVision Team**
- Academic Institution: [Your University Name]
- Project Type: Capstone Project
- Year: 2026

---

## 🙏 Acknowledgments

- **MediaPipe** by Google for face detection and landmark extraction
- **OpenCV** for computer vision algorithms
- **Supabase** for backend-as-a-service platform
- **React** and **Tailwind CSS** communities for excellent tools
- **Academic advisors and plastic surgery consultants** for domain guidance

---

## 📞 Contact & Support

For questions, suggestions, or collaboration opportunities:

- **GitHub Issues:** [Create an issue](https://github.com/yourusername/plastovision/issues)
- **Email:** your.email@university.edu
- **Documentation:** See `Project_Overview/` directory

---

<div align="center">

**Built with ❤️ for advancing medical photography through artificial intelligence**

⭐ **Star this repo** if you find PlastoVision interesting or useful!

[⬆ Back to Top](#plastovision-)

</div>
