#!/usr/bin/env python3
"""
Basal View Diagnostic Visualization Tool

Overlays detected landmarks on test images to verify anatomical assumptions.
Shows which landmarks are being used for basal classification.

Usage:
    python tools/visualize_basal_landmarks.py <image_path>
"""

import sys
import os
import cv2
import numpy as np

# Add parent directory to path to import services
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from services.landmark_detection import LandmarkDetector
from services.face_detection import FaceDetector
from utils.image_utils import load_image_from_bytes


# Landmark indices used in basal validator
BASAL_LANDMARKS = {
    'nasal_base': 2,       # Currently claimed: "columella base" (INCORRECT)
    'nasal_tip': 4,        # Nose tip (pronasale) - CORRECT
    'left_nostril': 98,    # Currently claimed: "left nostril" (INCORRECT)
    'right_nostril': 327,  # Currently claimed: "right nostril" (INCORRECT)
    'nasal_bridge': 6,     # Nasal bridge - CORRECT
    'left_eye_center': 33, # Left eye outer corner
    'right_eye_center': 263, # Right eye outer corner
    'left_eyebrow': 70,    # Left eyebrow outer
    'right_eyebrow': 300,  # Right eyebrow outer
}

# CORRECT nose landmarks according to MediaPipe documentation
CORRECT_NOSE_LANDMARKS = {
    'columella': 1,        # Actual columella
    'subnasale': 2,        # Bottom center between nostrils
    'nose_tip': 4,         # Nose tip (pronasale)
    'nasal_bridge': 6,     # Nasal bridge
    'left_nostril_approx': [102, 49, 48, 115],  # Left nostril region
    'right_nostril_approx': [331, 279, 278, 344], # Right nostril region
    'left_alar': [129, 198, 217, 209, 131],  # Left nasal wing
    'right_alar': [358, 429, 437, 420, 360], # Right nasal wing
}


def visualize_landmarks(image_path, output_path=None):
    """
    Visualize basal validation landmarks on an image.
    
    Args:
        image_path: Path to input image
        output_path: Optional path to save annotated image
    """
    # Load image
    with open(image_path, 'rb') as f:
        image_bytes = f.read()
    
    image = load_image_from_bytes(image_bytes)
    height, width = image.shape[:2]
    
    # Create output image
    output = image.copy()
    
    # Detect face and landmarks
    face_detector = FaceDetector()
    landmark_detector = LandmarkDetector()
    
    face_result = face_detector.detect_faces(image)
    landmark_result = landmark_detector.detect_landmarks(image)
    
    print(f"\n{'='*80}")
    print(f"BASAL VIEW DIAGNOSTIC VISUALIZATION")
    print(f"{'='*80}")
    print(f"Image: {os.path.basename(image_path)}")
    print(f"Size: {width}x{height}")
    print(f"Face detected: {face_result['faces_detected']}")
    print(f"Landmarks detected: {landmark_result['landmarks_detected']}")
    print(f"Landmark count: {landmark_result['landmark_count']}")
    print(f"{'='*80}\n")
    
    if not landmark_result['landmarks_detected']:
        print("❌ No landmarks detected - cannot visualize")
        return
    
    landmarks_2d = landmark_result['landmarks_2d']
    
    # Draw all landmarks in light gray
    for i, (x, y) in enumerate(landmarks_2d):
        cv2.circle(output, (int(x), int(y)), 1, (200, 200, 200), -1)
    
    # Draw basal validation landmarks with labels
    print("LANDMARKS USED IN CURRENT BASAL VALIDATOR:")
    print("-" * 80)
    
    for name, idx in BASAL_LANDMARKS.items():
        if idx < len(landmarks_2d):
            x, y = landmarks_2d[idx]
            x, y = int(x), int(y)
            
            # Color code: red for incorrect, green for correct
            if name in ('nasal_base', 'left_nostril', 'right_nostril'):
                color = (0, 0, 255)  # Red - incorrect semantic meaning
                marker = 'X'
            else:
                color = (0, 255, 0)  # Green - correct
                marker = '✓'
            
            # Draw larger circle
            cv2.circle(output, (x, y), 5, color, 2)
            
            # Draw label
            label = f"{name}[{idx}]"
            cv2.putText(output, label, (x + 10, y - 10),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)
            
            print(f"{marker} [{idx:3d}] {name:20s} @ ({x:4d}, {y:4d})")
    
    print("\n" + "="*80)
    print("CORRECT NOSE LANDMARKS (MediaPipe Documentation):")
    print("-" * 80)
    
    # Draw correct nose landmarks
    for name, idx_or_list in CORRECT_NOSE_LANDMARKS.items():
        if isinstance(idx_or_list, list):
            # Region of multiple points
            for idx in idx_or_list:
                if idx < len(landmarks_2d):
                    x, y = landmarks_2d[idx]
                    cv2.circle(output, (int(x), int(y)), 3, (255, 0, 255), -1)
            print(f"✓ {name:20s} region: {idx_or_list}")
        else:
            # Single point
            if idx_or_list < len(landmarks_2d):
                x, y = landmarks_2d[idx_or_list]
                x, y = int(x), int(y)
                cv2.circle(output, (x, y), 5, (255, 165, 0), 2)
                label = f"{name}[{idx_or_list}]"
                cv2.putText(output, label, (x + 10, y + 20),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 165, 0), 1)
                print(f"✓ [{idx_or_list:3d}] {name:20s} @ ({x:4d}, {y:4d})")
    
    # Calculate and display current validator measurements
    print("\n" + "="*80)
    print("CURRENT VALIDATOR MEASUREMENTS:")
    print("-" * 80)
    
    nasal_base = landmarks_2d[2]
    nasal_tip = landmarks_2d[4]
    left_nostril = landmarks_2d[98]
    right_nostril = landmarks_2d[327]
    nasal_bridge = landmarks_2d[6]
    left_eye = landmarks_2d[33]
    right_eye = landmarks_2d[263]
    
    # CHECK 1: Columella visibility
    columella_check = nasal_base[1] > nasal_tip[1]
    print(f"CHECK 1 - Columella visible: {columella_check}")
    print(f"  Nasal base Y: {nasal_base[1]:.1f}")
    print(f"  Nasal tip Y:  {nasal_tip[1]:.1f}")
    print(f"  Interpretation: {'Subnasale below tip (normal anatomy)' if columella_check else 'Inverted'}")
    
    # CHECK 2: Nostril bilateral visibility
    nostrils_below_bridge = (left_nostril[1] > nasal_bridge[1] and 
                            right_nostril[1] > nasal_bridge[1])
    nostril_separation = abs(left_nostril[0] - right_nostril[0])
    face_width_approx = width * 0.25
    nostrils_separated = nostril_separation > face_width_approx * 0.3
    nostril_check = nostrils_below_bridge and nostrils_separated
    
    print(f"\nCHECK 2 - Nostril bilateral: {nostril_check}")
    print(f"  Below bridge: {nostrils_below_bridge}")
    print(f"  Separation: {nostril_separation:.1f}px (threshold: {face_width_approx * 0.3:.1f}px)")
    print(f"  ⚠️  WARNING: Using landmarks 98/327 which are NOT nostril openings")
    
    # CHECK 3: Nasal tip position
    eye_level_y = (left_eye[1] + right_eye[1]) / 2
    nasal_tip_above_eyes = nasal_tip[1] < eye_level_y - (height * 0.02)
    
    print(f"\nCHECK 3 - Nasal tip above eyes: {nasal_tip_above_eyes}")
    print(f"  Nasal tip Y: {nasal_tip[1]:.1f}")
    print(f"  Eye level Y: {eye_level_y:.1f}")
    print(f"  Threshold: {eye_level_y - height * 0.02:.1f}")
    
    # CHECK 4: Nostril-eye proximity ratio
    nostril_y_avg = (left_nostril[1] + right_nostril[1]) / 2
    nostril_to_eye_dist = abs(nostril_y_avg - eye_level_y)
    nasal_base_to_tip_dist = abs(nasal_base[1] - nasal_tip[1])
    
    if nasal_base_to_tip_dist > 10:
        ratio = nostril_to_eye_dist / nasal_base_to_tip_dist
        ratio_check = ratio < 3.0
    else:
        ratio = None
        ratio_check = False
    
    print(f"\nCHECK 4 - Nostril-eye ratio: {ratio_check}")
    if ratio is not None:
        print(f"  Ratio: {ratio:.2f}")
    else:
        print(f"  Ratio: N/A")
    print(f"  Nostril to eye: {nostril_to_eye_dist:.1f}px")
    print(f"  Nasal base to tip: {nasal_base_to_tip_dist:.1f}px")
    
    # Calculate evidence
    evidence = sum([columella_check, nostril_check, nasal_tip_above_eyes, ratio_check])
    print(f"\n" + "="*80)
    print(f"EVIDENCE SCORE: {evidence}/4 (excluding pitch check)")
    print(f"THRESHOLD: 3/5 for 'probable basal'")
    print(f"RESULT: {'WOULD BE CLASSIFIED AS BASAL' if evidence >= 3 else 'Would be rejected'}")
    print(f"="*80 + "\n")
    
    # Add legend
    legend_y = 30
    cv2.putText(output, "Legend:", (10, legend_y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
    cv2.putText(output, "Red X = Incorrect landmark usage", (10, legend_y + 25),
               cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 255), 1)
    cv2.putText(output, "Green = Correct usage", (10, legend_y + 50),
               cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 0), 1)
    cv2.putText(output, "Orange = Correct nose landmarks", (10, legend_y + 75),
               cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 165, 0), 1)
    cv2.putText(output, "Magenta dots = Nostril regions", (10, legend_y + 100),
               cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 0, 255), 1)
    
    # Save or display
    if output_path:
        cv2.imwrite(output_path, output)
        print(f"✓ Saved annotated image to: {output_path}")
    else:
        # Display
        cv2.imshow("Basal Landmark Diagnostic", output)
        print("Press any key to close...")
        cv2.waitKey(0)
        cv2.destroyAllWindows()


def main():
    if len(sys.argv) < 2:
        print("Usage: python visualize_basal_landmarks.py <image_path> [output_path]")
        print("\nExample:")
        print("  python tools/visualize_basal_landmarks.py backend/uploads/basal_test.jpg")
        print("  python tools/visualize_basal_landmarks.py test.jpg debug_output.jpg")
        sys.exit(1)
    
    image_path = sys.argv[1]
    output_path = sys.argv[2] if len(sys.argv) > 2 else None
    
    if not os.path.exists(image_path):
        print(f"❌ Error: Image not found: {image_path}")
        sys.exit(1)
    
    visualize_landmarks(image_path, output_path)


if __name__ == "__main__":
    main()
