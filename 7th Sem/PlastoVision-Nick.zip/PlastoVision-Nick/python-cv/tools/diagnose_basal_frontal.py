#!/usr/bin/env python3
"""
Basal vs Frontal Diagnostic Tool

Analyzes why the classifier chooses frontal or basal for a given image.
Shows both hypotheses and discriminating features.

Usage:
    python tools/diagnose_basal_frontal.py <image_path>
"""

import sys
import os
import cv2
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from services.landmark_detection import LandmarkDetector
from services.face_detection import FaceDetector
from services.validation_pipeline import ValidationPipeline
from utils.image_utils import load_image_from_bytes


def diagnose_basal_frontal(image_path):
    """
    Comprehensive diagnostic analysis of basal vs frontal classification.
    """
    # Load image
    with open(image_path, 'rb') as f:
        image_bytes = f.read()
    
    image = load_image_from_bytes(image_bytes)
    height, width = image.shape[:2]
    
    print(f"\n{'='*80}")
    print(f"BASAL VS FRONTAL CLASSIFICATION DIAGNOSTIC")
    print(f"{'='*80}")
    print(f"Image: {os.path.basename(image_path)}")
    print(f"Size: {width}x{height}")
    print(f"{'='*80}\n")
    
    # Detect landmarks
    landmark_detector = LandmarkDetector()
    landmark_result = landmark_detector.detect_landmarks(image)
    
    if not landmark_result['landmarks_detected']:
        print("❌ No landmarks detected - cannot classify")
        return
    
    landmarks_2d = landmark_result['landmarks_2d']
    print(f"✓ Landmarks detected: {landmark_result['landmark_count']}")
    
    # Create validator
    validator = ValidationPipeline()
    
    # Get reference measurements
    refs = validator._calculate_face_reference_measurements(landmarks_2d)
    
    if refs is None:
        print("❌ Cannot calculate reference measurements")
        return
    
    print(f"\n{'='*80}")
    print("REFERENCE MEASUREMENTS")
    print(f"{'='*80}")
    print(f"Inter-pupillary distance: {refs['inter_pupillary_distance']:.1f}px")
    print(f"Face width: {refs['face_width']:.1f}px")
    print(f"Face height: {refs['face_height']:.1f}px")
    print(f"Eye level Y: {refs['eye_level_y']:.1f}px")
    
    # Evaluate frontal hypothesis
    print(f"\n{'='*80}")
    print("HYPOTHESIS 1: NEUTRAL FRONTAL VIEWPOINT")
    print(f"{'='*80}")
    
    frontal_check = validator._detect_frontal_indicators(landmarks_2d, width, height)
    
    print(f"Detected: {frontal_check['frontal_detected']}")
    print(f"Confidence: {frontal_check['confidence']}")
    print(f"Contradicts basal: {frontal_check['contradictory_basal']}")
    
    print(f"\nHorizontal alignment features (NOT discriminative):")
    if frontal_check.get('alignment_only'):
        for item in frontal_check['alignment_only']:
            print(f"  ▸ {item}")
    else:
        print(f"  (none detected)")
    
    print(f"\nVertical viewpoint features (discriminative):")
    if frontal_check['evidence']:
        for item in frontal_check['evidence']:
            # Check if this is a discriminative feature
            if any(kw in item for kw in ['below eye', 'forehead', 'chin-to-nose', 'nostril', 'nasal bridge']):
                print(f"  ✓ {item}")
            else:
                print(f"  ▸ {item}")
    else:
        print(f"  (no vertical indicators detected)")
    
    # Evaluate basal hypothesis
    print(f"\n{'='*80}")
    print("HYPOTHESIS 2: BASAL VIEWPOINT (HEAD EXTENDED)")
    print(f"{'='*80}")
    
    basal_check = validator._validate_basal_viewpoint(landmarks_2d, width, height, None, None, None)
    
    print(f"Detected: {basal_check['basal_viewpoint_detected']}")
    print(f"Confidence: {basal_check['confidence']}")
    print(f"\nAnatomical features:")
    print(f"  Columella visible: {basal_check['columella_visible']}")
    print(f"  Nostrils bilateral: {basal_check['nostril_underside_bilateral']}")
    print(f"  Nasal tip position: {basal_check['nasal_tip_position']}")
    print(f"  Camera orientation: {basal_check['camera_orientation_verified']}")
    print(f"\nReasoning:")
    print(f"  {basal_check['reasoning']}")
    
    # Final decision
    print(f"\n{'='*80}")
    print("CLASSIFICATION DECISION")
    print(f"{'='*80}")
    
    # Apply decision logic
    if (frontal_check['contradictory_basal'] and 
        frontal_check['confidence'] in ('confident', 'probable') and
        not basal_check['basal_viewpoint_detected']):
        
        decision = "FRONTAL_NEUTRAL"
        confidence = frontal_check['confidence']
        reason = "Strong neutral frontal vertical indicators + no basal evidence"
        
    elif basal_check['basal_viewpoint_detected']:
        decision = "BASAL"
        confidence = basal_check['confidence']
        if frontal_check['contradictory_basal']:
            reason = "Basal evidence detected BUT frontal indicators also present - CONFLICTING"
        else:
            reason = "Basal evidence detected, no contradictory frontal vertical indicators"
    
    else:
        decision = "UNCERTAIN"
        confidence = "uncertain"
        reason = "Insufficient discriminating evidence for either viewpoint"
    
    print(f"Classification: {decision}")
    print(f"Confidence: {confidence}")
    print(f"Reason: {reason}")
    
    # Key diagnostic insights
    print(f"\n{'='*80}")
    print("DIAGNOSTIC INSIGHTS")
    print(f"{'='*80}")
    
    if frontal_check.get('alignment_only') and not frontal_check['contradictory_basal']:
        print("⚠️  Image shows bilateral alignment (centered eyes/nose) but this alone")
        print("    does NOT distinguish frontal from basal viewpoint.")
        print("    Both views can have symmetric horizontal alignment.")
    
    if frontal_check['contradictory_basal']:
        print("✓  Strong vertical viewpoint indicators contradict basal viewpoint:")
        for item in frontal_check['evidence']:
            if any(kw in item for kw in ['below eye', 'forehead', 'chin-to-nose', 'nostril']):
                print(f"    • {item}")
    
    if basal_check['basal_viewpoint_detected']:
        print(f"✓  Basal anatomical features detected: {basal_check['reasoning']}")
    
    if not frontal_check['contradictory_basal'] and not basal_check['basal_viewpoint_detected']:
        print("⚠️  Neither frontal nor basal viewpoint has strong discriminating evidence.")
        print("    This image requires clinician review.")
    
    print(f"\n{'='*80}\n")


def main():
    if len(sys.argv) < 2:
        print("Usage: python diagnose_basal_frontal.py <image_path>")
        print("\nExample:")
        print("  python tools/diagnose_basal_frontal.py backend/uploads/test_image.jpg")
        sys.exit(1)
    
    image_path = sys.argv[1]
    
    if not os.path.exists(image_path):
        print(f"❌ Error: Image not found: {image_path}")
        sys.exit(1)
    
    diagnose_basal_frontal(image_path)


if __name__ == "__main__":
    main()
