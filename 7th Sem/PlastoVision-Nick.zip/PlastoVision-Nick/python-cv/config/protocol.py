"""Engineering starting values, not validated clinical acceptance thresholds."""
ALIASES = {'FRONT': 'frontal_neutral', 'RIGHT_OBLIQUE': 'right_oblique_45',
           'LEFT_OBLIQUE': 'left_oblique_45', 'RIGHT_LATERAL': 'right_lateral',
           'LEFT_LATERAL': 'left_lateral', 'BASAL': 'basal',
           'right_oblique': 'right_oblique_45', 'left_oblique': 'left_oblique_45', 'worms_view': 'basal'}
VIEWS = {
    'frontal_neutral': dict(yaw=0, pitch=0, roll=0, tolerance=(5, 5, 3), review=False),
    'right_oblique_45': dict(yaw=45, pitch=0, roll=0, tolerance=(7, 5, 3), review=False),
    'right_lateral': dict(yaw=90, pitch=0, roll=0, tolerance=(10, 10, 8), review=True),
    'left_oblique_45': dict(yaw=-45, pitch=0, roll=0, tolerance=(7, 5, 3), review=False),
    'left_lateral': dict(yaw=-90, pitch=0, roll=0, tolerance=(10, 10, 8), review=True),
    'basal': dict(yaw=0, pitch=20, roll=0, tolerance=(10, 15, 8), review=True),
    'frontal_smiling': dict(yaw=0, pitch=0, roll=0, tolerance=(8, 8, 6), review=True),
    'top': dict(yaw=0, pitch=None, roll=0, tolerance=(10, None, 8), review=True),
}
FRAMING = {
    # Detector face boxes cannot verify vertex or suprasternal notch. Review is mandatory.
    'full_face': dict(min_height=.30, max_height=.65, center_x=.5, center_y=.45, tolerance=.16),
    'nasal_focused': dict(min_height=.55, max_height=.95, center_x=.5, center_y=.50, tolerance=.14),
    'basal': dict(min_height=.40, max_height=.90, center_x=.5, center_y=.50, tolerance=.18),
}

# One server-owned policy; frontend receives it from /capture-config.
CAPTURE = dict(experimental_auto_capture=True, stability_ms=1000, countdown_ms=1000, max_analysis_age_ms=700,
               gaze_horizontal_tolerance=.15, gaze_vertical_tolerance=.25,
               gaze_min_eye_width_px=12, gaze_min_openness=.12,
               auto_center_tolerance=.04,
               max_gap_ms=500, angle_motion_deg=3, position_motion=.025,
               analysis_interval_ms=100, analysis_width=640, min_image_width=480,
               min_image_height=360, blur_threshold=70, max_black_fraction=.35,
               max_white_fraction=.10, min_dynamic_range=20, min_roi_width=100,
               scale_tolerance=.12, max_mouth_open_ratio=.18,
               oblique_tangent_ratio=.16, landmark_margin=.01, angular_entry_margin_deg=.5)  # Tightened from .20 to .16
