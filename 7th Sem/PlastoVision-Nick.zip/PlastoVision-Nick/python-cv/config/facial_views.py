"""Compatibility adapter; active engineering protocol lives in config.protocol."""
from config.protocol import VIEWS, ALIASES

FACIAL_VIEWS = {}
for identifier, profile in VIEWS.items():
    FACIAL_VIEWS[identifier] = dict(
        name=identifier.replace('_45', '').replace('_', ' ').title(),
        **{'target_'+axis: profile[axis] for axis in ('yaw','pitch','roll')},
        **{axis+'_tolerance': tolerance for axis,tolerance in zip(('yaw','pitch','roll'), profile['tolerance'])},
        requires_clinician_confirmation=True,
        auto_capture_eligible=False,
        engineering_thresholds=True
    )
for alias, canonical in ALIASES.items():
    FACIAL_VIEWS[alias] = FACIAL_VIEWS[canonical]


def get_view_config(facial_view):
    return FACIAL_VIEWS.get(facial_view)


def is_valid_view(facial_view):
    return facial_view in FACIAL_VIEWS
