"""Local diagnostic viewer using the same validation pipeline as the web application.
No photos are saved. Use the authenticated app to capture, review and persist images.
"""
import argparse
import time
import cv2
from services.validation_pipeline import ValidationPipeline

VIEWS = ['frontal_neutral','right_oblique_45','right_lateral','left_oblique_45','left_lateral','basal']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--camera', type=int, default=0)
    parser.add_argument('--view', choices=VIEWS, default='frontal_neutral')
    parser.add_argument('--framing', choices=['full_face','nasal_focused'], default='full_face')
    parser.add_argument('--profile', default='')
    args = parser.parse_args()
    pipeline = ValidationPipeline()
    camera = cv2.VideoCapture(args.camera)
    if not camera.isOpened():
        raise RuntimeError('Camera unavailable; check OS permission and device index')
    view = args.view
    result = {}
    last_analysis = 0
    try:
        while True:
            ok, frame = camera.read()
            if not ok:
                raise RuntimeError('Camera stopped providing frames')
            now = time.monotonic()
            if now-last_analysis >= .125:
                scaled = cv2.resize(frame, (640, round(frame.shape[0]*640/frame.shape[1])))
                encoded = cv2.imencode('.jpg',scaled)[1].tobytes()
                result = pipeline.validate_photo(encoded,view,True,dict(framing_protocol=args.framing,camera_profile_id=args.profile))
                last_analysis = now
            display = frame.copy()
            color = (0,180,255)
            cv2.rectangle(display,(0,0),(display.shape[1],58),(30,30,30),-1)
            cv2.putText(display,result.get('guidance','Initializing'),(10,24),cv2.FONT_HERSHEY_SIMPLEX,.48,color,1)
            lines = [f"View: {view} | keys 1-6 select; Q exits | diagnostics only",
                     f"Faces: {result.get('face_count',0)} | state: {result.get('state','initializing')}",
                     ' | '.join(f"{a}: {result[a]:.1f}" if result.get(a) is not None else f"{a}: unavailable" for a in ('yaw','pitch','roll')),
                     f"Framing: {result.get('framing_ok',False)} | Quality: {result.get('quality_ok',False)}",
                     f"Calibration: {result.get('calibration_status','approximate')} | Clinician review required"]
            for index,line in enumerate(lines):
                cv2.putText(display,line,(10,48+index*24),cv2.FONT_HERSHEY_SIMPLEX,.45,color,1)
            bbox = result.get('face_bbox')
            if bbox:
                x,y,w,h = bbox
                height,width = display.shape[:2]
                cv2.rectangle(display,(int(x*width),int(y*height)),(int((x+w)*width),int((y+h)*height)),color,1)
            cv2.imshow('PlastoVision diagnostics - unmirrored',display)
            key = cv2.waitKey(1) & 0xff
            if key in (ord('q'),27): break
            if ord('1') <= key <= ord('6'):
                view = VIEWS[key-ord('1')]; result = {}; last_analysis = 0
    finally:
        camera.release(); cv2.destroyAllWindows()


if __name__ == '__main__': main()
