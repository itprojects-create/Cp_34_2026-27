"""Local checkerboard calibration. Input images contain the target, never patients."""
import argparse
import glob
import json
from pathlib import Path
from datetime import datetime, timezone
import cv2
import numpy as np


def calibrate(paths, columns, rows, square_size):
    target = np.zeros((columns*rows, 3), np.float32)
    target[:, :2] = np.mgrid[0:columns, 0:rows].T.reshape(-1, 2)*square_size
    objects, observations, accepted = [], [], []
    size = None
    for filename in paths:
        image = cv2.imread(filename)
        if image is None:
            continue
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        current = (gray.shape[1], gray.shape[0])
        if size and current != size:
            raise ValueError('All calibration images must use the same resolution')
        size = current
        found, corners = cv2.findChessboardCorners(gray, (columns, rows))
        if found:
            corners = cv2.cornerSubPix(gray, corners, (11, 11), (-1, -1),
                                      (cv2.TERM_CRITERIA_EPS+cv2.TERM_CRITERIA_MAX_ITER, 30, .001))
            objects.append(target.copy()); observations.append(corners); accepted.append(filename)
    if len(objects) < 12:
        raise ValueError('At least 12 usable checkerboard images at diverse positions and inclinations are required')
    rms, matrix, distortion, rotations, translations = cv2.calibrateCamera(objects, observations, size, None, None)
    residuals = []
    for obj, obs, rotation, translation in zip(objects, observations, rotations, translations):
        projected, _ = cv2.projectPoints(obj, rotation, translation, matrix, distortion)
        residuals.append(float(np.sqrt(np.mean(np.sum((obs-projected)**2, axis=2)))))
    return dict(camera_matrix=matrix.tolist(), distortion=distortion.ravel().tolist(), image_size=list(size),
                rms_px=float(rms), per_image_rmse_px=residuals, accepted_images=len(accepted),
                directions_verified=False, note='Verify device mode, focus/zoom and patient-facing signs before use')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--images', required=True, help='Quoted glob of local target images')
    parser.add_argument('--columns', type=int, required=True, help='Inner corners per row')
    parser.add_argument('--rows', type=int, required=True, help='Inner corners per column')
    parser.add_argument('--square-size', type=float, required=True, help='Measured checker square side length in a consistent unit')
    parser.add_argument('--id', required=True, help='Camera profile ID')
    parser.add_argument('--output', required=True)
    parser.add_argument('--device-id', help='Exact browser device ID from camera diagnostics')
    parser.add_argument('--distance-cm', type=float, help='Physically measured working distance, optional')
    parser.add_argument('--camera-height-cm', type=float, help='Physically measured camera height, optional')
    parser.add_argument('--setup-notes', default='')
    args = parser.parse_args()
    if args.columns < 3 or args.rows < 3 or args.square_size <= 0:
        parser.error('Use at least 3x3 inner corners and a positive measured square size')
    profile = calibrate(sorted(glob.glob(args.images)), args.columns, args.rows, args.square_size)
    profile.update(id=args.id, device_id=args.device_id,
                   reference_distance_cm=args.distance_cm, camera_height_cm=args.camera_height_cm,
                   setup_notes=args.setup_notes, calibrated_at=datetime.now(timezone.utc).isoformat(),
                   calibration_method='opencv_checkerboard',
                   aspect_ratio=profile['image_size'][0]/profile['image_size'][1], approved_views={})
    output = Path(args.output)
    profiles = json.loads(output.read_text()) if output.exists() else {}
    profiles[args.id] = profile
    output.write_text(json.dumps(profiles, indent=2))
    print(f"Saved {args.id}: {profile['accepted_images']} images, RMS {profile['rms_px']:.3f} px. Physical direction verification remains required.")
