"""
Image Utilities

Helper functions for image processing and validation.
"""

import cv2
import numpy as np
from PIL import Image
import io


def load_image_from_bytes(image_bytes):
    """
    Load image from bytes
    
    Args:
        image_bytes: Image file bytes
        
    Returns:
        numpy.ndarray: OpenCV image (BGR format)
    """
    with Image.open(io.BytesIO(image_bytes)) as header:
        if header.width * header.height > 40000000 or header.format not in ('JPEG', 'PNG'):
            raise ValueError('Only JPEG/PNG images up to 40 megapixels are supported')
    # Convert bytes to numpy array
    nparr = np.frombuffer(image_bytes, np.uint8)
    
    # Decode image
    image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    
    if image is None:
        raise ValueError("Failed to decode image")
    
    return image


def resize_image_if_needed(image, max_dimension=1920):
    """
    Resize image if it exceeds max dimension while maintaining aspect ratio
    
    Args:
        image: OpenCV image
        max_dimension: Maximum width or height
        
    Returns:
        numpy.ndarray: Resized image
    """
    height, width = image.shape[:2]
    
    if width <= max_dimension and height <= max_dimension:
        return image
    
    # Calculate scaling factor
    scale = max_dimension / max(width, height)
    
    # Calculate new dimensions
    new_width = int(width * scale)
    new_height = int(height * scale)
    
    # Resize
    resized = cv2.resize(image, (new_width, new_height), interpolation=cv2.INTER_AREA)
    
    return resized


def convert_bgr_to_rgb(image):
    """Convert BGR (OpenCV) to RGB (MediaPipe)"""
    return cv2.cvtColor(image, cv2.COLOR_BGR2RGB)


def convert_rgb_to_bgr(image):
    """Convert RGB (MediaPipe) to BGR (OpenCV)"""
    return cv2.cvtColor(image, cv2.COLOR_RGB2BGR)


def calculate_laplacian_variance(image):
    """
    Calculate Laplacian variance for blur detection
    
    Args:
        image: OpenCV image
        
    Returns:
        float: Variance value (higher = sharper)
    """
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    laplacian = cv2.Laplacian(gray, cv2.CV_64F)
    variance = laplacian.var()
    
    return variance


def calculate_brightness(image):
    """
    Calculate average brightness of image
    
    Args:
        image: OpenCV image
        
    Returns:
        float: Average brightness (0-255)
    """
    # Convert to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # Calculate mean brightness
    brightness = np.mean(gray)
    
    return brightness


def get_image_dimensions(image):
    """
    Get image dimensions
    
    Args:
        image: OpenCV image
        
    Returns:
        tuple: (height, width, channels)
    """
    return image.shape


def normalize_landmarks(landmarks, image_width, image_height):
    """
    Convert normalized landmarks to pixel coordinates
    
    Args:
        landmarks: MediaPipe landmarks (normalized 0-1)
        image_width: Image width in pixels
        image_height: Image height in pixels
        
    Returns:
        list: List of (x, y) tuples in pixel coordinates
    """
    points = []
    
    for landmark in landmarks:
        x = int(landmark.x * image_width)
        y = int(landmark.y * image_height)
        points.append((x, y))
    
    return points


def draw_landmarks_on_image(image, landmarks, connections=None, color=(0, 255, 0), thickness=1):
    """
    Draw landmarks on image for debugging
    
    Args:
        image: OpenCV image
        landmarks: List of (x, y) tuples
        connections: List of (start_idx, end_idx) tuples for connections
        color: BGR color tuple
        thickness: Line thickness
        
    Returns:
        numpy.ndarray: Image with landmarks drawn
    """
    output = image.copy()
    
    # Draw connections
    if connections:
        for connection in connections:
            start_idx, end_idx = connection
            if start_idx < len(landmarks) and end_idx < len(landmarks):
                start_point = landmarks[start_idx]
                end_point = landmarks[end_idx]
                cv2.line(output, start_point, end_point, color, thickness)
    
    # Draw landmarks
    for point in landmarks:
        cv2.circle(output, point, 2, color, -1)
    
    return output


def calculate_face_size_ratio(face_bbox, image_width, image_height):
    """
    Calculate what percentage of image is occupied by face
    
    Args:
        face_bbox: Bounding box (x, y, width, height)
        image_width: Image width
        image_height: Image height
        
    Returns:
        float: Ratio of face area to image area (0-1)
    """
    x, y, w, h = face_bbox
    
    face_area = w * h
    image_area = image_width * image_height
    
    ratio = face_area / image_area
    
    return ratio


def is_face_centered(face_bbox, image_width, image_height, tolerance=0.15):
    """
    Check if face is reasonably centered in frame
    
    Args:
        face_bbox: Bounding box (x, y, width, height)
        image_width: Image width
        image_height: Image height
        tolerance: How far from center is acceptable (0-0.5)
        
    Returns:
        bool: True if face is centered
    """
    x, y, w, h = face_bbox
    
    # Calculate face center
    face_center_x = x + w / 2
    face_center_y = y + h / 2
    
    # Calculate image center
    image_center_x = image_width / 2
    image_center_y = image_height / 2
    
    # Calculate offset as percentage of image dimensions
    offset_x = abs(face_center_x - image_center_x) / image_width
    offset_y = abs(face_center_y - image_center_y) / image_height
    
    # Check if within tolerance
    is_centered = (offset_x <= tolerance) and (offset_y <= tolerance)
    
    return is_centered
