"""Explicit real-model smoke check using synthetic pixels, no patient data."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import base64
import cv2
import numpy as np
import app

client = app.app.test_client()
config = client.get('/capture-config')
assert config.status_code == 200
image = cv2.imencode('.jpg', np.full((480,640,3),128,np.uint8))[1].tobytes()
result = client.post('/validate-live', json=dict(frame=base64.b64encode(image).decode(),
                     facial_view='FRONT',frame_id=1,timestamp=1)).get_json()
assert result['face_count'] == 0 and result['capture_ready'] is False, result
assert result['guidance_code'] == 'NO_FACE', result
print('PASS: real MediaPipe initialization, Flask configuration and live synthetic no-face inference')
print('Inference processing time (ms):', result['processing_time_ms'])
