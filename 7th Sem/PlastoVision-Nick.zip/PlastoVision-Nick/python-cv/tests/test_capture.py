import io
import json
import os
import unittest
from unittest.mock import patch
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import cv2
import numpy as np
from PIL import Image
from services.pose_estimation import PoseEstimator
from services.camera_calibration import camera_intrinsics
from config.protocol import VIEWS, ALIASES


def rotation(yaw, pitch, roll):
    y,p,r = np.radians([yaw,pitch,roll])
    rx = np.array([[1,0,0],[0,np.cos(p),-np.sin(p)],[0,np.sin(p),np.cos(p)]])
    ry = np.array([[np.cos(y),0,np.sin(y)],[0,1,0],[-np.sin(y),0,np.cos(y)]])
    rz = np.array([[np.cos(r),-np.sin(r),0],[np.sin(r),np.cos(r),0],[0,0,1]])
    return rz @ ry @ rx


def image_bytes():
    rng = np.random.default_rng(42)
    image = rng.integers(70,185,(480,640,3),dtype=np.uint8)
    return cv2.imencode('.jpg', image)[1].tobytes()


class PoseTests(unittest.TestCase):
    def test_separate_axes_and_combined_rotations(self):
        estimator = PoseEstimator()
        for angles in [(0,0,0),(35,0,0),(-35,0,0),(0,20,0),(0,-20,0),(0,0,12),(0,0,-12),(30,-15,8)]:
            with self.subTest(angles=angles):
                np.testing.assert_allclose(estimator._rotation_matrix_to_euler_angles(rotation(*angles)), angles, atol=1e-8)

    def test_project_and_recover_pose(self):
        estimator = PoseEstimator()
        matrix, distortion, _ = camera_intrinsics(1280,720)
        for angles in [(0,0,0),(40,5,-6),(-40,-5,6)]:
            with self.subTest(angles=angles):
                rvec, _ = cv2.Rodrigues(rotation(*angles))
                points, _ = cv2.projectPoints(estimator.model_points_3d,rvec,np.array([0.,0.,2200.]),matrix,distortion)
                result = estimator.estimate_pose(points.reshape(6,2),1280,720)
                self.assertTrue(result['success'], result)
                np.testing.assert_allclose([result[a] for a in ('yaw','pitch','roll')], angles, atol=.01)
                self.assertLess(result['reprojection_rmse_px'], .001)

    def test_invalid_landmarks_not_zero_angles(self):
        estimator = PoseEstimator()
        for points in [None, np.zeros((6,2)), np.full((6,2),np.nan), np.zeros((5,2)), np.full((6,2),-1)]:
            result = estimator.estimate_pose(points,640,480)
            self.assertFalse(result['success'])
            self.assertIsNone(result['yaw'])

    def test_calibration_scaled_to_frame(self):
        profile = dict(camera_matrix=[[1000,0,640],[0,1000,360],[0,0,1]], distortion=[0]*5,image_size=[1280,720])
        matrix, _, status = camera_intrinsics(640,360,profile)
        self.assertEqual(status,'calibrated')
        self.assertEqual(matrix[0,0],500)
        with self.assertRaises(ValueError): camera_intrinsics(640,480,profile)
        profile['camera_matrix'][0][0] = -1
        with self.assertRaises(ValueError): camera_intrinsics(640,360,profile)

    def test_profiles_and_basal_are_conservative(self):
        self.assertIsNone(VIEWS['basal']['pitch'])
        self.assertTrue(VIEWS['right_lateral']['review'])
        self.assertEqual(ALIASES['worms_view'],'basal')


class PipelineTests(unittest.TestCase):
    def setUp(self):
        # Test deterministic pipeline behavior independently of ML inference/hardware.
        with patch('services.validation_pipeline.FaceDetector'), patch('services.validation_pipeline.LandmarkDetector'):
            from services.validation_pipeline import ValidationPipeline
            self.pipeline = ValidationPipeline()
        self.pipeline.face_detector.detect_faces.return_value = dict(face_count=1,bounding_boxes=[(180,90,280,250)])
        self.pipeline.landmark_detector.detect_landmarks.return_value = dict(landmarks_detected=False,landmark_count=0)

    def test_multiple_faces_fail_closed(self):
        self.pipeline.face_detector.detect_faces.return_value = dict(face_count=2,bounding_boxes=[])
        result = self.pipeline.validate_photo(image_bytes(),'frontal_neutral',True)
        self.assertFalse(result['reviewable']); self.assertEqual(result['face_count'],2)
        self.assertEqual(result['guidance_code'],'MULTIPLE_FACES')

    def test_no_face_clears_measurements(self):
        self.pipeline.face_detector.detect_faces.return_value = dict(face_count=0,bounding_boxes=[])
        result = self.pipeline.validate_photo(image_bytes(),'frontal_neutral')
        self.assertIsNone(result['yaw']); self.assertFalse(result['capture_ready'])

    def test_basal_and_profile_never_auto_approved(self):
        for view in ['basal','right_lateral','left_lateral']:
            result = self.pipeline.validate_photo(image_bytes(),view)
            self.assertTrue(result['reviewable'],result)
            self.assertFalse(result['valid']); self.assertFalse(result['capture_ready'])
            self.assertIsNone(result['yaw'])
            self.assertTrue(result['requires_clinician_confirmation'])

    def test_face_roi_ignores_dark_background(self):
        image = np.zeros((480,640,3),np.uint8)
        rng = np.random.default_rng(1)
        image[90:340,180:460] = rng.integers(70,185,(250,280,3),dtype=np.uint8)
        result = self.pipeline.validate_photo(cv2.imencode('.png',image)[1].tobytes(),'basal')
        self.assertTrue(result['quality_ok'],result)

    def test_blur_and_clipped_frame_block_review(self):
        flat = np.full((480,640,3),128,np.uint8)
        result = self.pipeline.validate_photo(cv2.imencode('.jpg',flat)[1].tobytes(),'basal')
        self.assertFalse(result['quality_ok']); self.assertFalse(result['reviewable'])
        self.pipeline.face_detector.detect_faces.return_value = dict(face_count=1,bounding_boxes=[(-10,90,280,250)])
        result = self.pipeline.validate_photo(image_bytes(),'basal')
        self.assertFalse(result['framing_ok']); self.assertEqual(result['guidance_code'],'CLIPPED')

    def test_corrupt_image_safe_error(self):
        result = self.pipeline.validate_photo(b'not an image','frontal_neutral')
        self.assertEqual(result['state'],'ERROR'); self.assertFalse(result['reviewable'])
        self.assertIsNone(result['pitch'])

    def approved_camera(self):
        points = np.full((478, 2), [320., 220.])
        points[61], points[291], points[13], points[14] = [270,270], [370,270], [320,270], [320,272]
        points[234], points[454], points[1] = [190,230], [450,230], [320,200]
        for left,right,upper,lower,iris,x in [(33,133,159,145,468,250),(362,263,386,374,473,390)]:
            points[left],points[right]=[x-20,180],[x+20,180]
            points[upper],points[lower],points[iris]=[x,175],[x,185],[x,180]
        self.pipeline.landmark_detector.detect_landmarks.return_value = dict(landmarks_detected=True,landmark_count=478,landmarks_2d=points.tolist())
        self.pipeline.pose_estimator.estimate_pose = lambda *args: dict(success=True,yaw=0.,pitch=0.,roll=0.,calibration_status='calibrated')
        camera = dict(device_id='camera', image_size=[640,480], camera_matrix=[[640,0,320],[0,640,240],[0,0,1]],
                      distortion=[0]*5, directions_verified=True, approved_views={
                      'frontal_neutral':dict(clinician_id='doctor',approved_at='2026-10-19',physical_test_record='local test worksheet',
                                            reference_face_height_ratio=250/480,framing_protocol='full_face')})
        setup = dict(camera_profile_id='clinic',framing_protocol='full_face',physical_setup_confirmed=True,
                     actual_camera=dict(deviceId='camera',width=640,height=480))
        return camera, setup

    def test_auto_acceptance_requires_measured_setup_landmark_evidence_and_correct_pose(self):
        camera, setup = self.approved_camera()
        with patch('services.validation_pipeline.load_profiles', return_value={'clinic':camera}):
            good = self.pipeline.validate_photo(image_bytes(),'FRONT',True,setup)
            self.assertTrue(good['capture_ready'],good)
            self.assertTrue(good['anatomical_evidence']['passed'])
            for angles in [(20,0,0),(0,12,0),(0,0,10)]:
                self.pipeline.pose_estimator.estimate_pose = lambda *args: dict(success=True,yaw=angles[0],pitch=angles[1],roll=angles[2],calibration_status='calibrated')
                result = self.pipeline.validate_photo(image_bytes(),'FRONT',True,setup)
                self.assertFalse(result['capture_ready'])

    def test_device_mismatch_unapproved_camera_and_missing_landmarks_fail_closed(self):
        camera, setup = self.approved_camera()
        with patch('services.validation_pipeline.load_profiles', return_value={'clinic':camera}):
            for changed in [{**setup,'physical_setup_confirmed':False}, {**setup,'actual_camera':dict(deviceId='other',width=640,height=480)},
                            {**setup,'actual_camera':dict(deviceId='camera',width=1920,height=1080)}]:
                self.assertFalse(self.pipeline.validate_photo(image_bytes(),'FRONT',True,changed)['capture_ready'])
            camera['approved_views']['frontal_neutral'].pop('physical_test_record')
            self.assertFalse(self.pipeline.validate_photo(image_bytes(),'FRONT',True,setup)['capture_ready'])

    def test_correct_obliques_and_opposite_side_rejection(self):
        camera, setup = self.approved_camera()
        points = self.pipeline.landmark_detector.detect_landmarks.return_value['landmarks_2d']
        points[1] = [215,200]  # Synthetic supporting contour proximity, not clinical evidence.
        for view, yaw in [('right_oblique_45',45), ('left_oblique_45',-45)]:
            camera['approved_views'][view] = camera['approved_views']['frontal_neutral']
            with patch('services.validation_pipeline.load_profiles',return_value={'clinic':camera}):
                self.pipeline.pose_estimator.estimate_pose=lambda *args:dict(success=True,yaw=yaw,pitch=0.,roll=0.,calibration_status='calibrated')
                self.assertTrue(self.pipeline.validate_photo(image_bytes(),view,True,setup)['capture_ready'])
                self.pipeline.pose_estimator.estimate_pose=lambda *args:dict(success=True,yaw=-yaw,pitch=0.,roll=0.,calibration_status='calibrated')
                self.assertFalse(self.pipeline.validate_photo(image_bytes(),view,True,setup)['capture_ready'])

    def test_experimental_webcam_auto_readiness_without_approved_profile(self):
        self.approved_camera()  # Inject deterministic landmarks/pose, no profile is selected.
        setup=dict(physical_setup_confirmed=True,automatic_capture_mode='experimental')
        result=self.pipeline.validate_photo(image_bytes(),'FRONT',True,setup)
        self.assertTrue(result['capture_ready'],result)
        self.assertTrue(result['experimental_capture_ready']);self.assertFalse(result['valid'])
        self.assertTrue(result['requires_clinician_confirmation'])
        for changed in [{}, {**setup,'automatic_capture_mode':'approved'}]:
            self.assertFalse(self.pipeline.validate_photo(image_bytes(),'FRONT',True,changed)['capture_ready'])
        self.pipeline.pose_estimator.estimate_pose=lambda *args:dict(success=True,yaw=15.,pitch=0.,roll=0.,calibration_status='approximate')
        self.assertFalse(self.pipeline.validate_photo(image_bytes(),'FRONT',True,setup)['capture_ready'])
        for view in ['right_lateral','left_lateral','basal']:
            result=self.pipeline.validate_photo(image_bytes(),view,True,setup)
            self.assertFalse(result['capture_ready']);self.assertFalse(result['auto_capture_eligible'])

    def test_frontal_eyes_away_blink_or_missing_irises_block_live_and_final_capture(self):
        self.approved_camera()
        original=np.array(self.pipeline.landmark_detector.detect_landmarks.return_value['landmarks_2d'])
        setup=dict(physical_setup_confirmed=True)
        for live in [True,False]:
            for condition in ['sideways','down','blink','missing']:
                points=original.copy()
                if condition=='sideways': points[[468,473],0]+=12
                if condition=='down': points[[468,473],1]+=5
                if condition=='blink': points[[145,374],1]=points[[159,386],1]+1
                if condition=='missing': points=points[:468]
                self.pipeline.landmark_detector.detect_landmarks.return_value['landmarks_2d']=points.tolist()
                result=self.pipeline.validate_photo(image_bytes(),'FRONT',live,setup)
                self.assertFalse(result['gaze_ok'],(condition,result))
                self.assertFalse(result['capture_ready'],(condition,result))
                self.assertFalse(result['valid'])

    def test_eye_direction_and_tracking_follow_translated_landmarks(self):
        from services.eye_direction import check_eye_direction
        self.approved_camera()
        points=np.array(self.pipeline.landmark_detector.detect_landmarks.return_value['landmarks_2d'])
        self.assertTrue(check_eye_direction(points)['passed'])
        self.assertTrue(check_eye_direction(points+[25,20])['passed'])
        self.assertFalse(check_eye_direction(points[:468])['available'])
        result=self.pipeline.validate_photo(image_bytes(),'FRONT',True,dict(physical_setup_confirmed=True))
        self.assertEqual(len(result['tracking']['face_outline']),36)
        self.assertEqual(len(result['tracking']['iris_points']),2)

    def test_automatic_capture_requires_target_center_and_scale_not_just_broad_framing(self):
        self.approved_camera()
        for bbox,code in [((210,90,280,250),'CENTER'),((210,120,220,190),'SCALE')]:
            self.pipeline.face_detector.detect_faces.return_value=dict(face_count=1,bounding_boxes=[bbox])
            result=self.pipeline.validate_photo(image_bytes(),'FRONT',True,dict(physical_setup_confirmed=True))
            self.assertTrue(result['framing_ok'],result)
            self.assertFalse(result['spatial_alignment_ok'])
            self.assertFalse(result['capture_ready'])
            self.assertEqual(result['guidance_code'],code)

    def test_near_far_and_shifted_faces_fail_framing(self):
        for bbox in [(180,30,280,440),(250,180,120,100),(0,90,280,250),(360,90,280,250)]:
            with self.subTest(bbox=bbox):
                self.pipeline.face_detector.detect_faces.return_value=dict(face_count=1,bounding_boxes=[bbox])
                result=self.pipeline.validate_photo(image_bytes(),'FRONT',True)
                self.assertFalse(result['framing_ok']);self.assertFalse(result['capture_ready'])

    def test_open_mouth_and_oblique_wrong_side_block_automation_without_symmetry_rule(self):
        camera, setup = self.approved_camera()
        points = self.pipeline.landmark_detector.detect_landmarks.return_value['landmarks_2d']
        points[14] = [320,310]
        with patch('services.validation_pipeline.load_profiles', return_value={'clinic':camera}):
            result=self.pipeline.validate_photo(image_bytes(),'FRONT',True,setup)
            self.assertFalse(result['anatomical_evidence']['passed']); self.assertFalse(result['capture_ready'])
            points[14]=[320,272]
            for view in ['right_oblique_45','left_oblique_45']:
                camera['approved_views'][view]=camera['approved_views']['frontal_neutral']
                result=self.pipeline.validate_photo(image_bytes(),view,True,setup)
                self.assertFalse(result['capture_ready'])

    def test_lower_luminance_with_detail_is_not_rejected_by_mean_brightness(self):
        rng=np.random.default_rng(5)
        image=np.zeros((480,640,3),np.uint8)
        image[90:340,180:460]=rng.integers(12,60,(250,280,3),dtype=np.uint8)
        result=self.pipeline.validate_photo(cv2.imencode('.png',image)[1].tobytes(),'basal')
        self.assertLess(result['brightness'],50)
        self.assertTrue(result['quality_ok'],result)

    def test_busy_pipeline_drops_work_instead_of_queuing(self):
        self.pipeline.lock.acquire()
        try:
            result=self.pipeline.validate_photo(image_bytes(),'FRONT',True)
            self.assertEqual(result['state'],'BUSY'); self.assertFalse(result['capture_ready'])
        finally: self.pipeline.lock.release()

    def test_http_contract(self):
        # Inject pipeline to avoid MediaPipe's camera/GPU initialization in an API contract test.
        with patch('services.validation_pipeline.ValidationPipeline', return_value=self.pipeline):
            import app
        client = app.app.test_client()
        import base64
        response = client.post('/validate-live',json={'frame':base64.b64encode(image_bytes()).decode(),
                                                     'facial_view':'basal','frame_id':7,'timestamp':123})
        self.assertEqual(response.status_code,200)
        result = response.get_json()
        self.assertEqual(result['frame_id'],7); self.assertEqual(result['timestamp'],123)
        self.assertEqual(result['schema_version'],2); self.assertFalse(result['capture_ready'])
        self.assertEqual(client.post('/validate-live',json={'frame':'x','facial_view':'unknown'}).status_code,400)
        result = client.post('/validate',data={'facial_view':'basal','photo':(io.BytesIO(image_bytes()),'image.jpg')})
        self.assertEqual(result.status_code,200); self.assertFalse(result.get_json()['valid'])


if __name__ == '__main__': unittest.main()
