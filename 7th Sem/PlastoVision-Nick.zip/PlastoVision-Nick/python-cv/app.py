"""
PlastoVision Python CV Service

Flask application for facial photo validation using MediaPipe and OpenCV.
"""

import os
from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv
import numpy as np
from services.validation_pipeline import ValidationPipeline
from config.facial_views import FACIAL_VIEWS
from config.protocol import VIEWS, ALIASES, FRAMING, CAPTURE
from services.camera_calibration import load_profiles
def is_valid_view(view):
    return isinstance(view, str) and ALIASES.get(view, view) in VIEWS

# Load environment variables
load_dotenv()

# Initialize Flask app
app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 12 * 1024 * 1024


def convert_numpy_types(obj):
    """Convert NumPy types to native Python types for JSON serialization"""
    if isinstance(obj, dict):
        return {key: convert_numpy_types(value) for key, value in obj.items()}
    elif isinstance(obj, list):
        return [convert_numpy_types(item) for item in obj]
    elif isinstance(obj, (np.integer, np.int64, np.int32)):
        return int(obj)
    elif isinstance(obj, (np.floating, np.float64, np.float32)):
        return float(obj)
    elif isinstance(obj, (np.bool_, bool)):
        return bool(obj)
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    else:
        return obj

# Enable CORS
CORS(app, resources={
    r"/*": {
        "origins": ["http://localhost:5173", "http://localhost:3001"],
        "methods": ["GET", "POST", "OPTIONS"],
        "allow_headers": ["Content-Type"]
    }
})

# Initialize validation pipeline
validation_pipeline = ValidationPipeline()

# Configuration
PORT = int(os.getenv('PORT', 5002))
HOST = os.getenv('HOST', '127.0.0.1')
DEBUG = os.getenv('DEBUG', 'False').lower() == 'true'


@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'service': 'PlastoVision CV Service',
        'version': '1.0.0'
    }), 200


@app.route('/info', methods=['GET'])
def service_info():
    """Service information endpoint"""
    return jsonify({
        'service': 'PlastoVision Computer Vision Service',
        'version': '1.0.0',
        'description': 'Facial photo validation using MediaPipe and OpenCV',
        'capabilities': [
            'Face detection',
            'Facial landmark detection (468 points)',
            'Head pose estimation (yaw, pitch, roll)',
            'Image quality assessment',
            'View validation against six-view rhinoplasty protocol with legacy compatibility'
        ],
        'facial_views': list(FACIAL_VIEWS.keys()),
        'endpoints': {
            'GET /health': 'Health check',
            'GET /info': 'Service information',
            'POST /validate': 'Validate photo',
            'GET /views': 'List all facial views',
            'GET /views/<view_id>': 'Get facial view configuration'
        }
    }), 200


@app.route('/views', methods=['GET'])
def list_views():
    """List all facial views"""
    views = [dict(id=view_id, target_yaw=p['yaw'], target_pitch=p['pitch'], target_roll=p['roll'],
                  yaw_tolerance=p['tolerance'][0], pitch_tolerance=p['tolerance'][1], roll_tolerance=p['tolerance'][2],
                  automatic_requires_approved_camera=not p['review'], requires_clinician_confirmation=p['review'])
             for view_id, p in VIEWS.items()]
    return jsonify(views=views, count=len(views)), 200


@app.get('/capture-config')
def capture_config():
    # Profiles contain setup measurements, never patient frames.
    return jsonify(dict(policy=CAPTURE, views=VIEWS, aliases=ALIASES, framing=FRAMING,
                        camera_profiles=load_profiles(),
                        threshold_status='Provisional engineering values; require physical and clinician validation'))


@app.route('/views/<view_id>', methods=['GET'])
def get_view(view_id):
    """Get facial view configuration"""
    if not is_valid_view(view_id):
        return jsonify({
            'error': f'Invalid facial view: {view_id}',
            'valid_views': list(FACIAL_VIEWS.keys())
        }), 400
    
    view_id = ALIASES.get(view_id, view_id)
    config = VIEWS[view_id]
    
    return jsonify({
        'id': view_id,
        'auto_capture_eligible': False,
        'requires_clinician_confirmation': True,
        'name': view_id,
        'target_yaw': config['yaw'],
        'target_pitch': config['pitch'],
        'target_roll': config['roll'],
        'yaw_tolerance': config['tolerance'][0],
        'pitch_tolerance': config['tolerance'][1],
        'roll_tolerance': config['tolerance'][2]
    }), 200


@app.route('/validate', methods=['POST'])
def validate_photo():
    """
    Validate uploaded photo
    
    Expects multipart/form-data with:
    - photo: Image file
    - facial_view: Target facial view identifier
    """
    # Check if photo was uploaded
    if 'photo' not in request.files:
        return jsonify({
            'valid': False,
            'error': 'No photo file provided'
        }), 400
    
    photo = request.files['photo']
    
    # Check if file is empty
    if photo.filename == '':
        return jsonify({
            'valid': False,
            'error': 'Empty filename'
        }), 400
    
    # Get facial view from form data
    facial_view = request.form.get('facial_view')
    
    if not facial_view:
        return jsonify({
            'valid': False,
            'error': 'facial_view parameter is required'
        }), 400
    
    # Validate facial view
    if not is_valid_view(facial_view):
        return jsonify({
            'valid': False,
            'error': f'Invalid facial view: {facial_view}',
            'valid_views': list(FACIAL_VIEWS.keys())
        }), 400
    
    try:
        # Read image bytes
        image_bytes = photo.read()
        
        # Validate photo
        import json
        setup = json.loads(request.form.get('setup', '{}'))
        if not isinstance(setup, dict):
            return jsonify(error='setup must be an object'), 400
        result = validation_pipeline.validate_photo(image_bytes, facial_view, setup=setup)
        
        # Return result with appropriate status code
        status_code = 200
        
        return jsonify(convert_numpy_types(result)), status_code
        
    except Exception as e:
        app.logger.error(f"Validation error: {str(e)}")
        return jsonify({
            'valid': False,
            'error': f'Validation failed: {str(e)}'
        }), 500


@app.route('/validate-live', methods=['POST'])
def validate_live_frame():
    """
    Validate live camera frame for real-time guidance
    
    Expects JSON with:
    - frame: Base64-encoded JPEG image (low resolution for performance)
    - facial_view: Target facial view identifier
    
    Returns real-time validation status with guidance
    """
    try:
        data = request.get_json()
        
        if not isinstance(data, dict) or not isinstance(data.get('setup', {}), dict):
            return jsonify({
                'valid': False,
                'state': 'error',
                'error': 'No JSON data provided'
            }), 400
        
        # Get frame and facial view
        frame_b64 = data.get('frame')
        facial_view = data.get('facial_view')
        
        if not frame_b64:
            return jsonify({
                'valid': False,
                'state': 'error',
                'error': 'No frame data provided'
            }), 400
        
        if not facial_view:
            return jsonify({
                'valid': False,
                'state': 'error',
                'error': 'facial_view parameter is required'
            }), 400
        
        # Validate facial view
        if not is_valid_view(facial_view):
            return jsonify({
                'valid': False,
                'state': 'error',
                'error': f'Invalid facial view: {facial_view}',
                'valid_views': list(FACIAL_VIEWS.keys())
            }), 400
        
        # Decode base64 image
        import base64
        try:
            image_bytes = base64.b64decode(frame_b64.split(',')[1] if ',' in frame_b64 else frame_b64, validate=True)
        except Exception as e:
            return jsonify({
                'valid': False,
                'state': 'error',
                'error': f'Failed to decode frame: {str(e)}'
            }), 400
        
        # Validate frame (use same pipeline, results will be lighter for live frames)
        result = validation_pipeline.validate_photo(image_bytes, facial_view, live_mode=True, setup=data.get('setup', {}))
        result.update(frame_id=data.get('frame_id'), timestamp=data.get('timestamp'))
        
        # Convert NumPy types to native Python types for JSON serialization
        result = convert_numpy_types(result)
        
        # Return result (always 200 OK for live validation, client handles state)
        return jsonify(result), 200
        
    except Exception as e:
        app.logger.error(f"Live validation error: {str(e)}")
        return jsonify({
            'valid': False,
            'state': 'error',
            'error': f'Live validation failed: {str(e)}'
        }), 500


@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return jsonify({
        'error': 'Endpoint not found',
        'available_endpoints': [
            'GET /health',
            'GET /info',
            'POST /validate',
            'GET /views',
            'GET /views/<view_id>'
        ]
    }), 404


@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    app.logger.error(f"Internal error: {str(error)}")
    return jsonify({
        'error': 'Internal server error',
        'message': str(error)
    }), 500


if __name__ == '__main__':
    print("=" * 60)
    print("PlastoVision Computer Vision Service")
    print("=" * 60)
    print(f"Starting server on {HOST}:{PORT}")
    print(f"Debug mode: {DEBUG}")
    print(f"Supported facial views: {len(FACIAL_VIEWS)}")
    print("=" * 60)
    
    app.run(
        host=HOST,
        port=PORT,
        debug=DEBUG
    )
