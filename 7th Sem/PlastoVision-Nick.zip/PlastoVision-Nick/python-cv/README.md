# PlastoVision Python CV Service

Computer vision service for validating patient facial photographs using MediaPipe and OpenCV.

## Purpose

This service provides:
- **Face Detection** - Detects faces in uploaded photos
- **Landmark Detection** - Identifies facial landmarks using MediaPipe
- **Pose Estimation** - Estimates head pose (yaw, pitch, roll) using OpenCV solvePnP
- **View Validation** - Validates photos against selected facial view requirements
- **Image Quality** - Checks blur, lighting, and framing

## Architecture

```
Express Backend
      ↓
   HTTP POST
      ↓
Python Flask Service (THIS)
      ↓
MediaPipe + OpenCV
      ↓
Validation Result (JSON)
```

## Installation

### 1. Create Virtual Environment

```bash
cd python-cv
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

### 3. Verify Installation

```bash
python -c "import cv2; import mediapipe; print('✅ Installation successful')"
```

## Configuration

Create `.env` file (optional):

```bash
cp .env.example .env
```

Edit `.env`:
```
PORT=5000
HOST=0.0.0.0
DEBUG=False
```

## Running the Service

### Development Mode

```bash
source venv/bin/activate
python app.py
```

The service will start on http://localhost:5000

### Production Mode

```bash
source venv/bin/activate
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

## API Endpoints

### Health Check
```
GET /health
```

Returns service status.

### Service Info
```
GET /info
```

Returns service information and capabilities.

### Validate Photo
```
POST /validate
Content-Type: multipart/form-data

Fields:
- photo: File (required) - Image file
- facial_view: String (required) - e.g., 'frontal_neutral'
- target_yaw: Number (required) - Target yaw angle in degrees
- target_pitch: Number (required) - Target pitch angle
- target_roll: Number (required) - Target roll angle
- yaw_tolerance: Number (required) - Tolerance for yaw
- pitch_tolerance: Number (required) - Tolerance for pitch
- roll_tolerance: Number (required) - Tolerance for roll
```

**Response:**
```json
{
  "valid": true,
  "face_detected": true,
  "landmarks_detected": true,
  "yaw": 43.2,
  "pitch": 1.8,
  "roll": -1.1,
  "framing_ok": true,
  "quality_ok": true,
  "errors": [],
  "warnings": [],
  "confidence": 0.95,
  "landmark_count": 468,
  "processing_time_ms": 245
}
```

## Technical Details

### Face Detection

Uses MediaPipe Face Detection with model selection:
- Model 0: Fast, for close-range faces (< 2 meters)
- Model 1: More accurate, for full-range faces

### Landmark Detection

Uses MediaPipe Face Mesh with 468 3D facial landmarks.

### Pose Estimation

Uses OpenCV `solvePnP` with 6 key facial landmarks:
1. Nose tip
2. Chin
3. Left eye outer corner
4. Right eye outer corner
5. Left mouth corner
6. Right mouth corner

The 3D model points are based on a generic face model.
The 2D image points come from MediaPipe landmarks.

**Important**: These angles are for photographic standardization only, not medical-grade measurements.

### Validation Logic

For each facial view, the service checks:

1. **Face Detection**: Is a face detected?
2. **Landmark Detection**: Are facial landmarks detected?
3. **Pose Angles**: Are yaw/pitch/roll within tolerance?
4. **Framing**: Is the face properly centered and sized?
5. **Quality**: Is the image clear and well-lit?

### Angle Definitions

- **Yaw**: Rotation around vertical axis
  - 0° = frontal
  - +ve = face turned right (from camera view)
  - -ve = face turned left
- **Pitch**: Rotation around lateral axis
  - 0° = level
  - +ve = looking down
  - -ve = looking up
- **Roll**: Rotation around longitudinal axis
  - 0° = level
  - +ve = head tilted right
  - -ve = head tilted left

## Directory Structure

```
python-cv/
├── app.py                    # Main Flask application
├── requirements.txt          # Python dependencies
├── .env                      # Environment variables
├── config/
│   └── facial_views.py       # Facial view configurations
├── services/
│   ├── face_detection.py     # MediaPipe face detection
│   ├── landmark_detection.py # MediaPipe landmark detection
│   ├── pose_estimation.py    # OpenCV pose estimation
│   ├── view_validator.py     # View validation logic
│   ├── image_quality.py      # Quality checks
│   └── validation_pipeline.py# Complete validation pipeline
└── utils/
    └── image_utils.py        # Image processing utilities
```

## Testing

### Test with curl

```bash
# Health check
curl http://localhost:5000/health

# Validate photo
curl -X POST http://localhost:5000/validate \
  -F "photo=@test_image.jpg" \
  -F "facial_view=frontal_neutral" \
  -F "target_yaw=0" \
  -F "target_pitch=0" \
  -F "target_roll=0" \
  -F "yaw_tolerance=10" \
  -F "pitch_tolerance=10" \
  -F "roll_tolerance=10"
```

### Test with Python

```python
import requests

url = 'http://localhost:5000/validate'
files = {'photo': open('test_image.jpg', 'rb')}
data = {
    'facial_view': 'frontal_neutral',
    'target_yaw': 0,
    'target_pitch': 0,
    'target_roll': 0,
    'yaw_tolerance': 10,
    'pitch_tolerance': 10,
    'roll_tolerance': 10
}

response = requests.post(url, files=files, data=data)
print(response.json())
```

## Performance

- **Average processing time**: 200-300ms per photo
- **Memory usage**: ~200MB per worker
- **Recommended workers**: 4 (for quad-core CPU)

## Error Handling

The service returns detailed error messages:

| Error Code | Message | Meaning |
|------------|---------|---------|
| `no_face_detected` | No face detected | No face found in image |
| `multiple_faces` | Multiple faces detected | More than one face found |
| `landmarks_insufficient` | Insufficient landmarks | Landmark detection failed |
| `yaw_out_of_range` | Yaw out of range | Head rotation incorrect |
| `pitch_out_of_range` | Pitch out of range | Head tilt incorrect |
| `roll_out_of_range` | Roll out of range | Head roll incorrect |
| `face_too_small` | Face too small | Move closer to camera |
| `face_too_large` | Face too large | Move away from camera |
| `image_too_blurry` | Image is blurry | Hold camera steady |
| `insufficient_lighting` | Lighting insufficient | Improve lighting |

## Security

- Service should run on localhost or internal network
- Do NOT expose directly to public internet
- Use firewall to restrict access to Express backend only
- All photo data is processed in memory and not persisted

## Troubleshooting

### "ModuleNotFoundError: No module named 'cv2'"
```bash
pip install opencv-python
```

### "ImportError: cannot import name 'solutions' from 'mediapipe'"
```bash
pip install --upgrade mediapipe
```

### "Port 5000 already in use"
Change port in `.env` or app.py

### "Pose estimation failing"
Check that image quality is good and face is clearly visible

### High memory usage
Reduce number of workers or process images in batches

## Limitations

1. **Not Medical-Grade**: Angles are for photo standardization, not clinical measurement
2. **Single Face**: Only processes one face per image
3. **2D Only**: Does not perform 3D reconstruction
4. **Lighting Dependent**: Requires adequate lighting for accuracy
5. **Generic Model**: Uses generic face model, not patient-specific

## Future Enhancements

- [ ] 3D face reconstruction
- [ ] Landmark-based image alignment
- [ ] Advanced quality metrics
- [ ] GPU acceleration
- [ ] Batch processing
- [ ] Real-time video processing
- [ ] Patient-specific face models

## License

Part of PlastoVision capstone project.

## Support

For issues or questions, contact the development team.
