"""
Face Detection Service

Uses MediaPipe Face Detection to detect faces in images.
"""

import mediapipe as mp
import cv2


class FaceDetector:
    """Face detection using MediaPipe"""
    
    def __init__(self, model_selection=0, min_detection_confidence=0.5):
        """
        Initialize face detector
        
        Args:
            model_selection: 0 for short-range (< 2 meters), 1 for full-range
            min_detection_confidence: Minimum confidence threshold (0-1)
        """
        self.mp_face_detection = mp.solutions.face_detection
        self.face_detection = self.mp_face_detection.FaceDetection(
            model_selection=model_selection,
            min_detection_confidence=min_detection_confidence
        )
    
    def detect_faces(self, image):
        """
        Detect faces in image
        
        Args:
            image: OpenCV image (BGR format)
            
        Returns:
            dict: {
                'faces_detected': bool,
                'face_count': int,
                'detections': list of detection objects,
                'bounding_boxes': list of (x, y, width, height) tuples
            }
        """
        # Convert BGR to RGB
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        # Process image
        results = self.face_detection.process(image_rgb)
        
        # Extract results
        faces_detected = results.detections is not None
        face_count = len(results.detections) if faces_detected else 0
        
        # Get image dimensions
        height, width = image.shape[:2]
        
        # Extract bounding boxes
        bounding_boxes = []
        if faces_detected:
            for detection in results.detections:
                bbox = detection.location_data.relative_bounding_box
                
                # Convert normalized coordinates to pixels
                x = int(bbox.xmin * width)
                y = int(bbox.ymin * height)
                w = int(bbox.width * width)
                h = int(bbox.height * height)
                
                bounding_boxes.append((x, y, w, h))
        
        return {
            'faces_detected': faces_detected,
            'face_count': face_count,
            'detections': results.detections if faces_detected else [],
            'bounding_boxes': bounding_boxes
        }
    
    def get_primary_face(self, image):
        """
        Get the largest/most confident face in image
        
        Args:
            image: OpenCV image
            
        Returns:
            dict: Detection result for primary face or None
        """
        result = self.detect_faces(image)
        
        if not result['faces_detected']:
            return None
        
        if result['face_count'] == 1:
            return {
                'detection': result['detections'][0],
                'bounding_box': result['bounding_boxes'][0]
            }
        
        # Multiple faces - find largest
        largest_idx = 0
        largest_area = 0
        
        for idx, bbox in enumerate(result['bounding_boxes']):
            x, y, w, h = bbox
            area = w * h
            
            if area > largest_area:
                largest_area = area
                largest_idx = idx
        
        return {
            'detection': result['detections'][largest_idx],
            'bounding_box': result['bounding_boxes'][largest_idx]
        }
    
    def __del__(self):
        """Cleanup"""
        if hasattr(self, 'face_detection'):
            self.face_detection.close()
