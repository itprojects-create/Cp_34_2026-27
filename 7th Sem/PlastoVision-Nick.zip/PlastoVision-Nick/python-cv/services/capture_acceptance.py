"""Conservative engineering checks; local clinical approval is a separate input."""
import numpy as np
from config.protocol import CAPTURE, VIEWS


def anatomical_evidence(points, width, height, view, protocol='full_face'):
    unavailable = dict(available=False, passed=False, reason='Landmark anatomy unavailable')
    if points is None or len(points) < 468 or VIEWS[view]['review']:
        return unavailable
    p = np.asarray(points, dtype=float)
    if p.shape[1] != 2 or not np.isfinite(p).all():
        return unavailable
    # Presence is supporting evidence only: no facial symmetry test is applied.
    required = [1, 70, 300, 17, 33, 263, 61, 291, 13, 14] if protocol == 'nasal_focused' else [1, 10, 152, 33, 263, 61, 291, 13, 14, 234, 454]
    q = p[required] / [width, height]
    margin = CAPTURE['landmark_margin']
    contained = bool(((q > margin) & (q < 1-margin)).all())
    mouth_width = np.linalg.norm(p[61]-p[291])
    mouth_open = float(np.linalg.norm(p[13]-p[14])/max(mouth_width, 1))
    face_width = abs(p[454, 0]-p[234, 0])
    tangent = float(min(abs(p[1, 0]-p[234, 0]), abs(p[1, 0]-p[454, 0]))/max(face_width, 1))
    perspective_ok = 'oblique' not in view or tangent <= CAPTURE['oblique_tangent_ratio']
    return dict(available=True, passed=bool(contained and mouth_width > 10 and
                mouth_open <= CAPTURE['max_mouth_open_ratio'] and perspective_ok),
                landmarks_contained=contained, mouth_open_ratio=mouth_open,
                oblique_tangent_ratio=tangent, perspective_ok=perspective_ok,
                limitations='Mesh contour and closed mouth do not prove neutral expression, scalp boundaries or Frankfort plane.')


def automation_policy(camera, setup, view, image_size):
    """An approval flag alone is insufficient. Never promote profile/basal estimates."""
    if VIEWS[view]['review']:
        return False, 'Selected view requires clinician confirmation', None
    if not camera or not camera.get('directions_verified'):
        return False, 'Physically verify camera directions and side labels', None
    if not camera.get('camera_matrix') or not camera.get('distortion'):
        return False, 'Measured camera intrinsics are required for automatic capture', None
    if not camera.get('device_id') or setup.get('actual_camera', {}).get('deviceId') != camera['device_id']:
        return False, 'Camera device differs from calibrated device', None
    actual = setup.get('actual_camera', {})
    if [actual.get('width'), actual.get('height')] != camera.get('image_size'):
        return False, 'Capture resolution differs from calibrated camera mode', None
    approval = camera.get('approved_views', {}).get(view, {})
    reference = approval.get('reference_face_height_ratio')
    if (not approval.get('clinician_id') or not approval.get('approved_at') or
            not approval.get('physical_test_record') or not isinstance(reference, (float, int)) or
            not .1 < reference < .95):
        return False, 'Camera/view requires recorded physical testing and clinician-approved reference scale', None
    if approval.get('framing_protocol') != setup.get('framing_protocol', 'full_face'):
        return False, 'Framing protocol differs from approved camera/view', None
    if not setup.get('physical_setup_confirmed'):
        return False, 'Photographer must confirm physical setup and anatomical boundaries', None
    return True, 'Engineering automatic checks enabled for approved setup', float(reference)
