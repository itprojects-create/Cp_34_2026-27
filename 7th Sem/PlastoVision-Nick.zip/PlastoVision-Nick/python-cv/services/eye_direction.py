"""Frontal iris-position heuristic, not calibrated point-of-gaze measurement."""
import numpy as np
from config.protocol import CAPTURE


def check_eye_direction(points, required=True):
    result = dict(required=required, available=False, passed=not required, eyes_open=False,
                  method='iris_position_in_eyelids', eyes=[],
                  limitation='Approximate eye direction; does not prove exact lens fixation.')
    if not required:
        return result
    if points is None or len(points) < 478:
        return result
    p = np.asarray(points, dtype=float)
    if p.shape != (len(points), 2) or not np.isfinite(p).all():
        return result
    for left, right, upper, lower, iris in [(33,133,159,145,468),(362,263,386,374,473)]:
        axis = p[right]-p[left]
        width = float(np.linalg.norm(axis))
        if width < CAPTURE['gaze_min_eye_width_px']:
            return result
        axis /= width
        normal = np.array([-axis[1], axis[0]])
        if np.dot(p[lower]-p[upper], normal) < 0:
            normal *= -1
        opening = float(np.dot(p[lower]-p[upper], normal))
        if opening <= 0:
            return result
        x = float(np.dot(p[iris]-p[left], axis)/width)
        y = float(np.dot(p[iris]-p[upper], normal)/opening)
        result['eyes'].append(dict(horizontal_ratio=x, vertical_ratio=y,
                                  openness=opening/width))
    result['available'] = True
    result['eyes_open'] = all(eye['openness'] >= CAPTURE['gaze_min_openness'] for eye in result['eyes'])
    result['passed'] = bool(result['eyes_open'] and all(
        abs(eye['horizontal_ratio']-.5) <= CAPTURE['gaze_horizontal_tolerance'] and
        abs(eye['vertical_ratio']-.5) <= CAPTURE['gaze_vertical_tolerance'] for eye in result['eyes']))
    return result
