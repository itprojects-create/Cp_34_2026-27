"""
Guidance Engine

Generates specific, actionable guidance messages for patient positioning.
Priority-based deterministic guidance generation.
"""

from config.facial_views import get_view_config


class GuidanceEngine:
    """Deterministic guidance message generation"""
    
    # Guidance priorities (lower number = higher priority)
    PRIORITY = {
        'NO_FACE': 1,
        'MULTIPLE_FACES': 2,
        'LANDMARK_FAILURE': 3,
        'FACE_TOO_SMALL': 4,
        'FACE_TOO_LARGE': 5,
        'FACE_OFF_CENTER_H': 6,
        'FACE_OFF_CENTER_V': 7,
        'YAW': 8,
        'PITCH': 9,
        'ROLL': 10,
        'BLUR': 11,
        'BRIGHTNESS_LOW': 12,
        'BRIGHTNESS_HIGH': 13,
        'READY': 99
    }
    
    def generate_guidance(self, facial_view, validation_data):
        """
        Generate single highest-priority guidance message
        
        Args:
            facial_view: Target view identifier
            validation_data: Complete validation result dict
            
        Returns:
            dict: {
                'code': str,      # Guidance code (e.g., 'TURN_LEFT')
                'message': str,   # User-facing message
                'priority': int   # Priority number
            }
        """
        issues = []
        
        # Check for face detection issues
        if not validation_data.get('face_detected', False):
            issues.append({
                'code': 'NO_FACE',
                'message': 'Position your face inside the guide',
                'priority': self.PRIORITY['NO_FACE']
            })
        
        # Check for multiple faces
        if validation_data.get('face_count', 1) > 1:
            issues.append({
                'code': 'MULTIPLE_FACES',
                'message': 'Ensure only one face is visible',
                'priority': self.PRIORITY['MULTIPLE_FACES']
            })
        
        # Check for landmark detection issues
        if not validation_data.get('landmarks_detected', False):
            issues.append({
                'code': 'LANDMARK_FAILURE',
                'message': 'Face landmarks unclear. Improve lighting',
                'priority': self.PRIORITY['LANDMARK_FAILURE']
            })
        
        # If no face, return immediately
        if not validation_data.get('face_detected', False):
            return issues[0]
        
        # Check framing issues - DISTANCE
        face_size_ratio = validation_data.get('face_size_ratio', 0)
        if face_size_ratio > 0:
            if face_size_ratio < 0.15:  # Too small - too far
                # Calculate approximate distance guidance
                if face_size_ratio < 0.08:
                    distance_msg = 'Move much closer to the camera (approximately 2-3 feet away)'
                elif face_size_ratio < 0.12:
                    distance_msg = 'Move closer to the camera (approximately 3-4 feet away)'
                else:
                    distance_msg = 'Move slightly closer to the camera'
                
                issues.append({
                    'code': 'FACE_TOO_SMALL',
                    'message': distance_msg,
                    'priority': self.PRIORITY['FACE_TOO_SMALL']
                })
            elif face_size_ratio > 0.60:  # Too large - too close
                if face_size_ratio > 0.75:
                    distance_msg = 'Move much farther from the camera'
                elif face_size_ratio > 0.65:
                    distance_msg = 'Move farther from the camera'
                else:
                    distance_msg = 'Move slightly farther from the camera'
                
                issues.append({
                    'code': 'FACE_TOO_LARGE',
                    'message': distance_msg,
                    'priority': self.PRIORITY['FACE_TOO_LARGE']
                })
        
        # Check face centering - HORIZONTAL & VERTICAL POSITIONING
        offset_x = validation_data.get('offset_x', 0)
        offset_y = validation_data.get('offset_y', 0)
        
        # Horizontal centering (higher priority)
        if abs(offset_x) > 0.1:  # More than 10% off center horizontally
            if offset_x > 0:
                message = 'Move your face to the left in the frame'
            else:
                message = 'Move your face to the right in the frame'
            
            issues.append({
                'code': 'FACE_OFF_CENTER_H',
                'message': message,
                'priority': self.PRIORITY['FACE_OFF_CENTER_H']
            })
        
        # Vertical centering (lower priority)
        if abs(offset_y) > 0.1:  # More than 10% off center vertically
            if offset_y > 0:
                message = 'Move your face up in the frame'
            else:
                message = 'Move your face down in the frame'
            
            issues.append({
                'code': 'FACE_OFF_CENTER_V',
                'message': message,
                'priority': self.PRIORITY['FACE_OFF_CENTER_V']
            })
        
        # Check pose (yaw, pitch, roll)
        if validation_data.get('pose_estimated', False):
            config = get_view_config(facial_view)
            
            yaw = validation_data.get('yaw', 0)
            pitch = validation_data.get('pitch', 0)
            roll = validation_data.get('roll', 0)
            
            yaw_valid = validation_data.get('yaw_valid', False)
            pitch_valid = validation_data.get('pitch_valid', False)
            roll_valid = validation_data.get('roll_valid', False)
            
            target_yaw = config['target_yaw']
            target_pitch = config['target_pitch']
            target_roll = config['target_roll']
            
            yaw_tolerance = config['yaw_tolerance']
            pitch_tolerance = config['pitch_tolerance']
            roll_tolerance = config['roll_tolerance']
            
            # Yaw guidance (horizontal rotation)
            if not yaw_valid:
                yaw_error = yaw - target_yaw
                
                if abs(yaw_error) > yaw_tolerance:
                    if yaw_error > 0:
                        # Face turned too far to patient's left
                        # Need to turn right (toward camera left)
                        message = self._get_yaw_guidance(yaw_error, 'left', facial_view)
                    else:
                        # Face turned too far to patient's right
                        # Need to turn left (toward camera right)
                        message = self._get_yaw_guidance(yaw_error, 'right', facial_view)
                    
                    issues.append({
                        'code': 'YAW',
                        'message': message,
                        'priority': self.PRIORITY['YAW']
                    })
            
            # Pitch guidance (vertical tilt)
            if not pitch_valid:
                pitch_error = pitch - target_pitch
                
                if abs(pitch_error) > pitch_tolerance:
                    if pitch_error > 0:
                        message = 'Lower your chin slightly'
                    else:
                        message = 'Raise your chin slightly'
                    
                    issues.append({
                        'code': 'PITCH',
                        'message': message,
                        'priority': self.PRIORITY['PITCH']
                    })
            
            # Roll guidance (head tilt)
            if not roll_valid:
                roll_error = roll - target_roll
                
                if abs(roll_error) > roll_tolerance:
                    if roll_error > 0:
                        message = 'Straighten your head (tilt less to the right)'
                    else:
                        message = 'Straighten your head (tilt less to the left)'
                    
                    issues.append({
                        'code': 'ROLL',
                        'message': message,
                        'priority': self.PRIORITY['ROLL']
                    })
        
        # Check blur
        if validation_data.get('blur_detected', False):
            issues.append({
                'code': 'BLUR',
                'message': 'Hold camera steady',
                'priority': self.PRIORITY['BLUR']
            })
        
        # Check brightness
        brightness = validation_data.get('brightness', 128)
        if brightness < 50:
            issues.append({
                'code': 'BRIGHTNESS_LOW',
                'message': 'Improve lighting — too dark',
                'priority': self.PRIORITY['BRIGHTNESS_LOW']
            })
        elif brightness > 200:
            issues.append({
                'code': 'BRIGHTNESS_HIGH',
                'message': 'Reduce lighting — too bright',
                'priority': self.PRIORITY['BRIGHTNESS_HIGH']
            })
        
        # If no issues, return ready
        if not issues:
            return {
                'code': 'READY',
                'message': 'Position correct — hold still',
                'priority': self.PRIORITY['READY']
            }
        
        # Sort by priority and return highest priority issue
        issues.sort(key=lambda x: x['priority'])
        return issues[0]
    
    def _get_yaw_guidance(self, yaw_error, direction, facial_view):
        """
        Get yaw-specific guidance based on view type
        
        Args:
            yaw_error: Yaw error in degrees
            direction: 'left' or 'right'
            facial_view: View identifier
            
        Returns:
            str: Guidance message
        """
        error_magnitude = abs(yaw_error)
        
        # Determine intensity
        if error_magnitude > 30:
            intensity = 'significantly'
        elif error_magnitude > 15:
            intensity = 'further'
        else:
            intensity = 'slightly'
        
        # For frontal views
        if facial_view in ['frontal_neutral', 'frontal_smiling']:
            if direction == 'left':
                return f'Turn your face {intensity} to the right'
            else:
                return f'Turn your face {intensity} to the left'
        
        # For oblique views
        elif 'oblique' in facial_view:
            if 'right' in facial_view:
                # Right oblique - need to show right side of face
                if direction == 'left':
                    return f'Turn {intensity} more toward the right'
                else:
                    return f'Turn {intensity} back toward the camera'
            else:
                # Left oblique - need to show left side of face
                if direction == 'left':
                    return f'Turn {intensity} back toward the camera'
                else:
                    return f'Turn {intensity} more toward the left'
        
        # For lateral views
        elif 'lateral' in facial_view:
            if 'right' in facial_view:
                if direction == 'left':
                    return f'Turn {intensity} further to show profile'
                else:
                    return f'Turn {intensity} less — too much rotation'
            else:
                if direction == 'left':
                    return f'Turn {intensity} less — too much rotation'
                else:
                    return f'Turn {intensity} further to show profile'
        
        # Generic fallback
        if direction == 'left':
            return f'Turn your face {intensity} to the right'
        else:
            return f'Turn your face {intensity} to the left'
