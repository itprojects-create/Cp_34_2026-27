"""
Image Quality Service

Checks image quality including blur detection and lighting assessment.
"""

import cv2
import numpy as np


class ImageQualityChecker:
    """Image quality assessment"""
    
    def __init__(self, blur_threshold=100, min_brightness=50, max_brightness=200):
        """
        Initialize quality checker
        
        Args:
            blur_threshold: Minimum Laplacian variance (lower = more blurry)
            min_brightness: Minimum acceptable brightness
            max_brightness: Maximum acceptable brightness
        """
        self.blur_threshold = blur_threshold
        self.min_brightness = min_brightness
        self.max_brightness = max_brightness
    
    def check_blur(self, image):
        """
        Check if image is blurry using Laplacian variance
        
        Args:
            image: OpenCV image
            
        Returns:
            dict: {
                'is_blurry': bool,
                'blur_score': float,
                'threshold': float
            }
        """
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # Calculate Laplacian variance
        laplacian = cv2.Laplacian(gray, cv2.CV_64F)
        variance = laplacian.var()
        
        # Higher variance = sharper image
        is_blurry = variance < self.blur_threshold
        
        return {
            'is_blurry': is_blurry,
            'blur_score': variance,
            'threshold': self.blur_threshold
        }
    
    def check_brightness(self, image):
        """
        Check if image has acceptable brightness
        
        Args:
            image: OpenCV image
            
        Returns:
            dict: {
                'brightness_ok': bool,
                'brightness': float (0-255),
                'too_dark': bool,
                'too_bright': bool,
                'min_brightness': float,
                'max_brightness': float
            }
        """
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # Calculate mean brightness
        brightness = np.mean(gray)
        
        # Check if within acceptable range
        too_dark = brightness < self.min_brightness
        too_bright = brightness > self.max_brightness
        brightness_ok = not (too_dark or too_bright)
        
        return {
            'brightness_ok': brightness_ok,
            'brightness': float(brightness),
            'too_dark': too_dark,
            'too_bright': too_bright,
            'min_brightness': self.min_brightness,
            'max_brightness': self.max_brightness
        }
    
    def check_exposure(self, image):
        """
        Check exposure using histogram analysis
        
        Args:
            image: OpenCV image
            
        Returns:
            dict: {
                'exposure_ok': bool,
                'underexposed_ratio': float,
                'overexposed_ratio': float
            }
        """
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # Calculate histogram
        hist = cv2.calcHist([gray], [0], None, [256], [0, 256])
        
        # Normalize
        total_pixels = gray.shape[0] * gray.shape[1]
        hist = hist / total_pixels
        
        # Check for clipping (underexposed/overexposed)
        underexposed_ratio = np.sum(hist[0:10])  # Very dark pixels
        overexposed_ratio = np.sum(hist[245:256])  # Very bright pixels
        
        # Acceptable if less than 5% clipped
        exposure_ok = (underexposed_ratio < 0.05) and (overexposed_ratio < 0.05)
        
        return {
            'exposure_ok': exposure_ok,
            'underexposed_ratio': float(underexposed_ratio),
            'overexposed_ratio': float(overexposed_ratio)
        }
    
    def check_face_size(self, face_bbox, image_width, image_height, 
                       min_ratio=0.15, max_ratio=0.85):
        """
        Check if face occupies appropriate portion of frame
        
        Args:
            face_bbox: Bounding box (x, y, width, height)
            image_width: Image width
            image_height: Image height
            min_ratio: Minimum face area ratio
            max_ratio: Maximum face area ratio
            
        Returns:
            dict: {
                'size_ok': bool,
                'face_ratio': float,
                'too_small': bool,
                'too_large': bool
            }
        """
        x, y, w, h = face_bbox
        
        face_area = w * h
        image_area = image_width * image_height
        
        face_ratio = face_area / image_area
        
        too_small = face_ratio < min_ratio
        too_large = face_ratio > max_ratio
        size_ok = not (too_small or too_large)
        
        return {
            'size_ok': size_ok,
            'face_ratio': float(face_ratio),
            'too_small': too_small,
            'too_large': too_large,
            'min_ratio': min_ratio,
            'max_ratio': max_ratio
        }
    
    def check_face_position(self, face_bbox, image_width, image_height, tolerance=0.20):
        """
        Check if face is reasonably centered
        
        Args:
            face_bbox: Bounding box (x, y, width, height)
            image_width: Image width
            image_height: Image height
            tolerance: How far from center is acceptable (0-0.5)
            
        Returns:
            dict: {
                'position_ok': bool,
                'offset_x': float (percentage),
                'offset_y': float (percentage),
                'tolerance': float
            }
        """
        x, y, w, h = face_bbox
        
        # Calculate face center
        face_center_x = x + w / 2
        face_center_y = y + h / 2
        
        # Calculate image center
        image_center_x = image_width / 2
        image_center_y = image_height / 2
        
        # Calculate offset as percentage
        offset_x = abs(face_center_x - image_center_x) / image_width
        offset_y = abs(face_center_y - image_center_y) / image_height
        
        # Check if within tolerance
        position_ok = (offset_x <= tolerance) and (offset_y <= tolerance)
        
        return {
            'position_ok': position_ok,
            'offset_x': float(offset_x),
            'offset_y': float(offset_y),
            'tolerance': tolerance
        }
    
    def comprehensive_quality_check(self, image, face_bbox=None):
        """
        Run all quality checks
        
        Args:
            image: OpenCV image
            face_bbox: Optional face bounding box for framing checks
            
        Returns:
            dict: Combined results from all checks
        """
        height, width = image.shape[:2]
        
        # Run all checks
        blur_result = self.check_blur(image)
        brightness_result = self.check_brightness(image)
        exposure_result = self.check_exposure(image)
        
        # Face-specific checks
        if face_bbox:
            size_result = self.check_face_size(face_bbox, width, height)
            position_result = self.check_face_position(face_bbox, width, height)
        else:
            size_result = {'size_ok': True}
            position_result = {'position_ok': True}
        
        # Combine results
        quality_ok = (
            not blur_result['is_blurry'] and
            brightness_result['brightness_ok'] and
            exposure_result['exposure_ok'] and
            size_result['size_ok'] and
            position_result['position_ok']
        )
        
        return {
            'quality_ok': quality_ok,
            'blur': blur_result,
            'brightness': brightness_result,
            'exposure': exposure_result,
            'face_size': size_result,
            'face_position': position_result
        }
