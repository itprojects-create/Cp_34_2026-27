"""Camera profiles are loaded from an operator-controlled local JSON file."""
import json
import os
import numpy as np


def load_profiles():
    filename = os.getenv('CAMERA_PROFILES_FILE')
    if not filename:
        return {}
    with open(filename, encoding='utf-8') as stream:
        profiles = json.load(stream)
    if not isinstance(profiles, dict):
        raise ValueError('Camera profiles must be an object keyed by profile ID')
    return profiles


def camera_intrinsics(width, height, calibration=None):
    if width <= 0 or height <= 0:
        raise ValueError('Invalid image dimensions')
    if not calibration:
        return np.array([[width, 0, width/2], [0, width, height/2], [0, 0, 1.]], dtype=float), np.zeros(5), 'approximate'
    matrix = np.asarray(calibration['camera_matrix'], dtype=float).copy()
    distortion = np.asarray(calibration['distortion'], dtype=float)
    source_width, source_height = calibration['image_size']
    if matrix.shape != (3, 3) or distortion.size not in (4, 5, 8, 12, 14):
        raise ValueError('Invalid calibration shape')
    if not np.isfinite(matrix).all() or not np.isfinite(distortion).all() or min(source_width, source_height) <= 0:
        raise ValueError('Invalid calibration values')
    if matrix[0, 0] <= 0 or matrix[1, 1] <= 0 or not np.allclose(matrix[2], [0, 0, 1]):
        raise ValueError('Invalid intrinsic matrix')
    if abs(width/height - source_width/source_height) > 0.01:
        raise ValueError('Calibration aspect ratio differs; recalibrate for this camera mode')
    matrix[0] *= width/source_width
    matrix[1] *= height/source_height
    return matrix, distortion, 'calibrated'
