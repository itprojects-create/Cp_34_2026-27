"""
Pose Estimation Service

Uses OpenCV solvePnP to estimate head pose (yaw, pitch, roll) from facial landmarks.
"""

import cv2
import numpy as np


class PoseEstimator:
    """Head pose estimation using OpenCV solvePnP"""
    
    def __init__(self):
        """Initialize pose estimator with 3D face model"""
        
        # Generic 3D face model points (in arbitrary units)
        # Based on standard anthropometric measurements
        # Camera-aligned generic model: x image-right, y down, z away.
        # Units are arbitrary; translation is NOT a physical distance.
        self.model_points_3d = np.array([
            (0, 0, 0), (0, 330, 65), (-225, -170, 135),
            (225, -170, 135), (-150, 150, 125), (150, 150, 125)
        ], dtype=np.float64)

    def estimate_pose(self, image_points_2d, image_width, image_height, calibration=None):
        failure = dict(success=False, yaw=None, pitch=None, roll=None,
                       method='solvePnP', calibration_status='approximate')
        try:
            points = np.asarray(image_points_2d, dtype=np.float64)
            if points.shape != (6, 2) or not np.isfinite(points).all():
                return failure
            if np.any(points < 0) or np.any(points[:, 0] >= image_width) or np.any(points[:, 1] >= image_height):
                return failure
            if np.linalg.matrix_rank(points - points.mean(axis=0)) < 2:
                return failure
            from services.camera_calibration import camera_intrinsics
            matrix, distortion, status = camera_intrinsics(image_width, image_height, calibration)
            success, rvec, tvec = cv2.solvePnP(self.model_points_3d, points, matrix,
                                             distortion, flags=cv2.SOLVEPNP_ITERATIVE)
            if not success or not np.isfinite(rvec).all() or not np.isfinite(tvec).all():
                return failure
            rotation, _ = cv2.Rodrigues(rvec)
            depths = (rotation @ self.model_points_3d.T + tvec)[2]
            projected, _ = cv2.projectPoints(self.model_points_3d, rvec, tvec, matrix, distortion)
            residual = float(np.sqrt(np.mean(np.sum((projected.reshape(-1, 2) - points)**2, axis=1))))
            span = float(np.linalg.norm(points[2] - points[3]))
            if np.any(depths <= 0) or span < 10 or residual / span > 0.08:
                return {**failure, 'reprojection_rmse_px': residual}
            yaw, pitch, roll = self._rotation_matrix_to_euler_angles(rotation)
            return dict(success=True, yaw=yaw, pitch=pitch, roll=roll, method='solvePnP',
                        calibration_status=status, reprojection_rmse_px=residual,
                        normalized_residual=residual / span,
                        rotation_vector=rvec, translation_vector=tvec)
        except (cv2.error, ValueError, TypeError):
            return failure

    def _rotation_matrix_to_euler_angles(self, rotation_matrix):
        # R = Rz(roll) Ry(yaw) Rx(pitch). At +/-90 yaw pitch/roll are coupled.
        sy = np.hypot(rotation_matrix[0, 0], rotation_matrix[1, 0])
        yaw = np.arctan2(-rotation_matrix[2, 0], sy)
        pitch = np.arctan2(rotation_matrix[2, 1], rotation_matrix[2, 2])
        roll = np.arctan2(rotation_matrix[1, 0], rotation_matrix[0, 0])
        return tuple(float(np.degrees(a)) for a in (yaw, pitch, roll))

    def validate_pose(self, yaw, pitch, roll, target_yaw, target_pitch, target_roll,
                     yaw_tolerance, pitch_tolerance, roll_tolerance):
        """
        Validate if pose is within acceptable range
        
        Args:
            yaw, pitch, roll: Detected angles
            target_yaw, target_pitch, target_roll: Target angles
            yaw_tolerance, pitch_tolerance, roll_tolerance: Tolerances
            
        Returns:
            dict: {
                'valid': bool,
                'yaw_valid': bool,
                'pitch_valid': bool,
                'roll_valid': bool,
                'yaw_error': float,
                'pitch_error': float,
                'roll_error': float
            }
        """
        # Calculate errors
        yaw_error = abs(yaw - target_yaw)
        pitch_error = abs(pitch - target_pitch)
        roll_error = abs(roll - target_roll)
        
        # Check if within tolerance
        yaw_valid = yaw_error <= yaw_tolerance
        pitch_valid = pitch_error <= pitch_tolerance
        roll_valid = roll_error <= roll_tolerance
        
        valid = yaw_valid and pitch_valid and roll_valid
        
        return {
            'valid': valid,
            'yaw_valid': yaw_valid,
            'pitch_valid': pitch_valid,
            'roll_valid': roll_valid,
            'yaw_error': yaw_error,
            'pitch_error': pitch_error,
            'roll_error': roll_error
        }
