"""
Landmark Detection Service

Uses MediaPipe Face Mesh to detect 468 facial landmarks.
"""

import mediapipe as mp
import cv2
import numpy as np
import os
import time


class LandmarkDetector:
    """Facial landmark detection using MediaPipe Face Mesh"""
    
    # Key landmark indices for pose estimation
    KEY_LANDMARKS = {
        'nose_tip': 1,           # Nose tip
        'chin': 152,             # Chin
        'left_eye_outer': 33,   # Left eye outer corner
        'right_eye_outer': 263,   # Right eye outer corner
        'left_mouth': 61,       # Left mouth corner
        'right_mouth': 291        # Right mouth corner
    }
    
    def __init__(self, static_image_mode=True, max_num_faces=1, 
                 refine_landmarks=True, min_detection_confidence=0.5,
                 min_tracking_confidence=0.5):
        """
        Initialize landmark detector
        
        Args:
            static_image_mode: True for static images, False for video
            max_num_faces: Maximum number of faces to detect
            refine_landmarks: Whether to refine landmarks around eyes and lips
            min_detection_confidence: Minimum detection confidence
            min_tracking_confidence: Minimum tracking confidence
        """
        self.mp_face_mesh = mp.solutions.face_mesh
        self.task = None
        self.timestamp = 0
        model = os.getenv('FACE_LANDMARKER_MODEL')
        if model:
            from mediapipe.tasks import python
            from mediapipe.tasks.python import vision
            self.task = vision.FaceLandmarker.create_from_options(vision.FaceLandmarkerOptions(
                base_options=python.BaseOptions(model_asset_path=model),
                running_mode=vision.RunningMode.IMAGE if static_image_mode else vision.RunningMode.VIDEO,
                num_faces=max_num_faces, min_face_detection_confidence=min_detection_confidence,
                min_tracking_confidence=min_tracking_confidence))
            self.static_image_mode = static_image_mode
            return
        self.face_mesh = self.mp_face_mesh.FaceMesh(
            static_image_mode=static_image_mode,
            max_num_faces=max_num_faces,
            refine_landmarks=refine_landmarks,
            min_detection_confidence=min_detection_confidence,
            min_tracking_confidence=min_tracking_confidence
        )
    
    def detect_landmarks(self, image):
        """
        Detect facial landmarks
        
        Args:
            image: OpenCV image (BGR format)
            
        Returns:
            dict: {
                'landmarks_detected': bool,
                'landmark_count': int,
                'landmarks': list of landmark objects,
                'landmarks_2d': list of (x, y) tuples in pixel coordinates,
                'landmarks_3d': list of (x, y, z) tuples (normalized)
            }
        """
        # Convert BGR to RGB
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        # Get image dimensions
        height, width = image.shape[:2]
        
        # Process image
        if self.task:
            frame = mp.Image(image_format=mp.ImageFormat.SRGB, data=np.ascontiguousarray(image_rgb))
            self.timestamp = max(self.timestamp+1, time.monotonic_ns()//1_000_000)
            result = self.task.detect(frame) if self.static_image_mode else self.task.detect_for_video(frame, self.timestamp)
            from types import SimpleNamespace
            results = SimpleNamespace(multi_face_landmarks=[SimpleNamespace(landmark=p) for p in result.face_landmarks] or None)
        else:
            results = self.face_mesh.process(image_rgb)
        
        # Check if landmarks detected
        landmarks_detected = results.multi_face_landmarks is not None
        
        if not landmarks_detected:
            return {
                'landmarks_detected': False,
                'landmark_count': 0,
                'landmarks': None,
                'landmarks_2d': [],
                'landmarks_3d': []
            }
        
        # Get first face (we only process one face)
        face_landmarks = results.multi_face_landmarks[0]
        landmark_count = len(face_landmarks.landmark)
        
        # Convert to 2D pixel coordinates
        landmarks_2d = []
        for landmark in face_landmarks.landmark:
            x = float(landmark.x * width)
            y = float(landmark.y * height)
            landmarks_2d.append((x, y))
        
        # Store 3D normalized coordinates
        landmarks_3d = []
        for landmark in face_landmarks.landmark:
            landmarks_3d.append((landmark.x, landmark.y, landmark.z))
        
        return {
            'face_count': len(results.multi_face_landmarks),
            'landmarks_detected': True,
            'landmark_count': landmark_count,
            'landmarks': face_landmarks,
            'landmarks_2d': landmarks_2d,
            'landmarks_3d': landmarks_3d
        }
    
    def get_key_landmarks_2d(self, image):
        """
        Get 6 key facial landmarks for pose estimation
        
        Args:
            image: OpenCV image
            
        Returns:
            numpy.ndarray: Array of shape (6, 2) with key landmarks in pixel coordinates
            or None if detection failed
        """
        result = self.detect_landmarks(image)
        
        if not result['landmarks_detected']:
            return None
        
        landmarks_2d = result['landmarks_2d']
        height, width = image.shape[:2]
        
        # Extract 6 key points
        key_points = np.array([
            landmarks_2d[self.KEY_LANDMARKS['nose_tip']],
            landmarks_2d[self.KEY_LANDMARKS['chin']],
            landmarks_2d[self.KEY_LANDMARKS['left_eye_outer']],
            landmarks_2d[self.KEY_LANDMARKS['right_eye_outer']],
            landmarks_2d[self.KEY_LANDMARKS['left_mouth']],
            landmarks_2d[self.KEY_LANDMARKS['right_mouth']]
        ], dtype=np.float64)
        
        return key_points
    
    def get_face_bounding_box(self, landmarks_2d):
        """
        Calculate bounding box from landmarks
        
        Args:
            landmarks_2d: List of (x, y) tuples
            
        Returns:
            tuple: (x, y, width, height)
        """
        if not landmarks_2d:
            return None
        
        # Convert to numpy array
        points = np.array(landmarks_2d)
        
        # Get min/max
        x_min = np.min(points[:, 0])
        x_max = np.max(points[:, 0])
        y_min = np.min(points[:, 1])
        y_max = np.max(points[:, 1])
        
        # Calculate bounding box
        x = int(x_min)
        y = int(y_min)
        width = int(x_max - x_min)
        height = int(y_max - y_min)
        
        return (x, y, width, height)
    
    def __del__(self):
        """Cleanup"""
        if hasattr(self, 'face_mesh'):
            self.face_mesh.close()
