"""Single-frame measurements. Temporal readiness belongs to the capture session."""
import time
import threading
import numpy as np
import cv2
from services.face_detection import FaceDetector
from services.landmark_detection import LandmarkDetector
from services.pose_estimation import PoseEstimator
from services.image_quality import ImageQualityChecker
from services.camera_calibration import load_profiles, camera_intrinsics
from config.protocol import ALIASES, VIEWS, FRAMING, CAPTURE
from services.capture_acceptance import anatomical_evidence, automation_policy
from services.eye_direction import check_eye_direction
from utils.image_utils import load_image_from_bytes, resize_image_if_needed


class ValidationPipeline:
    def __init__(self):
        self.face_detector = FaceDetector(model_selection=1, min_detection_confidence=.5)
        self.landmark_detector = LandmarkDetector(static_image_mode=True, max_num_faces=2)
        # Optional Tasks VIDEO tracker is only shared within one explicitly identified session.
        # Solutions IMAGE fallback avoids transferring tracking state between patients.
        import os
        self.video_detector = LandmarkDetector(static_image_mode=False, max_num_faces=2) if os.getenv('FACE_LANDMARKER_MODEL') else None
        self.video_session = None
        self.pose_estimator = PoseEstimator()
        self.quality_checker = ImageQualityChecker(blur_threshold=CAPTURE['blur_threshold'])
        self.profiles = load_profiles()
        self.lock = threading.Lock()  # MediaPipe solution instances are not request-thread safe.

    def validate_photo(self, image_bytes, facial_view, live_mode=False, setup=None):
        # No request backlog: let the browser retry using a newer frame.
        if not self.lock.acquire(blocking=False):
            return dict(schema_version=2, state='BUSY', valid=False, capture_ready=False,
                        reviewable=False, guidance_code='BUSY', guidance='Analysis busy; hold still')
        try:
            return self._validate(image_bytes, facial_view, live_mode, setup or {})
        finally:
            self.lock.release()

    def _calculate_face_reference_measurements(self, landmarks_2d):
        """
        Calculate reliable reference measurements for normalizing geometric features.
        
        Args:
            landmarks_2d: MediaPipe 468 facial landmarks
            
        Returns:
            dict: {
                'inter_pupillary_distance': float,
                'face_width': float,
                'face_height': float,
                'eye_level_y': float
            }
        """
        if landmarks_2d is None or len(landmarks_2d) < 468:
            return None
        
        # Inter-pupillary distance (IPD) - most reliable reference
        left_eye = landmarks_2d[33]   # Left eye outer corner
        right_eye = landmarks_2d[263]  # Right eye outer corner
        ipd = np.sqrt((right_eye[0] - left_eye[0])**2 + (right_eye[1] - left_eye[1])**2)
        
        # Face bounding measurements
        all_x = [lm[0] for lm in landmarks_2d]
        all_y = [lm[1] for lm in landmarks_2d]
        face_width = max(all_x) - min(all_x)
        face_height = max(all_y) - min(all_y)
        
        # Eye level
        eye_level_y = (left_eye[1] + right_eye[1]) / 2
        
        return {
            'inter_pupillary_distance': ipd,
            'face_width': face_width,
            'face_height': face_height,
            'eye_level_y': eye_level_y
        }

    def _detect_frontal_indicators(self, landmarks_2d, width, height):
        """
        Detect strong NEUTRAL FRONTAL view indicators that contradict basal viewpoint.
        
        CRITICAL: This function must distinguish NEUTRAL FRONTAL from BASAL viewpoint.
        Both views can have centered eyes, centered nose, and bilateral symmetry.
        
        The key discriminator is VERTICAL VIEWPOINT:
        - Frontal: neutral head pitch, nose/eyes at expected relative positions
        - Basal: head extended back, nasal underside visible, altered vertical relationships
        
        Args:
            landmarks_2d: MediaPipe 468 facial landmarks
            width, height: Image dimensions
            
        Returns:
            dict: {
                'frontal_detected': bool,
                'confidence': 'confident' | 'probable' | 'uncertain',
                'evidence': list of str,
                'contradictory_basal': bool  # True if features contradict basal viewpoint
            }
        """
        if landmarks_2d is None or len(landmarks_2d) < 468:
            return {'frontal_detected': False, 'confidence': 'uncertain', 'evidence': [], 'contradictory_basal': False}
        
        evidence = []
        contradictory_basal_evidence = []
        
        # Get reference measurements
        refs = self._calculate_face_reference_measurements(landmarks_2d)
        if refs is None:
            return {'frontal_detected': False, 'confidence': 'uncertain', 'evidence': [], 'contradictory_basal': False}
        
        # HORIZONTAL ALIGNMENT (not discriminative for frontal vs basal)
        left_eye = landmarks_2d[33]
        right_eye = landmarks_2d[263]
        eye_y_diff = abs(left_eye[1] - right_eye[1])
        eye_y_symmetry = eye_y_diff < (refs['inter_pupillary_distance'] * 0.15)
        
        nose_tip = landmarks_2d[4]
        face_center_x = (left_eye[0] + right_eye[0]) / 2
        nose_offset = abs(nose_tip[0] - face_center_x)
        nose_centered = nose_offset < (refs['inter_pupillary_distance'] * 0.25)
        
        left_to_nose = np.sqrt((nose_tip[0] - left_eye[0])**2 + (nose_tip[1] - left_eye[1])**2)
        right_to_nose = np.sqrt((nose_tip[0] - right_eye[0])**2 + (nose_tip[1] - right_eye[1])**2)
        distance_ratio = min(left_to_nose, right_to_nose) / max(left_to_nose, right_to_nose) if max(left_to_nose, right_to_nose) > 0 else 0
        eye_distances_symmetric = distance_ratio > 0.85
        
        # These indicate bilateral alignment, not neutral frontal viewpoint
        alignment_evidence = []
        if eye_y_symmetry:
            alignment_evidence.append(f"bilateral eye alignment (y_diff={eye_y_diff:.1f}px)")
        if nose_centered:
            alignment_evidence.append(f"nose horizontally centered (offset={nose_offset:.1f}px)")
        if eye_distances_symmetric:
            alignment_evidence.append(f"bilateral eye-to-nose symmetry (ratio={distance_ratio:.2f})")
        
        # VERTICAL VIEWPOINT INDICATORS (discriminative for frontal vs basal)
        
        # CHECK 1: Nose tip BELOW eyes (neutral frontal indicator, contradicts basal)
        # In neutral frontal: nose tip Y > eye level Y (lower in image)
        # In basal: nose tip Y may be < eye level Y (higher in image) due to head extension
        nose_below_eyes = nose_tip[1] > refs['eye_level_y']
        nose_to_eye_vertical = nose_tip[1] - refs['eye_level_y']
        
        if nose_below_eyes and nose_to_eye_vertical > (refs['inter_pupillary_distance'] * 0.3):
            evidence.append(f"nose tip well below eye level (+{nose_to_eye_vertical:.1f}px, neutral frontal indicator)")
            contradictory_basal_evidence.append("nose tip below eyes")
        
        # CHECK 2: Nasal bridge to nose tip distance (neutral frontal has typical distance)
        # In basal, this distance may appear compressed or elongated
        nasal_bridge = landmarks_2d[6]
        bridge_to_tip_dist = abs(nasal_bridge[1] - nose_tip[1])
        bridge_to_tip_normalized = bridge_to_tip_dist / refs['inter_pupillary_distance'] if refs['inter_pupillary_distance'] > 0 else 0
        typical_nose_length = 0.4 < bridge_to_tip_normalized < 0.9
        
        if typical_nose_length:
            evidence.append(f"typical nasal bridge-to-tip distance (ratio={bridge_to_tip_normalized:.2f})")
        
        # CHECK 3: Forehead visible and proportional
        # In basal, forehead may be less prominent or occluded
        # Use top landmarks to assess forehead visibility
        forehead_top = landmarks_2d[10]  # Forehead center
        forehead_to_eyes = abs(forehead_top[1] - refs['eye_level_y'])
        forehead_to_eyes_normalized = forehead_to_eyes / refs['face_height'] if refs['face_height'] > 0 else 0
        forehead_prominent = forehead_to_eyes_normalized > 0.20
        
        if forehead_prominent:
            evidence.append(f"forehead prominent (ratio={forehead_to_eyes_normalized:.2f})")
            contradictory_basal_evidence.append("prominent forehead")
        
        # CHECK 4: Chin to nose distance (neutral frontal has typical proportions)
        chin = landmarks_2d[152]
        chin_to_nose = abs(chin[1] - nose_tip[1])
        chin_to_nose_normalized = chin_to_nose / refs['inter_pupillary_distance'] if refs['inter_pupillary_distance'] > 0 else 0
        typical_lower_face = 0.8 < chin_to_nose_normalized < 1.8
        
        if typical_lower_face:
            evidence.append(f"typical chin-to-nose distance (ratio={chin_to_nose_normalized:.2f})")
        
        # CHECK 5: Nostrils NOT prominently visible
        # In basal, nostril regions should be more visible
        # Use approximate nostril landmarks to check visibility
        try:
            # Approximate nostril region landmarks
            left_nostril_region = [landmarks_2d[i] for i in [102, 49, 48, 115] if i < len(landmarks_2d)]
            right_nostril_region = [landmarks_2d[i] for i in [331, 279, 278, 344] if i < len(landmarks_2d)]
            
            if left_nostril_region and right_nostril_region:
                # Calculate vertical span of nostril regions
                left_nostril_y_span = max(p[1] for p in left_nostril_region) - min(p[1] for p in left_nostril_region)
                right_nostril_y_span = max(p[1] for p in right_nostril_region) - min(p[1] for p in right_nostril_region)
                avg_nostril_span = (left_nostril_y_span + right_nostril_y_span) / 2
                nostril_span_normalized = avg_nostril_span / refs['inter_pupillary_distance'] if refs['inter_pupillary_distance'] > 0 else 0
                
                # In frontal, nostril span is small; in basal, it's larger
                nostrils_not_prominent = nostril_span_normalized < 0.25
                
                if nostrils_not_prominent:
                    evidence.append(f"nostrils not prominently visible (span={nostril_span_normalized:.2f})")
                    contradictory_basal_evidence.append("nostrils not prominent")
        except (IndexError, ValueError):
            pass
        
        # DECISION LOGIC
        # Require VERTICAL viewpoint evidence, not just horizontal alignment
        vertical_evidence_count = len([e for e in evidence if any(kw in e for kw in ['below eye', 'forehead', 'chin-to-nose', 'nostril', 'nasal bridge'])])
        contradictory_basal_count = len(contradictory_basal_evidence)
        
        # Strong neutral frontal: multiple vertical indicators + contradicts basal
        if vertical_evidence_count >= 3 and contradictory_basal_count >= 2:
            return {
                'frontal_detected': True,
                'confidence': 'confident',
                'evidence': evidence,
                'alignment_only': alignment_evidence,
                'contradictory_basal': True
            }
        # Probable neutral frontal: some vertical indicators
        elif vertical_evidence_count >= 2 and contradictory_basal_count >= 1:
            return {
                'frontal_detected': True,
                'confidence': 'probable',
                'evidence': evidence,
                'alignment_only': alignment_evidence,
                'contradictory_basal': True
            }
        # Only horizontal alignment - insufficient to determine frontal vs basal
        else:
            return {
                'frontal_detected': False,
                'confidence': 'uncertain',
                'evidence': evidence,
                'alignment_only': alignment_evidence,
                'contradictory_basal': False
            }


    def _validate_basal_viewpoint(self, landmarks_2d, width, height, yaw, pitch, roll):
        """
        Dedicated validator for basal/worm's-eye view.
        
        Verifies actual nasal-base viewpoint, not just pitch angle.
        Checks multiple anatomical indicators to distinguish from frontal with raised chin.
        
        Args:
            landmarks_2d: MediaPipe 468 facial landmarks
            width, height: Image dimensions
            yaw, pitch, roll: Pose angles (may be None/unreliable)
        
        Returns:
            dict: {
                'basal_viewpoint_detected': bool,
                'confidence': 'confident' | 'probable' | 'uncertain',
                'columella_visible': bool | None,
                'nostril_underside_bilateral': bool | None,
                'nasal_tip_position': str | None,
                'camera_orientation_verified': bool | None,
                'reasoning': str
            }
        """
        result = {
            'basal_viewpoint_detected': False,
            'confidence': 'uncertain',
            'columella_visible': None,
            'nostril_underside_bilateral': None,
            'nasal_tip_position': None,
            'camera_orientation_verified': None,
            'reasoning': 'Insufficient evidence for basal viewpoint verification'
        }
        
        if landmarks_2d is None or len(landmarks_2d) < 468:
            result['reasoning'] = 'Insufficient facial landmarks for basal validation'
            return result
        
        try:
            # Key nasal landmarks
            nasal_base = landmarks_2d[2]      # Nasal base center (columella base)
            nasal_tip = landmarks_2d[4]       # Nasal tip
            left_nostril = landmarks_2d[98]   # Left nostril
            right_nostril = landmarks_2d[327] # Right nostril
            nasal_bridge = landmarks_2d[6]    # Nasal bridge (between eyes)
            
            # Eye landmarks for reference
            left_eye_center = landmarks_2d[468] if len(landmarks_2d) > 468 else landmarks_2d[33]
            right_eye_center = landmarks_2d[473] if len(landmarks_2d) > 473 else landmarks_2d[263]
            
            # Eyebrow landmarks for nasal tip alignment
            left_eyebrow = landmarks_2d[70]
            right_eyebrow = landmarks_2d[300]
            
            evidence_count = 0
            max_evidence = 5
            reasons = []
            
            # CHECK 1: Columella/Nasal Base Visibility
            # In basal view, nasal base (landmark 2) should be BELOW nasal tip (landmark 4)
            # This is OPPOSITE of frontal view
            if nasal_base[1] > nasal_tip[1]:  # y increases downward
                result['columella_visible'] = True
                evidence_count += 1
                reasons.append("columella visible below nasal tip")
            else:
                result['columella_visible'] = False
                reasons.append("columella NOT visible (nasal base above tip)")
            
            # CHECK 2: Nostril Underside Bilateral Visibility
            # Both nostrils should be visible AND appear below nasal bridge
            nostrils_below_bridge = (left_nostril[1] > nasal_bridge[1] and 
                                    right_nostril[1] > nasal_bridge[1])
            nostril_separation = abs(left_nostril[0] - right_nostril[0])
            face_width_approx = width * 0.25
            nostrils_separated = nostril_separation > face_width_approx * 0.3
            
            if nostrils_below_bridge and nostrils_separated:
                result['nostril_underside_bilateral'] = True
                evidence_count += 1
                reasons.append(f"bilateral nostrils visible below bridge (sep={nostril_separation:.0f}px)")
            else:
                result['nostril_underside_bilateral'] = False
                if not nostrils_below_bridge:
                    reasons.append("nostrils NOT below nasal bridge")
                else:
                    reasons.append(f"nostril separation insufficient ({nostril_separation:.0f}px)")
            
            # CHECK 3: Nasal Tip Vertical Position
            # In basal view, nasal tip should be ABOVE eyes (higher in frame)
            # In frontal view, nasal tip is AT or BELOW eye level
            eye_level_y = (left_eye_center[1] + right_eye_center[1]) / 2
            nasal_tip_above_eyes = nasal_tip[1] < eye_level_y - (height * 0.02)
            
            if nasal_tip_above_eyes:
                result['nasal_tip_position'] = 'above_eyes'
                evidence_count += 1
                reasons.append("nasal tip above eye level (basal indicator)")
            else:
                result['nasal_tip_position'] = 'at_or_below_eyes'
                reasons.append("nasal tip at/below eye level (frontal indicator)")
            
            # CHECK 4: Nostril to Eye Distance Ratio
            # In basal, nostrils appear much closer to eyes than in frontal
            nostril_y_avg = (left_nostril[1] + right_nostril[1]) / 2
            nostril_to_eye_dist = abs(nostril_y_avg - eye_level_y)
            nasal_base_to_tip_dist = abs(nasal_base[1] - nasal_tip[1])
            
            if nasal_base_to_tip_dist > 10:  # Avoid division by zero
                ratio = nostril_to_eye_dist / nasal_base_to_tip_dist
                if ratio < 3.0:  # Nostrils close to eyes relative to nasal length
                    evidence_count += 1
                    reasons.append(f"nostril-eye proximity ratio={ratio:.2f} (basal indicator)")
                else:
                    reasons.append(f"nostril-eye ratio={ratio:.2f} (frontal indicator)")
            
            # CHECK 5: Pitch Angle Confirmation (if available)
            # Positive pitch supports basal but is NOT sufficient alone
            if pitch is not None and pitch > 12:
                result['camera_orientation_verified'] = True
                evidence_count += 1
                reasons.append(f"positive pitch={pitch:.1f}° (camera below)")
            elif pitch is not None:
                result['camera_orientation_verified'] = False
                reasons.append(f"pitch={pitch:.1f}° insufficient for basal")
            
            # DECISION LOGIC
            if evidence_count >= 4:
                result['basal_viewpoint_detected'] = True
                result['confidence'] = 'confident'
                result['reasoning'] = f"Strong basal evidence ({evidence_count}/{max_evidence}): {'; '.join(reasons)}"
            elif evidence_count >= 3:
                result['basal_viewpoint_detected'] = True
                result['confidence'] = 'probable'
                result['reasoning'] = f"Probable basal viewpoint ({evidence_count}/{max_evidence}): {'; '.join(reasons)}"
            elif evidence_count >= 2:
                result['basal_viewpoint_detected'] = False
                result['confidence'] = 'uncertain'
                result['reasoning'] = f"Insufficient basal evidence ({evidence_count}/{max_evidence}): {'; '.join(reasons)}"
            else:
                result['basal_viewpoint_detected'] = False
                result['confidence'] = 'confident'  # Confident it's NOT basal
                result['reasoning'] = f"Not basal viewpoint ({evidence_count}/{max_evidence}): {'; '.join(reasons)}"
            
            # Debug logging
            print(f"\n[BASAL VALIDATOR] Evidence: {evidence_count}/{max_evidence}, Confidence: {result['confidence']}")
            print(f"[BASAL VALIDATOR] Columella: {result['columella_visible']}, Nostrils: {result['nostril_underside_bilateral']}")
            print(f"[BASAL VALIDATOR] Nasal tip: {result['nasal_tip_position']}, Camera: {result['camera_orientation_verified']}")
            print(f"[BASAL VALIDATOR] {result['reasoning']}")
            
            return result
            
        except Exception as e:
            print(f"[BASAL VALIDATOR] Error: {e}")
            result['reasoning'] = f'Basal validation error: {str(e)}'
            return result
    
    def _check_lateral_side(self, landmarks_2d, width, view_id):
        """
        Verify correct side (left/right) for lateral view using anatomical landmarks.
        
        At 90° profile, one side of face is fully visible, other side is occluded.
        Use spatial distribution of landmarks to determine which side is visible.
        
        Strategy: Calculate center of mass (centroid) of all landmarks in camera space.
        - Right lateral (yaw=+90°): Subject rotated right, right side visible
          → Appears on CAMERA LEFT, centroid_x < 0.5
        - Left lateral (yaw=-90°): Subject rotated left, left side visible
          → Appears on CAMERA RIGHT, centroid_x > 0.5
        
        Returns:
            True if correct side, False if wrong side, None if cannot determine
        """
        try:
            if len(landmarks_2d) < 250:  # Need substantial landmarks for lateral
                return None
            
            # Calculate centroid of all landmarks in camera space
            landmark_xs = [lm[0] for lm in landmarks_2d if lm[0] > 0]  # Filter out invalid
            if len(landmark_xs) < 200:
                return None
                
            centroid_x = sum(landmark_xs) / len(landmark_xs)
            normalized_centroid = centroid_x / width  # 0.0 = camera left, 1.0 = camera right
            
            # Debug logging
            print(f"[LATERAL SIDE CHECK] view_id={view_id}, centroid={normalized_centroid:.3f}, landmarks={len(landmark_xs)}")
            print(f"[LATERAL SIDE CHECK] centroid_x={centroid_x:.1f}, width={width}, range=({min(landmark_xs):.1f}, {max(landmark_xs):.1f})")
            
            if view_id == 'right_lateral':
                # Right lateral: subject rotated right, face appears on CAMERA LEFT
                # Centroid should be in left half of frame
                # CORRECTED: Based on actual test data, right lateral has centroid > 0.5
                result = 0.52 < normalized_centroid < 0.80
                print(f"[LATERAL SIDE CHECK] Right lateral check: {result} (expect 0.52-0.80)")
                return result
                
            elif view_id == 'left_lateral':
                # Left lateral: subject rotated left, face appears on CAMERA RIGHT
                # Centroid should be in right half of frame
                # CORRECTED: Based on actual test data, left lateral has centroid < 0.5
                result = 0.20 < normalized_centroid < 0.48
                print(f"[LATERAL SIDE CHECK] Left lateral check: {result} (expect 0.20-0.48)")
                return result
                
            return None
            
        except Exception as e:
            print(f"[LATERAL SIDE CHECK] Error: {e}")
            return None
    
    def _check_oblique_side(self, landmarks_2d, width, view_id):
        """
        Verify correct side is visible for oblique view.
        
        CORRECTED: MediaPipe landmarks 234/454 are ANATOMICAL (subject's left/right),
        NOT spatial (camera left/right). When subject rotates, these landmarks move
        in camera space but retain their anatomical meaning.
        
        Strategy: Use MIN/MAX x-coordinates to establish camera left/right,
        then check nose position relative to that spatial ordering.
        
        For right oblique (patient rotated right, yaw ≈ +45°):
        - Subject's right cheek is MORE visible to camera
        - Nose appears shifted toward camera RIGHT (toward subject's left ear)
        - nose_x > 0.5 in normalized face width
        
        For left oblique (patient rotated left, yaw ≈ -45°):
        - Subject's left cheek is MORE visible to camera
        - Nose appears shifted toward camera LEFT (toward subject's right ear)
        - nose_x < 0.5 in normalized face width
        
        Returns:
            True if correct side, False if wrong side, None if cannot determine
        """
        try:
            if len(landmarks_2d) < 468:
                return None
            
            # Get anatomical landmarks (234=subject's left, 454=subject's right)
            landmark_234_x = landmarks_2d[234][0]
            landmark_454_x = landmarks_2d[454][0]
            nose_tip_x = landmarks_2d[1][0]
            
            # Establish SPATIAL ordering (camera left vs camera right)
            # Use min/max since landmark IDs don't correspond to camera position
            camera_left_x = min(landmark_234_x, landmark_454_x)
            camera_right_x = max(landmark_234_x, landmark_454_x)
            
            # Calculate nose position in CAMERA space
            # 0.0 = camera left, 1.0 = camera right, 0.5 = centered
            face_width = camera_right_x - camera_left_x
            if face_width < 10:  # Face too narrow, unreliable
                return None
            
            nose_position = (nose_tip_x - camera_left_x) / face_width
            
            # Debug logging
            print(f"[OBLIQUE SIDE CHECK] view_id={view_id}, nose_position={nose_position:.3f}")
            print(f"[OBLIQUE SIDE CHECK] landmark_234={landmark_234_x:.1f}, landmark_454={landmark_454_x:.1f}, nose={nose_tip_x:.1f}")
            print(f"[OBLIQUE SIDE CHECK] camera_left={camera_left_x:.1f}, camera_right={camera_right_x:.1f}")
            
            if view_id == 'right_oblique_45':
                # Patient rotated RIGHT (yaw ≈ +45°)
                # Nose shifted toward camera RIGHT
                # nose_position should be > 0.5
                result = 0.52 < nose_position < 0.75
                print(f"[OBLIQUE SIDE CHECK] Right oblique check: {result} (expect 0.52-0.75)")
                return result
                
            elif view_id == 'left_oblique_45':
                # Patient rotated LEFT (yaw ≈ -45°)
                # Nose shifted toward camera LEFT
                # nose_position should be < 0.5
                result = 0.25 < nose_position < 0.48
                print(f"[OBLIQUE SIDE CHECK] Left oblique check: {result} (expect 0.25-0.48)")
                return result
            
            return None
            
        except (IndexError, ZeroDivisionError, TypeError):
            return None
    
    def _check_far_eye_visibility(self, landmarks_2d, width, view_id):
        """
        Check if far eye is appropriately visible for oblique view.
        
        Oblique: far eye should be partially visible (20-75% of landmarks)
        Frontal: both eyes fully visible
        Lateral: far eye mostly/fully occluded
        
        Returns:
            True if visibility appropriate for oblique, False if not, None if cannot determine
        """
        try:
            if len(landmarks_2d) < 468:
                return None
            
            # Eye landmarks
            # Left eye: 33, 133, 160, 144, 153, 154, 155, 157
            # Right eye: 362, 263, 385, 380, 382, 381, 384, 386
            
            left_eye_landmarks = [33, 133, 160, 144, 153, 154, 155, 157]
            right_eye_landmarks = [362, 263, 385, 380, 382, 381, 384, 386]
            
            # Count visible landmarks (within image bounds)
            def count_visible(landmark_indices):
                visible = 0
                for idx in landmark_indices:
                    x, y = landmarks_2d[idx]
                    if 0 < x < width:  # Within horizontal bounds
                        visible += 1
                return visible / len(landmark_indices)
            
            left_eye_visibility = count_visible(left_eye_landmarks)
            right_eye_visibility = count_visible(right_eye_landmarks)
            
            if view_id == 'right_oblique_45':
                # Left eye is far eye, should be partially visible
                # Right eye is near eye, should be fully visible
                return (0.25 < left_eye_visibility < 0.90 and 
                        right_eye_visibility > 0.75)
                
            elif view_id == 'left_oblique_45':
                # Right eye is far eye, should be partially visible
                # Left eye is near eye, should be fully visible
                return (0.25 < right_eye_visibility < 0.90 and 
                        left_eye_visibility > 0.75)
            
            return None
            
        except (IndexError, ZeroDivisionError, TypeError):
            return None

    def _detect_facial_view(self, yaw, pitch, roll, landmarks_2d=None, width=None, height=None, view=None, pose_quality=None):
        """
        Detect which facial view the photo actually shows based on pose angles and anatomical evidence.
        
        Args:
            yaw, pitch, roll: Detected pose angles (may be None for profiles)
            landmarks_2d: MediaPipe landmarks (optional, for anatomical checks)
            width, height: Image dimensions (optional)
            view: Selected view (optional, for context-aware validation)
            pose_quality: Pose quality metrics (reprojection error, etc.)
            
        Returns:
            dict: {
                'detected_view': str | None,
                'confidence': str ('confident' | 'probable' | 'uncertain'),
                'reasoning': str,
                'pose_reliable': bool
            }
        """
        # Special case: Lateral views with unavailable pose
        # At 90° profile, frontal landmarks are occluded, so pose estimation fails
        # This is expected and acceptable - use landmark evidence instead
        if view in ('right_lateral', 'left_lateral') and (yaw is None or pitch is None or roll is None):
            if landmarks_2d is not None and len(landmarks_2d) >= 250:
                # Sufficient landmarks detected for a profile - verify side
                side_correct = self._check_lateral_side(landmarks_2d, width, view) if width else None
                
                if side_correct is True:
                    return {
                        'detected_view': view,
                        'confidence': 'probable',
                        'reasoning': f'Profile view {view}: Pose unavailable (expected at 90°), but face detected with {len(landmarks_2d)} landmarks. Side verification passed. Requires clinician confirmation of correct side and complete profile.',
                        'pose_reliable': False
                    }
                elif side_correct is False:
                    # Wrong side detected!
                    opposite_side = 'left_lateral' if view == 'right_lateral' else 'right_lateral'
                    return {
                        'detected_view': None,
                        'confidence': 'uncertain',
                        'reasoning': f'Lateral view {view}: Wrong side detected. Photo appears to be {opposite_side} based on landmark distribution. Please upload correct side or change view selection.',
                        'pose_reliable': False
                    }
                else:
                    # Cannot determine side - REJECT instead of assuming correct
                    return {
                        'detected_view': None,
                        'confidence': 'uncertain',
                        'reasoning': f'Profile view {view}: Pose unavailable, side verification inconclusive. {len(landmarks_2d)} landmarks detected but cannot reliably determine left vs right side. Image quality or angle may be insufficient.',
                        'pose_reliable': False
                    }
            else:
                landmark_count = len(landmarks_2d) if landmarks_2d is not None else 0
                return {
                    'detected_view': None,
                    'confidence': 'uncertain',
                    'reasoning': f'Lateral view {view}: Insufficient landmarks detected ({landmark_count}/250 minimum). Face may not be fully visible or image quality insufficient. Please ensure complete profile is visible.',
                    'pose_reliable': False
                }
        
        # Special case: Basal view with unavailable pose
        # At extreme basal angles, pose estimation may fail
        # This is expected - use anatomical evidence instead
        if view == 'basal' and (yaw is None or pitch is None or roll is None):
            if landmarks_2d is not None and len(landmarks_2d) >= 200:
                
                # EVALUATE BOTH HYPOTHESES - do not prematurely return
                
                # Hypothesis 1: Frontal viewpoint with neutral pitch
                frontal_check = self._detect_frontal_indicators(landmarks_2d, width, height)
                
                # Hypothesis 2: Basal viewpoint with head extension
                basal_check = self._validate_basal_viewpoint(landmarks_2d, width, height, yaw, pitch, roll)
                
                # DECISION LOGIC: Compare evidence from both hypotheses
                
                # Case 1: Strong contradictory frontal evidence AND basal not detected
                if (frontal_check['contradictory_basal'] and 
                    frontal_check['confidence'] in ('confident', 'probable') and
                    not basal_check['basal_viewpoint_detected']):
                    
                    # Log diagnostic information
                    print(f"\n[BASAL VS FRONTAL DEBUG]")
                    print(f"[FRONTAL HYPOTHESIS] Detected: {frontal_check['frontal_detected']}, Confidence: {frontal_check['confidence']}")
                    print(f"[FRONTAL HYPOTHESIS] Vertical evidence: {frontal_check['evidence']}")
                    print(f"[FRONTAL HYPOTHESIS] Horizontal alignment only: {frontal_check.get('alignment_only', [])}")
                    print(f"[FRONTAL HYPOTHESIS] Contradicts basal: {frontal_check['contradictory_basal']}")
                    print(f"[BASAL HYPOTHESIS] Detected: {basal_check['basal_viewpoint_detected']}, Confidence: {basal_check['confidence']}")
                    print(f"[BASAL HYPOTHESIS] {basal_check['reasoning']}")
                    print(f"[DECISION] Frontal viewpoint confirmed, basal viewpoint not supported")
                    
                    return {
                        'detected_view': 'frontal_neutral',
                        'confidence': frontal_check['confidence'],
                        'reasoning': f'View mismatch: Photo shows neutral frontal viewpoint, not basal. Vertical viewpoint indicators: {"; ".join(frontal_check["evidence"])}. Basal evidence insufficient.',
                        'pose_reliable': False,
                        'debug_info': {
                            'frontal_check': frontal_check,
                            'basal_check': basal_check
                        }
                    }
                
                # Case 2: Basal viewpoint detected, frontal does not contradict
                elif basal_check['basal_viewpoint_detected']:
                    
                    print(f"\n[BASAL VS FRONTAL DEBUG]")
                    print(f"[FRONTAL HYPOTHESIS] Detected: {frontal_check['frontal_detected']}, Confidence: {frontal_check['confidence']}")
                    print(f"[FRONTAL HYPOTHESIS] Contradicts basal: {frontal_check['contradictory_basal']}")
                    print(f"[BASAL HYPOTHESIS] Detected: {basal_check['basal_viewpoint_detected']}, Confidence: {basal_check['confidence']}")
                    print(f"[BASAL HYPOTHESIS] {basal_check['reasoning']}")
                    print(f"[DECISION] Basal viewpoint supported")
                    
                    # Basal viewpoint verified anatomically
                    reasoning_parts = [f'Basal view {view}: Pose unavailable (expected for extreme angles), but basal viewpoint verified.']
                    reasoning_parts.append(basal_check['reasoning'])
                    
                    # Add note if only horizontal alignment detected (not contradictory)
                    if not frontal_check['contradictory_basal'] and frontal_check.get('alignment_only'):
                        reasoning_parts.append(f"Note: Face is bilaterally aligned ({', '.join(frontal_check['alignment_only'])}) but vertical viewpoint indicators support basal.")
                    
                    return {
                        'detected_view': view,
                        'confidence': basal_check['confidence'],
                        'reasoning': ' '.join(reasoning_parts),
                        'pose_reliable': False,
                        'debug_info': {
                            'frontal_check': frontal_check,
                            'basal_check': basal_check
                        }
                    }
                
                # Case 3: Both hypotheses weak or conflicting
                else:
                    print(f"\n[BASAL VS FRONTAL DEBUG]")
                    print(f"[FRONTAL HYPOTHESIS] Detected: {frontal_check['frontal_detected']}, Confidence: {frontal_check['confidence']}")
                    print(f"[FRONTAL HYPOTHESIS] Evidence: {frontal_check['evidence']}")
                    print(f"[BASAL HYPOTHESIS] Detected: {basal_check['basal_viewpoint_detected']}, Confidence: {basal_check['confidence']}")
                    print(f"[BASAL HYPOTHESIS] {basal_check['reasoning']}")
                    print(f"[DECISION] Insufficient evidence to determine view")
                    
                    # Uncertain - insufficient discriminating evidence
                    reasoning_parts = [f'Basal view {view}: Pose unavailable, cannot reliably determine viewpoint.']
                    
                    if frontal_check.get('alignment_only'):
                        reasoning_parts.append(f"Face is bilaterally aligned but lacks strong vertical viewpoint indicators.")
                    
                    reasoning_parts.append(basal_check['reasoning'])
                    reasoning_parts.append("Requires clinician review.")
                    
                    return {
                        'detected_view': None,
                        'confidence': 'uncertain',
                        'reasoning': ' '.join(reasoning_parts),
                        'pose_reliable': False,
                        'debug_info': {
                            'frontal_check': frontal_check,
                            'basal_check': basal_check
                        }
                    }
            else:
                landmark_count = len(landmarks_2d) if landmarks_2d is not None else 0
                return {
                    'detected_view': None,
                    'confidence': 'uncertain',
                    'reasoning': f'Basal view {view}: Insufficient landmarks detected ({landmark_count}/200 minimum). Nasal region may not be fully visible or image quality insufficient.',
                    'pose_reliable': False
                }
        
        # Special case: Oblique views with unavailable pose (less common but possible)
        # May happen with poor lighting, extreme angles, or image quality issues
        if view in ('right_oblique_45', 'left_oblique_45') and (yaw is None or pitch is None or roll is None):
            if landmarks_2d is not None and len(landmarks_2d) >= 400:
                # Enough landmarks for oblique - try to verify side at least
                side_correct = self._check_oblique_side(landmarks_2d, width, view) if width else None
                if side_correct is True:
                    return {
                        'detected_view': view,
                        'confidence': 'uncertain',
                        'reasoning': f'Oblique view {view}: Pose unavailable but anatomical side matches. Image quality may be insufficient. Requires clinician review.',
                        'pose_reliable': False
                    }
                else:
                    return {
                        'detected_view': None,
                        'confidence': 'uncertain',
                        'reasoning': f'Oblique view {view}: Pose unavailable and side verification inconclusive. Cannot verify view automatically.',
                        'pose_reliable': False
                    }
            else:
                return {
                    'detected_view': None,
                    'confidence': 'uncertain',
                    'reasoning': f'Oblique view {view}: Pose unavailable and insufficient landmarks. Image quality may be too poor for validation.',
                    'pose_reliable': False
                }
        
        # If pose unavailable for NON-lateral/oblique views, this is problematic
        if yaw is None or pitch is None or roll is None:
            # Try to infer from landmarks if available
            if landmarks_2d is not None and len(landmarks_2d) >= 468:
                # Check if this might be a lateral (profile) misclassified as oblique/frontal
                # Profile has one side occluded
                left_eye_landmarks = [33, 133, 160, 144]
                right_eye_landmarks = [362, 263, 385, 380]
                
                try:
                    left_visible = sum(1 for i in left_eye_landmarks if 0 < landmarks_2d[i][0] < width) / 4
                    right_visible = sum(1 for i in right_eye_landmarks if 0 < landmarks_2d[i][0] < width) / 4
                    
                    # If one eye heavily occluded, likely a profile view
                    if left_visible < 0.3 or right_visible < 0.3:
                        likely_view = 'right_lateral' if left_visible < right_visible else 'left_lateral'
                        return {
                            'detected_view': likely_view,
                            'confidence': 'probable',
                            'reasoning': f'Pose unavailable (expected for profiles). Photo appears to show {likely_view} based on eye occlusion. Selected view was {view}.',
                            'pose_reliable': False
                        }
                except:
                    pass
            
            return {
                'detected_view': None,
                'confidence': 'uncertain',
                'reasoning': f'Pose estimation unavailable for {view}. Cannot verify facial view automatically.',
                'pose_reliable': False
            }
        
        # Assess pose quality/reliability
        pose_reliable = True
        if pose_quality:
            # High reprojection error indicates unreliable pose
            if pose_quality.get('normalized_residual', 0) > 0.06:
                pose_reliable = False
        
        # Check for obviously unreasonable pose values that indicate estimation failure
        if abs(pitch) > 40 or abs(roll) > 30:
            pose_reliable = False
        
        # Candidate views with scores
        candidates = []
        
        # Helper function to check bilateral eye visibility (frontal indicator)
        def check_bilateral_eyes(landmarks, w, h):
            if landmarks is None or len(landmarks) < 468:
                return False
            # Check if both eyes are clearly visible (not occluded)
            # Left eye: landmarks 33, 133, 160, 144
            # Right eye: landmarks 362, 263, 385, 380
            left_eye_pts = [33, 133, 160, 144]
            right_eye_pts = [362, 263, 385, 380]
            try:
                left_visible = all(0 < landmarks[i][0] < w and 0 < landmarks[i][1] < h for i in left_eye_pts)
                right_visible = all(0 < landmarks[i][0] < w and 0 < landmarks[i][1] < h for i in right_eye_pts)
                return left_visible and right_visible
            except:
                return False
        
        # Helper function to check nostril visibility (basal indicator)
        def check_nostril_visibility(landmarks, w, h):
            if landmarks is None or len(landmarks) < 468:
                return False
            # Nostril landmarks: 2 (nasal base center), 98 (left nostril), 327 (right nostril)
            # In basal view, these should be prominent and well-separated
            try:
                nasal_pts = [2, 98, 327]
                visible = all(0 < landmarks[i][0] < w and 0 < landmarks[i][1] < h for i in nasal_pts)
                if not visible:
                    return False
                # Check nostril separation (should be wide in basal view)
                nostril_dist = abs(landmarks[98][0] - landmarks[327][0])
                face_width = w * 0.3  # approximate face width
                return nostril_dist > face_width * 0.15  # Nostrils visibly separated
            except:
                return False
        
        bilateral_eyes = check_bilateral_eyes(landmarks_2d, width, height) if landmarks_2d and width and height else None
        nostril_visible = check_nostril_visibility(landmarks_2d, width, height) if landmarks_2d and width and height else None
        
        for view_id, profile in VIEWS.items():
            # Skip non-standard views
            if view_id not in ['frontal_neutral', 'right_oblique_45', 'left_oblique_45', 
                               'right_lateral', 'left_lateral', 'basal']:
                continue
            
            # Calculate angular errors
            yaw_error = abs(yaw - profile['yaw']) if profile['yaw'] is not None else float('inf')
            pitch_error = abs(pitch - profile['pitch']) if profile['pitch'] is not None else float('inf')
            roll_error = abs(roll - profile['roll']) if profile['roll'] is not None else float('inf')
            
            yaw_tol, pitch_tol, roll_tol = profile['tolerance']
            
            # Calculate weighted score (lower is better)
            # Increased weights for pitch to better distinguish frontal from basal
            # DO NOT filter out candidates early - let scoring decide
            score = (yaw_error * 3.0) + (pitch_error * 2.0) + (roll_error * 1.0)
            
            # Anatomical evidence adjustments
            anatomical_bonus = 0
            
            # BASAL SPECIFIC CHECKS
            if view_id == 'basal':
                # Use dedicated basal validator instead of pitch alone
                basal_check = self._validate_basal_viewpoint(landmarks_2d, width, height, yaw, pitch, roll)
                
                if not basal_check['basal_viewpoint_detected']:
                    # Not a basal viewpoint - heavy penalty
                    if basal_check['confidence'] == 'confident':
                        score += 150  # Confident it's NOT basal
                    else:
                        score += 100  # Uncertain/probable not basal
                else:
                    # Basal viewpoint detected - apply bonuses
                    if basal_check['confidence'] == 'confident':
                        anatomical_bonus -= 30  # Strong bonus
                    elif basal_check['confidence'] == 'probable':
                        anatomical_bonus -= 20
                    
                    # Additional bonuses for specific features
                    if basal_check['columella_visible']:
                        anatomical_bonus -= 5
                    if basal_check['nostril_underside_bilateral']:
                        anatomical_bonus -= 5
                
                # Pitch still matters but is not sufficient alone
                if pitch is not None:
                    if pitch < 10:
                        score += 60  # Not tilted back enough
                    elif pitch > 35:
                        score += 50  # Excessively tilted
                    elif 15 <= pitch <= 30:
                        anatomical_bonus -= 5  # Ideal basal pitch range
                
                # Penalize if both eyes equally visible (frontal indicator)
                if bilateral_eyes:
                    score += 40  # Increased from 30
            
            # FRONTAL SPECIFIC CHECKS  
            elif view_id == 'frontal_neutral':
                # Frontal MUST have near-zero pitch
                if abs(pitch) > 10:  # Tilted too much
                    score += 60  # Heavy penalty - not frontal
                elif abs(pitch) < 5:  # Good frontal posture
                    anatomical_bonus = -15  # Strong bonus
                
                # Frontal MUST have centered yaw
                if abs(yaw) > 10:  # Too much rotation
                    score += 70  # Very heavy penalty - not frontal
                elif abs(yaw) < 3:  # Well centered
                    anatomical_bonus -= 10
                
                # Frontal SHOULD have both eyes clearly visible
                if bilateral_eyes:
                    anatomical_bonus -= 10  # Bonus for bilateral visibility
                elif bilateral_eyes is False:  # One eye occluded
                    score += 40  # Likely oblique or lateral, not frontal
                
                # Frontal should NOT show prominent nostril underside
                # Use dedicated basal validator to check
                if landmarks_2d is not None and width is not None and height is not None:
                    basal_check = self._validate_basal_viewpoint(landmarks_2d, width, height, yaw, pitch, roll)
                    if basal_check['basal_viewpoint_detected']:
                        # Strong penalty if basal indicators present
                        if basal_check['confidence'] in ('confident', 'probable'):
                            score += 80  # This looks like basal, not frontal
            
            # OBLIQUE CHECKS
            elif 'oblique' in view_id:
                # Oblique should have near-zero pitch
                if abs(pitch) > 8:  # Aligned with tolerance (was 12)
                    score += 35  # Stronger penalty
                
                # CRITICAL: Verify rotation is in correct range
                # Oblique should be 30-60°, not too frontal or too lateral
                if view_id == 'right_oblique_45':
                    if yaw < 30:  # Too frontal
                        score += 80  # Very heavy penalty - clearly not oblique
                    elif yaw > 60:  # Too lateral
                        score += 80  # Very heavy penalty - approaching profile
                    elif 35 <= yaw <= 55:  # Ideal oblique range
                        anatomical_bonus -= 15  # Strong bonus for good positioning
                    
                elif view_id == 'left_oblique_45':
                    if yaw > -30:  # Too frontal (not negative enough)
                        score += 80  # Very heavy penalty
                    elif yaw < -60:  # Too lateral (too negative)
                        score += 80  # Very heavy penalty
                    elif -55 <= yaw <= -35:  # Ideal oblique range
                        anatomical_bonus -= 15  # Strong bonus
                
                # Check anatomical side correctness
                if landmarks_2d is not None and width is not None:
                    side_correct = self._check_oblique_side(landmarks_2d, width, view_id)
                    if side_correct is True:
                        anatomical_bonus -= 10  # Bonus for correct side
                    elif side_correct is False:
                        score += 60  # Heavy penalty for wrong side
                
                # Far eye visibility check
                if landmarks_2d is not None and width is not None:
                    far_eye_ok = self._check_far_eye_visibility(landmarks_2d, width, view_id)
                    if far_eye_ok is True:
                        anatomical_bonus -= 5  # Bonus for proper oblique
                    elif far_eye_ok is False:
                        score += 25  # Penalty if visibility wrong
            
            # LATERAL/PROFILE CHECKS
            elif 'lateral' in view_id:
                # Laterals need strong rotation (>70°) and substantial landmarks
                if landmarks_2d is not None and len(landmarks_2d) >= 250:
                    anatomical_bonus -= 15  # Strong bonus for sufficient landmarks
                elif landmarks_2d is not None and len(landmarks_2d) < 250:
                    score += 50  # Penalty for insufficient landmarks
                
                if yaw is not None and abs(yaw) < 70:
                    score += 80  # Not rotated enough for lateral
                
                # Verify side matches
                if yaw is not None:
                    # Use yaw sign for side verification when available
                    if view_id == 'right_lateral' and yaw < 60:  # Should be strongly positive
                        score += 120  # Wrong side or not rotated enough
                    elif view_id == 'left_lateral' and yaw > -60:  # Should be strongly negative
                        score += 120  # Wrong side or not rotated enough
                    
                    # If yaw indicates correct strong rotation, verify anatomically too
                    if width and landmarks_2d is not None:
                        side_correct = self._check_lateral_side(landmarks_2d, width, view_id)
                        if side_correct is True:
                            anatomical_bonus -= 10  # Bonus for anatomical confirmation
                        elif side_correct is False:
                            score += 100  # Heavy penalty for anatomical mismatch
                else:
                    # Pose unavailable for lateral - verify side anatomically
                    if width and landmarks_2d is not None:
                        side_correct = self._check_lateral_side(landmarks_2d, width, view_id)
                        if side_correct is True:
                            anatomical_bonus -= 10  # Bonus for correct side
                        elif side_correct is False:
                            score += 100  # Wrong side detected
                        else:
                            score += 15  # Uncertainty penalty
                    else:
                        score += 20  # Cannot verify side
            
            # Apply anatomical bonus
            score += anatomical_bonus
            
            # Debug output for oblique and lateral views
            if 'oblique' in view_id or 'lateral' in view_id:
                print(f"\n[VIEW SCORE] view_id={view_id}, score={score:.1f}, bonus={anatomical_bonus}")
                print(f"  yaw_error={yaw_error:.1f}, pitch_error={pitch_error:.1f}, roll_error={roll_error:.1f}")
                if yaw is not None:
                    print(f"  actual: yaw={yaw:.1f}, pitch={pitch:.1f}, roll={roll:.1f}")
                else:
                    print(f"  actual: pose unavailable")
                if landmarks_2d is not None:
                    print(f"  landmarks={len(landmarks_2d)}")
            
            candidates.append({
                'view_id': view_id,
                'score': score,
                'yaw_error': yaw_error,
                'pitch_error': pitch_error,
                'roll_error': roll_error
            })
        
        if not candidates:
            return {
                'detected_view': None,
                'confidence': 'uncertain',
                'reasoning': 'No views match within tolerance',
                'pose_reliable': pose_reliable
            }
        
        # Sort by score (lower is better)
        candidates.sort(key=lambda x: x['score'])
        best = candidates[0]
        
        # Debug: Show top candidates
        print(f"\n[VIEW DETECTION] Selected view: {view}")
        print(f"[VIEW DETECTION] Top 3 candidates:")
        for i, c in enumerate(candidates[:3]):
            print(f"  {i+1}. {c['view_id']}: score={c['score']:.1f}")
        
        # Determine confidence based on score separation and pose reliability
        if len(candidates) > 1:
            second_best = candidates[1]
            score_gap = second_best['score'] - best['score']
            
            if score_gap > 40:
                confidence = 'confident'  # Clear winner
            elif score_gap > 20:
                confidence = 'probable'   # Likely but not certain
            else:
                confidence = 'uncertain'  # Ambiguous
        else:
            # Only one candidate - confidence based on absolute score
            confidence = 'confident' if best['score'] < 15 else 'probable' if best['score'] < 30 else 'uncertain'
        
        # Downgrade confidence if pose is unreliable
        if not pose_reliable:
            if confidence == 'confident':
                confidence = 'probable'
            elif confidence == 'probable':
                confidence = 'uncertain'
        
        # Build reasoning
        reasoning_parts = [
            f'Best match: {best["view_id"]}',
            f'(yaw_err: {best["yaw_error"]:.1f}°, pitch_err: {best["pitch_error"]:.1f}°, roll_err: {best["roll_error"]:.1f}°)',
            f'score: {best["score"]:.1f}'
        ]
        
        if len(candidates) > 1:
            reasoning_parts.append(f'vs {candidates[1]["view_id"]} (score: {candidates[1]["score"]:.1f})')
        
        if not pose_reliable:
            reasoning_parts.append('Note: Pose estimation quality low')
        
        reasoning = ' '.join(reasoning_parts)
        
        return {
            'detected_view': best['view_id'],
            'confidence': confidence,
            'reasoning': reasoning,
            'pose_reliable': pose_reliable
        }

    def _validate(self, image_bytes, facial_view, live_mode, setup):
        started = time.monotonic()
        view = ALIASES.get(facial_view, facial_view)
        upload_mode = not live_mode  # File upload vs live capture
        result = dict(schema_version=2, valid=False, capture_ready=False, experimental_capture_ready=False, auto_capture_eligible=False, state='ALIGNMENT_REQUIRED',
                      facial_view=view, face_count=0, face_detected=False, landmarks_detected=False,
                      pose_estimated=False, yaw=None, pitch=None, roll=None, framing_ok=False,
                      quality_ok=False, requires_clinician_confirmation=True, reviewable=False,
                      calibration_status='approximate', errors=[], warnings=[], stability_ms=0)

        def finish(code, live_message, upload_message=None):
            """Return validation result with context-appropriate guidance message"""
            message = upload_message if upload_mode and upload_message else live_message
            result.update(guidance_code=code, guidance=message, guidance_message=message,
                          processing_time_ms=round((time.monotonic()-started)*1000))
            return result

        if view not in VIEWS:
            return finish('INVALID_VIEW', 
                         'Select a supported photographic view',
                         'Invalid facial view selected')
        profile = VIEWS[view]
        result['target_pose'] = {axis: profile[axis] for axis in ('yaw', 'pitch', 'roll')}
        result['pose_tolerances'] = dict(zip(('yaw', 'pitch', 'roll'), profile['tolerance']))
        try:
            image = load_image_from_bytes(image_bytes)
            original_height, original_width = image.shape[:2]
            result.update(image_width=original_width, image_height=original_height)
            # Final quality measurements use the actual image, live frames use smaller inputs.
            if live_mode:
                image = resize_image_if_needed(image, max_dimension=640)
            height, width = image.shape[:2]
            camera_id = setup.get('camera_profile_id')
            self.profiles = load_profiles()
            camera = self.profiles.get(camera_id) if camera_id else None
            if camera_id and camera is None:
                return finish('CAMERA_PROFILE', 'Configured camera profile was not found')
            _, _, camera_status = camera_intrinsics(width, height, camera)
            result['calibration_status'] = camera_status
            quality_keys = ('blur_threshold', 'max_black_fraction', 'max_white_fraction', 'min_dynamic_range')
            quality_policy = {key: (camera or {}).get('quality_thresholds', {}).get(key, CAPTURE[key]) for key in quality_keys}
            if any(not isinstance(value, (float, int)) or not np.isfinite(value) or value <= 0 for value in quality_policy.values()):
                return finish('CAMERA_PROFILE', 'Invalid camera quality calibration')
            if any(quality_policy[key] >= 1 for key in ('max_black_fraction', 'max_white_fraction')):
                return finish('CAMERA_PROFILE', 'Invalid camera clipping fractions')
            detection = self.face_detector.detect_faces(image)
            count = detection['face_count']
            
            # DUAL-STAGE DETECTION: Fallback to landmark-based detection for lateral AND basal views
            # MediaPipe Face Detection fails on 90° profiles and extreme basal angles
            landmarks_fallback = None
            if count == 0 and ('lateral' in view or view == 'basal'):
                print(f"[FALLBACK DETECTION] Face detection failed for {view}, attempting landmark-based detection...")
                landmarks_fallback = self.landmark_detector.detect_landmarks(image)
                
                min_landmarks = 250 if 'lateral' in view else 200  # Basal may have fewer landmarks
                if landmarks_fallback['landmarks_detected'] and landmarks_fallback['landmark_count'] >= min_landmarks:
                    # Calculate bounding box from landmarks
                    bbox = self.landmark_detector.get_face_bounding_box(landmarks_fallback['landmarks_2d'])
                    if bbox is not None:
                        detection['bounding_boxes'] = [bbox]
                        count = 1
                        print(f"[FALLBACK DETECTION] ✓ Success: {landmarks_fallback['landmark_count']} landmarks detected, bbox={bbox}")
                    else:
                        print(f"[FALLBACK DETECTION] ✗ Failed: Could not calculate bounding box from {landmarks_fallback['landmark_count']} landmarks")
                elif landmarks_fallback['landmarks_detected']:
                    print(f"[FALLBACK DETECTION] ✗ Insufficient landmarks: {landmarks_fallback['landmark_count']}/{min_landmarks} minimum")
                else:
                    print(f"[FALLBACK DETECTION] ✗ No landmarks detected")
            
            result.update(face_count=count, face_detected=count > 0)
            if count != 1:
                result['state'] = 'SEARCHING_FOR_FACE'
                # Provide specific error for lateral views
                if 'lateral' in view and count == 0:
                    if landmarks_fallback is not None:
                        landmark_count = landmarks_fallback.get('landmark_count', 0)
                        if landmark_count > 0 and landmark_count < 250:
                            return finish('INSUFFICIENT_PROFILE',
                                        'Profile detection incomplete',
                                        f'Insufficient facial landmarks for {view} validation ({landmark_count}/250 minimum). '
                                        'Ensure the complete side profile is visible with adequate lighting and the face is not cropped.')
                    return finish('NO_PROFILE',
                                 'Profile not detected',
                                 f'Could not detect facial profile for {view}. '
                                 'Ensure a clear side-profile view with the face fully visible and adequate lighting.')
                # Provide specific error for basal view
                elif view == 'basal' and count == 0:
                    if landmarks_fallback is not None:
                        landmark_count = landmarks_fallback.get('landmark_count', 0)
                        if landmark_count > 0 and landmark_count < 200:
                            return finish('INSUFFICIENT_BASAL',
                                        'Basal detection incomplete',
                                        f'Insufficient facial landmarks for basal validation ({landmark_count}/200 minimum). '
                                        'Ensure nasal-base region is clearly visible with adequate lighting.')
                    return finish('NO_BASAL_REGION',
                                 'Nasal region not detected',
                                 'Could not detect nasal/facial region for basal view. '
                                 'Ensure photo shows underside of nose with adequate lighting and proper basal viewpoint.')
                return finish('NO_FACE' if count == 0 else 'MULTIPLE_FACES',
                              'Place one face in view' if count == 0 else 'Only the patient should be visible',
                              'No face detected in image. Please upload a clear photo with one face visible.' if count == 0 
                              else 'Multiple faces detected. Please upload a photo with only the patient visible.')
            detector = self.landmark_detector
            if live_mode and self.video_detector and setup.get('capture_session_id'):
                session = setup['capture_session_id']
                if self.video_session != session:
                    # Recreate tracking state on patient/camera/view session transitions.
                    self.video_detector.task.close()
                    self.video_detector = LandmarkDetector(static_image_mode=False, max_num_faces=2)
                    self.video_session = session
                detector = self.video_detector
            
            # Reuse fallback landmarks if already detected (avoid redundant processing)
            if landmarks_fallback is not None and landmarks_fallback['landmarks_detected']:
                landmarks = landmarks_fallback
                print(f"[FALLBACK DETECTION] Reusing fallback landmarks ({landmarks['landmark_count']} landmarks)")
            else:
                landmarks = detector.detect_landmarks(image)
            if landmarks.get('face_count', 0) > 1:
                result.update(face_count=landmarks['face_count'], state='SEARCHING_FOR_FACE')
                return finish('MULTIPLE_FACES', 'Only the patient should be visible')
            result.update(landmarks_detected=landmarks['landmarks_detected'], landmark_count=landmarks['landmark_count'])
            points_2d = landmarks.get('landmarks_2d')
            gaze_required = view in ('frontal_neutral', 'frontal_smiling')
            result['gaze'] = check_eye_direction(points_2d, required=gaze_required)
            result['gaze_required'] = gaze_required
            result['gaze_ok'] = result['gaze']['passed']
            if points_2d is not None and len(points_2d) >= 468:
                oval = [10,338,297,332,284,251,389,356,454,323,361,288,397,365,379,378,400,377,152,
                        148,176,149,150,136,172,58,132,93,234,127,162,21,54,103,67,109]
                result['tracking'] = dict(face_outline=[[points_2d[i][0]/width,points_2d[i][1]/height] for i in oval],
                    eye_points=[[points_2d[i][0]/width,points_2d[i][1]/height] for i in (33,133,362,263)],
                    iris_points=[[points_2d[i][0]/width,points_2d[i][1]/height] for i in (468,473)] if len(points_2d) >= 478 else [])
            x, y, bw, bh = detection['bounding_boxes'][0]
            result['face_bbox'] = [x/width, y/height, bw/width, bh/height]
            framing_id = 'basal' if view == 'basal' else setup.get('framing_protocol', 'full_face')
            if framing_id not in FRAMING:
                return finish('INVALID_PROTOCOL', 'Choose a supported framing protocol')
            framing = FRAMING[framing_id]
            cx, cy = (x+bw/2)/width, (y+bh/2)/height
            clipped = x < 0 or y < 0 or x+bw > width or y+bh > height
            measured_height = bh/height
            if framing_id == 'nasal_focused':
                # Close-ups may intentionally omit scalp/chin. Check required nasal
                # boundaries instead of rejecting the entire detector face box.
                p = np.asarray(landmarks.get('landmarks_2d', []), dtype=float)
                if len(p) < 468:
                    return finish('NASAL_BOUNDS', 'Nasal landmarks unavailable; adjust framing for clinician review')
                region = p[[70, 300, 1, 17, 61, 291]] / [width, height]
                clipped = bool(((region <= .01) | (region >= .99)).any())
                cx = float(p[1,0]/width)
                top, bottom = float(min(p[70,1],p[300,1])/height), float(p[17,1]/height)
                cy = (top+bottom)/2
                measured_height = bottom-top
            scale_ok = framing['min_height'] <= measured_height <= framing['max_height']
            centered = abs(cx-framing['center_x']) <= framing['tolerance'] and abs(cy-framing['center_y']) <= framing['tolerance']
            
            # Relax centering requirement for lateral views
            # Profile photos often have face offset to one side - this is acceptable
            if 'lateral' in view:
                # For laterals, only require vertical centering and not clipped
                # Horizontal offset is expected as profile naturally shifts left/right
                vertical_centered = abs(cy-framing['center_y']) <= framing['tolerance']
                result['framing_ok'] = bool(scale_ok and vertical_centered and not clipped)
                # Debug logging for lateral framing
                print(f"[LATERAL FRAMING DEBUG] view={view}, scale_ok={scale_ok}, measured_height={measured_height:.3f}, "
                      f"min={framing['min_height']:.3f}, max={framing['max_height']:.3f}")
                print(f"[LATERAL FRAMING DEBUG] cx={cx:.3f}, cy={cy:.3f}, target_cy={framing['center_y']:.3f}, "
                      f"tolerance={framing['tolerance']:.3f}, vertical_centered={vertical_centered}, clipped={clipped}")
            else:
                result['framing_ok'] = bool(scale_ok and centered and not clipped)
            result['framing'] = dict(protocol=framing_id, face_height_ratio=measured_height, center=[cx, cy], clipped=clipped,
                                     offset=[cx-framing['center_x'],cy-framing['center_y']],
                                     scale_region='eyebrows_to_lip' if framing_id == 'nasal_focused' else 'detected_face',
                                     anatomical_boundaries_verified=False)
            result['guide'] = dict(center_x=framing['center_x'], center_y=framing['center_y'],
                                   height=(framing['min_height']+framing['max_height'])/2,
                                   tolerance=framing['tolerance'], shape='basal' if view == 'basal' else 'profile' if 'lateral' in view else 'face')
            roi = image[max(0,y):min(height,y+bh), max(0,x):min(width,x+bw)]
            if roi.size == 0:
                return finish('FRAMING', 
                             'Move into the camera frame',
                             'Face not properly positioned in frame. Please upload a photo with the face fully visible.')
            # Normalize ROI scale so sharpness thresholds do not depend on capture resolution.
            native_roi_width = roi.shape[1]
            roi = cv2.resize(roi, (256, max(1, round(256*roi.shape[0]/roi.shape[1]))))
            checker = ImageQualityChecker(blur_threshold=quality_policy['blur_threshold'])
            blur, light, exposure = checker.check_blur(roi), checker.check_brightness(roi), checker.check_exposure(roi)
            gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
            dynamic_range = float(np.percentile(gray, 95)-np.percentile(gray, 5))
            # Mean brightness is informational; clipping and retained detail are the gates.
            # These provisional values still require representative skin-tone evaluation.
            exposure['exposure_ok'] = bool(exposure['underexposed_ratio'] <= quality_policy['max_black_fraction'] and
                                           exposure['overexposed_ratio'] <= quality_policy['max_white_fraction'])
            resolution_ok = original_width >= CAPTURE['min_image_width'] and original_height >= CAPTURE['min_image_height'] and native_roi_width >= CAPTURE['min_roi_width']
            result['quality'] = dict(blur=blur, brightness=light, exposure=exposure, region='face_roi',
                                    dynamic_range=dynamic_range, resolution_ok=resolution_ok,
                                    illumination_verified=False, thresholds=quality_policy)
            result.update(blur_detected=bool(blur['is_blurry']), blur_score=float(blur['blur_score']),
                          brightness=float(light['brightness']),
                          quality_ok=bool(blur['blur_score'] >= quality_policy['blur_threshold'] and exposure['exposure_ok'] and
                                          dynamic_range >= quality_policy['min_dynamic_range'] and resolution_ok))
            pose = dict(success=False, yaw=None, pitch=None, roll=None)
            result['camera_profile'] = camera or {'id': None}
            eligible, eligibility_reason, reference = automation_policy(camera, setup, view, (width, height))
            experimental = bool(CAPTURE['experimental_auto_capture'] and not camera_id and
                setup.get('automatic_capture_mode', 'experimental') == 'experimental' and
                setup.get('physical_setup_confirmed') is True and not profile['review'] and
                (view == 'frontal_neutral' or setup.get('side_directions_confirmed') is True))
            if experimental:
                eligibility_reason = 'Experimental webcam auto-capture: approximate angles; saved pending clinical review'
            elif not camera_id and 'oblique' in view and not setup.get('side_directions_confirmed'):
                eligibility_reason = 'Confirm physical left/right directions in camera setup before experimental oblique auto-capture'
            result.update(auto_capture_eligible=eligible or experimental, automation_reason=eligibility_reason,
                          automation_mode='approved' if eligible else 'experimental' if experimental else 'unavailable')
            if reference is not None:
                scale_ok = abs(measured_height-reference) <= reference*CAPTURE['scale_tolerance']
                result['framing_ok'] = bool(result['framing_ok'] and scale_ok)
                result['framing'].update(reference_face_height_ratio=reference, scale_ok=scale_ok)
            target_scale = reference if reference is not None else (framing['min_height']+framing['max_height'])/2
            auto_centered = abs(cx-framing['center_x']) <= CAPTURE['auto_center_tolerance'] and abs(cy-framing['center_y']) <= CAPTURE['auto_center_tolerance']
            auto_scale_ok = abs(measured_height-target_scale) <= target_scale*CAPTURE['scale_tolerance']
            result['spatial_alignment_ok'] = bool(auto_centered and auto_scale_ok and not clipped)
            if landmarks['landmarks_detected']:
                points = np.array([landmarks['landmarks_2d'][i] for i in (1,152,33,263,61,291)], dtype=float)
                pose = self.pose_estimator.estimate_pose(points, width, height, camera)
            # Frontal PnP landmarks become occluded in profiles; never present them as a reliable 90-degree measurement.
            if profile['review'] or (pose['success'] and abs(pose['yaw']) > 65):
                pose = {**pose, 'success': False, 'yaw': None, 'pitch': None, 'roll': None}
            result['pose_quality'] = {k:v for k,v in pose.items() if k not in ('rotation_vector', 'translation_vector')}
            result.update(pose_estimated=pose['success'], yaw=pose['yaw'], pitch=pose['pitch'], roll=pose['roll'],
                          calibration_status=pose.get('calibration_status', camera_status))
            result['pose_errors'] = {a: pose[a]-profile[a] if pose['success'] and profile[a] is not None else None for a in ('yaw','pitch','roll')}
            for axis, tolerance in zip(('yaw','pitch','roll'), profile['tolerance']):
                error = result['pose_errors'][axis]
                result[axis+'_valid'] = error is not None and tolerance is not None and abs(error) <= tolerance
            
            # View Detection: Identify which view the photo actually shows
            detection_result = self._detect_facial_view(
                pose['yaw'], pose['pitch'], pose['roll'],
                landmarks_2d=points_2d,
                width=width,
                height=height,
                view=view,
                pose_quality=pose if pose['success'] else None
            )
            
            detected_view = detection_result['detected_view']
            view_confidence = detection_result['confidence']
            view_match = detected_view == view if detected_view is not None else None
            pose_reliable = detection_result.get('pose_reliable', True)
            
            # Debug logging
            print(f"\n[VIEW DETECTION RESULT] Selected: {view}, Detected: {detected_view}, Match: {view_match}, Confidence: {view_confidence}")
            print(f"[VIEW DETECTION RESULT] Reasoning: {detection_result['reasoning']}")
            
            result['detected_view'] = detected_view
            result['view_confidence'] = view_confidence
            result['view_detection_reasoning'] = detection_result['reasoning']
            result['view_match'] = view_match
            result['pose_reliable'] = pose_reliable
            
            # Strict view mismatch rejection
            if view_match is False:
                if view_confidence in ('confident', 'probable'):
                    # Confident mismatch - reject immediately
                    result['state'] = 'VIEW_MISMATCH'
                    result['valid'] = False
                    result['reviewable'] = False
                    opposite_side_msg = ''
                    if 'lateral' in view and 'lateral' in (detected_view or ''):
                        # Specific message for opposite lateral
                        opposite_side_msg = ' This appears to be the opposite side.'
                    return finish('VIEW_MISMATCH',
                                f'Wrong view: photo shows {detected_view}',
                                f'View mismatch: Selected {view} but photo shows {detected_view}.{opposite_side_msg} '
                                f'{detection_result["reasoning"]}')
                elif view_confidence == 'uncertain':
                    # Uncertain mismatch - warn but allow review
                    result['warnings'].append(
                        f'Possible view mismatch (uncertain): Photo may show {detected_view} instead of {view}. '
                        'Clinician review required.'
                    )
            elif view_match is None:
                # Could not detect view reliably - reject for lateral views
                if 'lateral' in view:
                    result['state'] = 'VIEW_UNVERIFIED'
                    result['valid'] = False
                    result['reviewable'] = False
                    return finish('VIEW_UNVERIFIED',
                                'Could not verify profile view',
                                f'Could not reliably verify {view}. {detection_result["reasoning"]} '
                                'Please ensure photo shows clear side profile or try another image.')
                else:
                    # For non-lateral views, warn but continue
                    result['warnings'].append(
                        f'View detection uncertain: {detection_result["reasoning"]}. Clinician review required.'
                    )

            result['warnings'] = ['Engineering thresholds require camera and clinician validation.',
                                  'Confirm head boundaries, expression, lighting consistency and anatomical viewpoint.']
            if result['calibration_status'] != 'calibrated':
                result['warnings'].append('Approximate intrinsics: angles are estimates; no physical distance measurement.')
            # Independent low-level checks remain available for the explicit review path.
            result['reviewable'] = bool(result['quality_ok'] and result['framing_ok'])
            direction_verified = bool(camera and camera.get('directions_verified'))
            evidence = anatomical_evidence(landmarks.get('landmarks_2d'), width, height, view, framing_id)
            result['anatomical_evidence'] = evidence
            result['measurable_checks_pass'] = bool(result['reviewable'] and pose['success'] and
                all(result[a+'_valid'] for a in ('yaw','pitch','roll')) and direction_verified)
            result['alignment_ok'] = bool(pose['success'] and all(result[a+'_valid'] for a in ('yaw','pitch','roll')))
            result['valid'] = bool(eligible and result['measurable_checks_pass'] and evidence['passed'] and
                                   result['calibration_status'] == 'calibrated' and result['gaze_ok'] and result['spatial_alignment_ok'])
            result['experimental_capture_ready'] = bool(experimental and result['reviewable'] and
                result['alignment_ok'] and evidence['passed'] and result['gaze_ok'] and result['spatial_alignment_ok'])
            result['capture_ready'] = result['valid'] or result['experimental_capture_ready']
            result['requires_clinician_confirmation'] = not result['valid']
            
            # Special handling for lateral/profile views with unavailable pose
            # These views require clinician review and shouldn't be rejected for alignment issues
            if 'lateral' in view and not pose['success']:
                # Profile views: pose unavailable is expected due to occlusion
                # Mark as reviewable if basic quality/framing pass
                if result['reviewable']:
                    result['state'] = 'CLINICIAN_REVIEW_REQUIRED'
                    # Provide detailed reasoning about what was verified
                    side_verification = "Side verification: "
                    if view_match is True:
                        side_verification += "✓ Passed (correct side detected)"
                    elif view_match is False:
                        side_verification += "✗ Failed (wrong side detected)"
                    else:
                        side_verification += "? Uncertain (requires clinician confirmation)"
                    
                    return finish('REVIEW_PROFILE', 
                                f'Profile view detected. {side_verification}. '
                                'Clinician must confirm: correct side (left/right), true 90° profile orientation, '
                                'level reference plane, and complete facial contour visibility.')
                else:
                    # Quality or framing issues - provide specific guidance
                    if not landmarks['landmarks_detected']:
                        return finish('NO_LANDMARKS',
                                    'Profile landmarks not detected',
                                    'Could not detect sufficient facial landmarks for profile validation. '
                                    'Ensure the complete side profile is clearly visible with proper lighting.')
                    elif landmarks['landmark_count'] < 250:
                        return finish('INSUFFICIENT_LANDMARKS',
                                    'Profile detection incomplete',
                                    f'Insufficient facial landmarks detected ({landmarks["landmark_count"]}/250 minimum). '
                                    'Ensure the complete side profile is visible with adequate lighting and not cropped.')
                    elif not result['quality_ok']:
                        result['state'] = 'IMAGE_QUALITY_REQUIRED'
                        # Determine specific quality issue
                        if blur['is_blurry']:
                            return finish('BLUR', 'Profile image is blurry. '
                                        'Ensure sharp focus on the facial profile. Use adequate lighting and hold camera steady.')
                        elif not exposure['exposure_ok']:
                            if exposure['underexposed_ratio'] > quality_policy['max_black_fraction']:
                                return finish('UNDEREXPOSED', 'Profile image is too dark. '
                                            'Increase lighting or adjust camera exposure settings.')
                            else:
                                return finish('OVEREXPOSED', 'Profile image is too bright. '
                                            'Reduce lighting or adjust camera exposure settings.')
                        elif dynamic_range < quality_policy['min_dynamic_range']:
                            return finish('LOW_CONTRAST', 'Profile image has insufficient contrast. '
                                        'Improve lighting to create clearer facial contours.')
                        else:
                            return finish('QUALITY', 'Image quality insufficient for profile documentation. '
                                        'Ensure sharp focus, proper lighting, and adequate resolution.')
                    elif not result['framing_ok']:
                        if clipped:
                            return finish('CLIPPED', 'Profile is clipped at image boundary. '
                                        'Move camera farther back or reframe to capture complete head profile including ear, nose, and chin.')
                        elif not scale_ok:
                            return finish('SCALE', 'Profile face size incorrect. '
                                        f'Face height should be {framing["min_height"]:.0%}-{framing["max_height"]:.0%} of frame (currently {measured_height:.0%}).')
                        else:
                            return finish('FRAMING', 'Profile not properly framed. '
                                        'Center the head profile vertically in frame and ensure complete visibility.')
            
            if result['capture_ready']:
                result['state'] = 'CHECKS_PASSED'
                return finish('HOLD', 
                             'Experimental alignment checks passed — hold still' if experimental else 'Correct position — hold still',
                             'Photo meets automated validation requirements. Ready for clinician review.')
            if not result['framing_ok'] or ((eligible or experimental) and not result['spatial_alignment_ok']):
                if clipped:
                    return finish('CLIPPED', 
                                 'Move farther away; include the required anatomy',
                                 'Face is clipped at image boundary. Please upload a photo showing the complete head.')
                if not centered or ((eligible or experimental) and not auto_centered):
                    return finish('CENTER', 
                                 'Move your face toward the highlighted target; follow the arrow',
                                 'Face not centered in frame. Please upload a centered frontal photo.')
                target = reference if reference is not None else (framing['min_height']+framing['max_height'])/2
                return finish('SCALE', 
                             'Patient: move farther away' if measured_height > target else 'Photographer: adjust working distance and lens to fill the guide',
                             'Face size incorrect. Please upload a photo with the face sized properly (30-65% of frame height).')
            if not profile['review'] and not pose['success']:
                return finish('UNRELIABLE_POSE', 
                             'Pose unavailable; improve the view or request clinician review',
                             'Head pose could not be verified automatically. Photo will require clinician review.')
            if pose['success'] and (direction_verified or experimental):
                for axis in ('yaw','pitch','roll'):
                    if not result[axis+'_valid']:
                        error = result['pose_errors'][axis]
                        live_instructions = {'yaw': ('Turn slightly toward your left', 'Turn slightly toward your right'),
                                        'pitch': ('Raise your chin slightly', 'Lower your chin slightly'),
                                        'roll': ('Keep your head level', 'Keep your head level')}
                        upload_instructions = {'yaw': ('Head rotated left. Upload a photo facing directly forward.', 
                                                      'Head rotated right. Upload a photo facing directly forward.'),
                                              'pitch': ('Head tilted up. Upload a photo with neutral head position.', 
                                                       'Head tilted down. Upload a photo with neutral head position.'),
                                              'roll': ('Head tilted sideways. Upload a photo with level head position.', 
                                                      'Head tilted sideways. Upload a photo with level head position.')}
                        if axis == 'yaw' and not direction_verified and not setup.get('side_directions_confirmed'):
                            return finish('YAW', 
                                         'Patient: face the camera directly; reduce sideways rotation',
                                         'Head not facing forward. Upload a frontal photo with face looking directly at camera.')
                        return finish(axis.upper(), 
                                     live_instructions[axis][0 if error > 0 else 1],
                                     upload_instructions[axis][0 if error > 0 else 1])
            if not result['quality_ok']:
                result['state'] = 'IMAGE_QUALITY_REQUIRED'
                return finish('QUALITY', 
                             'Photographer: improve lighting or image resolution' if not exposure['exposure_ok'] or not resolution_ok or dynamic_range < quality_policy['min_dynamic_range'] else 'Patient: hold still; photographer: improve focus',
                             'Image quality insufficient. Please upload a sharp, well-lit, high-resolution photo.' if not exposure['exposure_ok'] or not resolution_ok or dynamic_range < quality_policy['min_dynamic_range'] else 'Image is blurry. Please upload a sharp, focused photo.')
            if (eligible or experimental) and not evidence['passed']:
                return finish('ANATOMY', 'Patient: relax your mouth; photographer: check facial boundaries and selected oblique contour')
            if gaze_required and not result['gaze_ok']:
                return finish('GAZE_UNAVAILABLE' if not result['gaze']['available'] else 'EYES_CLOSED' if not result['gaze']['eyes_open'] else 'LOOK_AT_CAMERA',
                              'Keep both eyes visible and look at the camera lens' if not result['gaze']['available'] else
                              'Open your eyes and look at the camera lens' if not result['gaze']['eyes_open'] else
                              'Look directly at the camera lens, rather than the screen')
            result['state'] = 'CLINICIAN_REVIEW_REQUIRED'
            if view == 'basal':
                return finish('REVIEW_BASAL', 
                             'Clinician: confirm nostrils, columella and nasal base visibility; adjust the lower camera viewpoint',
                             'Basal view: Automatic validation cannot confirm. Clinician must verify nostril visibility and camera angle.')
            if 'lateral' in view:
                return finish('REVIEW_PROFILE', 
                             'Clinician: confirm the selected side, true profile, level reference plane and complete contour',
                             'Profile view: Automatic validation cannot confirm. Clinician must verify correct side and true 90° orientation.')
            return finish('REVIEW', 
                         'Hold still; clinician must confirm expression, framing and selected viewpoint',
                         'Photo requires clinician review to confirm facial view, expression, and positioning.')
        except Exception as error:
            result['state'] = 'ERROR'
            result['errors'] = [str(error)]
            return finish('ERROR', 'Measurement failed; check camera setup and retry')
