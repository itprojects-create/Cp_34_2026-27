"""
View Validator Service

Validates photos against selected facial view requirements.
"""

from config.facial_views import get_view_config, is_valid_view


class ViewValidator:
    """Validates photos against facial view configurations"""
    
    def __init__(self):
        """Initialize validator"""
        pass
    
    def validate_view(self, facial_view, yaw, pitch, roll):
        """
        Validate if angles match the selected facial view
        
        Args:
            facial_view: View identifier (e.g., 'frontal_neutral')
            yaw: Detected yaw angle
            pitch: Detected pitch angle
            roll: Detected roll angle
            
        Returns:
            dict: {
                'valid': bool,
                'view': str,
                'yaw_valid': bool,
                'pitch_valid': bool,
                'roll_valid': bool,
                'yaw_error': float,
                'pitch_error': float,
                'roll_error': float,
                'errors': list of error messages,
                'warnings': list of warning messages
            }
        """
        # Check if view is valid
        if not is_valid_view(facial_view):
            return {
                'valid': False,
                'view': facial_view,
                'errors': [f'Invalid facial view: {facial_view}'],
                'warnings': []
            }
        
        # Get view configuration
        config = get_view_config(facial_view)
        
        # Calculate errors
        yaw_error = abs(yaw - config['target_yaw'])
        pitch_error = abs(pitch - config['target_pitch'])
        roll_error = abs(roll - config['target_roll'])
        
        # Check if within tolerance
        yaw_valid = yaw_error <= config['yaw_tolerance']
        pitch_valid = pitch_error <= config['pitch_tolerance']
        roll_valid = roll_error <= config['roll_tolerance']
        
        valid = yaw_valid and pitch_valid and roll_valid
        
        # Build error and warning messages
        errors = []
        warnings = []
        
        if not yaw_valid:
            direction = 'right' if yaw > config['target_yaw'] else 'left'
            errors.append(
                f"Head rotation incorrect: Turn your head {direction} "
                f"(target: {config['target_yaw']}°, detected: {yaw:.1f}°, "
                f"error: {yaw_error:.1f}°)"
            )
        
        if not pitch_valid:
            direction = 'down' if pitch > config['target_pitch'] else 'up'
            errors.append(
                f"Head tilt incorrect: Tilt your head {direction} "
                f"(target: {config['target_pitch']}°, detected: {pitch:.1f}°, "
                f"error: {pitch_error:.1f}°)"
            )
        
        if not roll_valid:
            direction = 'right' if roll > config['target_roll'] else 'left'
            errors.append(
                f"Head roll incorrect: Roll your head {direction} "
                f"(target: {config['target_roll']}°, detected: {roll:.1f}°, "
                f"error: {roll_error:.1f}°)"
            )
        
        # Add warnings for angles that are close but not perfect
        warning_threshold = 0.7  # Warn if using 70% of tolerance
        
        if yaw_valid and yaw_error > (config['yaw_tolerance'] * warning_threshold):
            warnings.append(
                f"Yaw angle is acceptable but could be more precise "
                f"(error: {yaw_error:.1f}° out of {config['yaw_tolerance']}° tolerance)"
            )
        
        if pitch_valid and pitch_error > (config['pitch_tolerance'] * warning_threshold):
            warnings.append(
                f"Pitch angle is acceptable but could be more precise "
                f"(error: {pitch_error:.1f}° out of {config['pitch_tolerance']}° tolerance)"
            )
        
        if roll_valid and roll_error > (config['roll_tolerance'] * warning_threshold):
            warnings.append(
                f"Roll angle is acceptable but could be more precise "
                f"(error: {roll_error:.1f}° out of {config['roll_tolerance']}° tolerance)"
            )
        
        return {
            'valid': valid,
            'view': facial_view,
            'view_name': config['name'],
            'yaw_valid': yaw_valid,
            'pitch_valid': pitch_valid,
            'roll_valid': roll_valid,
            'yaw_error': yaw_error,
            'pitch_error': pitch_error,
            'roll_error': roll_error,
            'errors': errors,
            'warnings': warnings
        }
    
    def get_guidance_message(self, facial_view, yaw, pitch, roll):
        """
        Get user-friendly guidance message for corrections
        
        Args:
            facial_view: View identifier
            yaw, pitch, roll: Detected angles
            
        Returns:
            str: Guidance message
        """
        if not is_valid_view(facial_view):
            return "Invalid facial view selected"
        
        config = get_view_config(facial_view)
        
        # Calculate errors
        yaw_error = yaw - config['target_yaw']
        pitch_error = pitch - config['target_pitch']
        roll_error = roll - config['target_roll']
        
        # Build guidance
        guidance_parts = []
        
        # Yaw guidance
        if abs(yaw_error) > config['yaw_tolerance']:
            if yaw_error > 0:
                guidance_parts.append("Turn your head LEFT")
            else:
                guidance_parts.append("Turn your head RIGHT")
        
        # Pitch guidance
        if abs(pitch_error) > config['pitch_tolerance']:
            if pitch_error > 0:
                guidance_parts.append("Tilt your head UP")
            else:
                guidance_parts.append("Tilt your head DOWN")
        
        # Roll guidance
        if abs(roll_error) > config['roll_tolerance']:
            if roll_error > 0:
                guidance_parts.append("Roll your head LEFT")
            else:
                guidance_parts.append("Roll your head RIGHT")
        
        if not guidance_parts:
            return "Position looks good!"
        
        return " • ".join(guidance_parts)
